#Requires -Version 5.1
<#
.SYNOPSIS
    Generates the daily certification evidence report (v7c) -- calendar-day-oriented
    visualization with reviewer engagement heatmap and entitlement state summary
    (output: daily-evidence-v7c-*.html).
.DESCRIPTION
    V7c extends V7 with two visualization features:
      - Reviewer Engagement Heatmap: C/P/M/U daily grid per reviewer
      - Entitlement State Summary: honest decision distribution via SP.CampaignSeries

    V7c reads daily-metrics.jsonl (written by V4b) and optionally the rich campaign
    items cache for series-aware analysis. V7c never calls the ISC API.

    PREREQUISITE: Run Invoke-SPDailyEvidenceReportV4b.ps1 at least once (daily while
    campaigns are ACTIVE) to populate daily-metrics.jsonl. V7c reads this file.

    Pipeline:  V4b (export from ISC) --> V7c (visualize from JSONL)

    CRITICAL DIFFERENCE from V6: V7c resolves data to ONE record per calendar day.
    For daily certification campaigns, the JSONL contains one record per campaign
    and multiple campaigns can share the same calendar date. V7c deduplicates to
    exactly one data point per date, preferring ACTIVE over COMPLETED status and
    latest captureTimestamp as tiebreaker.

    Data source: {Metrics.Path}/daily-metrics.jsonl

    Charts rendered (15 sections):
      1  KPI Banner + Executive Summary
      2  Completion Progression Line Chart (one point per calendar day)
      3  Decision Distribution Stacked Bars (Approved/Revoked/Undecided per day)
      4  Per-Reviewer Accountability Table (with direction arrows and first-seen date)
      5  Reviewer Activity Heatmap (delta-based, consecutive calendar day diffs)
      6  Completion Projection vs Deadline (velocity from last 3 calendar days)
      7  Decision Activity Trending Table (one row per day + cumulative)
      8  Decision Activity Trending Stacked Bars (with cumulative line overlay)
      9  Cross-Campaign Risk Matrix (sorted by date descending, data quality badge)
     10  Reviewer Completion Progression (day-by-day bars)
     11  Source-Level Completion Breakdown
     12  Scope Waterfall / Decision Velocity
     13  Reviewer Compliance Accountability
     14  Reviewer Engagement Heatmap (C/P/M/U daily grid)
     15  Entitlement State Summary (honest decision distribution)

    Exit codes:
        0 = Healthy (completion >= 80%)
        1 = Warning (completion 50-79%)
        2 = Parameter error
        4 = Configuration error
        5 = Critical (completion < 50% or insufficient data)
.PARAMETER DaysBack
    Lookback window in days. Default: 7.
.PARAMETER CampaignNameContains
    Campaign name contains this substring (case-insensitive).
.PARAMETER Status
    Filter to only ACTIVE, COMPLETED, or COMPLETING campaigns.
.PARAMETER OutputPath
    Directory for output files. Defaults to daily-evidence subdirectory.
.PARAMETER OutputMode
    Console: formatted summary to terminal.
    HTML: self-contained HTML report file.
    Both (default): console output and HTML file.
.PARAMETER IncludeSuspect
    Include suspect (pre-fix inflated) JSONL records that would otherwise be excluded.
.PARAMETER ShowPrerequisites
    Display the data pipeline prerequisites and exit.
.PARAMETER Help
    Display detailed help.
.EXAMPLE
    .\Invoke-SPDailyEvidenceReportV7c.ps1
    # Render last 7 days from daily-metrics.jsonl.
.EXAMPLE
    .\Invoke-SPDailyEvidenceReportV7c.ps1 -DaysBack 30 -CampaignNameContains 'Q2'
    # 30-day trend for campaigns matching 'Q2'.
.EXAMPLE
    .\Invoke-SPDailyEvidenceReportV7c.ps1 -ShowPrerequisites
    # Show what scripts to run before V7c can generate a report.
.NOTES
    Script:  Invoke-SPDailyEvidenceReportV7c.ps1
    Version: 1.0.0
    Based on: Invoke-SPDailyEvidenceReportV7.ps1 (2,097 lines, 80+ commits)
#>
[CmdletBinding()]
param(
    [Parameter()]
    [int]$DaysBack = 7,

    [Parameter()]
    [string]$StartDate,

    [Parameter()]
    [string]$EndDate,

    [Parameter()]
    [string]$CampaignNameContains,

    [Parameter()]
    [ValidateSet('ACTIVE', 'COMPLETED', 'COMPLETING', '')]
    [string]$Status,

    [Parameter()]
    [string]$OutputPath,

    [Parameter()]
    [ValidateSet('Console', 'HTML', 'Both')]
    [string]$OutputMode = 'Both',

    [Parameter()]
    [switch]$IncludeSuspect,

    [Parameter()]
    [switch]$ShowPrerequisites,

    [Parameter()]
    [Alias('?')]
    [switch]$Help
)

Set-StrictMode -Version 1
$ErrorActionPreference = 'Stop'

if ($Help) {
    Get-Help $MyInvocation.MyCommand.Path -Detailed
    return
}

if ($ShowPrerequisites) {
    Write-Host ''
    Write-Host '  V7c Data Pipeline Prerequisites' -ForegroundColor Cyan
    Write-Host '  ================================' -ForegroundColor Cyan
    Write-Host ''
    Write-Host '  V7c is a read-only visualizer. It reads data produced by V4b.' -ForegroundColor White
    Write-Host ''
    Write-Host '  Minimum pipeline (2 scripts):' -ForegroundColor Yellow
    Write-Host '    1. Invoke-SPDailyEvidenceReportV4b.ps1   (exports from ISC, writes daily-metrics.jsonl)'
    Write-Host '    2. Invoke-SPDailyEvidenceReportV7c.ps1   (reads JSONL, renders HTML report)'
    Write-Host ''
    Write-Host '  V4b must run at least once while campaigns are ACTIVE to capture honest' -ForegroundColor White
    Write-Host '  reviewer metrics. Run daily for multi-day progression charts.' -ForegroundColor White
    Write-Host ''
    Write-Host '  Data file:  {Metrics.Path}/daily-metrics.jsonl' -ForegroundColor DarkGray
    Write-Host '  Default:    ./Audit/metrics/daily-metrics.jsonl' -ForegroundColor DarkGray
    Write-Host ''
    Write-Host '  Optional (for Entitlement State Summary chart):' -ForegroundColor Yellow
    Write-Host '    V4b also writes the rich item cache (items-*.jsonl) that V7c uses'
    Write-Host '    for honest decision classification via SP.CampaignSeries.'
    Write-Host ''
    return
}

#region Module Load

$scriptRoot = $PSScriptRoot
if (-not $scriptRoot) {
    $scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
}
$toolkitRoot = Split-Path -Parent $scriptRoot

$moduleChain = @(
    @{ Path = Join-Path $toolkitRoot 'Modules\SP.Shared\SP.Shared.psd1'; Name = 'SP.Shared'; Required = $true  }
    @{ Path = Join-Path $toolkitRoot 'Modules\SP.Core\SP.Core.psd1';     Name = 'SP.Core';   Required = $true  }
    @{ Path = Join-Path $toolkitRoot 'Modules\SP.Api\SP.Api.psd1';       Name = 'SP.Api';    Required = $false }
    @{ Path = Join-Path $toolkitRoot 'Modules\SP.Audit\SP.Audit.psd1';   Name = 'SP.Audit';  Required = $false }
)

foreach ($mod in $moduleChain) {
    if (Test-Path $mod.Path) {
        Import-Module $mod.Path -Force -ErrorAction Stop -DisableNameChecking
    }
    else {
        $moduleDir = Split-Path -Parent $mod.Path
        $psm1Files = Get-ChildItem -Path $moduleDir -Filter '*.psm1' -ErrorAction SilentlyContinue
        if ($psm1Files) {
            foreach ($psm1 in $psm1Files) {
                Import-Module $psm1.FullName -Force -ErrorAction SilentlyContinue -DisableNameChecking
            }
        }
        elseif ($mod.Required) {
            Write-Host "ERROR: Required module '$($mod.Name)' not found at: $($mod.Path)" -ForegroundColor Red
            exit 4
        }
    }
}

#endregion

#region Helper Functions

function Get-V7Prop {
    param($Object, [string]$Name, $Default = '')
    return (Get-SPObjectProperty -Object $Object -Name $Name -Default $Default)
}

function Get-V7NumericProp {
    param([object]$Obj, [string]$Name, $Default = 0)
    if ($null -eq $Obj) { return $Default }
    try {
        $v = $null
        if ($Obj -is [System.Collections.IDictionary]) {
            if ($Obj.Contains($Name)) { $v = $Obj[$Name] }
        }
        else {
            $p = $Obj.PSObject.Properties[$Name]
            if ($null -ne $p) { $v = $p.Value }
        }
        if ($null -eq $v) { return $Default }
        if ($v -is [System.Array]) { $v = $v[0] }
        return $v
    } catch { }
    return $Default
}

function Build-V7BarChart {
    param([string]$Title, [double[]]$Values, [string[]]$Labels, [string]$Color, [string]$Unit = '',
          [int]$ChartW = 600, [int]$ChartH = 160, [bool]$HighIsGood = $true, [bool[]]$SuspectFlags = $null)
    $leftPad = 45; $topPad = 10; $bottomPad = 40
    $drawH = $ChartH - $topPad - $bottomPad
    $cnt = $Values.Count
    if ($cnt -eq 0) { return '' }
    $barW = [int][math]::Floor(($ChartW - $leftPad - 10) / $cnt * 0.65)
    $gapW = [int][math]::Floor(($ChartW - $leftPad - 10) / $cnt * 0.35)
    $maxVal = [math]::Max(1, ($Values | Measure-Object -Maximum).Maximum)

    $first = $Values[0]; $last = $Values[$cnt - 1]; $delta = [math]::Round($last - $first, 1)
    $dSignLocal = if ($delta -gt 0) { '+' } else { '' }
    if ($HighIsGood) {
        $dColorLocal = if ($delta -gt 0) { '#0a7d2c' } elseif ($delta -lt 0) { '#b00020' } else { '#9a6700' }
    } else {
        $dColorLocal = if ($delta -gt 0) { '#b00020' } elseif ($delta -lt 0) { '#0a7d2c' } else { '#9a6700' }
    }

    $svgH = $ChartH + 10
    $svg = "<div style='margin:8px 0;'>"
    $svg += "<div style='font-size:13px;font-weight:600;color:#1f3a5f;margin-bottom:4px;'>$Title <span style='font-size:12px;color:$dColorLocal;margin-left:8px;'>${dSignLocal}${delta}${Unit} vs first day</span></div>"
    $svg += "<svg width='$ChartW' height='$svgH' style='font-family:Segoe UI,Arial,sans-serif;'>"

    for ($g = 0; $g -le 4; $g++) {
        $gVal = [math]::Round($maxVal * $g / 4, 0)
        $gy = $topPad + $drawH - [int]($drawH * $g / 4)
        $svg += "<line x1='$leftPad' y1='$gy' x2='$ChartW' y2='$gy' stroke='#e3e9f0' stroke-width='1'/>"
        $svg += "<text x='$($leftPad - 4)' y='$($gy + 4)' text-anchor='end' font-size='9' fill='#888'>${gVal}${Unit}</text>"
    }

    for ($i = 0; $i -lt $cnt; $i++) {
        $v = $Values[$i]
        $bH = [int][math]::Max(2, [math]::Round($v / $maxVal * $drawH))
        $bX = $leftPad + $i * ($barW + $gapW) + [int]($gapW / 2)
        $bY = $topPad + $drawH - $bH
        $opacity = [math]::Round(0.4 + (0.6 * $i / [math]::Max(1, $cnt - 1)), 2)
        $isSuspect = $false
        if ($null -ne $SuspectFlags -and $i -lt $SuspectFlags.Count) { $isSuspect = $SuspectFlags[$i] }
        $dashAttr = ''
        if ($isSuspect) { $dashAttr = " stroke='#9a6700' stroke-width='2' stroke-dasharray='4,2'" }
        $svg += "<rect x='$bX' y='$bY' width='$barW' height='$bH' fill='$Color' opacity='$opacity' rx='2'$dashAttr/>"
        $svg += "<text x='$($bX + [int]($barW/2))' y='$($bY - 3)' text-anchor='middle' font-size='10' font-weight='600' fill='$Color'>$([math]::Round($v,0))${Unit}</text>"
        $labelY = $topPad + $drawH + 14
        $svg += "<text x='$($bX + [int]($barW/2))' y='$labelY' text-anchor='middle' font-size='9' fill='#566'>$($Labels[$i])</text>"
    }

    $svg += "</svg></div>"
    return $svg
}

#endregion

#region Setup

$startTime = Get-Date
$correlationID = [guid]::NewGuid().ToString()
$todayLabel = $startTime.ToString('yyyy-MM-dd')

$cfgPath = $null
try {
    $cfgPath = Resolve-SPConfigPath -ToolkitRoot $toolkitRoot
} catch {
    $defaultCfg = Join-Path $toolkitRoot 'settings.json'
    if (Test-Path $defaultCfg) { $cfgPath = $defaultCfg }
}

$config = $null
if ($cfgPath) {
    try {
        $config = Get-SPConfig -ConfigPath $cfgPath
    }
    catch {
        Write-Host "WARN: Failed to load configuration: $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

$effectiveDaysBack = $DaysBack
if ($effectiveDaysBack -le 0) { $effectiveDaysBack = 7 }

Write-Host ''
Write-Host '  SailPoint ISC Governance Toolkit' -ForegroundColor Cyan
Write-Host '  Daily Evidence Report (v7c) -- Calendar-Day Visualization' -ForegroundColor Cyan
Write-Host "  Date:          $todayLabel" -ForegroundColor DarkGray
$periodLabel = if (-not [string]::IsNullOrWhiteSpace($StartDate) -or -not [string]::IsNullOrWhiteSpace($EndDate)) { "$StartDate to $EndDate" } else { "Last $effectiveDaysBack day(s)" }
Write-Host "  Period:        $periodLabel" -ForegroundColor DarkGray
Write-Host "  CorrelationID: $correlationID" -ForegroundColor DarkGray
Write-Host ''

try {
    Initialize-SPLogging -ErrorAction SilentlyContinue
} catch { }

try {
    Write-SPLog -Message "Invoke-SPDailyEvidenceReportV7c started: CorrelationID=$correlationID DaysBack=$effectiveDaysBack" `
        -Severity INFO -Component 'DailyEvidenceV7c' -Action 'Start' -CorrelationID $correlationID
} catch { }

# Resolve output path
$effectiveOutputPath = $OutputPath
if ([string]::IsNullOrWhiteSpace($effectiveOutputPath)) {
    $deOutputPath = $null
    if ($null -ne $config) {
        try {
            if ($null -ne $config.PSObject.Properties['DailyEvidence'] -and
                $null -ne $config.DailyEvidence -and
                $null -ne $config.DailyEvidence.PSObject.Properties['OutputPath'] -and
                -not [string]::IsNullOrWhiteSpace($config.DailyEvidence.OutputPath)) {
                $deOutputPath = [string]$config.DailyEvidence.OutputPath
            }
        } catch { }
    }

    if ($null -ne $deOutputPath) {
        $effectiveOutputPath = $deOutputPath
    }
    elseif ($null -ne $config -and $null -ne $config.PSObject.Properties['Audit'] -and
        $null -ne $config.Audit -and
        $null -ne $config.Audit.PSObject.Properties['OutputPath'] -and
        -not [string]::IsNullOrWhiteSpace($config.Audit.OutputPath)) {
        $effectiveOutputPath = Join-Path ([string]$config.Audit.OutputPath) 'daily-evidence'
    }
    else {
        $effectiveOutputPath = Join-Path $toolkitRoot (Join-Path 'Audit' 'daily-evidence')
    }
}
if (-not [System.IO.Path]::IsPathRooted($effectiveOutputPath)) {
    $effectiveOutputPath = Join-Path $toolkitRoot $effectiveOutputPath
}
if (-not (Test-Path $effectiveOutputPath)) {
    New-Item -ItemType Directory -Path $effectiveOutputPath -Force | Out-Null
}

#endregion

#region Step 1: Load and filter JSONL

Write-Host '  Step 1: Load and filter JSONL' -ForegroundColor Cyan

$metricsDir = $null
if ($null -ne $config) {
    try {
        if ($null -ne $config.PSObject.Properties['Metrics'] -and
            $null -ne $config.Metrics -and
            $null -ne $config.Metrics.PSObject.Properties['Path'] -and
            -not [string]::IsNullOrWhiteSpace($config.Metrics.Path)) {
            $metricsDir = [string]$config.Metrics.Path
        }
    } catch { }
}
if ([string]::IsNullOrWhiteSpace($metricsDir)) {
    $metricsDir = Join-Path $toolkitRoot (Join-Path 'Audit' 'metrics')
}
if (-not [System.IO.Path]::IsPathRooted($metricsDir)) {
    $metricsDir = [System.IO.Path]::GetFullPath((Join-Path $toolkitRoot $metricsDir))
}

$jsonlPath = Join-Path $metricsDir 'daily-metrics.jsonl'
Write-Host "    Metrics file: $jsonlPath" -ForegroundColor DarkGray

if (-not (Test-Path $jsonlPath)) {
    Write-Host '' -ForegroundColor Red
    Write-Host '  ERROR: daily-metrics.jsonl not found.' -ForegroundColor Red
    Write-Host "  Expected at: $jsonlPath" -ForegroundColor Red
    Write-Host '' -ForegroundColor Yellow
    Write-Host '  V7c reads data produced by V4b. Run V4b first:' -ForegroundColor Yellow
    Write-Host '    .\Invoke-SPDailyEvidenceReportV4b.ps1 -CampaignNameContains "<your campaign>"' -ForegroundColor White
    Write-Host '' -ForegroundColor Yellow
    Write-Host '  Run V4b daily while campaigns are ACTIVE for multi-day charts.' -ForegroundColor Yellow
    Write-Host '  Use -ShowPrerequisites for full pipeline details.' -ForegroundColor DarkGray
    Write-Host '' -ForegroundColor Red
    exit 5
}

$utf8 = New-Object System.Text.UTF8Encoding($false)

# Date range: -StartDate/-EndDate take precedence over -DaysBack
$filterStartDate = ''
$filterEndDate = ''
if (-not [string]::IsNullOrWhiteSpace($StartDate)) {
    try { $filterStartDate = ([datetime]::Parse($StartDate)).ToString('yyyy-MM-dd') }
    catch { Write-Host "  ERROR: Invalid -StartDate '$StartDate'. Use yyyy-MM-dd format." -ForegroundColor Red; exit 2 }
}
if (-not [string]::IsNullOrWhiteSpace($EndDate)) {
    try { $filterEndDate = ([datetime]::Parse($EndDate)).ToString('yyyy-MM-dd') }
    catch { Write-Host "  ERROR: Invalid -EndDate '$EndDate'. Use yyyy-MM-dd format." -ForegroundColor Red; exit 2 }
}
# If no explicit range, use DaysBack from today
if ([string]::IsNullOrWhiteSpace($filterStartDate)) {
    $filterStartDate = (Get-Date).AddDays(-$effectiveDaysBack).ToString('yyyy-MM-dd')
}
if ([string]::IsNullOrWhiteSpace($filterEndDate)) {
    $filterEndDate = (Get-Date).ToString('yyyy-MM-dd')
}
Write-Host "    Date range: $filterStartDate to $filterEndDate" -ForegroundColor DarkGray

$allRecords = [System.Collections.Generic.List[object]]::new()
$corruptLines = 0

$rawLines = [System.IO.File]::ReadAllLines($jsonlPath, $utf8)
foreach ($ln in $rawLines) {
    if ([string]::IsNullOrWhiteSpace($ln)) { continue }
    try {
        $rec = $ln | ConvertFrom-Json
        $capDate = [string]$rec.captureDate
        if ([string]::IsNullOrWhiteSpace($capDate)) { continue }

        # Filter by date range
        if ($capDate -lt $filterStartDate) { continue }
        if ($capDate -gt $filterEndDate) { continue }

        # Filter by CampaignNameContains
        if (-not [string]::IsNullOrWhiteSpace($CampaignNameContains)) {
            $campName = [string]$rec.campaign.name
            if ($campName.IndexOf($CampaignNameContains, [System.StringComparison]::OrdinalIgnoreCase) -lt 0) {
                continue
            }
        }

        # Filter by Status
        if (-not [string]::IsNullOrWhiteSpace($Status)) {
            $recStatus = [string]$rec.campaign.status
            if ($recStatus.ToUpperInvariant() -ne $Status.ToUpperInvariant()) {
                continue
            }
        }

        $allRecords.Add($rec)
    } catch { $corruptLines++ }
}

Write-Host "    Loaded $($allRecords.Count) record(s) within ${effectiveDaysBack}-day window" -ForegroundColor DarkGray
if ($corruptLines -gt 0) {
    Write-Host "    WARN: $corruptLines unparseable JSONL line(s) skipped -- records may be missing from this report." -ForegroundColor Yellow
}

if ($allRecords.Count -eq 0) {
    Write-Host '' -ForegroundColor Red
    Write-Host '  ERROR: No matching records found in daily-metrics.jsonl.' -ForegroundColor Red
    Write-Host '' -ForegroundColor Yellow
    Write-Host '  V7c reads data produced by V4b. Possible fixes:' -ForegroundColor Yellow
    Write-Host "    - Increase -DaysBack (current: $effectiveDaysBack)" -ForegroundColor Yellow
    Write-Host '    - Check your -CampaignNameContains filter' -ForegroundColor Yellow
    Write-Host '    - Run V4b to capture fresh data:' -ForegroundColor Yellow
    Write-Host '        .\Invoke-SPDailyEvidenceReportV4b.ps1 -CampaignNameContains "<campaign>"' -ForegroundColor White
    Write-Host '    - Use -ShowPrerequisites for full pipeline details' -ForegroundColor DarkGray
    Write-Host '' -ForegroundColor Red
    exit 5
}

# Data coverage warning: fires whenever the actual data span is narrower than the
# REQUESTED window (explicit -StartDate/-EndDate included) -- the old gate only
# warned past 7 days AND below 50% coverage, so a default run over one day of
# data, or a 30-day request with 16 days, warned about nothing.
$actualDates = @($allRecords | ForEach-Object { [string]$_.captureDate } | Sort-Object -Unique)
if ($actualDates.Count -gt 0) {
    $actualStart = $actualDates[0]
    $actualEnd   = $actualDates[$actualDates.Count - 1]
    $invCul = [System.Globalization.CultureInfo]::InvariantCulture
    $actualSpanDays = ([datetime]::ParseExact($actualEnd, 'yyyy-MM-dd', $invCul) - [datetime]::ParseExact($actualStart, 'yyyy-MM-dd', $invCul)).Days + 1
    $requestedSpanDays = $effectiveDaysBack
    try {
        $requestedSpanDays = ([datetime]::ParseExact($filterEndDate, 'yyyy-MM-dd', $invCul) - [datetime]::ParseExact($filterStartDate, 'yyyy-MM-dd', $invCul)).Days + 1
    } catch { }
    if ($actualSpanDays -lt $requestedSpanDays) {
        Write-Host '' -ForegroundColor Yellow
        Write-Host "    DATA COVERAGE WARNING: Requested window covers $requestedSpanDays day(s) but data only" -ForegroundColor Yellow
        Write-Host "    spans $actualStart to $actualEnd ($actualSpanDays day(s), $($actualDates.Count) data point(s))." -ForegroundColor Yellow
        Write-Host '    Run V4b daily while campaigns are ACTIVE to accumulate more data points.' -ForegroundColor Yellow
        Write-Host ''
    }
}

Write-Host ''

#endregion

#region Step 2: Calendar-day resolution

Write-Host '  Step 2: Calendar-day resolution' -ForegroundColor Cyan

# Step 2a: Detect suspect records (pre-fix inflated data).
# schemaVersion gate: V4b stamps schemaVersion=2 on records whose counts are
# CANONICAL (idNowAutoApproved force-signs are demoted to Pending at write time).
# A v2+ COMPLETED record with pending=0 / ~100% therefore means the reviewers
# GENUINELY finished -- the inflated-data signature is impossible by
# construction, so v2+ records are never flagged suspect. Only legacy
# (unstamped) records can carry pre-canonical inflated counts.
$suspectCount = 0
foreach ($rec in $allRecords) {
    $recIsSuspect = $false
    try {
        $schemaV = [int](Get-V7NumericProp $rec 'schemaVersion' 0)
        if ($schemaV -lt 2) {
            $campStatus = [string]$rec.campaign.status
            $sm = $rec.summary
            $pendingVal = [int](Get-V7NumericProp $sm 'pending' 0)
            $compPct = [double](Get-V7NumericProp $sm 'completionPct' 0)
            if ($campStatus -eq 'COMPLETED' -and $pendingVal -eq 0 -and $compPct -ge 99.5) {
                $recIsSuspect = $true
                $suspectCount++
            }
        }
    } catch { }
    # Tag the record
    $rec | Add-Member -NotePropertyName '_isSuspect' -NotePropertyValue $recIsSuspect -Force
}

# Step 2b: Calendar-day grouping
# Group all records by calendar date (captureDate)
# Resolution: prefer ACTIVE over COMPLETED, then latest captureTimestamp
#
# Suspect handling: a suspect (post-completion inflated) record is dropped only
# when the SAME calendar day also has a non-suspect capture -- the honest record
# wins. A day whose ONLY evidence is suspect keeps its records, flagged
# IsSuspect (rendered dashed in charts), instead of silently vanishing. The
# COMPLETED+pending=0+~100% signature is indistinguishable from a campaign that
# genuinely finished, so unconditionally skipping those records deleted every
# legitimately-completed day from the report -- and when ALL days in the window
# had completed, the run died with 'No calendar days resolved' (exit 5).
$allDateGroups = [ordered]@{}
foreach ($rec in $allRecords) {
    $calDate = [string]$rec.captureDate
    if ([string]::IsNullOrWhiteSpace($calDate)) { continue }
    if (-not $allDateGroups.Contains($calDate)) {
        $allDateGroups[$calDate] = [System.Collections.Generic.List[object]]::new()
    }
    $allDateGroups[$calDate].Add($rec)
}

$dateGroups = [ordered]@{}
$suspectOnlyDays = 0
foreach ($dateKey in $allDateGroups.Keys) {
    $recs = $allDateGroups[$dateKey]
    $kept = $recs
    if (-not $IncludeSuspect) {
        $nonSuspect = [System.Collections.Generic.List[object]]::new()
        foreach ($r in $recs) {
            $isSusp = $false
            try { $isSusp = [bool]$r._isSuspect } catch { }
            if (-not $isSusp) { $nonSuspect.Add($r) }
        }
        if ($nonSuspect.Count -gt 0) { $kept = $nonSuspect }
        else { $suspectOnlyDays++ }   # keep the suspect records; day stays flagged
    }
    if ($kept.Count -gt 0) { $dateGroups[$dateKey] = $kept }
}
if ($suspectOnlyDays -gt 0) {
    Write-Host "    NOTE: $suspectOnlyDays day(s) have only suspect (post-completion) captures -- kept and flagged IsSuspect." -ForegroundColor Yellow
}

# Step 2c: Resolve one record per calendar day
$calendarDays = [ordered]@{}
$statusPriority = @{ 'ACTIVE' = 3; 'COMPLETING' = 2; 'COMPLETED' = 1 }

foreach ($dateKey in $dateGroups.Keys) {
    $recs = $dateGroups[$dateKey]
    $best = $null
    foreach ($r in $recs) {
        if ($null -eq $best) {
            $best = $r
            continue
        }
        # Compare status priority
        $bestStatus = [string]$best.campaign.status
        $rStatus = [string]$r.campaign.status
        $bestPri = 0
        $rPri = 0
        if ($statusPriority.Contains($bestStatus)) { $bestPri = $statusPriority[$bestStatus] }
        if ($statusPriority.Contains($rStatus)) { $rPri = $statusPriority[$rStatus] }

        if ($rPri -gt $bestPri) {
            $best = $r
        }
        elseif ($rPri -eq $bestPri) {
            # Same status -- prefer latest captureTimestamp
            $bestTs = [string]$best.captureTimestamp
            $rTs = [string]$r.captureTimestamp
            if ($rTs -gt $bestTs) {
                $best = $r
            }
        }
    }

    if ($null -ne $best) {
        $ts = [datetime]::Parse($dateKey)
        $sm = $best.summary

        # Map per-reviewer data
        $dayReviewers = @()
        $reviewerArray = $null
        try {
            if ($null -ne $best.PSObject.Properties['reviewers'] -and $null -ne $best.reviewers) {
                $reviewerArray = @($best.reviewers)
            }
        } catch { }

        if ($null -ne $reviewerArray) {
            foreach ($rv in $reviewerArray) {
                if ($null -eq $rv) { continue }
                $rvName = [string](Get-V7Prop $rv 'name' '')
                if ([string]::IsNullOrWhiteSpace($rvName)) { continue }
                $dayReviewers += @{
                    Name       = $rvName
                    Total      = [int](Get-V7NumericProp $rv 'total' 0)
                    Approved   = [int](Get-V7NumericProp $rv 'approved' 0)
                    Revoked    = [int](Get-V7NumericProp $rv 'revoked' 0)
                    Pending    = [int](Get-V7NumericProp $rv 'pending' 0)
                    Completion = [double](Get-V7NumericProp $rv 'completionPct' 0)
                    Signed     = $false
                    Phase      = [string](Get-V7Prop $rv 'phase' '')
                }
                try {
                    $signedVal = Get-V7Prop $rv 'signed' $false
                    if ($signedVal -eq $true -or $signedVal -eq 'True') {
                        $dayReviewers[$dayReviewers.Count - 1].Signed = $true
                    }
                } catch { }
            }
        }

        $totalItems = [int](Get-V7NumericProp $sm 'totalItems' 0)
        $approvedItems = [int](Get-V7NumericProp $sm 'approved' 0)
        $revokedItems = [int](Get-V7NumericProp $sm 'revoked' 0)
        $pendingItems = [int](Get-V7NumericProp $sm 'pending' 0)

        $isSuspectFlag = $false
        try { $isSuspectFlag = [bool]$best._isSuspect } catch { }

        $entry = @{
            Date             = $ts.ToString('yyyy-MM-dd')
            DayLabel         = $ts.ToString('MM/dd')
            Reviewers        = $dayReviewers
            Total            = $totalItems
            Approved         = $approvedItems
            Revoked          = $revokedItems
            Pending          = $pendingItems
            CompletionPct    = [double](Get-V7NumericProp $sm 'completionPct' 0)
            ReviewersTotal   = [int](Get-V7NumericProp $sm 'reviewersTotal' 0)
            ReviewersSigned  = [int](Get-V7NumericProp $sm 'reviewersSigned' 0)
            ReviewersCompleted = 0  # computed below from per-reviewer item data
            PrivTotal        = [int](Get-V7NumericProp $sm 'privilegedTotal' 0)
            PrivApproved     = [int](Get-V7NumericProp $sm 'privilegedApproved' 0)
            PrivRevoked      = [int](Get-V7NumericProp $sm 'privilegedRevoked' 0)
            PrivPending      = [int](Get-V7NumericProp $sm 'privilegedPending' 0)
            ScopeAdded       = 0
            ScopeRemoved     = 0
            NewlyApproved    = 0
            NewlyDecided     = 0
            CampaignName     = [string]$best.campaign.name
            CampaignId       = [string]$best.campaign.id
            CampaignStatus   = [string]$best.campaign.status
            CampaignDeadline = ''
            DiffData         = $null
            IsSuspect        = $isSuspectFlag
            CompletionDelta  = [double]0
            ApprovedDelta    = [int]0
            RevokedDelta     = [int]0
            PendingDelta     = [int]0
        }
        # Populate deadline
        try {
            $dlVal = [string]$best.campaign.deadline
            if (-not [string]::IsNullOrWhiteSpace($dlVal)) {
                $entry.CampaignDeadline = $dlVal
            }
        } catch { }
        # Populate diff data
        try {
            if ($null -ne $best.PSObject.Properties['diff'] -and $null -ne $best.diff) {
                $entry.DiffData = $best.diff
                $entry.ScopeAdded = [int](Get-V7NumericProp $best.diff 'scopeAdded' 0)
                $entry.ScopeRemoved = [int](Get-V7NumericProp $best.diff 'scopeRemoved' 0)
                $entry.NewlyApproved = [int](Get-V7NumericProp $best.diff 'newlyApprovedCount' 0)
                $entry.NewlyDecided = [int](Get-V7NumericProp $best.diff 'newlyDecidedCount' 0)
            }
        } catch { }

        # Carry source data for the source-level completion chart
        try {
            if ($null -ne $best.PSObject.Properties['sources'] -and $null -ne $best.sources) {
                $entry.SourceData = @($best.sources)
            }
        } catch { }

        # Compute honest ReviewersCompleted from per-reviewer item data.
        # A reviewer is "completed" if they have total > 0 and pending = 0.
        # This is immune to ISC's cert-level inflation on force-completion.
        $rvCompletedCount = 0
        foreach ($rv in $dayReviewers) {
            if ([int]$rv.Total -gt 0 -and [int]$rv.Pending -eq 0) { $rvCompletedCount++ }
        }
        $entry.ReviewersCompleted = $rvCompletedCount

        $calendarDays[$dateKey] = $entry
    }
}

# Sort by date ascending and rebuild ordered hashtable
$sortedDateKeys = @($calendarDays.Keys | Sort-Object)
$sortedCalendarDays = [ordered]@{}
foreach ($dk in $sortedDateKeys) {
    $sortedCalendarDays[$dk] = $calendarDays[$dk]
}
$calendarDays = $sortedCalendarDays

# Step 2d: Compute deltas between consecutive calendar days
$dayKeys = @($calendarDays.Keys)
$dayCount = $dayKeys.Count
for ($i = 1; $i -lt $dayCount; $i++) {
    $curr = $calendarDays[$dayKeys[$i]]
    $prev = $calendarDays[$dayKeys[$i - 1]]
    $curr.CompletionDelta = [math]::Round([double]$curr.CompletionPct - [double]$prev.CompletionPct, 1)
    $curr.ApprovedDelta = [int]$curr.Approved - [int]$prev.Approved
    $curr.RevokedDelta = [int]$curr.Revoked - [int]$prev.Revoked
    $curr.PendingDelta = [int]$curr.Pending - [int]$prev.Pending
    # Compute real daily deltas for trending table (instead of static per-campaign JSONL values)
    $dailyDecided = ([int]$curr.Approved + [int]$curr.Revoked) - ([int]$prev.Approved + [int]$prev.Revoked)
    $curr.NewlyDecided = [math]::Max(0, $dailyDecided)
    $dailyScopeChange = [int]$curr.Total - [int]$prev.Total
    $curr.NewlyApproved = [math]::Max(0, $dailyScopeChange)
}
# Day 0 has no prior day -- zero out its delta fields (they contain raw JSONL values, not deltas)
if ($dayCount -gt 0) {
    $day0 = $calendarDays[$dayKeys[0]]
    $day0.NewlyDecided = 0
    $day0.NewlyApproved = 0
    $day0.CompletionDelta = 0
    $day0.ApprovedDelta = 0
    $day0.RevokedDelta = 0
    $day0.PendingDelta = 0
}

$suspectIncluded = 0
foreach ($dk in $dayKeys) {
    if ($calendarDays[$dk].IsSuspect) { $suspectIncluded++ }
}

Write-Host "    $($allRecords.Count) records -> $dayCount calendar day(s), $suspectCount suspect flagged" -ForegroundColor DarkGray

if ($dayCount -eq 0) {
    Write-Host '' -ForegroundColor Red
    Write-Host '  ERROR: No calendar days resolved after deduplication.' -ForegroundColor Red
    Write-Host '  All records may have been filtered as suspect. Try -IncludeSuspect.' -ForegroundColor Red
    Write-Host '' -ForegroundColor Red
    exit 5
}

# Build dailyData array from calendarDays for indexed access
$dailyData = @()
foreach ($dk in $dayKeys) {
    $dailyData += $calendarDays[$dk]
}

# ---------------------------------------------------------------------------
# RECONCILIATION GUARD: what the report will DISPLAY must add up to what the
# JSONL actually CONTAINS for this window. The pre-fix suspect filter silently
# deleted 18 of 22 June days in production (the '399 missing revokes' bug,
# docs/BUG-V7-REVOKED-GAP-20260710.md) and nothing in the output said so.
# Truth basis: all in-window records deduped by captureDate|campaignId keeping
# the latest captureTimestamp (mirrors V4b's own write-dedup). Every truth
# record NOT represented in $dailyData is listed with its counts and a reason,
# and the total delta is printed -- silent loss is now structurally impossible.
# ---------------------------------------------------------------------------
$truthByKey = @{}
foreach ($rec in $allRecords) {
    $tKey = "$([string]$rec.captureDate)|$([string]$rec.campaign.id)"
    if (-not $truthByKey.ContainsKey($tKey) -or
        ([string]$rec.captureTimestamp) -gt ([string]$truthByKey[$tKey].captureTimestamp)) {
        $truthByKey[$tKey] = $rec
    }
}
$truthRevoked = 0; $truthApproved = 0; $truthPending = 0
foreach ($rec in $truthByKey.Values) {
    $truthRevoked  += [int](Get-V7NumericProp $rec.summary 'revoked' 0)
    $truthApproved += [int](Get-V7NumericProp $rec.summary 'approved' 0)
    $truthPending  += [int](Get-V7NumericProp $rec.summary 'pending' 0)
}
$shownKeys = @{}
$shownRevoked = 0; $shownApproved = 0; $shownPending = 0
foreach ($d in $dailyData) {
    $shownKeys["$($d.Date)|$($d.CampaignId)"] = $true
    $shownRevoked  += [int]$d.Revoked
    $shownApproved += [int]$d.Approved
    $shownPending  += [int]$d.Pending
}
if ($shownRevoked -ne $truthRevoked -or $shownApproved -ne $truthApproved -or $shownPending -ne $truthPending) {
    Write-Host "    RECONCILIATION WARNING: displayed day set does not account for all in-window JSONL records." -ForegroundColor Red
    Write-Host "      JSONL truth (deduped): approved=$truthApproved revoked=$truthRevoked pending=$truthPending" -ForegroundColor Red
    Write-Host "      Report will display:   approved=$shownApproved revoked=$shownRevoked pending=$shownPending" -ForegroundColor Red
    Write-Host "      Delta: revoked $($truthRevoked - $shownRevoked), approved $($truthApproved - $shownApproved), pending $($truthPending - $shownPending)" -ForegroundColor Red
    foreach ($tKey in ($truthByKey.Keys | Sort-Object)) {
        if ($shownKeys.ContainsKey($tKey)) { continue }
        $rec = $truthByKey[$tKey]
        $reason = 'not represented after calendar-day resolution'
        $isSusp = $false; try { $isSusp = [bool]$rec._isSuspect } catch { }
        if ($isSusp) { $reason = 'suspect record superseded by an honest same-day capture' }
        elseif ($shownKeys.Keys -match ('^' + [regex]::Escape([string]$rec.captureDate) + '\|')) {
            $reason = 'same-day sibling campaign dropped by one-record-per-day resolution'
        }
        Write-Host ("      EXCLUDED: {0} '{1}' (approved={2} revoked={3} pending={4}) -- {5}" -f `
            [string]$rec.captureDate, [string]$rec.campaign.name, `
            [int](Get-V7NumericProp $rec.summary 'approved' 0), [int](Get-V7NumericProp $rec.summary 'revoked' 0), `
            [int](Get-V7NumericProp $rec.summary 'pending' 0), $reason) -ForegroundColor Yellow
    }
}
else {
    Write-Host "    Reconciliation OK: displayed totals match in-window JSONL (approved=$truthApproved revoked=$truthRevoked pending=$truthPending)" -ForegroundColor DarkGreen
}

# Build reviewer list (distinct across all days, sorted alphabetically)
$reviewerNames = [ordered]@{}
foreach ($d in $dailyData) {
    foreach ($rv in $d.Reviewers) {
        $rn = $rv.Name
        if (-not [string]::IsNullOrWhiteSpace($rn) -and -not $reviewerNames.Contains($rn)) {
            $reviewerNames[$rn] = $true
        }
    }
}

# Build reviewer summary with behavior classification and first-seen tracking
$reviewerList = @()
foreach ($rn in ($reviewerNames.Keys | Sort-Object)) {
    [double]$firstComp = -1; [double]$lastComp = 0; $firstSeenIdx = -1
    [double]$yesterdayComp = 0; $lastSeenIdx = -1; $latestSigned = $false
    [string]$firstSeenDate = 'N/A'
    [string]$lastSeenDate = 'N/A'; [int]$lastPending = 0; [int]$lastTotal = 0
    for ($di = 0; $di -lt $dailyData.Count; $di++) {
        $rvDay = $null
        foreach ($r in $dailyData[$di].Reviewers) {
            if ($r.Name -eq $rn) { $rvDay = $r; break }
        }
        if ($null -ne $rvDay) {
            $compVal = [double]$rvDay.Completion
            if ($firstComp -lt 0) {
                $firstComp = $compVal
                $firstSeenIdx = $di
                $firstSeenDate = $dailyData[$di].DayLabel
            }
            if ($di -eq ($dailyData.Count - 2)) { $yesterdayComp = $compVal }
            $lastComp = $compVal
            $lastSeenIdx = $di
            $lastSeenDate = $dailyData[$di].DayLabel
            $lastPending = [int]$rvDay.Pending
            $lastTotal   = [int]$rvDay.Total
            # Track signed status from latest appearance
            $isSigned = $false
            try { $isSigned = [bool]$rvDay.Signed } catch { }
            if ($isSigned) { $latestSigned = $true }
        }
    }
    if ($firstComp -lt 0) { $firstComp = 0 }
    $daysInScope = if ($firstSeenIdx -ge 0 -and $lastSeenIdx -ge 0) { $lastSeenIdx - $firstSeenIdx + 1 } else { 1 }

    # Absence semantics (daily campaigns): a reviewer NOT present in the newest
    # day's campaign has nothing to attest today -- their items completed, were
    # revoked, or moved. They must never classify as stalled/slow from here on.
    $presentLatest = ($lastSeenIdx -eq ($dailyData.Count - 1))

    [double]$delta = $lastComp - $firstComp
    $rvStyle = 'steady'
    if ($latestSigned -or $lastComp -ge 95) { $rvStyle = 'finishing' }
    elseif (-not $presentLatest) { $rvStyle = 'out-of-scope' }
    elseif ($lastTotal -eq 0) { $rvStyle = 'steady' }   # zero items today: nothing to stall on
    elseif ($lastComp -lt 5 -and $daysInScope -ge 3) { $rvStyle = 'stalled' }
    elseif ($delta -ge 10) { $rvStyle = 'steady' }
    elseif ($delta -lt 5 -and $lastComp -lt 90) { $rvStyle = 'slow' }

    $reviewerList += @{
        Name                = $rn
        StartCompletion     = $firstComp
        YesterdayCompletion = $yesterdayComp
        LastCompletion      = $lastComp
        Style               = $rvStyle
        FirstSeenIdx        = $firstSeenIdx
        FirstSeenDate       = $firstSeenDate
        LastSeenIdx         = $lastSeenIdx
        LastSeenDate        = $lastSeenDate
        LastPending         = $lastPending
        LastTotal           = $lastTotal
        PresentLatest       = $presentLatest
    }
}

Write-Host "    Reviewers: $($reviewerList.Count)" -ForegroundColor DarkGray

# Resolve campaign metadata from latest day
$latestDay = $dailyData[$dayCount - 1]
$campaignNameResolved = $latestDay.CampaignName
$campaignIdResolved = $latestDay.CampaignId
$campaignStatusResolved = $latestDay.CampaignStatus
$campaignDeadlineResolved = $latestDay.CampaignDeadline

# Check if this spans multiple campaigns (common in daily campaigns)
$distinctCampIds = [ordered]@{}
foreach ($d in $dailyData) {
    $cid = $d.CampaignId
    if (-not [string]::IsNullOrWhiteSpace($cid) -and -not $distinctCampIds.Contains($cid)) {
        $distinctCampIds[$cid] = $d.CampaignName
    }
}
if ($distinctCampIds.Count -gt 1) {
    $allNames = @($distinctCampIds.Values)
    $prefix = $allNames[0]
    foreach ($n in $allNames) {
        while ($prefix.Length -gt 0 -and -not $n.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)) {
            $prefix = $prefix.Substring(0, $prefix.Length - 1)
        }
    }
    $prefix = $prefix.TrimEnd(' ', '-', '_')
    if ($prefix.Length -lt 5) { $prefix = $allNames[0] }
    $campaignNameResolved = "$prefix ($($distinctCampIds.Count) campaigns)"
}

Write-Host "    Campaign: $campaignNameResolved" -ForegroundColor DarkGray
Write-Host "    Status: $campaignStatusResolved" -ForegroundColor DarkGray
Write-Host ''

#endregion

#region Insufficient Data Guard

$insufficientData = ($dayCount -lt 2)

if ($insufficientData) {
    Write-Host '  NOTE: Less than 2 calendar days -- single-point report only.' -ForegroundColor Yellow
    Write-Host '        Multi-day charts require at least 2 captures on different days.' -ForegroundColor Yellow
    Write-Host ''
}

#endregion

#region Step 2b: Load series data for Entitlement State Summary (optional)

# Attempt to load campaign series data from the rich cache. This is optional --
# if SP.CampaignSeries is not available or the cache is empty, Chart 15 is skipped.
$seriesDeltaData = $null
$seriesLoadError = ''

$hasCampaignSeries = $false
try {
    $hasCampaignSeries = ($null -ne (Get-Command 'Get-SPCachedCampaignSeries' -ErrorAction SilentlyContinue))
} catch { }

if ($hasCampaignSeries) {
    Write-Host '  Step 2b: Load series data for entitlement state summary' -ForegroundColor Cyan

    $readerArgs = @{ CorrelationID = $correlationID }
    # Use default cache path (Get-SPAuditCacheDir handles config resolution)

    $seriesRes = $null
    try {
        $seriesRes = Get-SPCachedCampaignSeries @readerArgs
    } catch {
        $seriesLoadError = $_.Exception.Message
        Write-Host "    WARN: Series reader failed: $seriesLoadError" -ForegroundColor Yellow
    }

    if ($null -ne $seriesRes -and $seriesRes.Success -and $seriesRes.Data.SeriesCount -gt 0) {
        Write-Host "    Found $($seriesRes.Data.SeriesCount) series ($($seriesRes.Data.InstanceCount) instances)" -ForegroundColor DarkGray

        # Honor the campaign name filter: the series cache is tenant-wide, and a report
        # filtered to one campaign must not show tenant-wide entitlement totals that
        # cannot reconcile with the rest of the page.
        $chartSeries = @($seriesRes.Data.Series)
        if (-not [string]::IsNullOrWhiteSpace($CampaignNameContains)) {
            $chartSeries = @($chartSeries | Where-Object {
                ([string]$_.NormalizedStem).IndexOf($CampaignNameContains, [System.StringComparison]::OrdinalIgnoreCase) -ge 0
            })
            Write-Host "    Campaign filter narrows Chart 15 to $($chartSeries.Count) series" -ForegroundColor DarkGray
        }

        # Aggregate honest decision counts across the (possibly filtered) series
        $honestApproved = 0; $honestRevoked = 0; $honestUndecided = 0; $honestTotal = 0
        $seriesBreakdown = [System.Collections.Generic.List[object]]::new()

        foreach ($series in $chartSeries) {
            # Materialize instances
            $deltaInstances = [System.Collections.Generic.List[object]]::new()
            foreach ($inst in @($series.Instances)) {
                $loadedItems = @()
                $loadedRoster = @()
                try { $loadedItems = @(& $inst.LoadItems) } catch { $loadedItems = @() }
                try { $loadedRoster = @(& $inst.LoadRoster) } catch { $loadedRoster = @() }
                $deltaInstances.Add([pscustomobject]@{
                    OrderIndex   = $inst.OrderIndex
                    CampaignId   = $inst.CampaignId
                    CampaignName = $inst.CampaignName
                    Status       = $inst.Status
                    Unverified   = $inst.Unverified
                    PeriodToken  = $inst.PeriodToken
                    Items        = @($loadedItems)
                    Roster       = @($loadedRoster)
                })
            }

            $dr = $null
            try {
                $dr = Get-SPSeriesAttestationDelta -Instances @($deltaInstances.ToArray()) `
                    -SeriesStem ([string]$series.SeriesStem) -NormalizedStem ([string]$series.NormalizedStem) `
                    -PeriodType ([string]$series.PeriodType) -CorrelationID $correlationID
            } catch {
                Write-Host "    WARN: delta engine failed for '$($series.NormalizedStem)': $($_.Exception.Message)" -ForegroundColor Yellow
                continue
            }
            if ($null -eq $dr -or -not $dr.Success) { continue }

            # Count by CurrentHonestDecision from items
            $sAppr = 0; $sRev = 0; $sUndec = 0
            foreach ($item in @($dr.Data.Items)) {
                $hd = [string]$item.CurrentHonestDecision
                switch ($hd) {
                    'Approved'  { $sAppr++ }
                    'Revoked'   { $sRev++ }
                    default     { $sUndec++ }
                }
            }
            $sTotal = $sAppr + $sRev + $sUndec
            $honestApproved  += $sAppr
            $honestRevoked   += $sRev
            $honestUndecided += $sUndec
            $honestTotal     += $sTotal

            $seriesBreakdown.Add(@{
                SeriesName   = [string]$series.NormalizedStem
                Instances    = $series.InstanceCount
                Approved     = $sAppr
                Revoked      = $sRev
                Undecided    = $sUndec
                Total        = $sTotal
                Unverified   = [bool]$dr.Data.Unverified
            })
        }

        if ($honestTotal -gt 0) {
            $seriesDeltaData = @{
                Approved     = $honestApproved
                Revoked      = $honestRevoked
                Undecided    = $honestUndecided
                Total        = $honestTotal
                Series       = @($seriesBreakdown)
                SeriesCount  = @($seriesBreakdown).Count   # the rendered set, not the tenant-wide cache count
            }
            Write-Host "    Honest decisions: Approved=$honestApproved Revoked=$honestRevoked Undecided=$honestUndecided (Total=$honestTotal)" -ForegroundColor DarkGray
        }
        else {
            Write-Host "    No items found in series cache" -ForegroundColor DarkGray
        }
    }
    elseif ($null -ne $seriesRes -and $seriesRes.Success) {
        Write-Host "    No recurring campaign series found in cache (need >= 2 instances)" -ForegroundColor DarkGray
    }
    Write-Host ''
}

#endregion

#region Step 3: Build HTML Report

Write-Host '  Step 3: Build HTML report' -ForegroundColor Cyan

$colors = Get-SPHtmlColorPalette
$genDate = (Get-Date).ToUniversalTime().ToString('yyyy-MM-dd HH:mm UTC')
$timestamp = (Get-Date).ToUniversalTime().ToString('yyyyMMdd-HHmmss')

# Build safe campaign prefix for filename
$safeCampaignPrefix = $campaignNameResolved -replace '\s*\(\d+ campaigns\)', ''
$safeCampaignPrefix = $safeCampaignPrefix.Trim()
if ($safeCampaignPrefix.Length -gt 40) { $safeCampaignPrefix = $safeCampaignPrefix.Substring(0, 40) }
$safeCampaignPrefix = $safeCampaignPrefix -replace '[^A-Za-z0-9_\-]', '_'
$safeCampaignPrefix = $safeCampaignPrefix -replace '__+', '_'
$safeCampaignPrefix = $safeCampaignPrefix.Trim('_')
if ([string]::IsNullOrWhiteSpace($safeCampaignPrefix)) { $safeCampaignPrefix = 'report' }

$htmlFile = Join-Path $effectiveOutputPath "daily-evidence-v7c-${safeCampaignPrefix}-${timestamp}.html"

$css = @'
body{font-family:Segoe UI,Arial,sans-serif;color:#1c2b3a;margin:24px;background:#fff;max-width:1200px;}
h1{font-size:22px;color:#1f3a5f;border-bottom:2px solid #1f3a5f;padding-bottom:6px;margin-bottom:4px;}
h2{font-size:17px;color:#1f3a5f;margin-top:30px;border-bottom:1px solid #d4dce6;padding-bottom:4px;}
h3{font-size:14px;color:#336699;margin-top:20px;}
.meta{color:#566;font-size:12px;margin-bottom:16px;line-height:1.6;}
table{border-collapse:collapse;width:100%;margin:8px 0 16px 0;font-size:12px;}
th{background:#1f3a5f;color:#fff;text-align:left;padding:6px 8px;font-weight:600;}
td{border-bottom:1px solid #e3e9f0;padding:5px 8px;vertical-align:top;}
tr:nth-child(even) td{background:#f6f9fc;}
.kpi{display:inline-block;min-width:130px;margin:6px 10px 6px 0;padding:10px 14px;border:1px solid #d4dce6;border-radius:6px;background:#f6f9fc;text-align:center;}
.kpi .n{font-size:22px;font-weight:700;color:#1f3a5f;display:block;}
.kpi .l{font-size:11px;color:#566;text-transform:uppercase;letter-spacing:.04em;}
.note{font-size:11px;color:#777;margin-top:4px;}
.section{margin:24px 0;padding:16px 20px;border:1px solid #d4dce6;border-radius:8px;background:#fafbfd;}
.section-title{font-size:15px;color:#1f3a5f;font-weight:700;margin:0 0 12px 0;padding-bottom:6px;border-bottom:1px solid #d4dce6;}
.bar-track{background:#e3e9f0;border-radius:4px;height:18px;width:100%;position:relative;overflow:hidden;}
.bar-fill{height:18px;border-radius:4px;transition:width 0.3s;}
.bar-label{position:absolute;right:4px;top:1px;font-size:10px;font-weight:600;color:#1f3a5f;}
.stacked-bar{display:flex;height:22px;border-radius:4px;overflow:hidden;margin:2px 0;}
.stacked-seg{height:22px;display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:600;color:#fff;}
.up-arrow{display:inline-block;width:0;height:0;border-left:5px solid transparent;border-right:5px solid transparent;border-bottom:8px solid #0a7d2c;margin-right:3px;}
.down-arrow{display:inline-block;width:0;height:0;border-left:5px solid transparent;border-right:5px solid transparent;border-top:8px solid #b00020;margin-right:3px;}
.flat-line{display:inline-block;width:12px;height:3px;background:#9a6700;margin-right:3px;vertical-align:middle;}
.delta-up{color:#0a7d2c;font-weight:600;}
.delta-down{color:#b00020;font-weight:600;}
.delta-flat{color:#9a6700;}
.s-red{color:#b00020;font-weight:600;}
.s-amber{color:#9a6700;font-weight:600;}
.s-green{color:#0a7d2c;font-weight:600;}
.footer{margin-top:24px;padding-top:8px;border-top:1px solid #d4dce6;font-size:11px;color:#777;}
.badge{display:inline-block;padding:2px 8px;border-radius:10px;font-size:9px;font-weight:700;color:#fff;margin-left:6px;vertical-align:middle;}
.badge-red{background:#b00020;}
.badge-amber{background:#9a6700;}
.badge-green{background:#0a7d2c;}
.badge-suspect{background:#9a6700;color:#fff;font-size:9px;padding:2px 6px;border-radius:8px;margin-left:4px;}
.risk-matrix td{padding:6px 8px;font-size:12px;border-bottom:1px solid #e3e9f0;vertical-align:middle;}
.risk-matrix th{padding:6px 8px;font-size:11px;}
.thermometer{display:inline-block;width:100px;height:14px;background:#e3e9f0;border-radius:7px;overflow:hidden;vertical-align:middle;}
.thermometer-fill{height:14px;border-radius:7px;}
.suspect-border{border:2px dashed #9a6700 !important;}
'@

$sb = New-Object System.Text.StringBuilder 32768
[void]$sb.AppendLine("<!DOCTYPE html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>Daily Evidence V7c -- Calendar-Day Visualization</title><style>$css</style></head><body>")

# Header
[void]$sb.AppendLine("<h1>Daily Certification Evidence Report (V7c) -- Calendar-Day Visualization</h1>")
[void]$sb.AppendLine("<p class='meta'>")
[void]$sb.AppendLine("Campaign: <strong>$(ConvertTo-SPHtmlSafe $campaignNameResolved)</strong><br>")
[void]$sb.AppendLine("Status: $(ConvertTo-SPHtmlSafe $campaignStatusResolved)<br>")
if ($dayCount -ge 2) {
    [void]$sb.AppendLine("Period: $dayCount calendar days ($($dailyData[0].Date) to $($dailyData[$dayCount - 1].Date))<br>")
} else {
    [void]$sb.AppendLine("Period: Single day ($($dailyData[0].Date))<br>")
}
if ($suspectIncluded -gt 0) {
    [void]$sb.AppendLine("Data Quality: <span class='badge-suspect'>$suspectIncluded suspect day(s) included</span><br>")
}
[void]$sb.AppendLine("Generated: $genDate</p>")

#endregion

#region Chart 1: KPI Banner + Executive Summary

$todayRec = $dailyData[$dayCount - 1]
$firstRec = $dailyData[0]
$yesterdayRec = if ($dayCount -ge 2) { $dailyData[$dayCount - 2] } else { $todayRec }
$dayOverDayDelta = [math]::Round([double]$todayRec.CompletionPct - [double]$yesterdayRec.CompletionPct, 1)
$windowDelta = [math]::Round([double]$todayRec.CompletionPct - [double]$firstRec.CompletionPct, 1)

# Resolve deadline days
$effectiveDeadlineDays = 5
$isOverdue = $false
if (-not [string]::IsNullOrWhiteSpace($campaignDeadlineResolved)) {
    try {
        $dueDt = [datetime]::Parse([string]$campaignDeadlineResolved, $null, [System.Globalization.DateTimeStyles]::RoundtripKind)
        $daysToDeadline = [int][math]::Floor(($dueDt - (Get-Date)).TotalDays)
        $effectiveDeadlineDays = $daysToDeadline
        if ($daysToDeadline -lt 0) { $isOverdue = $true }
    } catch { }
}

[void]$sb.AppendLine("<div style='margin:16px 0;'>")
[void]$sb.AppendLine("<span class='kpi'><span class='n'>$($todayRec.CompletionPct)%</span><span class='l'>Completion</span></span>")
[void]$sb.AppendLine("<span class='kpi'><span class='n'>$($todayRec.Approved)</span><span class='l'>Approved</span></span>")
[void]$sb.AppendLine("<span class='kpi'><span class='n'>$($todayRec.Revoked)</span><span class='l'>Revoked</span></span>")
[void]$sb.AppendLine("<span class='kpi'><span class='n' style='color:$($colors.Red);'>$($todayRec.Pending)</span><span class='l'>Undecided</span></span>")
[void]$sb.AppendLine("<span class='kpi'><span class='n'>$($todayRec.ReviewersTotal)</span><span class='l'>Reviewers</span></span>")

$privPendingKpi = [int]$todayRec.PrivPending
$privTotalKpi = [int]$todayRec.PrivTotal
$privColor = if ($privPendingKpi -eq 0) { $colors.Green } elseif ($privPendingKpi -le 3) { $colors.Amber } else { $colors.Red }
[void]$sb.AppendLine("<span class='kpi'><span class='n' style='color:$privColor;'>$privPendingKpi / $privTotalKpi</span><span class='l'>Priv. Pending</span></span>")

if ($dayCount -ge 2) {
    $dSign = if ($windowDelta -gt 0) { '+' } else { '' }
    $dColor = if ($windowDelta -gt 5) { $colors.Green } elseif ($windowDelta -lt -2) { $colors.Red } else { $colors.Amber }
    $dLabel = "${dayCount}-Day Change"
    [void]$sb.AppendLine("<span class='kpi'><span class='n' style='color:$dColor;'>${dSign}${windowDelta}%</span><span class='l'>$dLabel</span></span>")
}

# Deadline KPI
if ($isOverdue) {
    $overdueDays = [math]::Abs($effectiveDeadlineDays)
    [void]$sb.AppendLine("<span class='kpi' style='border-color:$($colors.Red);background:#fdecec;'><span class='n' style='color:$($colors.Red);'>OVERDUE</span><span class='l'>by $overdueDays day(s)</span></span>")
    $dlKpiColor = $colors.Red
} else {
    $dlKpiColor = if ($effectiveDeadlineDays -le 3) { $colors.Red } elseif ($effectiveDeadlineDays -le 7) { $colors.Amber } else { $colors.Green }
    [void]$sb.AppendLine("<span class='kpi'><span class='n' style='color:$dlKpiColor;'>$effectiveDeadlineDays</span><span class='l'>Days to Deadline</span></span>")
}
[void]$sb.AppendLine("</div>")

# Executive summary paragraph
$stalledRvCount = 0
foreach ($rv in $reviewerList) { if ($rv.Style -eq 'stalled') { $stalledRvCount++ } }
$privPendCount = [int]$todayRec.PrivPending
$velocityLong = if ($dayCount -ge 2) { [math]::Round(([double]$todayRec.CompletionPct - [double]$firstRec.CompletionPct) / [math]::Max(1, $dayCount - 1), 1) } else { 0 }
$velocityShort = 0
if ($dayCount -ge 3) {
    $shortStart = $dailyData[[math]::Max(0, $dayCount - 3)]
    $velocityShort = [math]::Round(([double]$todayRec.CompletionPct - [double]$shortStart.CompletionPct) / [math]::Min(2, [math]::Max(1, $dayCount - 1)), 1)
}
else { $velocityShort = $velocityLong }
$velocityPerDay = $velocityShort  # projection uses recent velocity

if ($isOverdue) {
    $summaryText = "Campaign is $($todayRec.CompletionPct)% complete and OVERDUE by $([math]::Abs($effectiveDeadlineDays)) day(s)."
} else {
    $projectedCompletion = [math]::Min(100, [double]$todayRec.CompletionPct + ($velocityPerDay * $effectiveDeadlineDays))
    $willComplete = if ($projectedCompletion -ge 99.5) { 'will' } else { 'will NOT' }
    $summaryText = "Campaign is $($todayRec.CompletionPct)% complete with $effectiveDeadlineDays day(s) until deadline."
}
if ($stalledRvCount -gt 0) {
    $summaryText += " $stalledRvCount reviewer(s) have made zero progress (stalled)."
}
if ($privPendCount -gt 0) {
    $summaryText += " $privPendCount privileged access items remain undecided."
}
if ($dayCount -ge 2 -and -not $isOverdue) {
    $summaryText += " Avg velocity: ${velocityLong}%/day (${dayCount}-day) | Recent: ${velocityShort}%/day (3-day). Projection suggests the campaign $willComplete complete on time."
}
elseif ($dayCount -ge 2 -and $isOverdue) {
    $remaining = 100 - [double]$todayRec.CompletionPct
    $daysNeeded = if ($velocityPerDay -gt 0) { [int][math]::Ceiling($remaining / $velocityPerDay) } else { 999 }
    $summaryText += " Avg velocity: ${velocityLong}%/day (${dayCount}-day) | Recent: ${velocityShort}%/day (3-day). Estimated $daysNeeded more day(s) needed."
}
[void]$sb.AppendLine("<p style='font-size:13px;color:#1c2b3a;line-height:1.6;margin:12px 0 16px 0;padding:10px 14px;background:#f6f9fc;border-left:4px solid $dlKpiColor;border-radius:4px;'>$summaryText</p>")

# Insufficient data banner
if ($insufficientData) {
    [void]$sb.AppendLine("<div class='section' style='background:#fff7e6;border-color:#ffd97a;'>")
    [void]$sb.AppendLine("<div class='section-title' style='color:#7a5a00;'>Insufficient Trend Data</div>")
    [void]$sb.AppendLine("<p style='color:#7a5a00;font-size:13px;'>Only $dayCount calendar day(s) available. Multi-day progression charts require at least 2 captures on different days. Below shows today's snapshot data only. Run V4b daily to accumulate the series.</p>")
    [void]$sb.AppendLine("</div>")
}

#endregion

#region Chart 2: Completion Progression Line Chart

if ($dayCount -ge 2) {
    [void]$sb.AppendLine("<div class='section'>")
    [void]$sb.AppendLine("<div class='section-title'>Completion Progression -- Day-by-Day Line Chart</div>")
    [void]$sb.AppendLine("<p class='note'>One point per calendar day. Solid line = actual completion %. Suspect data points shown with dashed circle.</p>")

    $cW = 700; $cH = 220; $cPadL = 50; $cPadR = 20; $cPadT = 20; $cPadB = 40
    $cPlotW = $cW - $cPadL - $cPadR; $cPlotH = $cH - $cPadT - $cPadB

    [void]$sb.AppendLine("<div style='text-align:center;margin:12px 0;'>")
    [void]$sb.AppendLine("<svg width='$cW' height='$cH' style='font-family:Segoe UI,Arial,sans-serif;'>")

    # Grid lines
    for ($p = 0; $p -le 100; $p += 25) {
        $yy = [int]($cPadT + $cPlotH - ($p / 100 * $cPlotH))
        [void]$sb.AppendLine("<line x1='$cPadL' y1='$yy' x2='$($cW - $cPadR)' y2='$yy' stroke='#e3e9f0' stroke-width='1'/>")
        [void]$sb.AppendLine("<text x='$($cPadL - 5)' y='$($yy + 4)' text-anchor='end' font-size='9' fill='#888'>${p}%</text>")
    }

    # 100% target line
    $y100 = [int]($cPadT + $cPlotH - (100 / 100 * $cPlotH))
    [void]$sb.AppendLine("<line x1='$cPadL' y1='$y100' x2='$($cW - $cPadR)' y2='$y100' stroke='$($colors.Green)' stroke-width='1' stroke-dasharray='3,3' opacity='0.4'/>")

    # Build polyline points and area fill
    $linePts = @()
    for ($i = 0; $i -lt $dayCount; $i++) {
        $px = [int]($cPadL + ($i / [math]::Max(1, $dayCount - 1)) * $cPlotW)
        $py = [int]($cPadT + $cPlotH - ([double]$dailyData[$i].CompletionPct / 100 * $cPlotH))
        $linePts += "$px,$py"
    }

    # Area fill under the line
    $areaPath = "M $cPadL $($cPadT + $cPlotH)"
    foreach ($pt in $linePts) { $areaPath += " L $($pt -replace ',',' ')" }
    $lastParts = $linePts[$linePts.Count - 1] -split ','
    $areaPath += " L $($lastParts[0]) $($cPadT + $cPlotH) Z"
    [void]$sb.AppendLine("<path d='$areaPath' fill='#336699' opacity='0.08'/>")

    # Polyline
    [void]$sb.AppendLine("<polyline points='$($linePts -join ' ')' stroke='#336699' stroke-width='2.5' fill='none'/>")

    # Data points
    for ($i = 0; $i -lt $dayCount; $i++) {
        $parts = $linePts[$i] -split ','
        $cx = $parts[0]; $cy = $parts[1]
        $isSusp = $dailyData[$i].IsSuspect
        if ($isSusp) {
            [void]$sb.AppendLine("<circle cx='$cx' cy='$cy' r='5' fill='none' stroke='#9a6700' stroke-width='2' stroke-dasharray='3,2'/>")
            [void]$sb.AppendLine("<circle cx='$cx' cy='$cy' r='2' fill='#9a6700'/>")
        } else {
            [void]$sb.AppendLine("<circle cx='$cx' cy='$cy' r='3.5' fill='#336699'/>")
        }

        # Value label
        [void]$sb.AppendLine("<text x='$cx' y='$([int]$cy - 8)' text-anchor='middle' font-size='9' font-weight='600' fill='#336699'>$([math]::Round([double]$dailyData[$i].CompletionPct, 1))%</text>")
    }

    # X-axis labels
    for ($i = 0; $i -lt $dayCount; $i++) {
        $lx = [int]($cPadL + ($i / [math]::Max(1, $dayCount - 1)) * $cPlotW)
        [void]$sb.AppendLine("<text x='$lx' y='$($cH - 8)' text-anchor='middle' font-size='9' fill='#566'>$($dailyData[$i].DayLabel)</text>")
    }

    [void]$sb.AppendLine("</svg>")
    [void]$sb.AppendLine("</div></div>")
}

#endregion

#region Chart 3: Decision Distribution Stacked Bars

if ($dayCount -ge 2) {
    [void]$sb.AppendLine("<div class='section'>")
    [void]$sb.AppendLine("<div class='section-title'>Decision Distribution -- Day-by-Day Stacked Bars</div>")
    [void]$sb.AppendLine("<p class='note'>Green=Approved, Red=Revoked, Gray=Undecided. Each bar represents one calendar day. Width of each segment shows proportion of total items.</p>")

    [void]$sb.AppendLine("<table><thead><tr><th style='width:80px;'>Day</th><th>Decision Distribution</th><th style='width:70px;text-align:right;'>Completion</th></tr></thead><tbody>")
    foreach ($d in $dailyData) {
        $totalForPct = [math]::Max(1, [int]$d.Total)
        $aPct = [math]::Round([int]$d.Approved / $totalForPct * 100, 0)
        $rPct = [math]::Round([int]$d.Revoked / $totalForPct * 100, 0)
        $pPct = 100 - $aPct - $rPct
        if ($pPct -lt 0) { $pPct = 0 }

        $rowStyle = ''
        if ($d.IsSuspect) { $rowStyle = " class='suspect-border'" }

        [void]$sb.AppendLine("<tr$rowStyle><td style='font-weight:600;'>$($d.DayLabel)</td>")
        [void]$sb.AppendLine("<td><div class='stacked-bar'>")
        if ($aPct -gt 0) {
            $aLabel = if ($aPct -ge 8) { "${aPct}%" } else { '' }
            [void]$sb.AppendLine("<div class='stacked-seg' style='width:${aPct}%;background:$($colors.Green);'>$aLabel</div>")
        }
        if ($rPct -gt 0) {
            $rLabel = if ($rPct -ge 8) { "${rPct}%" } else { '' }
            [void]$sb.AppendLine("<div class='stacked-seg' style='width:${rPct}%;background:$($colors.Red);'>$rLabel</div>")
        }
        if ($pPct -gt 0) {
            $pLabel = if ($pPct -ge 8) { "${pPct}%" } else { '' }
            [void]$sb.AppendLine("<div class='stacked-seg' style='width:${pPct}%;background:#ccc;color:#555;'>$pLabel</div>")
        }
        [void]$sb.AppendLine("</div></td>")
        $suspBadge = ''
        if ($d.IsSuspect) { $suspBadge = " <span class='badge-suspect'>suspect</span>" }
        [void]$sb.AppendLine("<td style='text-align:right;font-weight:600;'>$($d.CompletionPct)%$suspBadge</td></tr>")
    }
    [void]$sb.AppendLine("</tbody></table></div>")
}

#endregion

#region Chart 4: Per-Reviewer Accountability Table

if ($reviewerList.Count -gt 0) {
    [void]$sb.AppendLine("<div class='section'>")
    [void]$sb.AppendLine("<div class='section-title'>Per-Reviewer Accountability -- Numeric Comparison with Direction</div>")
    [void]$sb.AppendLine("<p class='note'>Shows each reviewer's completion across the calendar-day window with direction arrows. First-seen date is the calendar day the reviewer first appeared. Stalled reviewers (in today's campaign with no progress) highlighted in red. '--' = not in that day's campaign (nothing to attest); reviewers who completed and left scope are marked green, never stalled.</p>")

    [void]$sb.AppendLine("<table><thead><tr><th>Reviewer</th><th style='text-align:right;'>First</th><th style='text-align:right;'>Yesterday</th><th style='text-align:right;'>Today</th><th style='text-align:center;'>Direction</th><th style='text-align:right;'>Change</th><th>Status</th><th style='font-size:10px;'>First Seen</th></tr></thead><tbody>")
    $rvIdx = 0
    foreach ($rv in $reviewerList) {
        # Get today's reviewer data
        $todayRvData = $null
        foreach ($r in $dailyData[$dayCount - 1].Reviewers) {
            if ($r.Name -eq $rv.Name) { $todayRvData = $r; break }
        }
        # Get yesterday's reviewer data
        $yestRvData = $null
        if ($dayCount -ge 2) {
            foreach ($r in $dailyData[$dayCount - 2].Reviewers) {
                if ($r.Name -eq $rv.Name) { $yestRvData = $r; break }
            }
        }
        # Get first-seen reviewer data
        $firstRvData = $null
        if ($rv.FirstSeenIdx -ge 0) {
            foreach ($r in $dailyData[$rv.FirstSeenIdx].Reviewers) {
                if ($r.Name -eq $rv.Name) { $firstRvData = $r; break }
            }
        }

        # ABSENCE IS NOT INACTION (daily campaigns): a reviewer missing from a day's
        # campaign had nothing to attest that day. Absent cells render '--' instead of
        # a fabricated 0%, and an absent-from-today reviewer can never be STALLED --
        # previously a reviewer who FINISHED early (and thus left scope) rendered as
        # 'STALLED 0%' with a red row for the rest of the window.
        $presentToday = ($null -ne $todayRvData)
        [double]$todayPct = if ($presentToday) { [double]$todayRvData.Completion } else { [double]$rv.LastCompletion }
        [double]$yestPct  = if ($null -ne $yestRvData) { [double]$yestRvData.Completion } else { 0 }
        [double]$firstPct = if ($null -ne $firstRvData) { [double]$firstRvData.Completion } else { 0 }
        $todayPct = [math]::Max(0, [math]::Min(100, $todayPct))
        $yestPct  = [math]::Max(0, [math]::Min(100, $yestPct))
        $firstPct = [math]::Max(0, [math]::Min(100, $firstPct))
        $todayCell = if ($presentToday) { "${todayPct}%" } else { '--' }
        $yestCell  = if ($null -ne $yestRvData) { "${yestPct}%" } else { '--' }

        [double]$deltaRv = [math]::Round($todayPct - $firstPct, 1)
        if (-not $presentToday) { $deltaRv = 0 }
        $arrow = if ($deltaRv -gt 2) { "<span class='up-arrow'></span>" } elseif ($deltaRv -lt -2) { "<span class='down-arrow'></span>" } else { "<span class='flat-line'></span>" }
        $dClass = if ($deltaRv -gt 2) { 'delta-up' } elseif ($deltaRv -lt -2) { 'delta-down' } else { 'delta-flat' }
        $dSignRv = if ($deltaRv -gt 0) { '+' } else { '' }
        $deltaCell = if ($presentToday) { "${dSignRv}${deltaRv}%" } else { '--' }

        $rvStatusHtml = ''
        $isStalledRow = $false
        if (-not $presentToday) {
            if ($rv.LastCompletion -ge 100 -or $rv.LastPending -eq 0) {
                $rvStatusHtml = "<span style='color:$($colors.Green);'>Completed -- out of scope since $($rv.LastSeenDate)</span>"
            }
            else {
                $rvStatusHtml = "<span style='color:#777;'>Out of scope since $($rv.LastSeenDate) (items moved/revoked)</span>"
            }
        }
        elseif ([int]$todayRvData.Total -eq 0) { $rvStatusHtml = "<span style='color:#777;'>No items today</span>" }
        elseif ($todayPct -ge 100) { $rvStatusHtml = "<span style='color:$($colors.Green);font-weight:600;'>Complete</span>" }
        elseif ($deltaRv -lt 1 -and $todayPct -lt 95) { $rvStatusHtml = "<span style='color:$($colors.Red);font-weight:600;'>STALLED</span>"; $isStalledRow = $true }
        elseif ($deltaRv -lt 5) { $rvStatusHtml = "<span style='color:$($colors.Amber);'>Slow</span>" }
        else { $rvStatusHtml = "<span style='color:$($colors.Green);'>On Track</span>" }

        $firstSeenLabel = $rv.FirstSeenDate
        $scopeStyle = if ($rv.FirstSeenIdx -gt 0) { "color:$($colors.Amber);font-weight:600;" } else { 'color:#888;' }

        $bg = if ($isStalledRow) { " style='background:#fdecec;'" } elseif ($rvIdx % 2 -eq 1) { " style='background:#f6f9fc;'" } else { '' }
        $rvNameSafe = ConvertTo-SPHtmlSafe $rv.Name
        [void]$sb.AppendLine("<tr$bg><td style='font-weight:600;'>$rvNameSafe</td><td style='text-align:right;color:#888;'>${firstPct}%</td><td style='text-align:right;'>$yestCell</td><td style='text-align:right;font-weight:600;'>$todayCell</td><td style='text-align:center;'>$arrow</td><td style='text-align:right;' class='$dClass'>$deltaCell</td><td>$rvStatusHtml</td><td style='font-size:10px;$scopeStyle'>$firstSeenLabel</td></tr>")
        $rvIdx++
    }
    [void]$sb.AppendLine("</tbody></table></div>")
}

#endregion

#region Chart 5: Reviewer Activity Heatmap

if ($dayCount -ge 2 -and $reviewerList.Count -gt 0) {
    [void]$sb.AppendLine("<div class='section'>")
    [void]$sb.AppendLine("<div class='section-title'>Reviewer Activity Heatmap -- ${dayCount}-Day Decision Intensity</div>")
    [void]$sb.AppendLine("<p class='note'>Rows = reviewers, Columns = calendar days. Cell value = decisions made on that day's campaign. Five-level blue scale. Dotted cells = reviewer not in that day's campaign (nothing to attest). A row is highlighted light red only when the reviewer left work undone (had pending items on an in-scope day) and made zero decisions all window.</p>")

    $hCellW = [math]::Min(70, [int](560 / [math]::Max(1, $dayCount)))
    $hCellH = 32; $hLabelW = 120
    $hTotalW = $hLabelW + ($dayCount * $hCellW) + 10
    $hTotalH = 30 + ($reviewerList.Count * $hCellH) + 5
    $heatColors = @('#f0f2f5', '#c6dbef', '#6baed6', '#2171b5', '#084594')

    [void]$sb.AppendLine("<div style='text-align:center;margin:12px 0;overflow-x:auto;'>")
    [void]$sb.AppendLine("<svg width='$hTotalW' height='$hTotalH' style='font-family:Segoe UI,Arial,sans-serif;'>")

    # Column headers (day labels)
    for ($i = 0; $i -lt $dayCount; $i++) {
        $hx = $hLabelW + ($i * $hCellW) + ($hCellW / 2)
        [void]$sb.AppendLine("<text x='$hx' y='16' text-anchor='middle' font-size='9' font-weight='600' fill='#566'>$($dailyData[$i].DayLabel)</text>")
    }

    $hmrvIdx = 0
    foreach ($rv in $reviewerList) {
        $hy = 24 + ($hmrvIdx * $hCellH)
        $rvNameSafe = ConvertTo-SPHtmlSafe $rv.Name
        $totalActivity = 0

        # For daily campaigns: show ABSOLUTE decisions per day (each day is a fresh campaign).
        # The reviewer's decided count on that day's campaign IS their daily work output.
        # ABSENCE IS NOT INACTION: days the reviewer is not in the campaign render as a
        # dotted empty cell ($null in $deltas), not a zero-activity cell.
        $deltas = @()
        $hadUndoneWork = $false   # any in-scope day that ended with pending items
        for ($i = 0; $i -lt $dayCount; $i++) {
            $rvDay = $null
            foreach ($r in $dailyData[$i].Reviewers) {
                if ($r.Name -eq $rv.Name) { $rvDay = $r; break }
            }
            if ($null -eq $rvDay) { $deltas += $null; continue }
            $dayDecided = [int]$rvDay.Approved + [int]$rvDay.Revoked
            if ([int]$rvDay.Total -gt 0 -and [int]$rvDay.Pending -gt 0) { $hadUndoneWork = $true }
            $deltas += $dayDecided
            $totalActivity += $dayDecided
        }

        # 'Inactive' row highlight only for real dereliction: zero decisions all window
        # AND at least one in-scope day left pending. A reviewer whose in-scope days
        # required nothing (or who was mostly out of scope) is not inactive.
        if ($totalActivity -eq 0 -and $hadUndoneWork) {
            [void]$sb.AppendLine("<rect x='0' y='$hy' width='$hTotalW' height='$hCellH' fill='#fdecec' opacity='0.5'/>")
        }

        [void]$sb.AppendLine("<text x='$($hLabelW - 8)' y='$($hy + $hCellH / 2 + 4)' text-anchor='end' font-size='11' font-weight='600' fill='#1c2b3a'>$rvNameSafe</text>")

        $maxDelta = 1
        foreach ($dv in $deltas) { if ($null -ne $dv -and $dv -gt $maxDelta) { $maxDelta = $dv } }
        for ($i = 0; $i -lt $deltas.Count; $i++) {
            $hcx = $hLabelW + ($i * $hCellW)
            $val = $deltas[$i]
            if ($null -eq $val) {
                # Not in this day's campaign: dotted outline, no fill, no number.
                [void]$sb.AppendLine("<rect x='$($hcx + 2)' y='$($hy + 2)' width='$($hCellW - 4)' height='$($hCellH - 4)' rx='3' fill='none' stroke='#c9d3de' stroke-width='1' stroke-dasharray='3,2'/>")
                continue
            }
            $level = [math]::Min(4, [int][math]::Floor($val / $maxDelta * 4.99))
            if ($val -eq 0) { $level = 0 }
            $cellColor = $heatColors[$level]
            [void]$sb.AppendLine("<rect x='$($hcx + 2)' y='$($hy + 2)' width='$($hCellW - 4)' height='$($hCellH - 4)' rx='3' fill='$cellColor' stroke='#e3e9f0' stroke-width='1'/>")
            if ($val -gt 0) {
                $textColor = if ($level -ge 3) { '#fff' } else { '#1c2b3a' }
                [void]$sb.AppendLine("<text x='$($hcx + $hCellW / 2)' y='$($hy + $hCellH / 2 + 4)' text-anchor='middle' font-size='10' font-weight='600' fill='$textColor'>$val</text>")
            }
        }
        $hmrvIdx++
    }

    # Legend
    $legY = $hTotalH - 2
    [void]$sb.AppendLine("<text x='$hLabelW' y='$($legY)' font-size='9' fill='#888'>Intensity:</text>")
    for ($lv = 0; $lv -lt 5; $lv++) {
        $lx = $hLabelW + 55 + ($lv * 22)
        [void]$sb.AppendLine("<rect x='$lx' y='$($legY - 10)' width='18' height='12' rx='2' fill='$($heatColors[$lv])' stroke='#d4dce6' stroke-width='0.5'/>")
    }

    [void]$sb.AppendLine("</svg>")
    [void]$sb.AppendLine("</div></div>")
}

#endregion

#region Chart 6: Completion Projection vs Deadline

if ($dayCount -ge 3) {
    [void]$sb.AppendLine("<div class='section'>")
    [void]$sb.AppendLine("<div class='section-title'>Completion Projection vs Deadline</div>")
    [void]$sb.AppendLine("<p class='note'>Solid line = actual completion %. Dashed = linear projection from last 3 calendar days velocity. Vertical red line = deadline. Green fill if on track, red if shortfall projected.</p>")

    $jW = 700; $jH = 220; $jPadL = 50; $jPadR = 60; $jPadT = 20; $jPadB = 40
    $jPlotW = $jW - $jPadL - $jPadR; $jPlotH = $jH - $jPadT - $jPadB

    $completionVals = @()
    foreach ($d in $dailyData) { $completionVals += [double]$d.CompletionPct }

    # Velocity from last 3 calendar days
    $vel3StartIdx = [math]::Max(0, $dayCount - 3)
    $vel3 = ($completionVals[$dayCount - 1] - $completionVals[$vel3StartIdx]) / [math]::Max(1, ($dayCount - 1) - $vel3StartIdx)
    if ($vel3 -lt 0) { $vel3 = 0 }

    $deadlineDayIdx = $effectiveDeadlineDays
    $projectionDays = if ($effectiveDeadlineDays -ge 0) { [math]::Max(3, $effectiveDeadlineDays + 2) } else { 5 }
    $totalDays = $dayCount + $projectionDays

    [void]$sb.AppendLine("<div style='text-align:center;margin:12px 0;'>")
    [void]$sb.AppendLine("<svg width='$jW' height='$jH' style='font-family:Segoe UI,Arial,sans-serif;'>")

    for ($p = 0; $p -le 100; $p += 25) {
        $yy = [int]($jPadT + $jPlotH - ($p / 100 * $jPlotH))
        [void]$sb.AppendLine("<line x1='$jPadL' y1='$yy' x2='$($jW - $jPadR)' y2='$yy' stroke='#e3e9f0' stroke-width='1'/>")
        [void]$sb.AppendLine("<text x='$($jPadL - 5)' y='$($yy + 4)' text-anchor='end' font-size='9' fill='#888'>${p}%</text>")
    }

    $y100 = [int]($jPadT + $jPlotH - (100 / 100 * $jPlotH))
    [void]$sb.AppendLine("<line x1='$jPadL' y1='$y100' x2='$($jW - $jPadR)' y2='$y100' stroke='$($colors.Green)' stroke-width='1' stroke-dasharray='3,3' opacity='0.5'/>")

    $actPts = @()
    for ($i = 0; $i -lt $dayCount; $i++) {
        $ax = [int]($jPadL + ($i / [math]::Max(1, $totalDays - 1)) * $jPlotW)
        $ay = [int]($jPadT + $jPlotH - ($completionVals[$i] / 100 * $jPlotH))
        $actPts += "$ax,$ay"
    }

    $actFill = "M $jPadL $($jPadT + $jPlotH)"
    foreach ($pt in $actPts) { $actFill += " L $($pt -replace ',',' ')" }
    $lastActParts = $actPts[$actPts.Count - 1] -split ','
    $actFill += " L $($lastActParts[0]) $($jPadT + $jPlotH) Z"
    [void]$sb.AppendLine("<path d='$actFill' fill='#336699' opacity='0.1'/>")
    [void]$sb.AppendLine("<polyline points='$($actPts -join ' ')' stroke='#336699' stroke-width='2.5' fill='none'/>")

    foreach ($pt in $actPts) {
        $parts = $pt -split ','
        [void]$sb.AppendLine("<circle cx='$($parts[0])' cy='$($parts[1])' r='3' fill='#336699'/>")
    }

    $projPts = @($actPts[$actPts.Count - 1])
    $lastPct = $completionVals[$dayCount - 1]
    for ($i = 1; $i -le $projectionDays; $i++) {
        $projPct = [math]::Min(100, $lastPct + ($vel3 * $i))
        $px = [int]($jPadL + (($dayCount - 1 + $i) / [math]::Max(1, $totalDays - 1)) * $jPlotW)
        $py = [int]($jPadT + $jPlotH - ($projPct / 100 * $jPlotH))
        $projPts += "$px,$py"
    }

    $projAtDeadline = [math]::Min(100, $lastPct + ($vel3 * $deadlineDayIdx))
    $hitsTarget = $projAtDeadline -ge 99.5
    $projFillColor = if ($hitsTarget) { $colors.Green } else { $colors.Red }

    $projFill = "M $($lastActParts[0]) $($jPadT + $jPlotH)"
    foreach ($pt in $projPts) { $projFill += " L $($pt -replace ',',' ')" }
    $lastProjParts = $projPts[$projPts.Count - 1] -split ','
    $projFill += " L $($lastProjParts[0]) $($jPadT + $jPlotH) Z"
    [void]$sb.AppendLine("<path d='$projFill' fill='$projFillColor' opacity='0.08'/>")
    [void]$sb.AppendLine("<polyline points='$($projPts -join ' ')' stroke='$projFillColor' stroke-width='2' fill='none' stroke-dasharray='6,4'/>")

    $deadlineX = [int]($jPadL + (($dayCount - 1 + $deadlineDayIdx) / [math]::Max(1, $totalDays - 1)) * $jPlotW)
    [void]$sb.AppendLine("<line x1='$deadlineX' y1='$jPadT' x2='$deadlineX' y2='$($jPadT + $jPlotH)' stroke='$($colors.Red)' stroke-width='2' stroke-dasharray='4,3'/>")
    [void]$sb.AppendLine("<text x='$($deadlineX + 4)' y='$($jPadT + 14)' font-size='9' font-weight='600' fill='$($colors.Red)'>DEADLINE</text>")

    # X-axis labels for actual days
    for ($i = 0; $i -lt $dayCount; $i++) {
        $lx = [int]($jPadL + ($i / [math]::Max(1, $totalDays - 1)) * $jPlotW)
        [void]$sb.AppendLine("<text x='$lx' y='$($jH - 8)' text-anchor='middle' font-size='8' fill='#566'>$($dailyData[$i].DayLabel)</text>")
    }
    for ($i = 1; $i -le $projectionDays; $i++) {
        $lx = [int]($jPadL + (($dayCount - 1 + $i) / [math]::Max(1, $totalDays - 1)) * $jPlotW)
        [void]$sb.AppendLine("<text x='$lx' y='$($jH - 8)' text-anchor='middle' font-size='8' fill='#aaa'>+${i}d</text>")
    }

    $projRounded = [math]::Round($projAtDeadline, 1)
    $calloutText = if ($hitsTarget) { "ON TRACK: projected $($projRounded)% at deadline" } else { "AT RISK: projected only $($projRounded)% at deadline (3-day velocity: $([math]::Round($vel3,1))%/day)" }
    $calloutColor = if ($hitsTarget) { $colors.Green } else { $colors.Red }
    [void]$sb.AppendLine("<text x='$($jW - $jPadR)' y='$($jPadT + 14)' text-anchor='end' font-size='10' font-weight='600' fill='$calloutColor'>$calloutText</text>")

    # Legend
    [void]$sb.AppendLine("<line x1='$($jPadL + 5)' y1='$($jPadT + 5)' x2='$($jPadL + 25)' y2='$($jPadT + 5)' stroke='#336699' stroke-width='2.5'/>")
    [void]$sb.AppendLine("<text x='$($jPadL + 29)' y='$($jPadT + 9)' font-size='9' fill='#1c2b3a'>Actual</text>")
    [void]$sb.AppendLine("<line x1='$($jPadL + 75)' y1='$($jPadT + 5)' x2='$($jPadL + 95)' y2='$($jPadT + 5)' stroke='$projFillColor' stroke-width='2' stroke-dasharray='6,4'/>")
    [void]$sb.AppendLine("<text x='$($jPadL + 99)' y='$($jPadT + 9)' font-size='9' fill='#1c2b3a'>Projection</text>")

    [void]$sb.AppendLine("</svg>")
    [void]$sb.AppendLine("</div></div>")
}

#endregion

#region Chart 7: Decision Activity Trending -- Table

if ($dayCount -ge 2) {
    $hasAnyDiff = $false
    foreach ($d in $dailyData) {
        if ([int]$d.Revoked -gt 0 -or [int]$d.NewlyDecided -gt 0 -or [int]$d.NewlyApproved -gt 0 -or [int]$d.ScopeAdded -gt 0) {
            $hasAnyDiff = $true; break
        }
    }

    if ($hasAnyDiff) {
        [void]$sb.AppendLine("<div class='section'>")
        [void]$sb.AppendLine("<div class='section-title'>Campaign Completion Evidence -- Day-by-Day</div>")
        [void]$sb.AppendLine("<p class='note'>One row per calendar day combining campaign status, item counts, reviewer progress, and day-over-day deltas. Color-coded by completion threshold.</p>")

        [void]$sb.AppendLine("<table><thead><tr>")
        [void]$sb.AppendLine("<th>Day</th><th>Campaign</th><th>Status</th>")
        [void]$sb.AppendLine("<th style='text-align:right;'>Total</th><th style='text-align:right;'>Approved</th><th style='text-align:right;'>Revoked</th><th style='text-align:right;'>Undecided</th>")
        [void]$sb.AppendLine("<th style='text-align:center;'>Items %</th><th style='text-align:center;'>Reviewer %</th>")
        [void]$sb.AppendLine("<th style='text-align:right;'>Decided +/-</th><th style='text-align:right;'>Completion +/-</th>")
        [void]$sb.AppendLine("</tr></thead><tbody>")

        # Total/Approved/Revoked/Pending are SNAPSHOT totals per day. The TOTALS row
        # aggregates the LATEST snapshot per distinct campaign -- summing every day's
        # snapshot multiply-counted items whenever one campaign spanned several days
        # (a 100-item campaign observed 5 days rendered 'TOTALS: 500 items' with a %
        # computed over the inflated denominator).
        $latestByCampaign = [ordered]@{}
        foreach ($d in $dailyData) {
            $dAppr = [int]$d.Approved
            $dRev  = [int]$d.Revoked
            $dPend = [int]$d.Pending
            $dTotal = [int]$d.Total
            $dComp = [double]$d.CompletionPct
            $cumCid = [string]$d.CampaignId
            if ([string]::IsNullOrWhiteSpace($cumCid)) { $cumCid = [string]$d.CampaignName }
            $latestByCampaign[$cumCid] = $d   # dailyData is date-ascending; last write wins

            $campFull = ConvertTo-SPHtmlSafe $d.CampaignName
            $statusLabel = [string]$d.CampaignStatus
            $stColor = if ($statusLabel -eq 'COMPLETED') { "color:$($colors.Green);font-weight:600;" } else { "color:$($colors.Blue);" }

            # Items decided %
            $itemPct = [math]::Round($dComp, 0)
            $itemCls = if ($itemPct -ge 80) { "color:$($colors.Green);font-weight:600;" } elseif ($itemPct -ge 50) { "color:$($colors.Amber);font-weight:600;" } else { "color:$($colors.Red);font-weight:600;" }

            # Reviewer signed %
            $rvTotal = [int]$d.ReviewersTotal
            $rvCompleted = [int]$d.ReviewersCompleted
            $rvPct = if ($rvTotal -gt 0) { [math]::Round($rvCompleted / $rvTotal * 100, 0) } else { 0 }
            $rvLabel = "$rvPct% ($rvCompleted/$rvTotal)"
            $rvCls = if ($rvPct -ge 80) { "color:$($colors.Green);font-weight:600;" } elseif ($rvPct -ge 50) { "color:$($colors.Amber);" } else { "color:$($colors.Red);font-weight:600;" }

            # Day-over-day deltas
            $decidedDelta = [int]$d.NewlyDecided
            $compDelta = [double]$d.CompletionDelta
            $ddSign = if ($decidedDelta -gt 0) { '+' } else { '' }
            $cdSign = if ($compDelta -gt 0) { '+' } else { '' }
            $ddStyle = if ($decidedDelta -gt 0) { "color:$($colors.Green);font-weight:600;" } elseif ($decidedDelta -lt 0) { "color:$($colors.Red);" } else { 'color:#888;' }
            $cdStyle = if ($compDelta -gt 0) { "color:$($colors.Green);font-weight:600;" } elseif ($compDelta -lt 0) { "color:$($colors.Red);" } else { 'color:#888;' }

            $pendStyle = if ($dPend -gt 0) { "color:$($colors.Red);font-weight:600;" } else { '' }
            $suspTag = if ($d.IsSuspect) { " <span class='badge-suspect'>S</span>" } else { '' }

            [void]$sb.AppendLine("<tr>")
            [void]$sb.AppendLine("<td style='font-weight:600;white-space:nowrap;'>$($d.DayLabel)$suspTag</td>")
            [void]$sb.AppendLine("<td style='font-size:11px;'>$campFull</td>")
            [void]$sb.AppendLine("<td style='$stColor'>$statusLabel</td>")
            [void]$sb.AppendLine("<td style='text-align:right;'>$('{0:N0}' -f $dTotal)</td>")
            [void]$sb.AppendLine("<td style='text-align:right;'>$('{0:N0}' -f $dAppr)</td>")
            [void]$sb.AppendLine("<td style='text-align:right;color:$($colors.Red);'>$('{0:N0}' -f $dRev)</td>")
            [void]$sb.AppendLine("<td style='text-align:right;$pendStyle'>$('{0:N0}' -f $dPend)</td>")
            [void]$sb.AppendLine("<td style='text-align:center;$itemCls'>${itemPct}%</td>")
            [void]$sb.AppendLine("<td style='text-align:center;$rvCls'>$rvLabel</td>")
            [void]$sb.AppendLine("<td style='text-align:right;$ddStyle'>${ddSign}${decidedDelta}</td>")
            [void]$sb.AppendLine("<td style='text-align:right;$cdStyle'>${cdSign}${compDelta}%</td>")
            [void]$sb.AppendLine("</tr>")
        }

        # Totals row: latest snapshot per distinct campaign (see above)
        $cumAppr = 0; $cumRev = 0; $cumPend = 0; $cumTotal = 0
        foreach ($cd in $latestByCampaign.Values) {
            $cumAppr  += [int]$cd.Approved
            $cumRev   += [int]$cd.Revoked
            $cumPend  += [int]$cd.Pending
            $cumTotal += [int]$cd.Total
        }
        $cumDecPct = if ($cumTotal -gt 0) { [math]::Round(($cumAppr + $cumRev) / $cumTotal * 100, 0) } else { 0 }
        [void]$sb.AppendLine("<tr style='background:#edf2f7;font-weight:700;border-top:2px solid $($colors.Dark);'>")
        [void]$sb.AppendLine("<td colspan='3'>TOTALS ($dayCount days, $($latestByCampaign.Count) campaign(s))</td>")
        [void]$sb.AppendLine("<td style='text-align:right;'>$('{0:N0}' -f $cumTotal)</td>")
        [void]$sb.AppendLine("<td style='text-align:right;'>$('{0:N0}' -f $cumAppr)</td>")
        [void]$sb.AppendLine("<td style='text-align:right;color:$($colors.Red);'>$('{0:N0}' -f $cumRev)</td>")
        [void]$sb.AppendLine("<td style='text-align:right;color:$($colors.Red);'>$('{0:N0}' -f $cumPend)</td>")
        [void]$sb.AppendLine("<td style='text-align:center;'>${cumDecPct}%</td>")
        [void]$sb.AppendLine("<td colspan='3'></td>")
        [void]$sb.AppendLine("</tr>")

        [void]$sb.AppendLine("</tbody></table></div>")
    }
}

#endregion

#region Chart 8: Decision Activity Trending -- Stacked Bar Chart

if ($dayCount -ge 2) {
    $hasAnyDiff2 = $false
    foreach ($d in $dailyData) {
        if ([int]$d.Revoked -gt 0 -or [int]$d.NewlyDecided -gt 0 -or [int]$d.NewlyApproved -gt 0) {
            $hasAnyDiff2 = $true; break
        }
    }

    if ($hasAnyDiff2) {
        [void]$sb.AppendLine("<div class='section'>")
        [void]$sb.AppendLine("<div class='section-title'>Decision Activity Trending -- Stacked Bar Chart with Cumulative Line</div>")
        [void]$sb.AppendLine("<p class='note'>Each calendar day shows stacked: Revoked (red) + Newly Decided (green) + New Scope (blue). Dashed line = running cumulative total.</p>")

        $chartW = 700; $chartH = 200; $padL = 50; $padR = 20; $padT = 20; $padB = 50
        $plotW = $chartW - $padL - $padR; $plotH = $chartH - $padT - $padB

        # Find max daily total for scaling
        $maxDayTotal = 1
        foreach ($d in $dailyData) {
            $dayTotal = [int]$d.Revoked + [int]$d.NewlyDecided + [int]$d.NewlyApproved
            if ($dayTotal -gt $maxDayTotal) { $maxDayTotal = $dayTotal }
        }

        $barW = [int][math]::Floor($plotW / $dayCount * 0.7)
        $gapW = [int][math]::Floor($plotW / $dayCount * 0.3)

        [void]$sb.AppendLine("<div style='text-align:center;margin:12px 0;'>")
        [void]$sb.AppendLine("<svg width='$chartW' height='$($chartH + 10)' style='font-family:Segoe UI,Arial,sans-serif;'>")

        # Grid lines
        for ($g = 0; $g -le 4; $g++) {
            $gVal = [math]::Round($maxDayTotal * $g / 4, 0)
            $gy = $padT + $plotH - [int]($plotH * $g / 4)
            [void]$sb.AppendLine("<line x1='$padL' y1='$gy' x2='$($chartW - $padR)' y2='$gy' stroke='#e3e9f0' stroke-width='1'/>")
            [void]$sb.AppendLine("<text x='$($padL - 4)' y='$($gy + 4)' text-anchor='end' font-size='9' fill='#888'>$gVal</text>")
        }

        # Cumulative tracking
        $cumTotal = 0
        $cumLinePts = @()

        for ($i = 0; $i -lt $dayCount; $i++) {
            $d = $dailyData[$i]
            $dRev = [int]$d.Revoked
            $dND  = [int]$d.NewlyDecided
            $dNS  = [int]$d.NewlyApproved
            $dayTotal = $dRev + $dND + $dNS
            $cumTotal += $dayTotal

            $bX = $padL + $i * ($barW + $gapW) + [int]($gapW / 2)
            $baseY = $padT + $plotH

            # Stack: Revoked (bottom, red), Newly Decided (middle, green), New Scope (top, blue)
            $rH = if ($maxDayTotal -gt 0) { [int][math]::Max(0, [math]::Round($dRev / $maxDayTotal * $plotH)) } else { 0 }
            $ndH = if ($maxDayTotal -gt 0) { [int][math]::Max(0, [math]::Round($dND / $maxDayTotal * $plotH)) } else { 0 }
            $nsH = if ($maxDayTotal -gt 0) { [int][math]::Max(0, [math]::Round($dNS / $maxDayTotal * $plotH)) } else { 0 }

            $curY = $baseY
            if ($rH -gt 0) {
                $curY -= $rH
                [void]$sb.AppendLine("<rect x='$bX' y='$curY' width='$barW' height='$rH' fill='$($colors.Red)' rx='2' opacity='0.85'/>")
                if ($rH -gt 12) { [void]$sb.AppendLine("<text x='$($bX + [int]($barW/2))' y='$($curY + [int]($rH/2) + 4)' text-anchor='middle' font-size='9' font-weight='600' fill='#fff'>$dRev</text>") }
            }
            if ($ndH -gt 0) {
                $curY -= $ndH
                [void]$sb.AppendLine("<rect x='$bX' y='$curY' width='$barW' height='$ndH' fill='$($colors.Green)' rx='2' opacity='0.85'/>")
                if ($ndH -gt 12) { [void]$sb.AppendLine("<text x='$($bX + [int]($barW/2))' y='$($curY + [int]($ndH/2) + 4)' text-anchor='middle' font-size='9' font-weight='600' fill='#fff'>$dND</text>") }
            }
            if ($nsH -gt 0) {
                $curY -= $nsH
                [void]$sb.AppendLine("<rect x='$bX' y='$curY' width='$barW' height='$nsH' fill='$($colors.Blue)' rx='2' opacity='0.85'/>")
                if ($nsH -gt 12) { [void]$sb.AppendLine("<text x='$($bX + [int]($barW/2))' y='$($curY + [int]($nsH/2) + 4)' text-anchor='middle' font-size='9' font-weight='600' fill='#fff'>$dNS</text>") }
            }

            # Day total label above bar
            if ($dayTotal -gt 0) {
                $topY = $baseY - $rH - $ndH - $nsH
                [void]$sb.AppendLine("<text x='$($bX + [int]($barW/2))' y='$($topY - 3)' text-anchor='middle' font-size='9' font-weight='600' fill='#1c2b3a'>$dayTotal</text>")
            }

            # Day label
            $labelY = $padT + $plotH + 16
            [void]$sb.AppendLine("<text x='$($bX + [int]($barW/2))' y='$labelY' text-anchor='middle' font-size='9' fill='#566'>$($d.DayLabel)</text>")

            # Cumulative line point
            $cumLinePts += "$($bX + [int]($barW/2)),$($padT + $plotH - 3)"
        }

        # Cumulative line (scaled to secondary axis)
        if ($cumTotal -gt 0 -and $cumLinePts.Count -ge 2) {
            $cumRunning = 0; $scaledPts = @()
            for ($i = 0; $i -lt $dayCount; $i++) {
                $d = $dailyData[$i]
                $cumRunning += [int]$d.Revoked + [int]$d.NewlyDecided + [int]$d.NewlyApproved
                $cx = $padL + $i * ($barW + $gapW) + [int]($gapW / 2) + [int]($barW / 2)
                $cy = [int]($padT + $plotH - ($cumRunning / [math]::Max(1, $cumTotal) * $plotH))
                $scaledPts += "$cx,$cy"
            }

            [void]$sb.AppendLine("<polyline points='$($scaledPts -join ' ')' stroke='#1f3a5f' stroke-width='2' fill='none' stroke-dasharray='4,3'/>")
            foreach ($pt in $scaledPts) {
                $parts = $pt -split ','
                [void]$sb.AppendLine("<circle cx='$($parts[0])' cy='$($parts[1])' r='3' fill='#1f3a5f'/>")
            }
            # Label last point
            $lastParts = $scaledPts[$scaledPts.Count - 1] -split ','
            [void]$sb.AppendLine("<text x='$([int]$lastParts[0] + 8)' y='$([int]$lastParts[1] + 4)' font-size='10' font-weight='700' fill='#1f3a5f'>$cumTotal total</text>")
        }

        # Legend
        $legY = $chartH
        [void]$sb.AppendLine("<rect x='$($padL + 5)' y='$legY' width='10' height='10' fill='$($colors.Red)' rx='1'/>")
        [void]$sb.AppendLine("<text x='$($padL + 19)' y='$($legY + 9)' font-size='10' fill='#1c2b3a'>Revoked</text>")
        [void]$sb.AppendLine("<rect x='$($padL + 85)' y='$legY' width='10' height='10' fill='$($colors.Green)' rx='1'/>")
        [void]$sb.AppendLine("<text x='$($padL + 99)' y='$($legY + 9)' font-size='10' fill='#1c2b3a'>Newly Decided</text>")
        [void]$sb.AppendLine("<rect x='$($padL + 200)' y='$legY' width='10' height='10' fill='$($colors.Blue)' rx='1'/>")
        [void]$sb.AppendLine("<text x='$($padL + 214)' y='$($legY + 9)' font-size='10' fill='#1c2b3a'>New Scope</text>")
        [void]$sb.AppendLine("<line x1='$($padL + 290)' y1='$($legY + 5)' x2='$($padL + 310)' y2='$($legY + 5)' stroke='#1f3a5f' stroke-width='2' stroke-dasharray='4,3'/>")
        [void]$sb.AppendLine("<text x='$($padL + 314)' y='$($legY + 9)' font-size='10' fill='#1c2b3a'>Cumulative</text>")

        [void]$sb.AppendLine("</svg>")
        [void]$sb.AppendLine("</div></div>")
    }
}

#endregion

#region Chart 9: Cross-Campaign Risk Matrix

# Only render the risk matrix if campaigns are genuinely different (mixed types/scopes).
# For daily recurring campaigns with the same scope and reviewers, the matrix produces
# identical scores and adds no value -- the Campaign Completion Evidence table is better.
$uniqueTotals = @{}; $uniqueReviewerCounts = @{}
foreach ($d in $dailyData) {
    $uniqueTotals[[string]$d.Total] = $true
    $uniqueReviewerCounts[[string]$d.ReviewersTotal] = $true
}
$isMixedCampaigns = ($uniqueTotals.Count -gt 1 -or $uniqueReviewerCounts.Count -gt 1)

if ($dayCount -ge 1 -and $isMixedCampaigns) {
    $campaigns = @()
    foreach ($d in $dailyData) {
        # Count stalled reviewers: must actually HAVE items in this campaign.
        # Zero-item reviewers (nothing to attest -- e.g. their items were revoked
        # in an earlier campaign) carry Completion=0 and were previously counted
        # stalled on every single day.
        $stalledCountCamp = 0
        foreach ($r in $d.Reviewers) {
            if ([int]$r.Total -gt 0 -and [double]$r.Completion -lt 5) { $stalledCountCamp++ }
        }

        # Compute deadline days
        $dlDays = 999
        if (-not [string]::IsNullOrWhiteSpace($d.CampaignDeadline)) {
            try {
                $dueDtCamp = [datetime]::Parse([string]$d.CampaignDeadline, $null, [System.Globalization.DateTimeStyles]::RoundtripKind)
                $dlDays = [int][math]::Floor(($dueDtCamp - (Get-Date)).TotalDays)
                if ($dlDays -lt 0) { $dlDays = 0 }
            } catch { }
        }

        $campaigns += @{
            Name             = $d.CampaignName
            ShortName        = ''
            Date             = $d.Date
            DayLabel         = $d.DayLabel
            Completion       = [double]$d.CompletionPct
            Deadline         = $dlDays
            Pending          = [int]$d.Pending
            PrivPending      = [int]$d.PrivPending
            StalledReviewers = $stalledCountCamp
            TotalReviewers   = [int]$d.ReviewersTotal
            Approved         = [int]$d.Approved
            Revoked          = [int]$d.Revoked
            Total            = [int]$d.Total
            IsSuspect        = [bool]$d.IsSuspect
            RiskScore        = 0
        }
        # Short name for display
        $sn = $d.CampaignName
        if ($sn.Length -gt 40) { $sn = $sn.Substring(0, 37) + '...' }
        $campaigns[$campaigns.Count - 1].ShortName = $sn
    }

    # Sort by date descending (newest first)
    $campaigns = @($campaigns | Sort-Object { $_.Date } -Descending)

    # Compute risk scores
    foreach ($c in $campaigns) {
        $timeRisk = if ($c.Deadline -le 2) { 40 } elseif ($c.Deadline -le 5) { 25 } else { 10 }
        $completionRisk = [math]::Max(0, [int]((100 - $c.Completion) * 0.4))
        $privRisk = [math]::Min(25, [int]($c.PrivPending * 1.5))
        $stalledRisk = [math]::Min(30, [int]($c.StalledReviewers / [math]::Max(1, $c.TotalReviewers) * 40))
        $c.RiskScore = [math]::Min(100, $timeRisk + $completionRisk + $privRisk + $stalledRisk)
    }

    [void]$sb.AppendLine("<div class='section'>")
    [void]$sb.AppendLine("<div class='section-title'>Cross-Campaign Risk Matrix</div>")
    [void]$sb.AppendLine("<p class='note'>One row per calendar day, sorted by date descending. Risk = f(deadline proximity, completion gap, privileged pending, stalled reviewers). Suspect data marked with amber badge.</p>")

    [void]$sb.AppendLine("<table class='risk-matrix'><thead><tr>")
    [void]$sb.AppendLine("<th>Date</th><th>Campaign</th><th style='text-align:center;'>Completion</th><th style='text-align:center;'>Progress</th><th style='text-align:center;'>Deadline</th><th style='text-align:center;'>Priv. Pending</th><th style='text-align:center;'>Stalled</th><th style='text-align:center;'>Risk Score</th>")
    [void]$sb.AppendLine("</tr></thead><tbody>")

    foreach ($c in $campaigns) {
        $cName = ConvertTo-SPHtmlSafe $c.Name

        # Data quality badge
        $qualBadge = ''
        if ($c.IsSuspect) { $qualBadge = " <span class='badge-suspect'>suspect</span>" }

        # Donut SVG
        $donutR = 14; $donutCx = 20; $donutCy = 20; $donutStroke = 6
        $circumference = [math]::Round(2 * [math]::PI * $donutR, 1)
        $dashLen = [math]::Round($circumference * $c.Completion / 100, 1)
        $gapLen = [math]::Round($circumference - $dashLen, 1)
        $donutColor = if ($c.Completion -ge 80) { $colors.Green } elseif ($c.Completion -ge 50) { $colors.Amber } else { $colors.Red }
        $donutSvg = "<svg width='40' height='40' style='vertical-align:middle;'>"
        $donutSvg += "<circle cx='$donutCx' cy='$donutCy' r='$donutR' fill='none' stroke='#e3e9f0' stroke-width='$donutStroke'/>"
        $donutSvg += "<circle cx='$donutCx' cy='$donutCy' r='$donutR' fill='none' stroke='$donutColor' stroke-width='$donutStroke' stroke-dasharray='$dashLen $gapLen' stroke-dashoffset='$([math]::Round($circumference * 0.25, 1))' stroke-linecap='round'/>"
        $donutSvg += "<text x='$donutCx' y='$($donutCy + 4)' text-anchor='middle' font-size='8' font-weight='700' fill='#1c2b3a'>$([math]::Round($c.Completion,0))%</text>"
        $donutSvg += "</svg>"

        # Thermometer bar
        $thermColor = if ($c.Completion -ge 80) { $colors.Green } elseif ($c.Completion -ge 50) { $colors.Amber } else { $colors.Red }
        $thermBar = "<span class='thermometer'><span class='thermometer-fill' style='width:$($c.Completion)%;background:$thermColor;display:inline-block;'></span></span>"

        # Deadline indicator
        $dlColor = if ($c.Deadline -le 2) { $colors.Red } elseif ($c.Deadline -le 5) { $colors.Amber } else { $colors.Green }
        $dlLabel = if ($c.Deadline -ge 999) { 'N/A' } else { "$($c.Deadline)d" }
        $dlSvg = "<svg width='16' height='16' style='vertical-align:middle;'><circle cx='8' cy='8' r='6' fill='$dlColor'/></svg>"
        $dlText = "$dlSvg <span style='font-weight:600;'>$dlLabel</span>"

        # Risk bar
        $riskColor = if ($c.RiskScore -ge 60) { $colors.Red } elseif ($c.RiskScore -ge 35) { $colors.Amber } else { $colors.Green }
        $riskW = $c.RiskScore
        $riskBar = "<div style='display:inline-block;width:100px;height:14px;background:#e3e9f0;border-radius:7px;overflow:hidden;vertical-align:middle;'>"
        $riskBar += "<div style='width:${riskW}%;height:14px;background:$riskColor;border-radius:7px;display:inline-block;'></div></div>"
        $riskBar += " <span style='font-size:11px;font-weight:600;color:$riskColor;'>$($c.RiskScore)</span>"

        $privColor = if ($c.PrivPending -gt 10) { $colors.Red } elseif ($c.PrivPending -gt 5) { $colors.Amber } else { '#1c2b3a' }
        $stalledColor = if ($c.StalledReviewers -gt 0) { $colors.Red } else { $colors.Green }

        $rowStyle = ''
        if ($c.IsSuspect) { $rowStyle = " style='border-left:3px dashed #9a6700;'" }

        [void]$sb.AppendLine("<tr$rowStyle>")
        [void]$sb.AppendLine("<td style='font-weight:600;white-space:nowrap;'>$($c.DayLabel)</td>")
        [void]$sb.AppendLine("<td style='font-size:11px;'>$cName$qualBadge</td>")
        [void]$sb.AppendLine("<td style='text-align:center;'>$donutSvg</td>")
        [void]$sb.AppendLine("<td style='text-align:center;'>$thermBar</td>")
        [void]$sb.AppendLine("<td style='text-align:center;'>$dlText</td>")
        [void]$sb.AppendLine("<td style='text-align:center;font-weight:600;color:$privColor;'>$($c.PrivPending)</td>")
        [void]$sb.AppendLine("<td style='text-align:center;font-weight:600;color:$stalledColor;'>$($c.StalledReviewers) / $($c.TotalReviewers)</td>")
        [void]$sb.AppendLine("<td style='text-align:center;'>$riskBar</td>")
        [void]$sb.AppendLine("</tr>")
    }

    [void]$sb.AppendLine("</tbody></table></div>")
}

#endregion

#region Chart 10: Reviewer Completion Progression (day-by-day bars)

if ($dayCount -ge 2) {
    [void]$sb.AppendLine("<div class='section'>")
    [void]$sb.AppendLine("<div class='section-title'>Reviewer Completion Progression -- Day-by-Day</div>")
    [void]$sb.AppendLine("<p class='note'>Blue bars = % of items decided per day. Green bars = % of reviewers who signed off. Shows the gap between item completion and reviewer sign-off over time.</p>")

    $rcW = 700; $rcH = 220; $rcPadL = 50; $rcPadB = 45; $rcPadT = 15
    $rcPlotH = $rcH - $rcPadT - $rcPadB
    $rcGroupW = [int][math]::Floor(($rcW - $rcPadL - 10) / $dayCount)
    $rcBarW = [int][math]::Floor($rcGroupW * 0.38)
    $rcGap = [int][math]::Floor($rcGroupW * 0.08)

    [void]$sb.AppendLine("<div style='text-align:center;margin:12px 0;'>")
    [void]$sb.AppendLine("<svg width='$rcW' height='$($rcH + 10)' style='font-family:Segoe UI,Arial,sans-serif;'>")

    for ($g = 0; $g -le 4; $g++) {
        $gVal = $g * 25
        $gy = $rcPadT + $rcPlotH - [int]($rcPlotH * $g / 4)
        [void]$sb.AppendLine("<line x1='$rcPadL' y1='$gy' x2='$rcW' y2='$gy' stroke='#e3e9f0' stroke-width='1'/>")
        [void]$sb.AppendLine("<text x='$($rcPadL - 4)' y='$($gy + 4)' text-anchor='end' font-size='9' fill='#888'>${gVal}%</text>")
    }

    for ($i = 0; $i -lt $dayCount; $i++) {
        $d = $dailyData[$i]
        $xBase = $rcPadL + ($i * $rcGroupW) + $rcGap
        $opacity = [math]::Round(0.4 + (0.6 * $i / [math]::Max(1, $dayCount - 1)), 2)

        # Items decided %
        $itemPct = [math]::Max(0, [math]::Min(100, [double]$d.CompletionPct))
        $itemH = [int][math]::Max(2, [math]::Round($itemPct / 100 * $rcPlotH))
        $itemY = $rcPadT + $rcPlotH - $itemH
        [void]$sb.AppendLine("<rect x='$xBase' y='$itemY' width='$rcBarW' height='$itemH' fill='#336699' opacity='$opacity' rx='2'/>")
        if ($itemH -gt 14) { [void]$sb.AppendLine("<text x='$($xBase + [int]($rcBarW/2))' y='$($itemY - 3)' text-anchor='middle' font-size='9' font-weight='600' fill='#336699'>$([math]::Round($itemPct,0))%</text>") }

        # Reviewer completed % (from item-level data, not ISC cert sign-off)
        $rvTotal = [int]$d.ReviewersTotal
        $rvCompleted = [int]$d.ReviewersCompleted
        $rvPct = if ($rvTotal -gt 0) { [math]::Round($rvCompleted / $rvTotal * 100, 0) } else { 0 }
        $rvH = [int][math]::Max(2, [math]::Round($rvPct / 100 * $rcPlotH))
        $rvY = $rcPadT + $rcPlotH - $rvH
        $rvX = $xBase + $rcBarW + $rcGap
        [void]$sb.AppendLine("<rect x='$rvX' y='$rvY' width='$rcBarW' height='$rvH' fill='$($colors.Green)' opacity='$opacity' rx='2'/>")
        if ($rvH -gt 14) { [void]$sb.AppendLine("<text x='$($rvX + [int]($rcBarW/2))' y='$($rvY - 3)' text-anchor='middle' font-size='9' font-weight='600' fill='$($colors.Green)'>$rvPct%</text>") }

        # Day label
        [void]$sb.AppendLine("<text x='$($xBase + $rcBarW + [int]($rcGap/2))' y='$($rcPadT + $rcPlotH + 15)' text-anchor='middle' font-size='9' fill='#566'>$($d.DayLabel)</text>")
    }

    # Legend
    $legY = $rcH
    [void]$sb.AppendLine("<rect x='$($rcPadL + 20)' y='$legY' width='12' height='12' fill='#336699' rx='2'/>")
    [void]$sb.AppendLine("<text x='$($rcPadL + 37)' y='$($legY + 10)' font-size='10' fill='#1c2b3a'>Items Decided %</text>")
    [void]$sb.AppendLine("<rect x='$($rcPadL + 170)' y='$legY' width='12' height='12' fill='$($colors.Green)' rx='2'/>")
    [void]$sb.AppendLine("<text x='$($rcPadL + 187)' y='$($legY + 10)' font-size='10' fill='#1c2b3a'>Reviewers Completed %</text>")

    [void]$sb.AppendLine("</svg></div></div>")
}

#endregion

#region Chart 11: Source-Level Completion Breakdown

# Build source data from the latest calendar day's raw JSONL record
$latestRec = $null
$latestDayKey = @($calendarDays.Keys)[$dayCount - 1]
if ($null -ne $latestDayKey) { $latestRec = $calendarDays[$latestDayKey] }
# The source data is stored on the raw JSONL record, accessible via the calendar day's SourceData
if ($null -ne $latestRec -and $null -ne $latestRec.SourceData) {
    $sourceData = @($latestRec.SourceData)
    if ($sourceData.Count -gt 0) {
        [void]$sb.AppendLine("<div class='section'>")
        [void]$sb.AppendLine("<div class='section-title'>Source-Level Completion Breakdown</div>")
        [void]$sb.AppendLine("<p class='note'>Shows completion rate per source (application). Items reviewed = approved + revoked. Undecided items highlighted per source.</p>")

        [void]$sb.AppendLine("<table><thead><tr><th>Source</th><th style='text-align:right;'>Total</th><th style='text-align:right;'>Approved</th><th style='text-align:right;'>Revoked</th><th style='text-align:right;'>Undecided</th><th style='text-align:center;'>Completion</th><th>Progress</th></tr></thead><tbody>")
        foreach ($src in $sourceData) {
            $sName = ConvertTo-SPHtmlSafe ([string](Get-V7Prop $src 'name' 'Unknown'))
            $sTotal = [int](Get-V7NumericProp $src 'total' 0)
            $sAppr = [int](Get-V7NumericProp $src 'approved' 0)
            $sRev = [int](Get-V7NumericProp $src 'revoked' 0)
            $sPend = $sTotal - $sAppr - $sRev; if ($sPend -lt 0) { $sPend = 0 }
            $sPct = if ($sTotal -gt 0) { [math]::Round(($sAppr + $sRev) / $sTotal * 100, 0) } else { 0 }
            $sColor = if ($sPct -ge 80) { $colors.Green } elseif ($sPct -ge 50) { $colors.Amber } else { $colors.Red }
            $sPendColor = if ($sPend -gt 0) { "color:$($colors.Red);font-weight:600;" } else { '' }
            $thermBar = "<span class='thermometer'><span class='thermometer-fill' style='width:${sPct}%;background:$sColor;display:inline-block;'></span></span>"
            [void]$sb.AppendLine("<tr><td style='font-weight:600;'>$sName</td><td style='text-align:right;'>$sTotal</td><td style='text-align:right;'>$sAppr</td><td style='text-align:right;'>$sRev</td><td style='text-align:right;$sPendColor'>$sPend</td><td style='text-align:center;font-weight:600;color:$sColor;'>${sPct}%</td><td>$thermBar</td></tr>")
        }
        [void]$sb.AppendLine("</tbody></table></div>")
    }
}

#endregion

#region Chart 12: Scope Waterfall (day-over-day item count changes)

if ($dayCount -ge 3) {
    [void]$sb.AppendLine("<div class='section'>")
    [void]$sb.AppendLine("<div class='section-title'>Decision Velocity -- Day-over-Day Changes</div>")
    [void]$sb.AppendLine("<p class='note'>Shows daily changes in approved (green up), revoked (red up), and undecided (amber down) counts. Positive = growth, negative = reduction. Tracks how quickly decisions are being made.</p>")

    $wfW = 700; $wfH = 180; $wfPadL = 50; $wfPadB = 40; $wfPadT = 15
    $wfPlotH = $wfH - $wfPadT - $wfPadB
    $wfBarW = [int][math]::Floor(($wfW - $wfPadL - 10) / ($dayCount - 1) * 0.7)
    $wfGapW = [int][math]::Floor(($wfW - $wfPadL - 10) / ($dayCount - 1) * 0.3)

    # Find max absolute delta for scaling
    $maxDelta = 1
    for ($i = 1; $i -lt $dayCount; $i++) {
        $d = $dailyData[$i]
        $aD = [math]::Abs([int]$d.ApprovedDelta)
        $rD = [math]::Abs([int]$d.RevokedDelta)
        $pD = [math]::Abs([int]$d.PendingDelta)
        if ($aD -gt $maxDelta) { $maxDelta = $aD }
        if ($rD -gt $maxDelta) { $maxDelta = $rD }
        if ($pD -gt $maxDelta) { $maxDelta = $pD }
    }

    [void]$sb.AppendLine("<div style='text-align:center;margin:12px 0;'>")
    [void]$sb.AppendLine("<svg width='$wfW' height='$($wfH + 10)' style='font-family:Segoe UI,Arial,sans-serif;'>")

    # Zero line
    $zeroY = $wfPadT + [int]($wfPlotH / 2)
    [void]$sb.AppendLine("<line x1='$wfPadL' y1='$zeroY' x2='$wfW' y2='$zeroY' stroke='#1f3a5f' stroke-width='1' opacity='0.3'/>")
    [void]$sb.AppendLine("<text x='$($wfPadL - 4)' y='$($zeroY + 4)' text-anchor='end' font-size='9' fill='#888'>0</text>")
    # Top/bottom labels
    [void]$sb.AppendLine("<text x='$($wfPadL - 4)' y='$($wfPadT + 10)' text-anchor='end' font-size='8' fill='#888'>+$maxDelta</text>")
    [void]$sb.AppendLine("<text x='$($wfPadL - 4)' y='$($wfPadT + $wfPlotH - 2)' text-anchor='end' font-size='8' fill='#888'>-$maxDelta</text>")

    for ($i = 1; $i -lt $dayCount; $i++) {
        $d = $dailyData[$i]
        $xBase = $wfPadL + (($i - 1) * ($wfBarW + $wfGapW)) + [int]($wfGapW / 2)
        $subBarW = [int]($wfBarW / 3)

        # Approved delta (green, positive = up from zero line)
        $aD = [int]$d.ApprovedDelta
        $aH = [int][math]::Max(1, [math]::Abs($aD) / $maxDelta * ($wfPlotH / 2))
        $aY = if ($aD -ge 0) { $zeroY - $aH } else { $zeroY }
        [void]$sb.AppendLine("<rect x='$xBase' y='$aY' width='$subBarW' height='$aH' fill='$($colors.Green)' rx='1' opacity='0.8'/>")

        # Revoked delta (red)
        $rD = [int]$d.RevokedDelta
        $rH = [int][math]::Max(1, [math]::Abs($rD) / $maxDelta * ($wfPlotH / 2))
        $rY = if ($rD -ge 0) { $zeroY - $rH } else { $zeroY }
        $rX = $xBase + $subBarW
        [void]$sb.AppendLine("<rect x='$rX' y='$rY' width='$subBarW' height='$rH' fill='$($colors.Red)' rx='1' opacity='0.8'/>")

        # Pending delta (amber, negative = good, going down)
        $pD = [int]$d.PendingDelta
        $pH = [int][math]::Max(1, [math]::Abs($pD) / $maxDelta * ($wfPlotH / 2))
        $pY = if ($pD -ge 0) { $zeroY - $pH } else { $zeroY }
        $pX = $xBase + $subBarW * 2
        [void]$sb.AppendLine("<rect x='$pX' y='$pY' width='$subBarW' height='$pH' fill='$($colors.Amber)' rx='1' opacity='0.8'/>")

        # Day label
        [void]$sb.AppendLine("<text x='$($xBase + [int]($wfBarW/2))' y='$($wfH - 5)' text-anchor='middle' font-size='9' fill='#566'>$($d.DayLabel)</text>")
    }

    # Legend
    $wfLegY = $wfH
    [void]$sb.AppendLine("<rect x='$($wfPadL + 5)' y='$wfLegY' width='10' height='10' fill='$($colors.Green)' rx='1'/>")
    [void]$sb.AppendLine("<text x='$($wfPadL + 19)' y='$($wfLegY + 9)' font-size='10' fill='#1c2b3a'>Approved +/-</text>")
    [void]$sb.AppendLine("<rect x='$($wfPadL + 110)' y='$wfLegY' width='10' height='10' fill='$($colors.Red)' rx='1'/>")
    [void]$sb.AppendLine("<text x='$($wfPadL + 124)' y='$($wfLegY + 9)' font-size='10' fill='#1c2b3a'>Revoked +/-</text>")
    [void]$sb.AppendLine("<rect x='$($wfPadL + 215)' y='$wfLegY' width='10' height='10' fill='$($colors.Amber)' rx='1'/>")
    [void]$sb.AppendLine("<text x='$($wfPadL + 229)' y='$($wfLegY + 9)' font-size='10' fill='#1c2b3a'>Undecided +/-</text>")

    [void]$sb.AppendLine("</svg></div></div>")
}

#endregion

#region Chart 13: Reviewer Compliance Accountability

if ($dayCount -ge 2 -and $reviewerList.Count -gt 0) {
    [void]$sb.AppendLine("<div class='section'>")
    [void]$sb.AppendLine("<div class='section-title'>Reviewer Compliance Accountability</div>")
    [void]$sb.AppendLine("<p class='note'>Categorizes reviewers by ACCOUNTABLE days: days the reviewer was in that day's campaign WITH items to review. A day is 'missed' when it ended with pending items; 'completed' when nothing was left pending. Days the reviewer was not in the campaign -- or had no items -- never count against them (their scope completed, was revoked, or moved). Chronic = missed 3+ consecutive accountable days.</p>")

    # Build per-reviewer ACCOUNTABLE-day timeline. The old classifier used raw
    # decisions-per-day with absence indistinguishable from inaction: a reviewer who
    # FINISHED early (and thus vanished from later daily campaigns) aged into
    # 'Inactive N days' -> red 'Absent (needs reassignment?)', and a reviewer whose
    # in-scope days required no decisions was branded 'Never Complied'.
    $rvCompliance = @()
    foreach ($rv in $reviewerList) {
        $rn = $rv.Name
        $totalDecisions = 0
        $activeDayCount = 0
        $lastActiveIdx = -1
        $acctResults = @()        # chronological $true = missed / $false = completed, accountable days only
        $acctDayCount = 0
        $missedDayCount = 0
        $lastAcctIdx = -1
        $lastAcctMissed = $false

        for ($di = 0; $di -lt $dayCount; $di++) {
            $rvDay = $null
            foreach ($r in $dailyData[$di].Reviewers) {
                if ($r.Name -eq $rn) { $rvDay = $r; break }
            }
            if ($null -eq $rvDay) { continue }   # not in this day's campaign: not accountable
            $dayDec = [int]$rvDay.Approved + [int]$rvDay.Revoked
            $totalDecisions += $dayDec
            if ($dayDec -gt 0) { $activeDayCount++; $lastActiveIdx = $di }
            if ([int]$rvDay.Total -gt 0) {
                $acctDayCount++
                $lastAcctIdx = $di
                $missed = ([int]$rvDay.Pending -gt 0)
                if ($missed) { $missedDayCount++ }
                $acctResults += $missed
                $lastAcctMissed = $missed
            }
        }

        # Consecutive missed streak counting back from the most recent accountable day.
        $missStreak = 0
        for ($ri = $acctResults.Count - 1; $ri -ge 0; $ri--) {
            if ($acctResults[$ri]) { $missStreak++ } else { break }
        }

        $acctToday = ($lastAcctIdx -eq ($dayCount - 1))
        $lastAcctDate = if ($lastAcctIdx -ge 0) { $dailyData[$lastAcctIdx].DayLabel } else { 'Never' }

        # Classify on accountable days only.
        $compCategory = 'Unknown'; $compSeverity = 'green'
        if ($acctDayCount -eq 0) {
            $compCategory = 'No items in window'
            $compSeverity = 'info'
        }
        elseif (-not $acctToday) {
            if (-not $lastAcctMissed) {
                $compCategory = "Completed -- out of scope since $lastAcctDate"
                $compSeverity = 'green'
            }
            else {
                $compCategory = "Left scope with items pending (last in scope $lastAcctDate)"
                $compSeverity = 'info'
            }
        }
        elseif (-not $lastAcctMissed) {
            $compCategory = 'Compliant -- today complete'
            $compSeverity = 'green'
        }
        elseif ($missedDayCount -eq $acctDayCount -and $totalDecisions -eq 0 -and $acctDayCount -ge 2) {
            $compCategory = "Never Complied ($missedDayCount of $acctDayCount accountable days missed, zero decisions)"
            $compSeverity = 'red'
        }
        elseif ($missStreak -ge 3) {
            $compCategory = "Chronic: missed $missStreak consecutive accountable day(s)"
            $compSeverity = 'red'
        }
        else {
            $compCategory = "Missed $missStreak recent accountable day(s)"
            $compSeverity = 'amber'
        }

        $rvCompliance += @{
            Name            = $rn
            Category        = $compCategory
            Severity        = $compSeverity
            TotalDecisions  = $totalDecisions
            ActiveDays      = $activeDayCount
            AccountableDays = $acctDayCount
            MissedDays      = $missedDayCount
            DaysSinceActive = if ($lastActiveIdx -ge 0) { $dayCount - 1 - $lastActiveIdx } else { $dayCount }
            LastActiveDate  = if ($lastActiveIdx -ge 0) { $dailyData[$lastActiveIdx].DayLabel } else { 'Never' }
            LastAcctDate    = $lastAcctDate
        }
    }

    # Group by severity for summary counts
    $redCount   = @($rvCompliance | Where-Object { $_.Severity -eq 'red' }).Count
    $amberCount = @($rvCompliance | Where-Object { $_.Severity -eq 'amber' }).Count
    $greenCount = @($rvCompliance | Where-Object { $_.Severity -eq 'green' }).Count
    $infoCount  = @($rvCompliance | Where-Object { $_.Severity -eq 'info' }).Count
    $neverCount = @($rvCompliance | Where-Object { $_.Category -match '^Never Complied' }).Count

    # Summary KPIs
    [void]$sb.AppendLine("<div style='margin:8px 0 16px;'>")
    [void]$sb.AppendLine("<span class='kpi'><span class='n' style='color:$($colors.Green);'>$greenCount</span><span class='l'>Compliant / Completed</span></span>")
    [void]$sb.AppendLine("<span class='kpi'><span class='n' style='color:$($colors.Amber);'>$amberCount</span><span class='l'>At Risk (missed 1-2 days)</span></span>")
    $ncColor = if ($neverCount -gt 0) { $colors.Red } else { $colors.Green }
    [void]$sb.AppendLine("<span class='kpi'><span class='n' style='color:$ncColor;'>$neverCount</span><span class='l'>Never Complied</span></span>")
    [void]$sb.AppendLine("<span class='kpi'><span class='n' style='color:$($colors.Red);'>$redCount</span><span class='l'>Non-Compliant Total</span></span>")
    [void]$sb.AppendLine("<span class='kpi'><span class='n' style='color:#777;'>$infoCount</span><span class='l'>Out of Scope / No Items</span></span>")
    [void]$sb.AppendLine("</div>")

    # Order: red, amber, green, info; most missed days first within each group.
    $sorted = @($rvCompliance | Sort-Object @{ Expression = { switch ($_.Severity) { 'red' { 0 } 'amber' { 1 } 'green' { 2 } default { 3 } } } }, @{ Expression = { $_.MissedDays }; Descending = $true })
    $complianceCols = "<th>Reviewer</th><th style='text-align:right;'>Accountable Days</th><th style='text-align:right;'>Missed</th><th style='text-align:right;'>Decisions</th><th>Last In Scope</th><th>Status</th>"
    function _V7ComplianceRow {
        param($rv, [string]$RowStyle, [string]$StatusClass)
        return "<tr$RowStyle><td style='font-weight:600;'>$(ConvertTo-SPHtmlSafe $rv.Name)</td><td style='text-align:right;'>$($rv.AccountableDays)</td><td style='text-align:right;'>$($rv.MissedDays)</td><td style='text-align:right;'>$($rv.TotalDecisions)</td><td>$($rv.LastAcctDate)</td><td class='$StatusClass'>$($rv.Category)</td></tr>"
    }

    # Non-compliant (red: Never Complied + Chronic) -- currently accountable and failing.
    $redList = @($sorted | Where-Object { $_.Severity -eq 'red' })
    if ($redList.Count -gt 0) {
        [void]$sb.AppendLine("<details open><summary style='font-weight:bold;font-size:13px;margin:8px 0 4px;color:$($colors.Red);'>Non-Compliant ($($redList.Count) reviewers) -- In today's campaign with repeated missed days</summary>")
        [void]$sb.AppendLine("<table class='report'><thead><tr>$complianceCols</tr></thead><tbody>")
        foreach ($rv in $redList) { [void]$sb.AppendLine((_V7ComplianceRow $rv " style='background:#fdecec;'" 's-red')) }
        [void]$sb.AppendLine("</tbody></table></details>")
    }

    # At-risk (amber) -- accountable today, missed 1-2 recent accountable days.
    $atRiskList = @($sorted | Where-Object { $_.Severity -eq 'amber' })
    if ($atRiskList.Count -gt 0) {
        [void]$sb.AppendLine("<details><summary style='font-weight:bold;font-size:13px;margin:8px 0 4px;color:$($colors.Amber);'>At Risk ($($atRiskList.Count) reviewers) -- Missed recent accountable day(s)</summary>")
        [void]$sb.AppendLine("<table class='report'><thead><tr>$complianceCols</tr></thead><tbody>")
        foreach ($rv in $atRiskList) { [void]$sb.AppendLine((_V7ComplianceRow $rv '' 's-amber')) }
        [void]$sb.AppendLine("</tbody></table></details>")
    }

    # Compliant / completed (green, collapsed).
    $compliantList = @($sorted | Where-Object { $_.Severity -eq 'green' })
    if ($compliantList.Count -gt 0) {
        [void]$sb.AppendLine("<details><summary style='font-weight:bold;font-size:13px;margin:8px 0 4px;color:$($colors.Green);'>Compliant ($($compliantList.Count) reviewers) -- Today complete, or completed and left scope</summary>")
        [void]$sb.AppendLine("<table class='report'><thead><tr>$complianceCols</tr></thead><tbody>")
        foreach ($rv in $compliantList) { [void]$sb.AppendLine((_V7ComplianceRow $rv '' 's-green')) }
        [void]$sb.AppendLine("</tbody></table></details>")
    }

    # Informational (out of scope with items pending at exit / never had items).
    $infoList = @($sorted | Where-Object { $_.Severity -eq 'info' })
    if ($infoList.Count -gt 0) {
        [void]$sb.AppendLine("<details><summary style='font-weight:bold;font-size:13px;margin:8px 0 4px;color:#777;'>Out of Scope / No Items ($($infoList.Count) reviewers) -- Informational, not counted against compliance</summary>")
        [void]$sb.AppendLine("<p class='note'>Reviewers no longer in the newest campaign (their items completed elsewhere, were revoked, or moved to another reviewer) or who never had items in this window. Nothing for them to attest -- excluded from the non-compliance counts.</p>")
        [void]$sb.AppendLine("<table class='report'><thead><tr>$complianceCols</tr></thead><tbody>")
        foreach ($rv in $infoList) { [void]$sb.AppendLine((_V7ComplianceRow $rv '' 's-amber')) }
        [void]$sb.AppendLine("</tbody></table></details>")
    }

    [void]$sb.AppendLine("</div>")
}

#endregion

#region Chart 14: Reviewer Engagement Heatmap (C/P/M/U daily grid)

if ($dayCount -ge 2 -and $reviewerList.Count -gt 0) {
    [void]$sb.AppendLine("<div class='section'>")
    [void]$sb.AppendLine("<div class='section-title'>Reviewer Engagement Heatmap</div>")
    [void]$sb.AppendLine("<p class='note'>Daily engagement pattern per reviewer across the ${dayCount}-day window. Each cell shows the reviewer's status for that day's campaign.</p>")
    [void]$sb.AppendLine("<p class='note'><strong>C</strong> = Completed (all items decided) &nbsp; <strong>P</strong> = Partial (some decided) &nbsp; <strong>M</strong> = Missed (0 decisions, items pending) &nbsp; <strong>U</strong> = Auto-closed (campaign force-closed / legacy suspect data -- genuine engagement unknown, never counted as Completed) &nbsp; <span style='color:#999;'>-</span> = Not assigned (nothing to attest that day)</p>")

    # Build C/P/M/U grid: rows = reviewers, columns = dates
    $engGrid = @{}
    $engStats = @{}
    foreach ($rn in ($reviewerNames.Keys | Sort-Object)) {
        $engGrid[$rn] = @{}
        $cCount = 0; $pCount = 0; $mCount = 0; $uCount = 0; $presentDays = 0
        for ($di = 0; $di -lt $dayCount; $di++) {
            $rvDay = $null
            foreach ($r in $dailyData[$di].Reviewers) {
                if ($r.Name -eq $rn) { $rvDay = $r; break }
            }
            if ($null -eq $rvDay -or [int]$rvDay.Total -eq 0) {
                $engGrid[$rn][$di] = '-'
                continue
            }
            $presentDays++
            $decided = [int]$rvDay.Approved + [int]$rvDay.Revoked
            $pending = [int]$rvDay.Pending
            $campStatus = $dailyData[$di].CampaignStatus
            $dayIsSuspect = $false
            try { $dayIsSuspect = [bool]$dailyData[$di].IsSuspect } catch { }

            if ($dayIsSuspect -and $pending -eq 0 -and $campStatus -eq 'COMPLETED') {
                # Legacy pre-canonical (suspect) day: the force-close counted
                # auto-approvals as decided, so decided>0/pending=0 must NOT read as
                # Completed -- the honest state is U (auto-closed, engagement unknown).
                $engGrid[$rn][$di] = 'U'; $uCount++
            }
            elseif ($decided -gt 0 -and $pending -eq 0) {
                $engGrid[$rn][$di] = 'C'; $cCount++
            }
            elseif ($decided -gt 0 -and $pending -gt 0) {
                $engGrid[$rn][$di] = 'P'; $pCount++
            }
            elseif ($decided -eq 0 -and $pending -eq 0 -and $campStatus -eq 'COMPLETED') {
                # All items auto-closed (force-completed campaign, reviewer never acted)
                $engGrid[$rn][$di] = 'U'; $uCount++
            }
            else {
                # No decisions made, items still pending
                $engGrid[$rn][$di] = 'M'; $mCount++
            }
        }
        $engScore = if ($presentDays -gt 0) { [math]::Round($cCount / $presentDays * 100, 0) } else { 0 }
        $engStats[$rn] = @{
            C = $cCount; P = $pCount; M = $mCount; U = $uCount
            PresentDays = $presentDays; Score = $engScore
            Category = if ($presentDays -eq 0) { 'Not Assigned' }
                       elseif ($cCount -eq $presentDays) { 'Always Complete' }
                       elseif ($engScore -ge 75) { 'Usually Complete' }
                       elseif ($engScore -ge 25) { 'Inconsistent' }
                       elseif ($cCount -gt 0) { 'Rarely Complete' }
                       else { 'Chronic Non-Compliance' }
        }
    }

    # Sort: worst engagement first (Chronic Non-Compliance, then Rarely, Inconsistent, Usually, Always)
    $catOrder = @{ 'Chronic Non-Compliance' = 0; 'Rarely Complete' = 1; 'Inconsistent' = 2; 'Usually Complete' = 3; 'Always Complete' = 4; 'Not Assigned' = 5 }
    $sortedReviewers = @($engStats.Keys | Sort-Object {
        $co = if ($catOrder.ContainsKey($engStats[$_].Category)) { $catOrder[$engStats[$_].Category] } else { 9 }
        $co
    }, { $engStats[$_].Score })

    # Category summary counts
    $catCounts = @{}
    foreach ($rn in $sortedReviewers) {
        $cat = $engStats[$rn].Category
        if (-not $catCounts.ContainsKey($cat)) { $catCounts[$cat] = 0 }
        $catCounts[$cat]++
    }

    # KPI summary
    [void]$sb.AppendLine("<div style='margin:8px 0 16px;'>")
    $ncCount2 = if ($catCounts.ContainsKey('Chronic Non-Compliance')) { $catCounts['Chronic Non-Compliance'] } else { 0 }
    $rarCount = if ($catCounts.ContainsKey('Rarely Complete')) { $catCounts['Rarely Complete'] } else { 0 }
    $incCount = if ($catCounts.ContainsKey('Inconsistent')) { $catCounts['Inconsistent'] } else { 0 }
    $usCount = if ($catCounts.ContainsKey('Usually Complete')) { $catCounts['Usually Complete'] } else { 0 }
    $alwCount = if ($catCounts.ContainsKey('Always Complete')) { $catCounts['Always Complete'] } else { 0 }
    $ncColor2 = if ($ncCount2 -gt 0) { $colors.Red } else { $colors.Green }
    [void]$sb.AppendLine("<span class='kpi'><span class='n' style='color:$ncColor2;'>$ncCount2</span><span class='l'>Chronic Non-Compliance</span></span>")
    $rarColor = if ($rarCount -gt 0) { $colors.Red } else { $colors.Green }
    [void]$sb.AppendLine("<span class='kpi'><span class='n' style='color:$rarColor;'>$rarCount</span><span class='l'>Rarely Complete</span></span>")
    $incColor = if ($incCount -gt 0) { $colors.Amber } else { $colors.Green }
    [void]$sb.AppendLine("<span class='kpi'><span class='n' style='color:$incColor;'>$incCount</span><span class='l'>Inconsistent</span></span>")
    [void]$sb.AppendLine("<span class='kpi'><span class='n' style='color:$($colors.Green);'>$usCount</span><span class='l'>Usually Complete</span></span>")
    [void]$sb.AppendLine("<span class='kpi'><span class='n' style='color:$($colors.Green);'>$alwCount</span><span class='l'>Always Complete</span></span>")
    [void]$sb.AppendLine("</div>")

    # Heatmap grid table
    [void]$sb.AppendLine("<div style='overflow-x:auto;'>")
    [void]$sb.AppendLine("<table class='report' style='font-size:12px;'>")

    # Header row: Reviewer | Date columns | Score | Category
    [void]$sb.AppendLine("<thead><tr><th style='text-align:left;min-width:140px;'>Reviewer</th>")
    for ($di = 0; $di -lt $dayCount; $di++) {
        [void]$sb.AppendLine("<th style='text-align:center;min-width:28px;padding:2px 4px;font-size:10px;'>$($dailyData[$di].DayLabel)</th>")
    }
    [void]$sb.AppendLine("<th style='text-align:right;min-width:50px;'>Score</th><th style='text-align:left;min-width:110px;'>Category</th></tr></thead><tbody>")

    # Cell colors
    $cellColors = @{ C = '#d4edda'; P = '#fff3cd'; M = '#f8d7da'; U = '#e2e3e5' }
    $cellFg = @{ C = '#155724'; P = '#856404'; M = '#721c24'; U = '#383d41' }

    $prevCategory = ''
    foreach ($rn in $sortedReviewers) {
        $st = $engStats[$rn]
        # Category separator row
        if ($st.Category -ne $prevCategory) {
            $prevCategory = $st.Category
        }

        $catClass = switch ($st.Category) {
            'Chronic Non-Compliance' { 's-red' }
            'Rarely Complete' { 's-red' }
            'Inconsistent' { 's-amber' }
            'Usually Complete' { 's-green' }
            'Always Complete' { 's-green' }
            default { '' }
        }

        [void]$sb.AppendLine("<tr><td style='font-weight:600;white-space:nowrap;'>$(ConvertTo-SPHtmlSafe $rn)</td>")
        for ($di = 0; $di -lt $dayCount; $di++) {
            $cell = $engGrid[$rn][$di]
            if ($cell -eq '-') {
                [void]$sb.AppendLine("<td style='text-align:center;color:#ccc;padding:2px 4px;'>-</td>")
            }
            else {
                $bg = $cellColors[$cell]
                $fg = $cellFg[$cell]
                [void]$sb.AppendLine("<td style='text-align:center;background:$bg;color:$fg;font-weight:700;padding:2px 4px;'>$cell</td>")
            }
        }
        [void]$sb.AppendLine("<td style='text-align:right;font-weight:600;'>$($st.Score)%</td><td class='$catClass'>$($st.Category)</td></tr>")
    }

    [void]$sb.AppendLine("</tbody></table></div>")
    [void]$sb.AppendLine("</div>")
}

#endregion

#region Chart 15: Entitlement State Summary (honest decision distribution)

if ($null -ne $seriesDeltaData -and $seriesDeltaData.Total -gt 0) {
    [void]$sb.AppendLine("<div class='section'>")
    [void]$sb.AppendLine("<div class='section-title'>Entitlement State Summary</div>")
    $chart15Scope = if (-not [string]::IsNullOrWhiteSpace($CampaignNameContains)) { "series matching '-CampaignNameContains $CampaignNameContains'" } else { 'ALL cached campaign series (tenant-wide; the -StartDate/-EndDate window and other filters do not apply here)' }
    [void]$sb.AppendLine("<p class='note'>Honest decision distribution across $($seriesDeltaData.SeriesCount) recurring campaign series -- covers $(ConvertTo-SPHtmlSafe $chart15Scope). Auto-approved items (idNowAutoApproved) are classified as <strong>Undecided</strong>, not Approved. Powered by SP.CampaignSeries cross-instance analysis.</p>")

    $sdAppr = $seriesDeltaData.Approved
    $sdRev  = $seriesDeltaData.Revoked
    $sdUnd  = $seriesDeltaData.Undecided
    $sdTot  = $seriesDeltaData.Total
    $pctAppr = [math]::Round($sdAppr / $sdTot * 100, 1)
    $pctRev  = [math]::Round($sdRev / $sdTot * 100, 1)
    $pctUnd  = [math]::Round($sdUnd / $sdTot * 100, 1)

    # KPI tiles
    [void]$sb.AppendLine("<div style='margin:8px 0 16px;'>")
    [void]$sb.AppendLine("<span class='kpi'><span class='n' style='color:$($colors.Green);'>$sdAppr</span><span class='l'>Genuinely Approved ($pctAppr%)</span></span>")
    $revColor = if ($sdRev -gt 0) { $colors.Amber } else { $colors.Green }
    [void]$sb.AppendLine("<span class='kpi'><span class='n' style='color:$revColor;'>$sdRev</span><span class='l'>Revoked ($pctRev%)</span></span>")
    $undColor = if ($sdUnd -gt 0) { $colors.Red } else { $colors.Green }
    [void]$sb.AppendLine("<span class='kpi'><span class='n' style='color:$undColor;'>$sdUnd</span><span class='l'>Undecided ($pctUnd%)</span></span>")
    [void]$sb.AppendLine("<span class='kpi'><span class='n' style='color:#555;'>$sdTot</span><span class='l'>Total Items</span></span>")
    [void]$sb.AppendLine("</div>")

    # Horizontal stacked bar
    $barW = 600
    $apprW = [math]::Max(1, [math]::Round($pctAppr / 100 * $barW))
    $revW  = [math]::Max(1, [math]::Round($pctRev / 100 * $barW))
    $undW  = [math]::Max(1, [math]::Round($pctUnd / 100 * $barW))
    # Adjust last segment to fill exactly
    $undW = $barW - $apprW - $revW
    if ($undW -lt 0) { $undW = 0 }

    [void]$sb.AppendLine("<div style='margin:12px 0 16px;'>")
    [void]$sb.AppendLine("<svg viewBox='0 0 $barW 36' style='max-width:${barW}px;width:100%;height:36px;'>")
    $x = 0
    if ($apprW -gt 0) {
        [void]$sb.AppendLine("<rect x='$x' y='0' width='$apprW' height='28' fill='$($colors.Green)' rx='3'/>")
        if ($apprW -gt 30) {
            [void]$sb.AppendLine("<text x='$($x + $apprW / 2)' y='18' text-anchor='middle' font-size='11' font-weight='700' fill='#fff'>$pctAppr%</text>")
        }
        $x += $apprW
    }
    if ($revW -gt 0 -and $sdRev -gt 0) {
        [void]$sb.AppendLine("<rect x='$x' y='0' width='$revW' height='28' fill='$($colors.Amber)' rx='0'/>")
        if ($revW -gt 30) {
            [void]$sb.AppendLine("<text x='$($x + $revW / 2)' y='18' text-anchor='middle' font-size='11' font-weight='700' fill='#fff'>$pctRev%</text>")
        }
        $x += $revW
    }
    if ($undW -gt 0 -and $sdUnd -gt 0) {
        [void]$sb.AppendLine("<rect x='$x' y='0' width='$undW' height='28' fill='#999' rx='0'/>")
        if ($undW -gt 30) {
            [void]$sb.AppendLine("<text x='$($x + $undW / 2)' y='18' text-anchor='middle' font-size='11' font-weight='700' fill='#fff'>$pctUnd%</text>")
        }
    }
    [void]$sb.AppendLine("</svg></div>")

    # Per-series breakdown table (collapsed by default if more than 1 series)
    if ($seriesDeltaData.Series.Count -gt 0) {
        $detailsOpen = if ($seriesDeltaData.Series.Count -eq 1) { ' open' } else { '' }
        [void]$sb.AppendLine("<details$detailsOpen><summary style='font-weight:bold;font-size:13px;margin:8px 0 4px;'>Per-Series Breakdown ($($seriesDeltaData.Series.Count) series)</summary>")
        [void]$sb.AppendLine("<table class='report'><thead><tr><th style='text-align:left;'>Series</th><th style='text-align:right;'>Instances</th><th style='text-align:right;'>Approved</th><th style='text-align:right;'>Revoked</th><th style='text-align:right;'>Undecided</th><th style='text-align:right;'>Total</th><th style='text-align:right;'>Approval %</th></tr></thead><tbody>")
        foreach ($s in $seriesDeltaData.Series) {
            $sApprPct = if ([int]$s.Total -gt 0) { [math]::Round([int]$s.Approved / [int]$s.Total * 100, 1) } else { 0 }
            $uvBadge = if ($s.Unverified) { " <span style='color:#999;font-size:10px;'>(unverified)</span>" } else { '' }
            $undBg = if ([int]$s.Undecided -gt 0) { " style='text-align:right;background:#f8d7da;font-weight:600;'" } else { " style='text-align:right;'" }
            [void]$sb.AppendLine("<tr><td>$(ConvertTo-SPHtmlSafe ([string]$s.SeriesName))$uvBadge</td><td style='text-align:right;'>$($s.Instances)</td><td style='text-align:right;'>$($s.Approved)</td><td style='text-align:right;'>$($s.Revoked)</td><td$undBg>$($s.Undecided)</td><td style='text-align:right;'>$($s.Total)</td><td style='text-align:right;'>$sApprPct%</td></tr>")
        }
        [void]$sb.AppendLine("</tbody></table></details>")
    }

    # Undecided highlight
    if ($sdUnd -gt 0) {
        [void]$sb.AppendLine("<p class='note' style='color:$($colors.Red);'><strong>$sdUnd Undecided item(s)</strong> across $($seriesDeltaData.SeriesCount) series were auto-approved at campaign close without genuine reviewer action. These represent governance gaps.</p>")
    }

    [void]$sb.AppendLine("</div>")
}

#endregion

#region Footer

$envName = ''
if ($null -ne $config) {
    try {
        if ($null -ne $config.PSObject.Properties['Environment'] -and
            -not [string]::IsNullOrWhiteSpace($config.Environment)) {
            $envName = [string]$config.Environment
        }
    } catch { }
}
$envFooter = if (-not [string]::IsNullOrWhiteSpace($envName)) { " | Env: $envName" } else { '' }
[void]$sb.AppendLine("<p class='footer'>Daily Evidence V7c (Calendar-Day Visualization) | Campaign: $(ConvertTo-SPHtmlSafe $campaignNameResolved)$envFooter | Generated: $genDate | SailPoint ISC Governance Toolkit</p>")
[void]$sb.AppendLine('</body></html>')

# Write HTML file
if ($OutputMode -eq 'HTML' -or $OutputMode -eq 'Both') {
    Write-SPHtmlFile -Path $htmlFile -Content $sb.ToString()
    Write-Host "    HTML: $htmlFile" -ForegroundColor Green
    Write-Host ''
}

#endregion

#region Console Output

if ($OutputMode -eq 'Console' -or $OutputMode -eq 'Both') {
    Write-Host '  === V7 Calendar-Day Summary ===' -ForegroundColor Cyan
    Write-Host "  Campaign:     $campaignNameResolved" -ForegroundColor White
    Write-Host "  Status:       $campaignStatusResolved" -ForegroundColor White
    Write-Host "  Days:         $dayCount calendar day(s)" -ForegroundColor White
    Write-Host "  Completion:   $($todayRec.CompletionPct)%" -ForegroundColor White
    Write-Host "  Approved:     $($todayRec.Approved)" -ForegroundColor White
    Write-Host "  Revoked:      $($todayRec.Revoked)" -ForegroundColor White
    Write-Host "  Undecided:    $($todayRec.Pending)" -ForegroundColor White
    Write-Host "  Reviewers:    $($todayRec.ReviewersTotal)" -ForegroundColor White
    if ($dayCount -ge 2) {
        $trendDirection = if ($windowDelta -gt 0) { 'UP' } elseif ($windowDelta -lt 0) { 'DOWN' } else { 'FLAT' }
        $dSignConsole = if ($windowDelta -gt 0) { '+' } else { '' }
        Write-Host "  Trend:        ${trendDirection} (${dSignConsole}${windowDelta}% over $dayCount days)" -ForegroundColor White
    }
    Write-Host "  Priv Pending: $($todayRec.PrivPending) of $($todayRec.PrivTotal)" -ForegroundColor White
    if ($suspectIncluded -gt 0) {
        Write-Host "  Suspect Days: $suspectIncluded" -ForegroundColor Yellow
    }

    # Stalled reviewers
    $stalledNames = @()
    foreach ($rv in $reviewerList) { if ($rv.Style -eq 'stalled') { $stalledNames += $rv.Name } }
    if ($stalledNames.Count -gt 0) {
        Write-Host "  STALLED:      $($stalledNames.Count) reviewer(s): $($stalledNames -join ', ')" -ForegroundColor Red
    }
    Write-Host ''
}

#endregion

#region Audit Trail

$totalDuration = (Get-Date) - $startTime
$durationStr = "$([math]::Round($totalDuration.TotalSeconds, 1))s"

Write-Host "  Duration: $durationStr" -ForegroundColor DarkGray

try {
    Write-SPLog -Message "Invoke-SPDailyEvidenceReportV7c completed: Duration=$durationStr CalendarDays=$dayCount SuspectFlagged=$suspectCount" `
        -Severity INFO -Component 'DailyEvidenceV7c' -Action 'Complete' -CorrelationID $correlationID
} catch { }

#endregion

#region Exit Code

# 0: Healthy (completion >= 80%)
# 1: Warning (completion 50-79%)
# 2: Parameter error
# 4: Configuration error
# 5: Critical (completion < 50% or insufficient data)

$exitCode = 0

if ($insufficientData) {
    $exitCode = 5
}
elseif ([double]$todayRec.CompletionPct -lt 50) {
    $exitCode = 5
}
elseif ([double]$todayRec.CompletionPct -lt 80 -or $stalledRvCount -gt 0) {
    $exitCode = 1
}

exit $exitCode

#endregion
