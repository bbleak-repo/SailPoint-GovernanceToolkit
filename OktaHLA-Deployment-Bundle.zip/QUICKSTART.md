# Quickstart -- Top-level orchestrated path

This is the fast path from zero to a deployed Okta CPM platform + PSM
connector against a real Privilege Cloud tenant. About 15 minutes if
everything goes right.

For the simulator-only path (no CyberArk involved), see
[`cpm-simulator/QUICKSTART.md`](cpm-simulator/QUICKSTART.md).

For variant-specific quickstarts:
- **V6 (TPC + PowerShell, dual-auth):** [`docs/platforms/v6/QUICKSTART.md`](docs/platforms/v6/QUICKSTART.md)
- **V7 (WSChains, SSWS-only):** [`docs/platforms/v7/QUICKSTART.md`](docs/platforms/v7/QUICKSTART.md)
- **Adapting to other SaaS:** [`docs/platforms/ADAPTING-FOR-OTHER-SAAS.md`](docs/platforms/ADAPTING-FOR-OTHER-SAAS.md)

For the operator-focused deployment guide, see
[`scripts/platform/DEPLOY-README.md`](scripts/platform/DEPLOY-README.md).

For the developer-focused build/extend guide, see
[`DEVELOPMENT.md`](DEVELOPMENT.md).

## Prerequisites checklist

- [ ] Windows machine with **Windows PowerShell 5.1+** (default on Windows
      Server 2016/2019/2022 / Windows 10/11)
- [ ] **Okta tenant** (integrator or production) with Super Admin access
- [ ] **Okta API token** in `$env:OKTA_API_TOKEN`
- [ ] **CyberArk Privilege Cloud tenant** + ability to mint a service
      account token (OAuth2 client credentials or vault user)
- [ ] Repo cloned to a working dir, `cd` into it

```powershell
git clone https://github.com/bbleak-repo/CyberArk-CPM-PSM-TestKit
cd CyberArk-CPM-PSM-TestKit
```

## Step 1 -- Validate Okta OAuth+JWT (Phase 1, ~3 min)

This proves the Okta-side auth path works before any CyberArk piece is
involved. If this step succeeds you know V6 OAuth mode will work against
your tenant.

```powershell
# 1a. Provision an API Services app + register a JWK
.\scripts\Create-OktaApiServicesApp.ps1 `
    -OktaDomain integrator-XXXX.okta.com `
    -OktaToken $env:OKTA_API_TOKEN
# Copy the printed ClientId

# 1b. End-to-end OAuth+JWT exchange + admin API call
.\scripts\Test-OktaOAuth2Jwt.ps1 `
    -OktaDomain integrator-XXXX.okta.com `
    -ClientId <fromAbove> `
    -OktaToken $env:OKTA_API_TOKEN
```

Expect: token issued, admin API call returns user listing.

If this fails, **stop here**. Common causes:
- Wrong scope name (must be `okta.users.manage` -- not
  `okta.users.credentials.manage`, that doesn't exist)
- Custom auth server (admin scopes only on Org Authorization Server)
- `client_secret_*` instead of `private_key_jwt` (admin scopes mandate JWT)

## Step 2 -- Validate PVWA auth + Safes API (~2 min)

Proves the CyberArk-side auth path. Cheapest possible probe with no
resources created:

```powershell
$pvwa = 'https://YOUR-TENANT.privilegecloud.cyberark.cloud'
$token = '<your-pvwa-token>'

.\scripts\Test-CyberArkSafe.ps1 -PVWAUrl $pvwa -PVWAToken $token `
    -Action Get -SafeName 'NonExistent'
```

Expect: `Safe 'NonExistent' does not exist (404)` -- success means
you authenticated and the API responded correctly.

Then a full CRUD smoke (creates a safe, adds owner + member, verifies,
deletes):

```powershell
.\scripts\Test-CyberArkSafe.ps1 -PVWAUrl $pvwa -PVWAToken $token `
    -Action Roundtrip -MemberName 'svc-cpm-test'
```

Expect: 10/10 PASS. Anti-orphan: an admin owner is auto-added before any
other operation, so a failure mid-run never leaves an orphaned safe.

## Step 3 -- Import CPM platform (V6 recommended, ~2 min)

Imports the Okta CPM platform into PVWA, ready to be associated with
your Okta admin accounts.

```powershell
# Dry-run first (recommended)
.\scripts\Import-CyberArkPlatformZip.ps1 -PVWAUrl $pvwa -PVWAToken $token `
    -PlatformZipPath '.\scripts\platform\OktaCloud-V6-TPC.zip' -WhatIf

# Real import + activate
.\scripts\Import-CyberArkPlatformZip.ps1 -PVWAUrl $pvwa -PVWAToken $token `
    -PlatformZipPath '.\scripts\platform\OktaCloud-V6-TPC.zip' -Activate
```

If your environment can't run TPC for some reason, fall back to V7
(WSChains + SSWS):

```powershell
.\scripts\Import-CyberArkPlatformZip.ps1 -PVWAUrl $pvwa -PVWAToken $token `
    -PlatformZipPath '.\scripts\platform\OktaCloud-V7-WSChains.zip' -Activate
```

Verify in PVWA UI: **Administration > Platform Management >
Configuration Management > Manage Platforms** -- you should see
`OktaCloud` listed and Active.

## Step 4 -- Import a PSM connector (~2 min)

Pick one. They're alternatives.

### Option A: AutoIt thick-app (more flexible, larger zip)

```powershell
.\scripts\Import-CyberArkPlatformZip.ps1 -PVWAUrl $pvwa -PVWAToken $token `
    -PlatformZipPath '.\psm\okta-oie\packages\PSM-OktaOIE-Connector-ProductionV2.zip'
```

ConnectionComponentId: `PSM-OktaOIE-AutoIt-ProductionV2`.

### Option B: WebFormFields declarative (smaller zip, native CyberArk pattern)

```powershell
.\scripts\Import-CyberArkPlatformZip.ps1 -PVWAUrl $pvwa -PVWAToken $token `
    -PlatformZipPath '.\psm\okta-oie-webform\packages\PSM-OktaOIE-WebForm-Hardened.zip'
```

ConnectionComponentId: `PSM-OktaOIE-WebForm-Hardened`. Two other variants
(`Native`, `PreConnect`) are also pre-built in the same folder.

Comparison if you're undecided:
[`psm/okta-oie-webform/COMPARISON-AutoIt-vs-WebForm.md`](psm/okta-oie-webform/COMPARISON-AutoIt-vs-WebForm.md).

## Step 5 -- Associate connector with platform (~1 min, PVWA UI)

Currently a UI-only step (no API endpoint we trust):

1. PVWA -> Administration -> Platform Management -> OktaCloud (or
   variant name)
2. Edit > **PSM** section
3. Add the ConnectionComponentId you imported in Step 4 to the allowed
   list
4. Save

## Step 6 -- Add an Okta admin account to a safe (~3 min, PVWA UI)

1. Create or pick a safe
2. Add the safe owner (admin group) -- already automated via
   `Test-CyberArkSafe.ps1` if you used `-Action Roundtrip` in Step 2
3. **Accounts > Add Account**
4. Platform: `OktaCloud`
5. Address: your Okta domain (e.g., `integrator-XXXX.okta.com`)
6. Username: the Okta admin username you want to rotate
7. Password: current password (will be rotated on next CPM run)
8. Platform-specific properties:
   - V6 OAuth+JWT: `OktaAuthMode=OAuth`, plus the OAuth ClientId / private
     key reference from Step 1
   - V6 SSWS or V7: `OktaAuthMode=SSWS`, plus the API token reference

## Step 7 -- Trigger a rotation + watch logs

Either via PVWA UI ("Change") or wait for the next CPM cycle. Logs are
where you confirm success:

```
C:\Program Files (x86)\CyberArk\Password Manager\Logs\CPM-OktaCloud.log
```

Successful rotation looks like:
```
[INFO] OktaCloud :: Authentication successful (mode=OAuth)
[INFO] OktaCloud :: Reset password for user <id>
[INFO] OktaCloud :: Verification call succeeded
```

If it fails, the V5 archived path was probably the cause -- read
[`STATUS.md`](STATUS.md) (2026-05-04) for the symptom chain we already
debugged.

---

## What to do if any step fails

| Step | Most likely cause | Fix |
|---|---|---|
| 1 (Okta OAuth) | Wrong scope or auth server | See [CLAUDE.md](CLAUDE.md) "Critical gotchas" #3, #4 |
| 2 (PVWA Safes) | URL doubling | See [CLAUDE.md](CLAUDE.md) "Critical gotchas" #1 |
| 3 (Platform import) | Validator complains about placeholder | See [CLAUDE.md](CLAUDE.md) "Critical gotchas" #2, #5 |
| 4 (PSM import) | AppLocker rule rejected | Check `package.json` rule method matches binary signing state |
| 5 (Association) | Component not visible | Wait 1-2 min for vault sync; refresh browser |
| 6 (Account add) | Platform-specific property missing | Check OktaCloud-V6 doc strings via PVWA platform inspector |
| 7 (Rotation) | Auth mode mismatch | Verify `OktaAuthMode` matches what you configured Okta-side in Step 1 |

For deeper troubleshooting see [`scripts/platform/DEPLOY-README.md`](scripts/platform/DEPLOY-README.md).
