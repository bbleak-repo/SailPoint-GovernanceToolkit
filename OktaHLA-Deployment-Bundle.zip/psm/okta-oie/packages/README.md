# Pre-built PSM Connector Packages -- Okta OIE AutoIt (thick-app)

Three importable zips, one per AutoIt connector variant, ready to drop into
PVWA via **Administration > Platform Management > Import Platform**.

| Zip | ConnectionComponentId | Variant |
|---|---|---|
| `PSM-OktaOIE-Connector-ProductionV3.zip` | `PSM-OktaOIE-AutoIt-ProductionV3` | **Recommended.** v3.0 — V2's adaptive auth loop + per-host browser switch (`[WebDriver] Browser=Chrome\|Edge` in the INI). One codebase, both Chromium browsers. |
| `PSM-OktaOIE-Connector-ProductionV2.zip` | `PSM-OktaOIE-AutoIt-ProductionV2` | v2.0 single-browser fallback (Chrome only). Adaptive auth loop, element-based WaitForPageLoad (~3.5x faster), DOM-first page detection, query-param-stripped success matching. Kept as the proven V2-shaped fallback if V3's per-browser routing is implicated in any regression. |
| `PSM-OktaOIE-Connector-Production.zip` | `PSM-OktaOIE-AutoIt-Production` | v1.0 sequential auth flow (Username -> Next -> Password -> Verify -> TOTP -> Verify). Kept for archival comparison; prefer V3. |

Each zip contains:
- The compiled connector `.exe` (built from the corresponding `.au3` source via Aut2Exe)
- `package.json` declaring an AppLocker rule for the connector itself (Hash method)

## Sibling: WebForm variants

If you prefer the WebFormFields approach (browser-driven via CyberArk's
`WebAppDispatcher.exe` rather than this AutoIt thick-app), see
`psm/okta-oie-webform/packages/`. The two approaches are alternatives -- pick
one based on your PSM environment and team preferences (the
`COMPARISON-AutoIt-vs-WebForm.md` file in the webform folder lays out the
tradeoffs).

## Importing via PVWA UI (manual)

1. PVWA -> Administration -> Platform Management -> Import Platform
2. Select the zip
3. Confirm the connection component appears in **Configuration Options >
   Privileged Session Management > Connection Components**
4. Associate with the OktaCloud platform (V5/V6/V7) under
   Platforms > OktaCloud* > PSM Connection Components

## Importing via PowerShell

```powershell
.\scripts\Import-CyberArkPlatformZip.ps1 `
    -PVWAUrl 'https://tenant.privilegecloud.cyberark.cloud' `
    -PlatformZipPath '.\psm\okta-oie\packages\PSM-OktaOIE-Connector-ProductionV2.zip' `
    -PVWAToken $token
```

## Runtime dependencies (must be present on PSM server)

- **Chrome and/or Edge** (V3 supports both; V1/V2 are Chrome-only).
  - For V3, only the browser referenced by `[WebDriver] Browser=` in the INI
    must be installed on that PSM host. The other can be absent entirely.
- **Matching driver** in the connector's `lib\` folder:
  - `chromedriver.exe` matching installed Chrome major version (V1, V2, or
    V3 with `Browser=Chrome`)
  - `msedgedriver.exe` matching installed Edge major version (V3 with
    `Browser=Edge` only)
  - Standard PSM AppLocker rules typically allow either driver via Hash.
    If yours don't, add an AppLocker rule for the one(s) you ship.
- **PSMGenericClientWrapper.au3** -- ships with PSM v13.x+ in
  `C:\Program Files (x86)\CyberArk\PSM\Components\PSMGenericClientWrapper.au3`.
  Already linked at compile time -- just needs the runtime equivalent on PSM.

The connector reads its config (selectors, timeouts, browser choice) from
`PSM-OktaOIE-Config.ini` (V1), `PSM-OktaOIE-Config-ProductionV2.ini` (V2),
or `PSM-OktaOIE-Config-ProductionV3.ini` (V3).
**Copy the matching config INI to the PSM Components folder alongside the .exe**
or the connector will fail at startup with config-not-found.

### V3-specific: choosing Chrome vs Edge

V3 reads `[WebDriver] Browser=` from the INI at session start. Set it to
`Chrome` or `Edge` (case-insensitive) once per PSM host. Each host can pick
independently -- no PVWA changes, no recompile. If the chosen browser's
driver is missing, V3 exits with a clear "X requested but driver not found"
message rather than a generic WebDriver init failure.

## Local testing without PSM (V2 and V3)

Both V2 and V3 now share a common credential helper (`lib/PSMCredentials.au3`)
that can source credentials from the cpm-simulator vault when launched
outside the PSM host process. This lets you smoke-test the full OIE login
flow against real Chrome / Edge on a developer workstation before deploying
to PSM.

**Production PSM behavior is unchanged** -- without the `--test` flag, the
connector calls `PSMGenericClient_GetSessionProperty(...)` exactly as before.

### One-time setup

1. Have cpm-simulator working: vault provisioned, account password +
   TOTP seed stored. See `cpm-simulator/QUICKSTART.md`.
2. Set environment variables in your PowerShell profile (or per-session):
   ```powershell
   $env:CPM_SIMULATOR_DIR    = 'C:\path\to\repo\cpm-simulator'
   $env:CPM_VAULT_PASSPHRASE = '<your vault passphrase>'
   ```
3. Place `chromedriver.exe` and/or `msedgedriver.exe` in the connector's
   `lib\` directory matching your installed browser version(s).
4. Copy the matching `PSM-OktaOIE-Config-Production*.ini` next to the
   `.exe` (rename to `PSM-OktaOIE-Config.ini`). For V3, set
   `[WebDriver] Browser=Chrome` or `Edge`.

### Running a test

```powershell
# From the directory containing PSM-OktaOIE-Connector-ProductionV3.exe:
.\PSM-OktaOIE-Connector-ProductionV3.exe --test hla-superadmin-01
```

The connector will:
1. Detect `--test <account>` in the command line
2. Shell to `python -m src.cli show-test-creds --account hla-superadmin-01`
   inside `$env:CPM_SIMULATOR_DIR`
3. Decrypt the vault, generate a fresh TOTP code, return JSON
4. Drive the OIE login through the configured browser (Chrome or Edge for V3)
5. Log step-by-step screenshots to `screenshots/` if enabled in the INI

### Troubleshooting

The credential helper writes diagnostic lines prefixed `[PSMCreds]` to the
console (visible when running the .exe from a terminal). Common errors:

| Symptom | Cause |
|---|---|
| `$env:CPM_SIMULATOR_DIR is not set` | Set the env var in your shell |
| `cli.py not found at: ...` | Wrong path in CPM_SIMULATOR_DIR |
| `cpm-simulator returned empty stdout` | Check stderr line for the actual Python error (passphrase wrong, account not in vault, etc.) |
| `failed to parse JSON` | Python printed extra output before the JSON line; should not happen with the dedicated `show-test-creds` command but check stderr |

The password is **never** logged or written to disk by the connector
(only "credentials retrieved for: <username>" appears in logs).

## Rebuilding from source

If you edit the underlying `.au3`, rebuild with (V3 example -- swap version
suffix for V1/V2):

```powershell
# 1. Compile .au3 -> .exe
& 'C:\Program Files (x86)\AutoIt3\Aut2Exe\Aut2exe.exe' `
    /in '.\psm\okta-oie\PSM-OktaOIE-Connector-ProductionV3.au3' `
    /out '.\psm\okta-oie\packages\PSM-OktaOIE-Connector-ProductionV3.exe' `
    /comp 2

# 2. Wrap into deployable zip with package.json
.\scripts\Build-PSMConnectorPackage.ps1 `
    -ConnectorFile '.\psm\okta-oie\packages\PSM-OktaOIE-Connector-ProductionV3.exe' `
    -ComponentId 'PSM-OktaOIE-AutoIt-ProductionV3' `
    -OutputZip '.\psm\okta-oie\packages\PSM-OktaOIE-Connector-ProductionV3.zip' `
    -Force
```

`/comp 2` is the default LZMA compression. Use `/comp 0` for fastest builds
(uncompressed, useful during dev).

**Aut2Exe gotcha**: invoke via PowerShell `Start-Process -Wait` (or `&`
call as shown above). Bash invocation on Windows silently produces no
output and returns 0.

## Why ship V1, V2, and V3?

V3 is the recommended production target -- it carries V2's adaptive auth
loop forward and adds a per-host Chrome/Edge switch in the INI without
changing any selector logic. The browser-specific divergence is isolated
to ~40 lines in `InitializeWebDriver()`; everything below is byte-identical
to V2.

V2 ships alongside as a single-browser fallback in case V3's per-browser
routing is implicated in any session-spawn regression on a particular PSM
host. V1 stays as an archival reference of the original sequential auth
flow.

Run all three side-by-side under different ConnectionComponentIDs
(`PSM-OktaOIE-AutoIt-Production`, `-ProductionV2`, `-ProductionV3`) and
switch the platform association when ready.

## Comparing AutoIt vs WebForm

See `psm/okta-oie-webform/COMPARISON-AutoIt-vs-WebForm.md` for the
side-by-side. Quick summary:

- **AutoIt thick-app (this folder)**: more flexible (full AutoIt scripting),
  larger binary (~1.2 MB), needs `Aut2Exe` for any change
- **WebForm XML (`../okta-oie-webform/packages/`)**: declarative, smaller
  zip (~3-4 KB), edits are XML-only (no recompile), CyberArk-blessed pattern
