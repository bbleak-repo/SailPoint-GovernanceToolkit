# Pre-built PSM Connector Packages -- Okta OIE WebForm

Three importable zips, one per WebFormFields variant, ready to drop into PVWA via
**Administration > Platform Management > Import Platform**.

| Zip | ConnectionComponentId | When to use |
|---|---|---|
| `PSM-OktaOIE-WebForm-Hardened.zip` | `PSM-OktaOIE-WebForm-Hardened` | **Recommended for production.** Adaptive factor ordering, post-step error detection, minimized SleepSeconds, button selector fallback chains. PAS v14.8+. |
| `PSM-OktaOIE-WebForm-Native.zip` | `PSM-OktaOIE-WebForm-Native` | Native TOTP via `TOTPToken.exe` (ships with PSM v13+). Zero external dependencies. |
| `PSM-OktaOIE-WebForm-PreConnect.zip` | `PSM-OktaOIE-WebForm-PreConnect` | PreConnect DLL approach. Requires `CyberArk.PSM.GenerateTOTPPreconnect.dll` from the community release. |

Each zip contains:
- The corresponding WebFormFields XML
- `package.json` with `ConnectionComponentId` and an AppLocker rule for
  `CyberArk.PSM.WebAppDispatcher.exe` (Publisher-method since the dispatcher is
  CyberArk-signed)

## Importing via PVWA UI (manual)

1. PVWA -> Administration -> Platform Management -> Import Platform
2. Select the zip
3. Confirm the connection component appears in **Configuration Options >
   Privileged Session Management > Connection Components**
4. Associate with the OktaCloud platform (V5/V6/V7) under
   Platforms > OktaCloud* > PSM Connection Components

## Importing via PowerShell

```powershell
.\scripts\Import-CyberArkPlatformZip.ps1 `
    -PVWAUrl 'https://tenant.privilegecloud.cyberark.cloud' `
    -PlatformZipPath '.\psm\okta-oie-webform\packages\PSM-OktaOIE-WebForm-Hardened.zip' `
    -PVWAToken $token
```

## Rebuilding from source

If you edit the underlying XML, rebuild with:

```powershell
.\scripts\Build-PSMConnectorPackage.ps1 `
    -ConnectorFile '.\psm\okta-oie-webform\PSM-OktaOIE-WebForm-Hardened.xml' `
    -ComponentId 'PSM-OktaOIE-WebForm-Hardened' `
    -OutputZip '.\psm\okta-oie-webform\packages\PSM-OktaOIE-WebForm-Hardened.zip' `
    -Force
```

## Post-deployment configuration

See `psm/okta-oie-webform/DEPLOYMENT.md` for the per-variant property
configuration steps (LogonURL, ActionTimeout, EnableAdvancedDebugging,
WebFormFields, LogonAccount capability, etc.) -- those settings are
configured in PVWA after import, not baked into the zip.
