# Okta HLA Vault Structure

How to organize CyberArk safes + accounts to vault Okta highly-privileged
admin accounts (HLAs) for both CPM rotation and PSM session brokering.

> **Scope:** This is the safe/account structure. For platform deployment see
> [`scripts/platform/DEPLOY-README.md`](../scripts/platform/DEPLOY-README.md).
> For end-to-end orchestration see [`QUICKSTART.md`](../QUICKSTART.md).

## The three accounts per HLA

For each Okta admin you vault, there are **three CyberArk accounts** linked
together. The target account is the user; the other two carry secrets that
the rotation/session needs at runtime but should never be stored on the
target itself.

```
Safe: Okta-HLA-{tenant-name}
│
├── TARGET:    hla-okta-superadmin-01                   <-- the actual Okta admin user
│   ├─ Username:      okta-superadmin-01@example.com
│   ├─ Address:       yourtenant.okta.com
│   ├─ Password:      <CPM-rotated>                      <-- the Okta password
│   ├─ OktaUserId:    00uXXXXXXXXXXXXXXXXX               <-- Okta directory _id (custom property)
│   ├─ Platform:      OktaCloudWSChains  (or OktaCloudTPC)
│   └─ Linked:
│        ├─ LogonAccount    (PropertyIndex 1) -> "...-token"
│        ├─ TOTPAccount     (PropertyIndex 2) -> "...-totp"
│        └─ ReconcileAccount (PropertyIndex 3) -> "...-token"  (same as LogonAccount)
│
├── LOGON:     hla-okta-superadmin-01-token             <-- SSWS API token bearer
│   ├─ Username:      okta-rotation-token
│   ├─ Address:       yourtenant.okta.com
│   ├─ Password:      00aBCDxxxxxxxxxxxxxxxxxxxx         <-- the actual SSWS token
│   ├─ Platform:      CyberArkVault  (no auto-rotation -- token rotated via Okta UI)
│   └─ This is what V7's {{pmextrapass1}} resolves to.
│      V6's PowerShell reads it as $linkedSecret.
│
└── TOTP:      hla-okta-superadmin-01-totp              <-- TOTP seed bearer
    ├─ Username:      okta-totp-seed-01
    ├─ Address:       yourtenant.okta.com
    ├─ Password:      JBSWY3DPEHPK3PXP...                <-- base32 TOTP seed
    ├─ Platform:      CyberArkVault  (no auto-rotation -- seed rotated via Okta MFA reset)
    └─ Read by PSM TOTPToken.exe at session launch to compute the 6-digit OTP.
```

### Why three accounts and not one

**Separation of concerns and audit clarity.** Each secret has a different
lifecycle, different rotator, different access-control story:

| Account | Rotates how | Read by | Why separate |
|---|---|---|---|
| Target password | CPM (V6/V7 platform) | PSM at session launch via WebForm | Subject to CPM-managed rotation policy |
| SSWS token | Manual (Okta admin UI) | CPM at rotation time | Long-lived, revocation-managed; pinning lifecycle to CPM is wrong |
| TOTP seed | Manual (Okta MFA reset) | PSM at session launch via TOTPToken.exe | Independent of password lifecycle; rotates only when user re-enrolls factor |

Locking all three on the same record means CPM rotation churns the SSWS
token if anything goes wrong, and access-control on the seed is bound to
access on the password. Three accounts gives you three sets of safe
permissions to grant separately.

## Manual setup via PVWA UI

> Pre-req: V6 or V7 platform already imported and active. See
> [`QUICKSTART.md`](../QUICKSTART.md) Step 3.

### Step 1 — Create the safe

1. PVWA -> **Policies -> Safes -> Add Safe**
2. Name: `Okta-HLA-{tenant-name}` (e.g., `Okta-HLA-acme`)
3. Description: "Okta highly-privileged admin accounts and linked secrets"
4. Default settings are fine; tighten retention/access if your policy requires
5. **Save** -- IMMEDIATELY add an admin owner before doing anything else
   (anti-orphan; see below)

### Step 2 — Add the safe owner (anti-orphan, critical)

The account that creates the safe gets full ownership by default, but if
that service account is later deleted, the safe becomes orphaned.

1. **Members -> Add Member**
2. Member: `Privilege Cloud Administrators` (or your tenant's vault admin group)
3. Permissions: **Owner** preset (all 22 permissions)
4. Save

If you skip this and your CPM service account gets removed, only CyberArk
Support can recover the safe. Don't skip it.

### Step 3 — Create the SSWS token account first (LOGON)

This goes first because the target account links TO it.

1. **Accounts -> Add Account**
2. Platform: `CyberArkVault` (or any non-rotating "secrets" platform you use)
3. Safe: `Okta-HLA-{tenant-name}`
4. Address: `yourtenant.okta.com`
5. Username: `okta-rotation-token` (or any descriptive name)
6. Password: paste the SSWS token from Okta Admin -> Security -> API -> Tokens
7. Save

### Step 4 — Create the TOTP seed account (TOTP)

1. **Accounts -> Add Account**
2. Platform: `CyberArkVault`
3. Safe: `Okta-HLA-{tenant-name}`
4. Address: `yourtenant.okta.com`
5. Username: `okta-totp-seed-{N}` (one per HLA -- seeds are user-specific)
6. Password: paste the base32 TOTP seed
   - From Okta: when you enroll the HLA in TOTP, save the seed before
     scanning the QR code (Okta shows it once)
   - Or: re-enroll the HLA's TOTP factor and capture the seed at that point
7. Save

### Step 5 — Create the target HLA account

1. **Accounts -> Add Account**
2. Platform: `OktaCloudWSChains` (or `OktaCloudTPC` for V6)
3. Safe: `Okta-HLA-{tenant-name}`
4. Address: `yourtenant.okta.com`
5. Username: `okta-superadmin-01@example.com` (the actual Okta login)
6. Password: the *current* Okta password (CPM will rotate it on next cycle)
7. **Custom Property:** `OktaUserId` = the Okta `_id` for this user
   - Find via `GET /api/v1/users/{login}` from Okta API
   - Looks like `00uABCDEFGHIJKLMNOPQ`
8. Save WITHOUT rotation yet -- we still need to wire the links

### Step 6 — Wire the linked accounts

On the target HLA account from Step 5:

1. Open the account -> **Account Details -> Associated Accounts**
2. Click **LogonAccount** -> select the SSWS token account (Step 3)
3. Click **ReconcileAccount** -> select the SSWS token account (Step 3) again
   (same account; it's used for both rotation and recovery)
4. Click **TOTPAccount** -> select the TOTP seed account (Step 4)
5. Save

### Step 7 — Trigger a verify to confirm

1. Target HLA account -> **Verify**
2. Expected: green checkmark; CPM logs show 200 from `/api/v1/users/{id}`
3. If you get 8102 (Unauthorized): SSWS token is wrong or expired
4. If you get 8104 (Not Found): `OktaUserId` property is wrong
5. If you get 9999 + placeholder error: the linked account associations
   weren't saved properly -- redo Step 6

### Step 8 — Trigger a Change to test rotation end-to-end

1. Target HLA account -> **Change**
2. Watch CPM log: `verifypass -> changepass -> verifypass-new` should all
   succeed
3. Final exit code 0; the password in the vault is now the rotated value

## Repeat for each HLA

Steps 4-7 per Okta admin. Step 3's SSWS token account is shared across HLAs
(one token can rotate many users), but each HLA needs its own TOTP seed
account because seeds are per-user.

## Automated setup via PowerShell

For reproducible bulk setup, use the helper script:

```powershell
.\scripts\New-OktaHLAAccount.ps1 `
    -PVWAUrl 'https://yourtenant.privilegecloud.cyberark.cloud' `
    -PVWAToken $token `
    -SafeName 'Okta-HLA-acme' `
    -OktaDomain 'yourtenant.okta.com' `
    -HLAUsername 'okta-superadmin-01@example.com' `
    -HLAPassword (Read-Host -AsSecureString 'Okta password') `
    -OktaUserId '00uABCDEFGHIJKLMNOPQ' `
    -SSWSTokenAccountName 'hla-okta-superadmin-01-token' `
    -SSWSToken (Read-Host -AsSecureString 'SSWS API token') `
    -TOTPSeed (Read-Host -AsSecureString 'TOTP base32 seed') `
    -PlatformId 'OktaCloudWSChains'
```

The script (in `scripts/New-OktaHLAAccount.ps1`):

1. Creates the safe if it doesn't exist (idempotent)
2. Auto-adds the admin-owner group (anti-orphan)
3. Creates the three accounts in the right order (LOGON -> TOTP -> TARGET)
4. Wires the LinkedAccount associations on the target
5. Optionally triggers an initial Verify

Re-running with the same parameters is idempotent: existing accounts are
detected and updated rather than duplicated.

## Permissions tuning

Default safe member permissions for typical roles:

| Role | What they need | Permission preset |
|---|---|---|
| CPM service account | Retrieve, update, change permissions on target accounts | **Manager** |
| Operators (humans) | Use accounts (PSM session) but NOT see passwords directly | **Use Accounts**, **Initiate CPM Account Management** |
| Auditors | View activity logs | **List Accounts** + audit-only |
| Vault admins | Everything | **Owner** (already added in Step 2) |

The 22 permission keys and presets are codified in
[`scripts/Test-CyberArkSafe.ps1`](../scripts/Test-CyberArkSafe.ps1)
under `$Global:CanonicalPermissions`. Use them directly:

```powershell
.\scripts\Test-CyberArkSafe.ps1 -PVWAUrl '...' -PVWAToken $t `
    -Action AddMember -SafeName 'Okta-HLA-acme' `
    -MemberName 'svc-cpm-okta' -Preset 'Manager'
```

## Recovering from a broken setup

| Symptom | Cause | Fix |
|---|---|---|
| Verify: 401 / 8102 | Wrong SSWS token | Update LOGON account's password with a fresh Okta token |
| Verify: 404 / 8104 | Wrong `OktaUserId` property | Confirm via `GET /api/v1/users/{username}` then update the property |
| Verify: 9999 placeholder | Linked accounts not associated | Redo Step 6 in PVWA UI; some PVWA versions don't persist linkage on first save |
| Change: rotation succeeds but PSM session can't login | TOTP seed is wrong or PSM TOTPToken.exe not configured | Re-export the seed from Okta and update TOTP account; verify PSM connector reads it |
| Whole safe disappeared | Service account deleted, no admin owner | If Step 2 was skipped: open CyberArk support ticket. If Step 2 was done: re-grant owner from admin group |

## Why this structure works for V6 AND V7

The same three-account pattern works for both platforms:

| Resolution | V6 (TPC + PowerShell) | V7 (WSChains) |
|---|---|---|
| Target password | `$password` from stdin | `{{pmpass}}` |
| Target new password | `$newPassword` from stdin | `{{pmnewpass}}` |
| LogonAccount password (SSWS token) | `$linkedSecret` from stdin | `{{pmextrapass1}}` |
| TOTPAccount password (TOTP seed) | not consumed by CPM (PSM-only) | not consumed by CPM (PSM-only) |
| Username | `$Username` parameter | `{{Username}}` from Required property |
| OktaUserId | `$OktaUserId` parameter | `{{OktaUserId}}` from Required property |

CPM doesn't need TOTP at rotation time. The TOTP seed is consumed by PSM
(via TOTPToken.exe) at session launch, which is a separate flow. Keeping
all three vaulted in one safe lets PSM resolve the seed via the linked
TOTPAccount when it brokers a session.
