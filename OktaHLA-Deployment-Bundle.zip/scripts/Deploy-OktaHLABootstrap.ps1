#Requires -Version 5.1
<#
.SYNOPSIS
    Deploys or tears down Okta-side HLA 3-Tier privileged account infrastructure.

.DESCRIPTION
    v2.0.0 -- Interactive deploy/teardown for Okta HLA resources (CR CHG00XXXXX).

    Creates (or removes) all Okta-side resources for the CyberArk HLA 3-Tier architecture:
      - User accounts (Tier 1/2/3, break-glass, read-only, CPM service account)
      - Security groups (3 tier groups + umbrella + break-glass)
      - Network zone (CyberArk-Infrastructure)
      - Custom admin role (CyberArk CPM Credential Manager)
      - Resource set (CyberArk CPM Managed Accounts)
      - Role binding (CPM service account + custom role + resource set)
      - Sign-on policies (4 policies with allow/deny rules)
      - SSWS API token (from CPM service account)

    v2.0 Features:
      - Pre-flight API permission validation: tests every API endpoint before any
        resource creation, with clear PASS/WARN/FAIL reporting.
      - Post-step verification: each created resource is re-queried to confirm it
        actually exists before proceeding to the next step.
      - Interactive network zone CIDR input: prompts for real gateway IPs instead
        of always using a placeholder.
      - Account plan review: displays the full CR account layout for confirmation
        before any resources are created.

    Supports three actions:
      Deploy   - Creates all resources (idempotent, GET-before-POST)
      Teardown - Removes resources in dependency-safe order (interactive selection)
      WhatIf   - Dry-run: shows what would be created/deleted without making changes

    Interactive mode (default) prompts for confirmation at each stage: account
    plan review, API permission validation, network zone CIDRs, and teardown
    resource selection. Use -AcceptDefaults for CI pipelines.

.PARAMETER Action
    The operation to perform: Deploy, Teardown, or WhatIf.

.PARAMETER ApiToken
    Okta SSWS API token with Super Admin privilege.
    If not provided, reads from $env:OKTA_API_TOKEN or prompts securely.

.PARAMETER OktaDomain
    Okta tenant hostname (e.g. yourorg.okta.com). No https://.
    If not provided, reads from $env:OKTA_DOMAIN or prompts.

.PARAMETER HlaPrimaryRole
    Admin role for HLA-01 account. Default: ORG_ADMIN.
    Use SUPER_ADMIN for production (shows warning about developer tenant limitations).

.PARAMETER AcceptDefaults
    Suppresses all interactive prompts. Deploys/tears down ALL resource categories.
    When updating existing Admin Console session rules, accepts the proposed duration
    without prompting.

.PARAMETER Force
    Bypasses the explicit-Y safety prompts for tenant-wide Step 5.5 changes
    (google_otp authenticator activation and default policy TOTP disable).
    Use for automated testing or CI pipelines where interactive prompts are not
    possible. Not intended for production use -- operator review is recommended
    for tenant-wide changes. Also bypasses the Step 5.5 rollback confirmation.

.PARAMETER SIEMLogPath
    Directory for SIEM JSON log output. Defaults to a 'Logs' folder next to this script.

.PARAMETER Tier1ReauthDuration
    ISO 8601 duration for how long a Tier 1 (Super Admin) Admin Console session
    remains trusted before step-up re-authentication is required.
    Default: PT1H (1 hour -- NIST SP 800-53 AC-12 / PAM best practice for highest-privilege tier).

    ISO 8601 duration reference:
      PT0S  = 0 seconds  -- re-authenticate on EVERY page load (disables session; REFUSED by this script)
      PT15M = 15 minutes
      PT30M = 30 minutes
      PT1H  = 1 hour     -- Tier 1 DEFAULT (PAM best practice; matches max expected SuperAdmin task)
      PT2H  = 2 hours    -- Tier 2/3 DEFAULT (PAM best practice; matches max expected OrgAdmin task)
      PT4H  = 4 hours    -- WARNING: exceeds PAM best practice; script will prompt for confirmation
      PT8H  = 8 hours    -- WARNING: full-workday window on shared account; not recommended
      PT12H = 12 hours   -- NIST AAL2/AAL3 absolute maximum; script refuses values above this

    COMPLIANCE NOTE: Values above the tier default trigger a runtime warning citing NIST SP 800-53 AC-12.
    The implementor may accept the warning to proceed. Values above PT12H are refused unconditionally.

    SCOPE: This setting ONLY applies to users in the CyberArk-HLA-SuperAdmin group.
    All other Okta admin users are unaffected.

.PARAMETER Tier2ReauthDuration
    ISO 8601 duration for Tier 2 (Org Admin) Admin Console session trust.
    Default: PT2H (2 hours -- PAM best practice; covers standard admin task window).
    Values above PT2H trigger a NIST compliance warning. Values above PT12H are refused.
    SCOPE: Only applies to CyberArk-HLA-OrgAdmin group members.

.PARAMETER Tier3ReauthDuration
    ISO 8601 duration for Tier 3 (Operational Users) Admin Console session trust.
    Default: PT2H (2 hours -- PAM best practice; help desk tasks rarely exceed 30-60 min).
    Values above PT2H trigger a NIST compliance warning. Values above PT12H are refused.
    SCOPE: Only applies to CyberArk-HLA-Users group members.

.EXAMPLE
    .\Deploy-OktaHLABootstrap.ps1 -Action WhatIf -ApiToken $env:OKTA_API_TOKEN
    Dry-run: shows what would be created/updated, no changes made.

.EXAMPLE
    .\Deploy-OktaHLABootstrap.ps1 -Action Deploy -ApiToken $env:OKTA_API_TOKEN
    Interactive deploy: prompts for confirmation at each step.

.EXAMPLE
    .\Deploy-OktaHLABootstrap.ps1 -Action Deploy -ApiToken $env:OKTA_API_TOKEN `
        -Tier1ReauthDuration PT1H -Tier2ReauthDuration PT2H -Tier3ReauthDuration PT2H
    Deploy with explicit session durations (same as defaults -- NIST PAM best practice).

.EXAMPLE
    .\Deploy-OktaHLABootstrap.ps1 -Action Deploy -ApiToken $env:OKTA_API_TOKEN `
        -Tier1ReauthDuration PT2H -Tier2ReauthDuration PT4H -Tier3ReauthDuration PT4H
    Deploy with extended session windows. Script will warn that these exceed PAM best
    practice (NIST SP 800-53 AC-12) and prompt for confirmation before proceeding.

.EXAMPLE
    .\Deploy-OktaHLABootstrap.ps1 -Action Inspect -ApiToken $env:OKTA_API_TOKEN
    Read-only: displays current Layer 1 (OKTA_SIGN_ON) and Layer 2 (ACCESS_POLICY)
    session settings for all HLA tiers, with NIST compliance status tags. Lists
    available rollback snapshots. No changes made.

.EXAMPLE
    .\Deploy-OktaHLABootstrap.ps1 -Action Rollback -ApiToken $env:OKTA_API_TOKEN
    Restore Layer 2 (Step 11) ACCESS_POLICY rules from the most recent rollback snapshot.
    Shows current vs snapshot values and prompts for confirmation.

.EXAMPLE
    .\Deploy-OktaHLABootstrap.ps1 -Action Rollback -ApiToken $env:OKTA_API_TOKEN `
        -RollbackFile '.\Rollbacks\Deploy-OktaHLABootstrap-Step11-20260425-173200-ae5df6eb.json'
    Rollback to a specific snapshot by file path.

.EXAMPLE
    .\Deploy-OktaHLABootstrap.ps1 -Action Teardown -ApiToken $env:OKTA_API_TOKEN
    Interactive teardown: shows discovered resources, prompts for which to remove.

.PARAMETER RollbackFile
    Path to a specific rollback snapshot JSON file to use with -Action Rollback.
    If omitted, the most recent snapshot in the Rollbacks\ directory is used.
    Snapshots are created automatically at the start of Step 11 during each Deploy.

.EXAMPLE
    .\Deploy-OktaHLABootstrap.ps1 -Action Deploy -AcceptDefaults
    Non-interactive deploy for CI pipelines.

.NOTES
    Version:    2.8.0
    CR Ref:     CHG00XXXXX -- Implement 3-Tier CyberArk HLA in Okta
    Requires:   Okta Super Admin API token
    Companion:  Invoke-OktaHLAVaultSetup.ps1 (CyberArk-side automation)

    SESSION TIMING ARCHITECTURE
    ===========================
    Okta enforces session duration at two independent layers:

    Layer 1 -- Global Session Policy (OKTA_SIGN_ON, Step 10 of this script)
      Controls the overall Okta session cookie lifetime:
        maxSessionIdleMinutes     -- session expires after N minutes with no activity
        maxSessionLifetimeMinutes -- absolute ceiling regardless of activity
      Applied per-tier via group-scoped policies.

    Layer 2 -- App Authentication Policy (ACCESS_POLICY, Step 11 of this script)
      Controls how long the authentication ASSURANCE for a specific app (e.g., the
      Okta Admin Console) remains trusted before step-up MFA is required again.
        reauthenticateIn -- PT0S means "always re-prompt" (breaks PSM sessions);
                           PT8H means "trust the MFA for 8 hours after initial login"
      Applied per-tier via group-scoped rules on the Admin Console policy ONLY.
      ** This does NOT affect other Okta apps or non-HLA admin users. **

    For CyberArk PSM sessions:
      - PSM logs in once (password + TOTP) at session start
      - The browser session must stay alive for the duration of the privileged task
      - Layer 2 reauthenticateIn must be >= the longest expected PSM session duration
      - Setting PT0S at Layer 2 kills the session on every navigation -- refused by this script
      - CyberArk PSM session timeout (connection component) should be <= reauthenticateIn
        so CyberArk terminates the session before Okta does (graceful vs. mid-task eviction)

    NIST COMPLIANCE THRESHOLDS (NIST SP 800-53 AC-12, SP 800-207):
      Tier 1 (SuperAdmin) -- PAM recommended maximum: PT1H
      Tier 2 (OrgAdmin)   -- PAM recommended maximum: PT2H
      Tier 3 (Users)      -- PAM recommended maximum: PT2H
      NIST AAL2/AAL3 absolute maximum (all tiers): PT12H

      This script warns when a value exceeds the tier's PAM-recommended maximum and
      prompts the implementor to confirm the deviation. Values above PT12H are refused
      unconditionally as they exceed the NIST AAL2/AAL3 lifetime ceiling.

    IDLE TIMEOUT BEHAVIOUR:
      The idle timer (Layer 1 maxSessionIdleMinutes) resets on any authenticated
      request -- page navigation, form submission, admin console API calls. It is NOT
      a wall-clock timer from login. The session lifetime IS a wall-clock ceiling:
      the session is terminated at that absolute limit regardless of activity.

    SESSION COOKIE PROTECTION:
      Okta ASN Session Binding (default-on) invalidates cookies replayed from a
      different network/ISP. IP Session Binding (optional, Admin Console setting)
      provides stronger protection by binding to the exact egress IP. Both reduce
      the residual value of stolen session cookies independent of timeout values.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [ValidateSet('Deploy', 'Teardown', 'WhatIf', 'Inspect', 'Rollback', 'Restore')]
    [string]$Action,

    [string]$ApiToken,

    [string]$OktaDomain,

    [ValidateSet('SUPER_ADMIN', 'ORG_ADMIN')]
    [string]$HlaPrimaryRole = 'ORG_ADMIN',

    [switch]$AcceptDefaults,

    [switch]$Force,

    [string]$SIEMLogPath,

    # Path to a specific rollback snapshot file. Used with -Action Rollback.
    # If omitted, the most recent snapshot in the Rollbacks\ directory is used.
    [string]$RollbackFile = '',

    # Admin Console ACCESS_POLICY session trust durations (ISO 8601).
    # Defaults are PAM best practice per NIST SP 800-53 AC-12 / SP 800-207.
    # Values above the tier's recommended maximum trigger a runtime compliance warning.
    # Values above PT12H (NIST AAL2/3 ceiling) are refused unconditionally.
    # See .NOTES SESSION TIMING ARCHITECTURE for full explanation.
    [ValidatePattern('^PT(\d+H)?(\d+M)?(\d+S)?$')]
    [string]$Tier1ReauthDuration = 'PT1H',   # Tier 1 PAM best practice: 1 hour

    [ValidatePattern('^PT(\d+H)?(\d+M)?(\d+S)?$')]
    [string]$Tier2ReauthDuration = 'PT2H',   # Tier 2 PAM best practice: 2 hours

    [ValidatePattern('^PT(\d+H)?(\d+M)?(\d+S)?$')]
    [string]$Tier3ReauthDuration = 'PT2H',   # Tier 3 PAM best practice: 2 hours

    # OKTA_SIGN_ON session settings (Layer 1). Controls Okta session cookie lifetime.
    # Idle = rolling (resets on activity). Lifetime = absolute wall-clock cutoff.
    # NIST SP 800-53 AC-12 ceiling = 720 minutes (12 hours).
    [ValidateRange(1, 720)]
    [int]$Tier1IdleMinutes     = 15,   # Tier 1 NIST best practice: 15 min
    [ValidateRange(1, 720)]
    [int]$Tier1LifetimeMinutes = 60,   # Tier 1 NIST best practice: 60 min (1 hour)
    [ValidateRange(1, 720)]
    [int]$Tier2IdleMinutes     = 30,   # Tier 2 NIST best practice: 30 min
    [ValidateRange(1, 720)]
    [int]$Tier2LifetimeMinutes = 120,  # Tier 2 NIST best practice: 120 min (2 hours)
    [ValidateRange(1, 720)]
    [int]$Tier3IdleMinutes     = 30,   # Tier 3 NIST best practice: 30 min
    [ValidateRange(1, 720)]
    [int]$Tier3LifetimeMinutes = 120,  # Tier 3 NIST best practice: 120 min (2 hours)

    # TOTP provider for Step 5.5 enrollment policy and cpm-simulator enroll-totp.
    # OKTA  = okta_verify TOTP (RFC 6238). Standard authenticator, usually already
    #         active on OIE tenants. No tenant-wide activation needed.
    # GOOGLE = google_otp (RFC 6238, no push capability). Requires tenant-wide
    #          authenticator activation -- operator is prompted before this change.
    [ValidateSet('GOOGLE', 'OKTA')]
    [string]$TOTPProvider = 'OKTA',

    # Encrypt PreDeploy snapshots using AES-256-CBC with PBKDF2 key derivation.
    # Default: $true on Windows (uses Credential Manager nonce for machine-binding),
    # $false on macOS/Linux (Credential Manager unavailable, file-key-only mode).
    # Encrypted snapshots use .enc extension; plaintext use .json.
    [bool]$SnapshotEncryption = ($env:OS -eq 'Windows_NT'),

    # Maximum number of PreDeploy snapshots to retain. When exceeded after a new
    # snapshot is saved, the oldest are deleted. Step-specific snapshots are not
    # counted or deleted. Set to 0 to disable rotation.
    [ValidateRange(0, 100)]
    [int]$SnapshotRetention = 10
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

#region Constants

$Script:VERSION = '2.8.0'
$Script:CorrelationId = [guid]::NewGuid().ToString()
$Script:ROLLBACK_DIR = Join-Path $PSScriptRoot 'Rollbacks'

# Step 5.5: TOTP Authenticator & Enrollment Policy
$Script:HLA_ENROLLMENT_POLICY_NAME = 'CyberArk HLA TOTP Enrollment Policy'
$Script:HLA_ENROLLMENT_RULE_NAME   = 'CyberArk HLA Groups -- TOTP Required'
$Script:GOOGLE_OTP_KEY             = 'google_otp'
$Script:OKTA_VERIFY_KEY            = 'okta_verify'

# Provider-derived keys (set from -TOTPProvider parameter)
$Script:SELECTED_TOTP_KEY = if ($TOTPProvider -eq 'OKTA') { $Script:OKTA_VERIFY_KEY } else { $Script:GOOGLE_OTP_KEY }
$Script:BLOCKED_TOTP_KEY  = if ($TOTPProvider -eq 'OKTA') { $Script:GOOGLE_OTP_KEY } else { $Script:OKTA_VERIFY_KEY }

# Step 5.5 outcome -- populated by Invoke-Step55, read by Deploy Summary and Inspect
$Script:Step55Status = $null

# Resource naming conventions (must match CR and Invoke-OktaHLAVaultSetup.ps1)
$Script:GROUP_NAMES = @(
    'CyberArk-HLA-SuperAdmin',
    'CyberArk-HLA-OrgAdmin',
    'CyberArk-HLA-Users',
    'CyberArk-Vaulted-Admins',
    'Break-Glass-Admins'
)

$Script:POLICY_NAMES = @(
    'Break-Glass Emergency Sign-On Policy',
    'Tier 1: Super Admin HLA Sign-On Policy',
    'Tier 2: Org Admin HLA Sign-On Policy',
    'Tier 3: Operational Users HLA Sign-On Policy'
)

$Script:CUSTOM_ROLE_NAME    = 'CyberArk CPM Credential Manager'
$Script:RESOURCE_SET_NAME   = 'CyberArk CPM Managed Accounts'
$Script:NETWORK_ZONE_NAME   = 'CyberArk-Infrastructure'
$Script:SSWS_TOKEN_NAME     = 'CyberArk-CPM-SSWS'
$Script:ACCOUNT_FILTER      = 'svc-okta-'

# Snapshot encryption -- key storage and Credential Manager nonce
$Script:SNAP_KEY_DIR    = Join-Path $(if ($env:USERPROFILE) { $env:USERPROFILE } else { $HOME }) '.cyberark'
$Script:SNAP_KEY_FILE   = 'okta-snapshot.key'
$Script:SNAP_CM_TARGET  = 'OktaHLASnapshot'

# User definitions -- populated by Build-UserDefinitions with CR-standard layout
$Script:USER_DEFS = @()

# SIEM state
$Script:SIEMEnabled = $false
$Script:SIEMLogFile = $null

#endregion

#region Logging

function Initialize-SIEMLogging {
    param([string]$LogDir = '')
    if ([string]::IsNullOrWhiteSpace($LogDir)) {
        $LogDir = Join-Path $PSScriptRoot 'Logs'
    }
    try {
        if (-not (Test-Path $LogDir)) {
            New-Item $LogDir -ItemType Directory -Force | Out-Null
        }
        $dateStr = Get-Date -Format 'yyyy-MM-dd'
        $Script:SIEMLogFile = Join-Path $LogDir "OktaHLABootstrap_${dateStr}_$($Script:CorrelationId.Substring(0,8)).json"
        $Script:SIEMEnabled = $true
    }
    catch {
        Write-Host "[SIEM] Cannot create log directory '$LogDir': $_  -- file logging disabled" -ForegroundColor Yellow
        $Script:SIEMEnabled = $false
    }
}

function Write-SIEMLog {
    param(
        [string]$Level   = 'INFO',
        [string]$Message = '',
        [string]$Action  = '',
        [hashtable]$Fields = $null
    )
    if (-not $Script:SIEMEnabled) { return }

    $severity = switch ($Level) {
        'ERROR' { 'ERROR' }
        'WARN'  { 'WARN' }
        'DEBUG' { 'DEBUG' }
        default { 'INFO' }
    }
    $user  = if ($env:USERNAME) { $env:USERNAME } elseif ($env:USER) { $env:USER } else { 'Unknown' }
    $hname = if ($env:COMPUTERNAME) { $env:COMPUTERNAME } elseif ($env:HOSTNAME) { $env:HOSTNAME } else { $env:NAME }

    $entry = [ordered]@{
        Timestamp     = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
        Severity      = $severity
        Component     = 'OktaHLABootstrap'
        Version       = $Script:VERSION
        Action        = $Action
        Message       = $Message
        CorrelationID = $Script:CorrelationId
        User          = $user
        Environment   = 'OktaHLABootstrap'
        Host          = $hname
        DryRun        = ($Action -eq 'WhatIf' -or $Script:IsDryRun)
    }
    if ($Fields) {
        foreach ($k in $Fields.Keys) { $entry[$k] = $Fields[$k] }
    }
    $json = $entry | ConvertTo-Json -Compress -Depth 5
    try { Add-Content -Path $Script:SIEMLogFile -Value $json -Encoding UTF8 -ErrorAction SilentlyContinue } catch {}
}

function Write-Log {
    param(
        [ValidateSet('INFO','WARN','ERROR','SKIP','OK','STEP','DEBUG')]
        [string]$Level = 'INFO',
        [string]$Message,
        [string]$Action = '',
        [hashtable]$Fields = $null
    )
    $ts    = Get-Date -Format 'HH:mm:ss'
    $corr  = $Script:CorrelationId.Substring(0,8)
    $color = switch ($Level) {
        'INFO'  { 'Cyan' }
        'WARN'  { 'Yellow' }
        'ERROR' { 'Red' }
        'SKIP'  { 'DarkGray' }
        'OK'    { 'Green' }
        'STEP'  { 'White' }
        'DEBUG' { 'DarkGray' }
    }
    Write-Host "[$ts][$corr][$Level] $Message" -ForegroundColor $color
    Write-SIEMLog -Level $Level -Message $Message -Action $Action -Fields $Fields
}

#endregion

#region Okta API

$Script:OktaHeaders = $null
$Script:OktaBaseUrl = $null
$Script:IsDryRun    = ($Action -eq 'WhatIf')
$Script:Force       = [bool]$Force

function Initialize-OktaSession {
    param(
        [Parameter(Mandatory)][string]$Token,
        [Parameter(Mandatory)][string]$Domain
    )
    $Script:OktaBaseUrl = "https://$Domain"
    $Script:OktaHeaders = @{
        'Authorization' = "SSWS $Token"
        'Accept'        = 'application/json'
        'Content-Type'  = 'application/json'
    }
}

function Invoke-OktaApi {
    <#
    .SYNOPSIS
        Executes an Okta REST API call with retry on 429/503.
        Returns $null on 404 (for teardown discovery) unless -Strict is set.
    #>
    param(
        [Parameter(Mandatory)][string]$Path,
        [ValidateSet('GET','POST','PUT','DELETE')][string]$Method = 'GET',
        [object]$Body = $null,
        [int]$MaxRetries = 3,
        [switch]$Strict,
        [switch]$RawResponse
    )
    $url = "$Script:OktaBaseUrl$Path"
    $attempt = 0
    do {
        $attempt++
        try {
            $params = @{
                Uri             = $url
                Method          = $Method
                Headers         = $Script:OktaHeaders
                UseBasicParsing = $true
            }
            if ($null -ne $Body) {
                $params['Body'] = ($Body | ConvertTo-Json -Depth 10)
            }
            $resp = Invoke-WebRequest @params
            if ($RawResponse) { return $resp }
            if ($resp.Content) {
                return ($resp.Content | ConvertFrom-Json)
            }
            return $null
        }
        catch {
            $status = $null
            if ($_.Exception.Response) {
                $status = [int]$_.Exception.Response.StatusCode
            }
            # 404 = resource not found (expected during teardown discovery)
            if ($status -eq 404 -and -not $Strict) {
                return $null
            }
            if ($status -in @(429, 503) -and $attempt -lt $MaxRetries) {
                $retryAfter = 2 * $attempt
                Write-Log -Level WARN -Message "Okta $Method $Path => $status. Retry $attempt/$MaxRetries in ${retryAfter}s..."
                Start-Sleep -Seconds $retryAfter
            }
            else {
                $errBody = ''
                try {
                    $stream = $_.Exception.Response.GetResponseStream()
                    $reader = [System.IO.StreamReader]::new($stream)
                    $errBody = $reader.ReadToEnd()
                }
                catch {}
                throw "Okta API $Method $Path failed (HTTP $status): $errBody`n$($_.Exception.Message)"
            }
        }
    } while ($attempt -lt $MaxRetries)
}

function Get-SecureInput {
    param([string]$Prompt)
    $ss = Read-Host -Prompt $Prompt -AsSecureString
    $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($ss)
    try { return [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr) }
    finally { [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
}

function Confirm-UserChoice {
    param(
        [string]$Prompt,
        [string]$Default = 'Y'
    )
    if ($AcceptDefaults) { return ($Default -eq 'Y') }
    $indicator = if ($Default -eq 'Y') { '[Y/n]' } else { '[y/N]' }
    $response  = Read-Host "$Prompt $indicator"
    if ([string]::IsNullOrWhiteSpace($response)) { $response = $Default }
    return $response.Trim().ToUpper() -eq 'Y'
}

function Show-SelectionMenu {
    <#
    .SYNOPSIS
        Displays a numbered list and lets the user select items.
        Returns an array of selected indices (0-based).
    #>
    param(
        [Parameter(Mandatory)][string[]]$Items,
        [string]$Title = 'Select items',
        [switch]$AllByDefault
    )

    if ($AcceptDefaults) {
        if ($AllByDefault) { return @(0..($Items.Count - 1)) }
        return @()
    }

    Write-Host ""
    Write-Host "  $Title" -ForegroundColor White
    Write-Host "  $('-' * 60)" -ForegroundColor DarkGray
    for ($i = 0; $i -lt $Items.Count; $i++) {
        $marker = if ($AllByDefault) { '[*]' } else { '[ ]' }
        Write-Host "  $($i + 1). $marker $($Items[$i])" -ForegroundColor Cyan
    }
    Write-Host ""
    $defaultHint = if ($AllByDefault) { 'all' } else { 'none' }
    Write-Host "  Enter numbers separated by commas (e.g. 1,3,5), 'all', or press Enter for $defaultHint" -ForegroundColor DarkGray
    $input = Read-Host "  Selection"

    if ([string]::IsNullOrWhiteSpace($input)) {
        if ($AllByDefault) { return @(0..($Items.Count - 1)) }
        return @()
    }
    if ($input.Trim().ToLower() -eq 'all') {
        return @(0..($Items.Count - 1))
    }
    if ($input.Trim().ToLower() -eq 'none') {
        return @()
    }

    $selected = @()
    foreach ($part in $input.Split(',')) {
        $num = $part.Trim() -as [int]
        if ($null -ne $num -and $num -ge 1 -and $num -le $Items.Count) {
            $selected += ($num - 1)
        }
    }
    return $selected
}

function Build-UserDefinitions {
    <#
    .SYNOPSIS
        Builds the CR-standard account layout and displays it for confirmation.
        Layout: S01, O01, H01, H02, A01, BG01, R01, CPM01 (8 accounts).
    #>

    # CR default layout
    $Script:USER_DEFS = @(
        @{ Code = 'S01';   First = 'IAM';     Last = 'S01';   Role = 'SUPER_ADMIN';     Tier = 1; Group = 'CyberArk-HLA-SuperAdmin' }
        @{ Code = 'O01';   First = 'IAM';     Last = 'O01';   Role = 'ORG_ADMIN';       Tier = 2; Group = 'CyberArk-HLA-OrgAdmin' }
        @{ Code = 'H01';   First = 'IAM';     Last = 'H01';   Role = 'HELP_DESK_ADMIN'; Tier = 3; Group = 'CyberArk-HLA-Users' }
        @{ Code = 'H02';   First = 'IAM';     Last = 'H02';   Role = 'HELP_DESK_ADMIN'; Tier = 3; Group = 'CyberArk-HLA-Users' }
        @{ Code = 'A01';   First = 'IAM';     Last = 'A01';   Role = 'APP_ADMIN';       Tier = 3; Group = 'CyberArk-HLA-Users' }
        @{ Code = 'BG01';  First = 'IAM';     Last = 'BG01';  Role = 'SUPER_ADMIN';     Tier = 0; Group = 'Break-Glass-Admins' }
        @{ Code = 'R01';   First = 'IAM';     Last = 'R01';   Role = 'READ_ONLY_ADMIN'; Tier = 0; Group = $null }
        @{ Code = 'CPM01'; First = 'IAM-Svc'; Last = 'CPM01'; Role = $null;             Tier = 0; Group = $null }
    )

    # Display summary table
    Write-Host ""
    Write-Host "  =============================================" -ForegroundColor White
    Write-Host "  ACCOUNT PLAN ($($Script:USER_DEFS.Count) accounts)" -ForegroundColor White
    Write-Host "  =============================================" -ForegroundColor White
    Write-Host ""
    Write-Host ("  {0,-10} {1,-20} {2,-28} {3,-5}" -f 'Code', 'Role', 'Group', 'Tier') -ForegroundColor DarkGray
    Write-Host ("  {0,-10} {1,-20} {2,-28} {3,-5}" -f '----', '----', '-----', '----') -ForegroundColor DarkGray
    foreach ($def in $Script:USER_DEFS) {
        $roleName  = if ($def.Role) { $def.Role } else { '(custom role later)' }
        $groupName = if ($def.Group) { $def.Group } else { '-' }
        Write-Host ("  {0,-10} {1,-20} {2,-28} {3,-5}" -f $def.Code, $roleName, $groupName, $def.Tier) -ForegroundColor Cyan
    }
    Write-Host ""

    if (-not (Confirm-UserChoice -Prompt "  Proceed with this account layout?" -Default 'Y')) {
        Write-Log -Level WARN -Message "Account layout rejected by operator."
        return $false
    }
    return $true
}

function Test-ApiPermissions {
    <#
    .SYNOPSIS
        Validates that the SSWS token has the required permissions for the requested action
        BEFORE any resources are created. Tests each API endpoint the script will call.
        Returns $true if all checks pass, $false if any critical check fails.
    #>
    param(
        [ValidateSet('Deploy', 'Teardown', 'WhatIf')]
        [string]$RequiredAction = 'Deploy'
    )

    Write-Host ""
    Write-Host "  =============================================" -ForegroundColor White
    Write-Host "  PRE-FLIGHT: API PERMISSION VALIDATION" -ForegroundColor White
    Write-Host "  =============================================" -ForegroundColor White
    Write-Host ""

    $checks = [ordered]@{}
    $allPassed = $true

    # --- Check 1: Org info (basic connectivity, already validated but re-confirm) ---
    try {
        $org = Invoke-OktaApi -Path '/api/v1/org' -Strict
        $orgN = if ($org.PSObject.Properties['name'] -and $null -ne $org.name) { $org.name } else { '(integrator)' }
        $orgS = if ($org.PSObject.Properties['subdomain'] -and $null -ne $org.subdomain) { $org.subdomain } else { '' }
        $checks['Org Info (GET /api/v1/org)'] = @{ Status = 'PASS'; Detail = "$orgN ($orgS)" }
    }
    catch {
        $checks['Org Info (GET /api/v1/org)'] = @{ Status = 'FAIL'; Detail = "Cannot read org: $_" }
        $allPassed = $false
    }

    # --- Check 2: Token identity and role ---
    $tokenLevel = 'Unknown'
    try {
        $me = Invoke-OktaApi -Path '/api/v1/users/me' -Strict
        $meLogin = try { $me.profile.login } catch { $me.id }
        $checks['Token Identity (GET /api/v1/users/me)'] = @{ Status = 'PASS'; Detail = $meLogin }

        try {
            $roles = Invoke-OktaApi -Path "/api/v1/users/$($me.id)/roles"
            $roleTypes = @()
            if ($roles) { $roleTypes = @($roles | ForEach-Object { $_.type }) }
            if ('SUPER_ADMIN' -in $roleTypes) {
                $tokenLevel = 'SUPER_ADMIN'
                $checks['Token Role Level'] = @{ Status = 'PASS'; Detail = "SUPER_ADMIN (full permissions)" }
            }
            elseif ('ORG_ADMIN' -in $roleTypes) {
                $tokenLevel = 'ORG_ADMIN'
                $checks['Token Role Level'] = @{ Status = 'WARN'; Detail = "ORG_ADMIN (some operations may fail -- Super Admin recommended)" }
            }
            else {
                $tokenLevel = 'LIMITED'
                $checks['Token Role Level'] = @{ Status = 'FAIL'; Detail = "Insufficient role level: $($roleTypes -join ', '). Super Admin required." }
                $allPassed = $false
            }
        }
        catch {
            $checks['Token Role Level'] = @{ Status = 'WARN'; Detail = "Cannot enumerate roles (may still work): $_" }
        }
    }
    catch {
        $checks['Token Identity (GET /api/v1/users/me)'] = @{ Status = 'FAIL'; Detail = "Cannot identify token owner: $_" }
        $allPassed = $false
    }

    # --- Check 3: User listing (required for both deploy and teardown) ---
    try {
        $testSearch = [uri]::EscapeDataString("profile.login sw `"$Script:ACCOUNT_FILTER`"")
        $users = Invoke-OktaApi -Path "/api/v1/users?search=$testSearch&limit=1"
        $checks['List Users (GET /api/v1/users)'] = @{ Status = 'PASS'; Detail = "User search operational" }
    }
    catch {
        $checks['List Users (GET /api/v1/users)'] = @{ Status = 'FAIL'; Detail = "Cannot search users: $_" }
        $allPassed = $false
    }

    # --- Check 4: Group listing ---
    try {
        $groups = Invoke-OktaApi -Path '/api/v1/groups?limit=1'
        $checks['List Groups (GET /api/v1/groups)'] = @{ Status = 'PASS'; Detail = "Group listing operational" }
    }
    catch {
        $checks['List Groups (GET /api/v1/groups)'] = @{ Status = 'FAIL'; Detail = "Cannot list groups: $_" }
        $allPassed = $false
    }

    # --- Check 5: Policy listing ---
    try {
        $policies = Invoke-OktaApi -Path '/api/v1/policies?type=OKTA_SIGN_ON&limit=1'
        $checks['List Policies (GET /api/v1/policies)'] = @{ Status = 'PASS'; Detail = "Policy listing operational" }
    }
    catch {
        $checks['List Policies (GET /api/v1/policies)'] = @{ Status = 'WARN'; Detail = "Cannot list policies (may use ACCESS_POLICY type instead): $_" }
    }

    # --- Check 6: Zone listing ---
    try {
        $zones = Invoke-OktaApi -Path '/api/v1/zones?limit=1'
        $checks['List Zones (GET /api/v1/zones)'] = @{ Status = 'PASS'; Detail = "Zone listing operational" }
    }
    catch {
        $checks['List Zones (GET /api/v1/zones)'] = @{ Status = 'FAIL'; Detail = "Cannot list zones: $_" }
        if ($RequiredAction -ne 'Teardown') { $allPassed = $false }
    }

    # --- Check 7: IAM Roles API (custom roles -- requires Super Admin) ---
    try {
        $iamRoles = Invoke-OktaApi -Path '/api/v1/iam/roles?limit=1'
        $checks['IAM Roles API (GET /api/v1/iam/roles)'] = @{ Status = 'PASS'; Detail = "Custom roles API accessible" }
    }
    catch {
        $status = if ($_ -match 'HTTP (\d+)') { $matches[1] } else { 'unknown' }
        if ($status -eq '403') {
            $checks['IAM Roles API (GET /api/v1/iam/roles)'] = @{ Status = 'WARN'; Detail = "403 Forbidden -- custom role/resource set/binding operations will fail. Super Admin required." }
        }
        else {
            $checks['IAM Roles API (GET /api/v1/iam/roles)'] = @{ Status = 'WARN'; Detail = "IAM API error ($status) -- custom role features may not work" }
        }
    }

    # --- Check 8: IAM Resource Sets API ---
    try {
        $iamSets = Invoke-OktaApi -Path '/api/v1/iam/resource-sets?limit=1'
        $checks['IAM Resource Sets (GET /api/v1/iam/resource-sets)'] = @{ Status = 'PASS'; Detail = "Resource sets API accessible" }
    }
    catch {
        $checks['IAM Resource Sets (GET /api/v1/iam/resource-sets)'] = @{ Status = 'WARN'; Detail = "Resource sets API not accessible (may require Super Admin)" }
    }

    # --- Check 9: Token listing (for teardown) ---
    if ($RequiredAction -eq 'Teardown') {
        try {
            $tokens = Invoke-OktaApi -Path '/api/v1/api-tokens?limit=1'
            $checks['List API Tokens (GET /api/v1/api-tokens)'] = @{ Status = 'PASS'; Detail = "Token listing operational" }
        }
        catch {
            $checks['List API Tokens (GET /api/v1/api-tokens)'] = @{ Status = 'WARN'; Detail = "Cannot list tokens (may need manual revocation)" }
        }
    }

    # --- Display results ---
    $passCount = 0
    $warnCount = 0
    $failCount = 0

    foreach ($check in $checks.GetEnumerator()) {
        $status = $check.Value.Status
        $detail = $check.Value.Detail
        $color  = switch ($status) { 'PASS' { 'Green' } 'WARN' { 'Yellow' } 'FAIL' { 'Red' } }
        $icon   = switch ($status) { 'PASS' { 'PASS' } 'WARN' { 'WARN' } 'FAIL' { 'FAIL' } }

        Write-Host ("  [{0}] {1}" -f $icon, $check.Key) -ForegroundColor $color
        Write-Host ("         {0}" -f $detail) -ForegroundColor DarkGray

        switch ($status) { 'PASS' { $passCount++ } 'WARN' { $warnCount++ } 'FAIL' { $failCount++ } }

        # Log to SIEM
        Write-SIEMLog -Level $(if ($status -eq 'FAIL') { 'ERROR' } elseif ($status -eq 'WARN') { 'WARN' } else { 'INFO' }) `
            -Message "Pre-flight: $($check.Key) = $status -- $detail" `
            -Action 'PreFlightCheck' -Fields @{ Check = $check.Key; Status = $status; TokenLevel = $tokenLevel }
    }

    Write-Host ""
    Write-Host "  ----- Pre-Flight Summary -----" -ForegroundColor White
    Write-Host "  PASS: $passCount  WARN: $warnCount  FAIL: $failCount" -ForegroundColor $(if ($failCount -gt 0) { 'Red' } elseif ($warnCount -gt 0) { 'Yellow' } else { 'Green' })
    Write-Host ""

    if (-not $allPassed) {
        Write-Host "  CRITICAL: One or more required permission checks FAILED." -ForegroundColor Red
        Write-Host "  The token must have Super Admin privilege to deploy all resources." -ForegroundColor Red
        Write-Host ""
        if (-not (Confirm-UserChoice -Prompt "  Continue anyway (some operations WILL fail)?" -Default 'N')) {
            return $false
        }
        Write-Log -Level WARN -Message "Operator chose to continue despite failed pre-flight checks" -Action 'PreFlightOverride'
    }
    elseif ($warnCount -gt 0) {
        Write-Host "  Some permission checks returned warnings. Deploy may partially succeed." -ForegroundColor Yellow
        if (-not (Confirm-UserChoice -Prompt "  Continue with warnings?" -Default 'Y')) {
            return $false
        }
    }
    else {
        Write-Log -Level OK -Message "All pre-flight permission checks passed ($passCount/$passCount)" -Action 'PreFlightComplete'
    }

    return $true
}

function Confirm-StepResult {
    <#
    .SYNOPSIS
        Validates that a resource was actually created by re-querying the API.
        Logs the validation result and returns $true/$false.
    #>
    param(
        [Parameter(Mandatory)][string]$StepName,
        [Parameter(Mandatory)][string]$ResourceType,
        [Parameter(Mandatory)][string]$ResourceId,
        [string]$ValidationPath
    )

    if ($Script:IsDryRun) {
        Write-Log -Level DEBUG -Message "  [Validate] $StepName -- skipped (dry-run)" -Action 'ValidateStep'
        return $true
    }
    if ($ResourceId -like 'WHATIF-*') {
        return $true
    }
    if (-not $ValidationPath) {
        Write-Log -Level DEBUG -Message "  [Validate] $StepName -- no validation path, skipping" -Action 'ValidateStep'
        return $true
    }

    try {
        $result = Invoke-OktaApi -Path $ValidationPath
        if ($null -ne $result) {
            Write-Log -Level OK -Message "  [Validate] $StepName -- $ResourceType $ResourceId confirmed" `
                -Action 'ValidateStep' -Fields @{ Step = $StepName; ResourceType = $ResourceType; ResourceId = $ResourceId; Result = 'PASS' }
            return $true
        }
        else {
            Write-Log -Level ERROR -Message "  [Validate] $StepName -- $ResourceType $ResourceId NOT FOUND after creation" `
                -Action 'ValidateStep' -Fields @{ Step = $StepName; ResourceType = $ResourceType; ResourceId = $ResourceId; Result = 'FAIL' }
            return $false
        }
    }
    catch {
        Write-Log -Level WARN -Message "  [Validate] $StepName -- validation query failed: $_" `
            -Action 'ValidateStep' -Fields @{ Step = $StepName; ResourceType = $ResourceType; ResourceId = $ResourceId; Result = 'ERROR' }
        return $false
    }
}

#endregion

#region Password Generation

function New-SecurePassword {
    <#
    .SYNOPSIS
        Generates a cryptographically random password meeting Okta complexity requirements.
        Uses only ASCII printable characters, avoids ambiguous chars and account name substrings.
    #>
    param([int]$Length = 20)

    # Character pools
    $upper  = 'ABCDEFGHJKLMNPQRSTUVWXYZ'
    $lower  = 'abcdefghjkmnpqrstuvwxyz'
    $digits = '23456789'
    $specials = '!@#$%^&*-_=+'
    $all = $upper + $lower + $digits + $specials

    $rng = [System.Security.Cryptography.RNGCryptoServiceProvider]::new()
    $bytes = [byte[]]::new($Length)

    do {
        $rng.GetBytes($bytes)
        $pw = -join ($bytes | ForEach-Object { $all[$_ % $all.Length] })
    } until (
        $pw -cmatch '[A-Z]' -and
        $pw -cmatch '[a-z]' -and
        $pw -match '[0-9]' -and
        $pw -match '[!@#$%^&*\-_=+]'
    )
    $rng.Dispose()
    return $pw
}

#endregion

#region Discovery Functions (for Teardown)

function Find-OktaUsers {
    <#
    .SYNOPSIS
        Discovers all HLA-related users in Okta matching the svc-okta- prefix.
    #>
    Write-Log -Level INFO -Message "Discovering HLA users (prefix: $Script:ACCOUNT_FILTER)..."
    $encodedSearch = [uri]::EscapeDataString("profile.login sw `"$Script:ACCOUNT_FILTER`"")
    $users = Invoke-OktaApi -Path "/api/v1/users?search=$encodedSearch&limit=200"
    if (-not $users) { $users = @() }
    $users = @($users)
    Write-Log -Level INFO -Message "Found $($users.Count) user(s) matching prefix"
    return $users
}

function Find-OktaGroups {
    <#
    .SYNOPSIS
        Discovers HLA-related groups by name.
    #>
    Write-Log -Level INFO -Message "Discovering HLA groups..."
    $found = [System.Collections.Generic.List[object]]::new()
    foreach ($name in $Script:GROUP_NAMES) {
        $encodedQ = [uri]::EscapeDataString($name)
        $results = Invoke-OktaApi -Path "/api/v1/groups?q=$encodedQ&limit=10"
        if ($results) {
            $exact = @($results) | Where-Object { $_.profile.name -eq $name }
            foreach ($g in $exact) { $found.Add($g) }
        }
    }
    Write-Log -Level INFO -Message "Found $($found.Count) group(s)"
    return $found.ToArray()
}

function Find-OktaPolicies {
    <#
    .SYNOPSIS
        Discovers HLA sign-on policies by name.
        Searches both Authentication Policies (OIE) and legacy Sign-On Policies.
    #>
    Write-Log -Level INFO -Message "Discovering sign-on policies..."
    $found = [System.Collections.Generic.List[object]]::new()

    # Try OIE Authentication Policies first (/api/v1/policies?type=ACCESS_POLICY)
    foreach ($policyType in @('ACCESS_POLICY', 'OKTA_SIGN_ON')) {
        try {
            $policies = Invoke-OktaApi -Path "/api/v1/policies?type=$policyType&limit=200"
            if ($policies) {
                foreach ($p in @($policies)) {
                    if ($p.name -in $Script:POLICY_NAMES) {
                        # Avoid duplicates if found in both types
                        if (-not ($found | Where-Object { $_.id -eq $p.id })) {
                            $found.Add($p)
                        }
                    }
                }
            }
        }
        catch {
            Write-Log -Level DEBUG -Message "Policy type $policyType query returned error (may not be supported): $_"
        }
    }

    Write-Log -Level INFO -Message "Found $($found.Count) sign-on policy/ies"
    return $found.ToArray()
}

function Find-OktaNetworkZone {
    Write-Log -Level INFO -Message "Discovering network zone '$Script:NETWORK_ZONE_NAME'..."
    $zones = Invoke-OktaApi -Path '/api/v1/zones?limit=200'
    if (-not $zones) { return $null }
    $match = @($zones) | Where-Object { $_.name -eq $Script:NETWORK_ZONE_NAME }
    if ($match) {
        Write-Log -Level INFO -Message "Found network zone: $($match.id)"
        return $match
    }
    Write-Log -Level SKIP -Message "Network zone '$Script:NETWORK_ZONE_NAME' not found"
    return $null
}

function Find-OktaCustomRole {
    Write-Log -Level INFO -Message "Discovering custom role '$Script:CUSTOM_ROLE_NAME'..."
    try {
        $roles = Invoke-OktaApi -Path '/api/v1/iam/roles?limit=200'
        if (-not $roles) { return $null }
        # Roles response may be wrapped in .roles array or be flat
        $roleList = if ($roles.roles) { $roles.roles } else { @($roles) }
        $match = $roleList | Where-Object { $_.label -eq $Script:CUSTOM_ROLE_NAME }
        if ($match) {
            Write-Log -Level INFO -Message "Found custom role: $($match.id)"
            return $match
        }
    }
    catch {
        Write-Log -Level WARN -Message "Custom role API query failed (may require Super Admin): $_"
    }
    Write-Log -Level SKIP -Message "Custom role '$Script:CUSTOM_ROLE_NAME' not found"
    return $null
}

function Find-OktaResourceSet {
    Write-Log -Level INFO -Message "Discovering resource set '$Script:RESOURCE_SET_NAME'..."
    try {
        $sets = Invoke-OktaApi -Path '/api/v1/iam/resource-sets?limit=200'
        if (-not $sets) { return $null }
        $setList = if ($sets.'resource-sets') { $sets.'resource-sets' } else { @($sets) }
        $match = $setList | Where-Object { $_.label -eq $Script:RESOURCE_SET_NAME }
        if ($match) {
            Write-Log -Level INFO -Message "Found resource set: $($match.id)"
            return $match
        }
    }
    catch {
        Write-Log -Level WARN -Message "Resource set API query failed: $_"
    }
    Write-Log -Level SKIP -Message "Resource set '$Script:RESOURCE_SET_NAME' not found"
    return $null
}

function Find-OktaRoleBindings {
    <#
    .SYNOPSIS
        Discovers role bindings for the CPM service account user.
    #>
    param([string]$CpmUserId)
    if (-not $CpmUserId) { return @() }
    Write-Log -Level INFO -Message "Discovering role bindings for CPM user $CpmUserId..."
    try {
        $roles = Invoke-OktaApi -Path "/api/v1/users/$CpmUserId/roles"
        if (-not $roles) { return @() }
        $bindings = @($roles) | Where-Object { $_.label -eq $Script:CUSTOM_ROLE_NAME -or $_.type -eq 'CUSTOM' }
        Write-Log -Level INFO -Message "Found $($bindings.Count) custom role binding(s)"
        return $bindings
    }
    catch {
        Write-Log -Level WARN -Message "Cannot query role bindings for $CpmUserId : $_"
        return @()
    }
}

function Find-OktaTokens {
    <#
    .SYNOPSIS
        Discovers SSWS API tokens matching the CyberArk CPM token name.
        Note: Okta does not provide a public API to list tokens for other users.
        This searches the current user's tokens. For CPM tokens created by the
        service account, manual revocation may be needed.
    #>
    Write-Log -Level INFO -Message "Discovering API tokens..."
    try {
        # The /api/v1/api-tokens endpoint (preview) or legacy approach
        # Standard: only Super Admin can list all org tokens
        $tokens = Invoke-OktaApi -Path '/api/v1/api-tokens?limit=200'
        if (-not $tokens) { return @() }
        $match = @($tokens) | Where-Object { $_.name -eq $Script:SSWS_TOKEN_NAME }
        if ($match) {
            Write-Log -Level INFO -Message "Found $(@($match).Count) SSWS token(s) named '$Script:SSWS_TOKEN_NAME'"
            return $match
        }
    }
    catch {
        Write-Log -Level DEBUG -Message "Token listing not available (may require preview feature or Super Admin): $_"
    }
    Write-Log -Level SKIP -Message "No tokens found (or listing not supported)"
    return @()
}

#endregion

#region Snapshot Encryption (AES-256-CBC with Credential Manager Nonce)
# Adapted from Invoke-CALicenseAnalyzer-v4.ps1 lines 1101-1521.
# Key material: file-based 32-byte key + optional Windows Credential Manager nonce.
# On non-Windows or Constrained Language Mode, falls back to file-key-only mode.

$script:SnapNonceAvailable = $false
$script:SnapCredManagerLoaded = $null

function Initialize-SnapCredentialManagerAPI {
    <#
    .SYNOPSIS
        Load P/Invoke wrappers for Windows Credential Manager.
        Fails gracefully on non-Windows or Constrained Language Mode.
    #>
    [CmdletBinding()]
    param()

    if ($null -ne $script:SnapCredManagerLoaded) { return $script:SnapCredManagerLoaded }

    try {
        Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public static class SnapCredManagerNative {
    public const int CRED_TYPE_GENERIC = 1;
    public const int CRED_PERSIST_LOCAL_MACHINE = 2;

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct CREDENTIAL {
        public int Flags;
        public int Type;
        public string TargetName;
        public string Comment;
        public System.Runtime.InteropServices.ComTypes.FILETIME LastWritten;
        public int CredentialBlobSize;
        public IntPtr CredentialBlob;
        public int Persist;
        public int AttributeCount;
        public IntPtr Attributes;
        public string TargetAlias;
        public string UserName;
    }

    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern bool CredRead(string target, int type, int reservedFlag, out IntPtr credentialPtr);

    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern bool CredWrite([In] ref CREDENTIAL credential, [In] int flags);

    [DllImport("advapi32.dll", SetLastError = true)]
    public static extern bool CredFree([In] IntPtr cred);

    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern bool CredDelete(string target, int type, int flags);
}
"@ -ErrorAction Stop

        $script:SnapCredManagerLoaded = $true
        $script:SnapNonceAvailable = $true
        return $true
    }
    catch {
        Write-Verbose "Credential Manager P/Invoke not available: $($_.Exception.Message)"
        $script:SnapCredManagerLoaded = $false
        $script:SnapNonceAvailable = $false
        return $false
    }
}

function New-SnapshotEncryptionKey {
    <#
    .SYNOPSIS
        Generate a 32-byte random encryption key and save to user profile.
        Key path: ~/.cyberark/okta-snapshot.key (separate from license cache key).
    #>
    [CmdletBinding()]
    param()

    if (-not (Test-Path $Script:SNAP_KEY_DIR)) {
        New-Item -Path $Script:SNAP_KEY_DIR -ItemType Directory -Force | Out-Null
    }
    $keyPath = Join-Path $Script:SNAP_KEY_DIR $Script:SNAP_KEY_FILE

    $rng = [System.Security.Cryptography.RNGCryptoServiceProvider]::new()
    $keyBytes = New-Object byte[] 32
    $rng.GetBytes($keyBytes)
    $rng.Dispose()

    [System.IO.File]::WriteAllBytes($keyPath, $keyBytes)
    return $keyBytes
}

function Get-SnapshotEncryptionKey {
    <#
    .SYNOPSIS
        Load the snapshot encryption key from disk.
    #>
    [CmdletBinding()]
    param()

    $keyPath = Join-Path $Script:SNAP_KEY_DIR $Script:SNAP_KEY_FILE
    if (-not (Test-Path $keyPath)) { return $null }

    try {
        $keyBytes = [System.IO.File]::ReadAllBytes($keyPath)
        if ($keyBytes.Length -ne 32) {
            Write-Warning "Snapshot encryption key is wrong size ($($keyBytes.Length) bytes). Expected 32."
            return $null
        }
        return $keyBytes
    }
    catch {
        Write-Warning "Failed to read snapshot encryption key: $($_.Exception.Message)"
        return $null
    }
}

function Set-SnapCredentialManagerNonce {
    <#
    .SYNOPSIS
        Store a nonce in Windows Credential Manager (target: OktaHLASnapshot).
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [byte[]]$Nonce
    )

    if (-not $script:SnapNonceAvailable) { return $false }

    try {
        $targetName = $Script:SNAP_CM_TARGET
        $nonceB64 = [Convert]::ToBase64String($Nonce)
        $nonceBytes = [System.Text.Encoding]::Unicode.GetBytes($nonceB64)

        $blobPtr = [System.Runtime.InteropServices.Marshal]::AllocHGlobal($nonceBytes.Length)
        [System.Runtime.InteropServices.Marshal]::Copy($nonceBytes, 0, $blobPtr, $nonceBytes.Length)

        $cred = New-Object SnapCredManagerNative+CREDENTIAL
        $cred.Type = [SnapCredManagerNative]::CRED_TYPE_GENERIC
        $cred.TargetName = $targetName
        $cred.CredentialBlobSize = $nonceBytes.Length
        $cred.CredentialBlob = $blobPtr
        $cred.Persist = [SnapCredManagerNative]::CRED_PERSIST_LOCAL_MACHINE
        $cred.UserName = [System.Environment]::UserName

        $result = [SnapCredManagerNative]::CredWrite([ref]$cred, 0)
        [System.Runtime.InteropServices.Marshal]::FreeHGlobal($blobPtr)

        return $result
    }
    catch {
        Write-Verbose "Failed to write Credential Manager nonce: $($_.Exception.Message)"
        return $false
    }
}

function Get-SnapCredentialManagerNonce {
    <#
    .SYNOPSIS
        Retrieve the snapshot nonce from Windows Credential Manager.
    #>
    [CmdletBinding()]
    param()

    if (-not $script:SnapNonceAvailable) { return $null }

    try {
        $targetName = $Script:SNAP_CM_TARGET
        $credPtr = [IntPtr]::Zero
        $success = [SnapCredManagerNative]::CredRead($targetName, [SnapCredManagerNative]::CRED_TYPE_GENERIC, 0, [ref]$credPtr)

        if (-not $success -or $credPtr -eq [IntPtr]::Zero) { return $null }

        $cred = [System.Runtime.InteropServices.Marshal]::PtrToStructure($credPtr, [Type][SnapCredManagerNative+CREDENTIAL])

        if ($cred.CredentialBlobSize -gt 0 -and $cred.CredentialBlob -ne [IntPtr]::Zero) {
            $blobBytes = New-Object byte[] $cred.CredentialBlobSize
            [System.Runtime.InteropServices.Marshal]::Copy($cred.CredentialBlob, $blobBytes, 0, $cred.CredentialBlobSize)
            $nonceB64 = [System.Text.Encoding]::Unicode.GetString($blobBytes)
            $nonceBytes = [Convert]::FromBase64String($nonceB64)
            [SnapCredManagerNative]::CredFree($credPtr) | Out-Null
            return $nonceBytes
        }

        [SnapCredManagerNative]::CredFree($credPtr) | Out-Null
        return $null
    }
    catch {
        Write-Verbose "Failed to read Credential Manager nonce: $($_.Exception.Message)"
        return $null
    }
}

function Protect-SnapshotData {
    <#
    .SYNOPSIS
        Encrypt JSON data using AES-256-CBC with PBKDF2 key derivation.
        Uses file key + optional Credential Manager nonce for key material.
        Returns a JSON envelope string.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$JsonData
    )

    $aes = $null
    $deriveBytes = $null
    $encryptor = $null
    $derivedKey = $null
    $keyInput = $null

    try {
        # Get or generate file key
        $fileKey = Get-SnapshotEncryptionKey
        if ($null -eq $fileKey) {
            $fileKey = New-SnapshotEncryptionKey
            Write-Verbose "Generated new snapshot encryption key."
        }

        # Get or generate CM nonce
        $nonceProtected = $false
        $nonce = $null
        Initialize-SnapCredentialManagerAPI | Out-Null
        if ($script:SnapNonceAvailable) {
            $nonce = Get-SnapCredentialManagerNonce
            if ($null -eq $nonce) {
                $rng = [System.Security.Cryptography.RNGCryptoServiceProvider]::new()
                $nonce = New-Object byte[] 32
                $rng.GetBytes($nonce)
                $rng.Dispose()
                $stored = Set-SnapCredentialManagerNonce -Nonce $nonce
                if ($stored) {
                    $nonceProtected = $true
                    Write-Verbose "Stored new nonce in Credential Manager."
                }
            }
            else {
                $nonceProtected = $true
            }
        }
        else {
            Write-Verbose "Credential Manager not available. Using file-key-only mode."
        }

        # Generate random salt (16 bytes) and IV (16 bytes)
        $rngSalt = [System.Security.Cryptography.RNGCryptoServiceProvider]::new()
        $salt = New-Object byte[] 16
        $iv = New-Object byte[] 16
        $rngSalt.GetBytes($salt)
        $rngSalt.GetBytes($iv)
        $rngSalt.Dispose()

        # Build PBKDF2 input: fileKey + nonce (if available) + salt
        $keyInput = if ($nonceProtected -and $null -ne $nonce) {
            $combined = New-Object byte[] ($fileKey.Length + $nonce.Length)
            [Array]::Copy($fileKey, 0, $combined, 0, $fileKey.Length)
            [Array]::Copy($nonce, 0, $combined, $fileKey.Length, $nonce.Length)
            $combined
        }
        else {
            $fileKey
        }

        $iterations = 100000
        $deriveBytes = New-Object System.Security.Cryptography.Rfc2898DeriveBytes(
            $keyInput, $salt, $iterations
        )
        $derivedKey = $deriveBytes.GetBytes(32)

        # AES-256-CBC encryption
        $aes = [System.Security.Cryptography.AesCryptoServiceProvider]::new()
        $aes.KeySize = 256
        $aes.BlockSize = 128
        $aes.Mode = [System.Security.Cryptography.CipherMode]::CBC
        $aes.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7
        $aes.Key = $derivedKey
        $aes.IV = $iv

        $encryptor = $aes.CreateEncryptor()
        $plainBytes = [System.Text.Encoding]::UTF8.GetBytes($JsonData)
        $encrypted = $encryptor.TransformFinalBlock($plainBytes, 0, $plainBytes.Length)

        # Build envelope
        $envelope = [ordered]@{
            envelope       = "AES-256-CBC-SNAP-V1"
            salt           = [Convert]::ToBase64String($salt)
            iv             = [Convert]::ToBase64String($iv)
            iterations     = $iterations
            nonceProtected = $nonceProtected
            data           = [Convert]::ToBase64String($encrypted)
        } | ConvertTo-Json -Depth 4

        return $envelope
    }
    finally {
        if ($encryptor) { $encryptor.Dispose() }
        if ($aes) { $aes.Dispose() }
        if ($deriveBytes) { $deriveBytes.Dispose() }
        if ($derivedKey) { [Array]::Clear($derivedKey, 0, $derivedKey.Length) }
        if ($keyInput -and $keyInput.Length -gt 0) { [Array]::Clear($keyInput, 0, $keyInput.Length) }
    }
}

function Unprotect-SnapshotData {
    <#
    .SYNOPSIS
        Decrypt a JSON envelope encrypted by Protect-SnapshotData.
        Returns the original plaintext JSON string.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$EnvelopeJson
    )

    $aes = $null
    $deriveBytes = $null
    $decryptor = $null
    $derivedKey = $null
    $keyInput = $null

    try {
        $envelope = $EnvelopeJson | ConvertFrom-Json

        if ($envelope.envelope -ne "AES-256-CBC-SNAP-V1") {
            throw "Unsupported snapshot envelope format: $($envelope.envelope)"
        }

        $salt = [Convert]::FromBase64String($envelope.salt)
        $iv = [Convert]::FromBase64String($envelope.iv)
        $iterations = [int]$envelope.iterations
        $nonceProtected = [bool]$envelope.nonceProtected
        $encryptedData = [Convert]::FromBase64String($envelope.data)

        # Get file key
        $fileKey = Get-SnapshotEncryptionKey
        if ($null -eq $fileKey) {
            throw "Snapshot encryption key not found ($($Script:SNAP_KEY_DIR)/$($Script:SNAP_KEY_FILE)). The snapshot cannot be decrypted. If the key was lost, snapshots encrypted with it are irrecoverable."
        }

        # Get nonce if required
        $nonce = $null
        if ($nonceProtected) {
            Initialize-SnapCredentialManagerAPI | Out-Null
            $nonce = Get-SnapCredentialManagerNonce
            if ($null -eq $nonce) {
                throw ("Snapshot was encrypted with Credential Manager nonce protection, " +
                       "but the nonce is not available. This can happen if the snapshot was " +
                       "created on a different machine or user profile. The snapshot cannot " +
                       "be decrypted without both the key file and the original nonce.")
            }
        }

        # Build PBKDF2 input
        $keyInput = if ($nonceProtected -and $null -ne $nonce) {
            $combined = New-Object byte[] ($fileKey.Length + $nonce.Length)
            [Array]::Copy($fileKey, 0, $combined, 0, $fileKey.Length)
            [Array]::Copy($nonce, 0, $combined, $fileKey.Length, $nonce.Length)
            $combined
        }
        else {
            $fileKey
        }

        $deriveBytes = New-Object System.Security.Cryptography.Rfc2898DeriveBytes(
            $keyInput, $salt, $iterations
        )
        $derivedKey = $deriveBytes.GetBytes(32)

        # AES-256-CBC decryption
        $aes = [System.Security.Cryptography.AesCryptoServiceProvider]::new()
        $aes.KeySize = 256
        $aes.BlockSize = 128
        $aes.Mode = [System.Security.Cryptography.CipherMode]::CBC
        $aes.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7
        $aes.Key = $derivedKey
        $aes.IV = $iv

        $decryptor = $aes.CreateDecryptor()
        $decrypted = $decryptor.TransformFinalBlock($encryptedData, 0, $encryptedData.Length)

        return [System.Text.Encoding]::UTF8.GetString($decrypted)
    }
    finally {
        if ($decryptor) { $decryptor.Dispose() }
        if ($aes) { $aes.Dispose() }
        if ($deriveBytes) { $deriveBytes.Dispose() }
        if ($derivedKey) { [Array]::Clear($derivedKey, 0, $derivedKey.Length) }
        if ($keyInput -and $keyInput.Length -gt 0) { [Array]::Clear($keyInput, 0, $keyInput.Length) }
    }
}

function Remove-SnapshotEncryptionMaterial {
    <#
    .SYNOPSIS
        Remove all snapshot encryption keys and Credential Manager entries.
        Securely zeros key file before deletion.
    #>
    [CmdletBinding()]
    param()

    # Remove file key
    $keyPath = Join-Path $Script:SNAP_KEY_DIR $Script:SNAP_KEY_FILE
    if (Test-Path $keyPath) {
        # Zero file contents before deletion (use actual file length, not assumed 32)
        $actualLen = (Get-Item $keyPath).Length
        $zeros = New-Object byte[] ([Math]::Max($actualLen, 32))
        [System.IO.File]::WriteAllBytes($keyPath, $zeros)
        Remove-Item $keyPath -Force
        Write-Verbose "Removed snapshot encryption key file."
    }

    # Remove Credential Manager entry
    Initialize-SnapCredentialManagerAPI | Out-Null
    if ($script:SnapNonceAvailable) {
        try {
            [SnapCredManagerNative]::CredDelete($Script:SNAP_CM_TARGET, [SnapCredManagerNative]::CRED_TYPE_GENERIC, 0) | Out-Null
            Write-Verbose "Removed Credential Manager nonce."
        }
        catch {
            Write-Verbose "CredDelete failed: $($_.Exception.Message)"
        }
    }
}

#endregion

#region Pre-Deploy Snapshot (Comprehensive State Capture & Restore)

function Get-FileSha256 {
    <# Returns lowercase hex SHA256 hash of a file, or $null on error. #>
    param([Parameter(Mandatory)][string]$Path)
    try {
        $sha = [System.Security.Cryptography.SHA256]::Create()
        $stream = [System.IO.File]::OpenRead($Path)
        try {
            $hash = $sha.ComputeHash($stream)
            return ([System.BitConverter]::ToString($hash) -replace '-','').ToLower()
        }
        finally { $stream.Close(); $sha.Dispose() }
    }
    catch { return $null }
}

function Test-PreDeploySnapshot {
    <#
    .SYNOPSIS
        Validates a PreDeploy snapshot file: checksum, schema version, required fields.
        Handles both plaintext (.json) and encrypted (.enc) snapshots.
        Returns @{ Valid=$true/$false; Reason='...'; Document=$parsedJson; Encrypted=$bool }
    #>
    param([Parameter(Mandatory)][string]$SnapshotPath)

    $result = @{ Valid = $false; Reason = ''; Document = $null; Encrypted = $false }

    if (-not (Test-Path $SnapshotPath)) {
        $result.Reason = "Snapshot file not found: $SnapshotPath"
        return $result
    }

    $isEncrypted = $SnapshotPath -like '*.enc'
    $result.Encrypted = $isEncrypted

    # SHA256 sidecar check (on raw file -- ciphertext for .enc, plaintext for .json)
    $shaFile = "$SnapshotPath.sha256"
    if (Test-Path $shaFile) {
        $expectedHash = (Get-Content -Path $shaFile -Raw).Trim()
        if ($expectedHash -like 'sha256:*') { $expectedHash = $expectedHash.Substring(7) }
        $actualHash = Get-FileSha256 -Path $SnapshotPath
        if ($actualHash -ne $expectedHash) {
            $result.Reason = "Checksum mismatch: expected=$expectedHash actual=$actualHash (file may be corrupted)"
            return $result
        }
    }

    # Read and optionally decrypt
    $rawContent = Get-Content -Path $SnapshotPath -Raw
    if ($isEncrypted) {
        try {
            $rawContent = Unprotect-SnapshotData -EnvelopeJson $rawContent
        }
        catch {
            $result.Reason = "Decryption failed: $_"
            return $result
        }
    }

    # Parse JSON
    try {
        $doc = $rawContent | ConvertFrom-Json
    }
    catch {
        $result.Reason = "Invalid JSON: $_"
        return $result
    }

    # Schema version
    if (-not $doc.PSObject.Properties['schemaVersion']) {
        $result.Reason = "Missing schemaVersion field"
        return $result
    }
    if ($doc.schemaVersion -gt 1) {
        $result.Reason = "Unsupported schema version $($doc.schemaVersion) (this script supports version 1)"
        return $result
    }

    # Snapshot type
    if ($doc.snapshotType -ne 'PreDeploy') {
        $result.Reason = "Not a PreDeploy snapshot (type: $($doc.snapshotType))"
        return $result
    }

    # Required fields
    foreach ($field in @('capturedAt', 'tenant', 'users', 'groups', 'signOnPolicies', 'authenticators')) {
        if (-not $doc.PSObject.Properties[$field]) {
            $result.Reason = "Missing required field: $field"
            return $result
        }
    }

    $result.Valid = $true
    $result.Document = $doc
    return $result
}

function Save-PreDeploySnapshot {
    <#
    .SYNOPSIS
        Captures the complete pre-change state of ALL Okta resources the script can
        modify. Saves to a single JSON file in the Rollbacks directory.
        This snapshot enables full restore to the exact state before any Deploy run.

        Resources captured:
          - Users (profiles, status, admin roles, group memberships, enrolled factors)
          - Groups (profiles, member lists)
          - Network zone (CyberArk-Infrastructure gateways)
          - Sign-on policies + rules (session settings, MFA prompt mode)
          - ACCESS_POLICY rules (re-auth durations, constraints)
          - Authenticators (google_otp, okta_verify lifecycle status)
          - MFA enrollment policies + rules (authenticator settings, group scope)
          - Custom admin role, resource set, role bindings
    #>

    Write-Log -Level INFO -Message "Capturing pre-deploy snapshot of all modifiable resources..." -Action 'PreDeploySnapshot'

    if (-not (Test-Path $Script:ROLLBACK_DIR)) {
        New-Item -ItemType Directory -Path $Script:ROLLBACK_DIR -Force | Out-Null
    }

    $snapshot = [ordered]@{
        schemaVersion = 1
        snapshotType  = 'PreDeploy'
        capturedAt    = (Get-Date).ToUniversalTime().ToString('o')
        correlationId = $Script:CorrelationId
        scriptVersion = $Script:VERSION
        tenant        = $Script:OktaBaseUrl
    }

    # --- Users ---
    Write-Log -Level DEBUG -Message "  Snapshotting users..." -Action 'PreDeploySnapshot'
    $userList = [System.Collections.Generic.List[object]]::new()
    $discoveredUsers = Find-OktaUsers
    foreach ($u in $discoveredUsers) {
        $uid = $u.id
        $userEntry = [ordered]@{
            id      = $uid
            profile = [ordered]@{
                login     = $u.profile.login
                firstName = $u.profile.firstName
                lastName  = $u.profile.lastName
                email     = $u.profile.email
            }
            status = $u.status
        }

        # Admin roles
        $roles = @()
        try {
            $rolesRaw = Invoke-OktaApi -Path "/api/v1/users/$uid/roles"
            if ($rolesRaw) { $roles = @($rolesRaw) | ForEach-Object { $_.type } }
        } catch {}
        $userEntry['roles'] = $roles

        # Group memberships
        $groupIds = @()
        try {
            $groupsRaw = Invoke-OktaApi -Path "/api/v1/users/$uid/groups"
            if ($groupsRaw) { $groupIds = @($groupsRaw) | ForEach-Object { $_.id } }
        } catch {}
        $userEntry['groupIds'] = $groupIds

        # Enrolled factors
        $factors = @()
        try {
            $factorsRaw = Invoke-OktaApi -Path "/api/v1/users/$uid/factors"
            if ($factorsRaw) {
                $factors = @($factorsRaw) | ForEach-Object {
                    [ordered]@{ id = $_.id; factorType = $_.factorType; provider = $_.provider; status = $_.status }
                }
            }
        } catch {}
        $userEntry['factors'] = $factors

        $userList.Add($userEntry)
    }
    $snapshot['users'] = $userList.ToArray()

    # --- Groups ---
    Write-Log -Level DEBUG -Message "  Snapshotting groups..." -Action 'PreDeploySnapshot'
    $groupList = [System.Collections.Generic.List[object]]::new()
    $discoveredGroups = Find-OktaGroups
    foreach ($g in $discoveredGroups) {
        $gEntry = [ordered]@{
            id   = $g.id
            name = $g.profile.name
        }
        # Member user IDs
        $members = @()
        try {
            $membersRaw = Invoke-OktaApi -Path "/api/v1/groups/$($g.id)/users?limit=200"
            if ($membersRaw) { $members = @($membersRaw) | ForEach-Object { $_.id } }
        } catch {}
        $gEntry['memberUserIds'] = $members
        $groupList.Add($gEntry)
    }
    $snapshot['groups'] = $groupList.ToArray()

    # --- Network Zone ---
    Write-Log -Level DEBUG -Message "  Snapshotting network zone..." -Action 'PreDeploySnapshot'
    $zoneSnapshot = $null
    $zone = Find-OktaNetworkZone
    if ($zone) {
        $zoneSnapshot = [ordered]@{
            id       = $zone.id
            name     = $zone.name
            status   = $zone.status
            gateways = @($zone.gateways | ForEach-Object { [ordered]@{ type = $_.type; value = $_.value } })
        }
    }
    $snapshot['networkZone'] = $zoneSnapshot

    # --- Sign-On Policies + Rules ---
    Write-Log -Level DEBUG -Message "  Snapshotting sign-on policies..." -Action 'PreDeploySnapshot'
    $policyList = [System.Collections.Generic.List[object]]::new()
    $discoveredPolicies = Find-OktaPolicies
    foreach ($p in $discoveredPolicies) {
        $pEntry = [ordered]@{
            id       = $p.id
            name     = $p.name
            type     = $p.type
            status   = $p.status
            priority = $p.priority
        }
        $ruleList = @()
        try {
            $rulesRaw = Invoke-OktaApi -Path "/api/v1/policies/$($p.id)/rules"
            if ($rulesRaw) {
                $ruleList = @($rulesRaw) | ForEach-Object {
                    $rEntry = [ordered]@{
                        id       = $_.id
                        name     = $_.name
                        status   = $_.status
                        priority = $_.priority
                    }
                    # Capture full actions block (session settings, MFA config)
                    if ($_.PSObject.Properties['actions']) { $rEntry['actions'] = $_.actions }
                    if ($_.PSObject.Properties['conditions']) { $rEntry['conditions'] = $_.conditions }
                    $rEntry
                }
            }
        } catch {}
        $pEntry['rules'] = $ruleList
        $policyList.Add($pEntry)
    }
    $snapshot['signOnPolicies'] = $policyList.ToArray()

    # --- ACCESS_POLICY (Admin Console) ---
    Write-Log -Level DEBUG -Message "  Snapshotting ACCESS_POLICY..." -Action 'PreDeploySnapshot'
    $accessPolicySnapshot = $null
    try {
        $apPolicies = Invoke-OktaApi -Path '/api/v1/policies?type=ACCESS_POLICY&limit=50'
        $adminPolicy = @($apPolicies) | Where-Object { $_.name -like '*Admin Console*' -or $_.name -like '*Admin*' } | Select-Object -First 1
        if ($adminPolicy) {
            $apRules = @(Invoke-OktaApi -Path "/api/v1/policies/$($adminPolicy.id)/rules")
            $accessPolicySnapshot = [ordered]@{
                id    = $adminPolicy.id
                name  = $adminPolicy.name
                rules = @($apRules | ForEach-Object {
                    [ordered]@{
                        id         = $_.id
                        name       = $_.name
                        status     = $_.status
                        priority   = $_.priority
                        actions    = $_.actions
                        conditions = $_.conditions
                    }
                })
            }
        }
    } catch {}
    $snapshot['accessPolicy'] = $accessPolicySnapshot

    # --- Authenticators ---
    Write-Log -Level DEBUG -Message "  Snapshotting authenticators..." -Action 'PreDeploySnapshot'
    $authSnapshot = [ordered]@{}
    try {
        $auths = Invoke-OktaApi -Path '/api/v1/authenticators'
        foreach ($a in @($auths)) {
            if ($a.key -in @('google_otp', 'okta_verify')) {
                $authSnapshot[$a.key] = [ordered]@{ id = $a.id; status = $a.status; name = $a.name }
            }
        }
    } catch {}
    $snapshot['authenticators'] = $authSnapshot

    # --- MFA Enrollment Policies ---
    Write-Log -Level DEBUG -Message "  Snapshotting enrollment policies..." -Action 'PreDeploySnapshot'
    $enrollList = [System.Collections.Generic.List[object]]::new()
    try {
        $enrollPolicies = Invoke-OktaApi -Path '/api/v1/policies?type=MFA_ENROLL'
        foreach ($ep in @($enrollPolicies)) {
            $epEntry = [ordered]@{
                id          = $ep.id
                name        = $ep.name
                status      = $ep.status
                priority    = $ep.priority
                description = if ($ep.PSObject.Properties['description']) { $ep.description } else { '' }
                conditions  = if ($ep.PSObject.Properties['conditions']) { $ep.conditions } else { $null }
                settings    = if ($ep.PSObject.Properties['settings']) { $ep.settings } else { $null }
            }
            # Rules
            $epRules = @()
            try {
                $epRulesRaw = Invoke-OktaApi -Path "/api/v1/policies/$($ep.id)/rules"
                if ($epRulesRaw) {
                    $epRules = @($epRulesRaw) | ForEach-Object {
                        [ordered]@{
                            id         = $_.id
                            name       = $_.name
                            status     = $_.status
                            priority   = $_.priority
                            actions    = $_.actions
                            conditions = $_.conditions
                        }
                    }
                }
            } catch {}
            $epEntry['rules'] = $epRules
            $enrollList.Add($epEntry)
        }
    } catch {}
    $snapshot['enrollmentPolicies'] = $enrollList.ToArray()

    # --- Custom Role + Resource Set ---
    Write-Log -Level DEBUG -Message "  Snapshotting custom role and resource set..." -Action 'PreDeploySnapshot'
    $customRole = Find-OktaCustomRole
    $snapshot['customRole'] = if ($customRole) {
        [ordered]@{ id = $customRole.id; label = $customRole.label; description = $customRole.description }
    } else { $null }

    $resourceSet = Find-OktaResourceSet
    $snapshot['resourceSet'] = if ($resourceSet) {
        [ordered]@{ id = $resourceSet.id; label = $resourceSet.label; description = $resourceSet.description }
    } else { $null }

    # --- Role Bindings (CPM user) ---
    Write-Log -Level DEBUG -Message "  Snapshotting role bindings..." -Action 'PreDeploySnapshot'
    $bindingsList = @()
    $cpmUser = @($discoveredUsers) | Where-Object { $_.profile.login -like '*cpm*' } | Select-Object -First 1
    if ($cpmUser) {
        try {
            $bindings = Find-OktaRoleBindings -CpmUserId $cpmUser.id
            if ($bindings) {
                $bindingsList = @($bindings) | ForEach-Object {
                    [ordered]@{ id = $_.id; type = $_.type; label = if ($_.PSObject.Properties['label']) { $_.label } else { '' } }
                }
            }
        } catch {}
    }
    $snapshot['roleBindings'] = $bindingsList

    # --- Save ---
    $ts      = Get-Date -Format 'yyyyMMdd-HHmmss'
    $corrId8 = $Script:CorrelationId.Substring(0, 8)
    $jsonContent = $snapshot | ConvertTo-Json -Depth 15

    if ($SnapshotEncryption) {
        $file = Join-Path $Script:ROLLBACK_DIR "Deploy-OktaHLABootstrap-PreDeploy-$ts-$corrId8.enc"
        Write-Log -Level INFO -Message "Encrypting snapshot (AES-256-CBC)..." -Action 'PreDeploySnapshot'
        $encrypted = Protect-SnapshotData -JsonData $jsonContent
        Set-Content -Path $file -Value $encrypted -Encoding UTF8
    }
    else {
        $file = Join-Path $Script:ROLLBACK_DIR "Deploy-OktaHLABootstrap-PreDeploy-$ts-$corrId8.json"
        Set-Content -Path $file -Value $jsonContent -Encoding UTF8
    }

    # SHA256 sidecar -- computed on the file as written (ciphertext if encrypted, plaintext if not)
    $sha = Get-FileSha256 -Path $file
    if ($sha) {
        Set-Content -Path "$file.sha256" -Value "sha256:$sha" -Encoding UTF8
    }

    Write-Log -Level OK -Message "Pre-deploy snapshot saved: $file ($sha)" -Action 'PreDeploySnapshot' `
        -Fields @{
            Users = $userList.Count; Groups = $groupList.Count
            Policies = $policyList.Count; RoleBindings = $bindingsList.Count
            File = $file; Encrypted = $SnapshotEncryption
        }

    # Snapshot rotation: remove oldest PreDeploy snapshots beyond retention limit
    if ($SnapshotRetention -gt 0) {
        $existingSnapshots = @(Get-ChildItem -Path $Script:ROLLBACK_DIR -Filter 'Deploy-OktaHLABootstrap-PreDeploy-*' -ErrorAction SilentlyContinue |
            Where-Object { $_.Extension -in @('.json', '.enc') } |
            Sort-Object LastWriteTime -Descending)
        if ($existingSnapshots.Count -gt $SnapshotRetention) {
            $toDelete = $existingSnapshots | Select-Object -Skip $SnapshotRetention
            foreach ($old in $toDelete) {
                # Remove the snapshot and its sidecar
                Remove-Item $old.FullName -Force -ErrorAction SilentlyContinue
                $sidecar = "$($old.FullName).sha256"
                if (Test-Path $sidecar) { Remove-Item $sidecar -Force -ErrorAction SilentlyContinue }
                Write-Log -Level DEBUG -Message "Rotated old snapshot: $($old.Name)" -Action 'SnapshotRotation'
            }
            Write-Log -Level INFO -Message "Snapshot rotation: removed $(@($toDelete).Count) old snapshot(s), keeping $SnapshotRetention" -Action 'SnapshotRotation'
        }
    }

    return $file
}

function Invoke-RestorePreDeploy {
    <#
    .SYNOPSIS
        Restores ALL Okta resources to the state captured in a PreDeploy snapshot.
        This is the comprehensive rollback -- reverses everything Deploy touches.

        v2.8.0 enhancements:
          - Pre-restore safety snapshot (undo the undo)
          - WhatIf shows full impact assessment without making changes
          - Group membership reconciliation (remove members not in snapshot)
          - Role binding / resource set / custom role deletion

        Restore order (dependency-safe):
          1. Sign-on policy rules (session settings, MFA prompt mode)
          2. ACCESS_POLICY rules (re-auth durations)
          3. Enrollment policies (authenticator settings, group scope)
          4. Authenticator lifecycle (google_otp active/inactive)
          5. Network zone gateways
          6. Group membership reconciliation
          7. Delete enrollment policies created by Deploy
          8. Delete sign-on policies created by Deploy
          9. Delete groups created by Deploy
         10. Delete users created by Deploy
         11. Delete role bindings not in snapshot
         12. Delete resource set not in snapshot
         13. Delete custom role not in snapshot
    #>
    param([Parameter(Mandatory)][string]$SnapshotPath)

    # Validate snapshot
    $validation = Test-PreDeploySnapshot -SnapshotPath $SnapshotPath
    if (-not $validation.Valid) {
        Write-Log -Level ERROR -Message "Snapshot validation failed: $($validation.Reason)"
        return
    }
    $snap = $validation.Document

    # Count what will be cleaned up
    $currentUsers    = @(Find-OktaUsers)
    $currentGroups   = @(Find-OktaGroups)
    $currentPolicies = @(Find-OktaPolicies)
    $snapUserIds     = if ($snap.users)          { @($snap.users | ForEach-Object { $_.id }) }          else { @() }
    $snapGroupIds    = if ($snap.groups)          { @($snap.groups | ForEach-Object { $_.id }) }         else { @() }
    $snapPolicyIds   = if ($snap.signOnPolicies)  { @($snap.signOnPolicies | ForEach-Object { $_.id }) } else { @() }
    $usersToDelete   = @($currentUsers    | Where-Object { $_.id -notin $snapUserIds })
    $groupsToDelete  = @($currentGroups   | Where-Object { $_.id -notin $snapGroupIds })
    $policiesToDelete = @($currentPolicies | Where-Object { $_.id -notin $snapPolicyIds })

    # Count group membership differences
    $groupMembershipChanges = 0
    if ($snap.groups) {
        foreach ($gSnap in @($snap.groups)) {
            $snapMembers = if ($gSnap.PSObject.Properties['memberUserIds']) { @($gSnap.memberUserIds) } else { @() }
            try {
                $currentMembers = @(Invoke-OktaApi -Path "/api/v1/groups/$($gSnap.id)/users?limit=200" -ErrorAction SilentlyContinue)
                $currentMemberIds = @($currentMembers | ForEach-Object { $_.id })
                $extraMembers = @($currentMemberIds | Where-Object { $_ -notin $snapMembers })
                $groupMembershipChanges += $extraMembers.Count
            } catch {}
        }
    }

    # Count role/resource set differences
    $currentCustomRole  = Find-OktaCustomRole
    $currentResourceSet = Find-OktaResourceSet
    $snapHasRole = ($null -ne $snap.customRole)
    $snapHasRS   = ($null -ne $snap.resourceSet)
    $roleToDelete = ($null -ne $currentCustomRole -and -not $snapHasRole)
    $rsToDelete   = ($null -ne $currentResourceSet -and -not $snapHasRS)

    # Count role binding differences
    $bindingsToDelete = @()
    $snapBindingIds = @()
    if ($snap.roleBindings) { $snapBindingIds = @($snap.roleBindings | ForEach-Object { $_.id }) }
    $cpmUser = @($currentUsers) | Where-Object { $_.profile.login -like '*cpm*' } | Select-Object -First 1
    if ($cpmUser) {
        try {
            $currentBindings = @(Find-OktaRoleBindings -CpmUserId $cpmUser.id)
            $bindingsToDelete = @($currentBindings | Where-Object { $_.id -notin $snapBindingIds })
        } catch {}
    }

    # --- Impact Assessment Display ---
    Write-Host ""
    Write-Host "  ================================================================" -ForegroundColor Cyan
    Write-Host "  FULL RESTORE: Pre-Deploy Snapshot" -ForegroundColor Cyan
    Write-Host "  ================================================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  Snapshot: $SnapshotPath" -ForegroundColor DarkGray
    Write-Host "  Taken:    $($snap.capturedAt)" -ForegroundColor DarkGray
    Write-Host "  Version:  $($snap.scriptVersion)" -ForegroundColor DarkGray
    Write-Host "  Tenant:   $($snap.tenant)" -ForegroundColor DarkGray
    Write-Host "  Schema:   v$($snap.schemaVersion)" -ForegroundColor DarkGray
    if ($validation.Encrypted) {
        Write-Host "  Format:   Encrypted (AES-256-CBC)" -ForegroundColor DarkGray
    }
    Write-Host ""
    Write-Host "  This will:" -ForegroundColor Yellow
    Write-Host "    - Restore sign-on policy session settings" -ForegroundColor Yellow
    Write-Host "    - Restore ACCESS_POLICY re-auth durations" -ForegroundColor Yellow
    Write-Host "    - Restore enrollment policy authenticator settings" -ForegroundColor Yellow
    Write-Host "    - Restore authenticator lifecycle status" -ForegroundColor Yellow
    Write-Host "    - Restore network zone gateways" -ForegroundColor Yellow
    if ($groupMembershipChanges -gt 0) {
        Write-Host "    - Remove $groupMembershipChanges extra group member(s) not in snapshot" -ForegroundColor Yellow
    }
    if ($policiesToDelete.Count -gt 0) {
        Write-Host "    - DELETE $($policiesToDelete.Count) sign-on policy(ies) created by Deploy" -ForegroundColor Red
    }
    if ($groupsToDelete.Count -gt 0) {
        Write-Host "    - DELETE $($groupsToDelete.Count) group(s) created by Deploy" -ForegroundColor Red
    }
    if ($usersToDelete.Count -gt 0) {
        Write-Host "    - DELETE $($usersToDelete.Count) user(s) created by Deploy" -ForegroundColor Red
    }
    if ($bindingsToDelete.Count -gt 0) {
        Write-Host "    - DELETE $($bindingsToDelete.Count) role binding(s) not in snapshot" -ForegroundColor Red
    }
    if ($rsToDelete) {
        Write-Host "    - DELETE resource set '$($currentResourceSet.label)' (not in snapshot)" -ForegroundColor Red
    }
    if ($roleToDelete) {
        Write-Host "    - DELETE custom role '$($currentCustomRole.label)' (not in snapshot)" -ForegroundColor Red
    }
    Write-Host ""

    # WhatIf: show impact assessment THEN return (fix #6)
    if ($Script:IsDryRun) {
        Write-Log -Level INFO -Message "[WhatIf] Would restore all settings from pre-deploy snapshot" -Action 'RestoreWhatIf' `
            -Fields @{
                PoliciesDelete = $policiesToDelete.Count; GroupsDelete = $groupsToDelete.Count
                UsersDelete = $usersToDelete.Count; MembershipChanges = $groupMembershipChanges
                BindingsDelete = $bindingsToDelete.Count; RoleDelete = $roleToDelete; ResourceSetDelete = $rsToDelete
            }
        return
    }

    if ($Script:Force) {
        Write-Host "  [Force] Auto-accepting full restore (-Force specified)" -ForegroundColor Yellow
    }
    else {
        $answer = Read-Host "  Restore all settings from this snapshot? [y/N]"
        if ($answer -notmatch '^[Yy]') {
            Write-Log -Level INFO -Message "Full restore cancelled by operator."
            return
        }
    }

    # Pre-restore safety snapshot (fix #5): capture current state before making any changes
    Write-Log -Level INFO -Message "Capturing current state before restore (safety net)..." -Action 'PreRestoreSnapshot'
    try {
        $safetyFile = Save-PreDeploySnapshot
        Write-Log -Level OK -Message "Safety snapshot saved: $safetyFile (you can undo this restore)" -Action 'PreRestoreSnapshot'
    }
    catch {
        Write-Log -Level WARN -Message "Failed to save pre-restore safety snapshot: $_ (proceeding with restore)" -Action 'PreRestoreSnapshot'
    }

    $restoreErrors = 0

    # 1. Restore sign-on policy rules
    if ($snap.signOnPolicies) {
        Write-Log -Level INFO -Message "Restoring sign-on policy rules..."
        foreach ($pSnap in @($snap.signOnPolicies)) {
            foreach ($rSnap in @($pSnap.rules)) {
                if (-not $rSnap.actions -or -not $rSnap.actions.signon) { continue }
                if ($rSnap.actions.signon.access -eq 'DENY') { continue }
                try {
                    $existingRule = Invoke-OktaApi -Path "/api/v1/policies/$($pSnap.id)/rules/$($rSnap.id)"
                    if ($existingRule) {
                        $existingRule.actions = $rSnap.actions
                        Invoke-OktaApi -Path "/api/v1/policies/$($pSnap.id)/rules/$($rSnap.id)" -Method PUT -Body $existingRule | Out-Null
                        Write-Log -Level OK -Message "Restored rule '$($rSnap.name)' on policy '$($pSnap.name)'" -Action 'RestoreSignOnRule'
                    }
                }
                catch {
                    Write-Log -Level WARN -Message "Failed to restore rule '$($rSnap.name)': $_" -Action 'RestoreSignOnRule'
                    $restoreErrors++
                }
            }
        }
    }

    # 2. Restore ACCESS_POLICY rules
    if ($snap.accessPolicy -and $snap.accessPolicy.rules) {
        Write-Log -Level INFO -Message "Restoring ACCESS_POLICY rules..."
        foreach ($rSnap in @($snap.accessPolicy.rules)) {
            try {
                $existingRule = Invoke-OktaApi -Path "/api/v1/policies/$($snap.accessPolicy.id)/rules/$($rSnap.id)"
                if ($existingRule) {
                    $existingRule.actions = $rSnap.actions
                    if ($rSnap.conditions) { $existingRule.conditions = $rSnap.conditions }
                    Invoke-OktaApi -Path "/api/v1/policies/$($snap.accessPolicy.id)/rules/$($rSnap.id)" -Method PUT -Body $existingRule | Out-Null
                    Write-Log -Level OK -Message "Restored ACCESS_POLICY rule '$($rSnap.name)'" -Action 'RestoreAccessRule'
                }
            }
            catch {
                Write-Log -Level WARN -Message "Failed to restore ACCESS_POLICY rule '$($rSnap.name)': $_" -Action 'RestoreAccessRule'
                $restoreErrors++
            }
        }
    }

    # 3. Restore enrollment policies
    if ($snap.enrollmentPolicies) {
        Write-Log -Level INFO -Message "Restoring enrollment policies..."
        foreach ($epSnap in @($snap.enrollmentPolicies)) {
            try {
                $existingPolicy = Invoke-OktaApi -Path "/api/v1/policies/$($epSnap.id)"
                if ($existingPolicy) {
                    $putBody = [ordered]@{
                        type     = 'MFA_ENROLL'
                        name     = $epSnap.name
                        status   = $epSnap.status
                        priority = $epSnap.priority
                    }
                    if ($epSnap.description) { $putBody['description'] = $epSnap.description }
                    if ($epSnap.conditions)  { $putBody['conditions']  = $epSnap.conditions }
                    if ($epSnap.settings)    { $putBody['settings']    = $epSnap.settings }
                    Invoke-OktaApi -Path "/api/v1/policies/$($epSnap.id)" -Method PUT -Body $putBody | Out-Null
                    Write-Log -Level OK -Message "Restored enrollment policy '$($epSnap.name)'" -Action 'RestoreEnrollmentPolicy'
                }
            }
            catch {
                Write-Log -Level WARN -Message "Failed to restore enrollment policy '$($epSnap.name)': $_" -Action 'RestoreEnrollmentPolicy'
                $restoreErrors++
            }
        }
    }

    # 4. Restore authenticator lifecycle
    if ($snap.authenticators) {
        Write-Log -Level INFO -Message "Restoring authenticator lifecycle states..."
        foreach ($key in @($snap.authenticators.PSObject.Properties.Name)) {
            $authSnap = $snap.authenticators.$key
            try {
                $current = Invoke-OktaApi -Path "/api/v1/authenticators/$($authSnap.id)"
                if ($current -and $current.status -ne $authSnap.status) {
                    if ($authSnap.status -eq 'ACTIVE') {
                        Invoke-OktaApi -Path "/api/v1/authenticators/$($authSnap.id)/lifecycle/activate" -Method POST | Out-Null
                    }
                    else {
                        Invoke-OktaApi -Path "/api/v1/authenticators/$($authSnap.id)/lifecycle/deactivate" -Method POST | Out-Null
                    }
                    Write-Log -Level OK -Message "Restored $key to $($authSnap.status)" -Action 'RestoreAuthenticator'
                }
                else {
                    Write-Log -Level SKIP -Message "$key already $($authSnap.status)" -Action 'RestoreAuthenticator'
                }
            }
            catch {
                Write-Log -Level WARN -Message "Failed to restore $key lifecycle: $_" -Action 'RestoreAuthenticator'
                $restoreErrors++
            }
        }
    }

    # 5. Restore network zone gateways
    if ($snap.networkZone) {
        Write-Log -Level INFO -Message "Restoring network zone gateways..."
        try {
            $putBody = @{
                type     = 'IP'
                name     = $snap.networkZone.name
                status   = $snap.networkZone.status
                gateways = @($snap.networkZone.gateways)
            }
            Invoke-OktaApi -Path "/api/v1/zones/$($snap.networkZone.id)" -Method PUT -Body $putBody | Out-Null
            Write-Log -Level OK -Message "Restored network zone '$($snap.networkZone.name)' ($($snap.networkZone.gateways.Count) gateway(s))" -Action 'RestoreNetworkZone'
        }
        catch {
            Write-Log -Level WARN -Message "Failed to restore network zone: $_" -Action 'RestoreNetworkZone'
            $restoreErrors++
        }
    }

    # 6. Group membership reconciliation (fix #8): remove members not in snapshot
    if ($snap.groups) {
        Write-Log -Level INFO -Message "Reconciling group memberships..."
        foreach ($gSnap in @($snap.groups)) {
            $snapMembers = if ($gSnap.PSObject.Properties['memberUserIds']) { @($gSnap.memberUserIds) } else { @() }
            try {
                $currentMembers = @(Invoke-OktaApi -Path "/api/v1/groups/$($gSnap.id)/users?limit=200")
                $currentMemberIds = @($currentMembers | ForEach-Object { $_.id })
                $extraMembers = @($currentMemberIds | Where-Object { $_ -notin $snapMembers })
                foreach ($extraUserId in $extraMembers) {
                    try {
                        Invoke-OktaApi -Path "/api/v1/groups/$($gSnap.id)/users/$extraUserId" -Method DELETE | Out-Null
                        Write-Log -Level OK -Message "Removed extra member $extraUserId from group '$($gSnap.name)'" -Action 'RestoreGroupMembership'
                    }
                    catch {
                        Write-Log -Level WARN -Message "Failed to remove member $extraUserId from group '$($gSnap.name)': $_" -Action 'RestoreGroupMembership'
                        $restoreErrors++
                    }
                }
                if ($extraMembers.Count -eq 0) {
                    Write-Log -Level SKIP -Message "Group '$($gSnap.name)' membership matches snapshot" -Action 'RestoreGroupMembership'
                }
            }
            catch {
                Write-Log -Level WARN -Message "Failed to reconcile group '$($gSnap.name)': $_" -Action 'RestoreGroupMembership'
                $restoreErrors++
            }
        }
    }

    # 7. Delete enrollment policies NOT in snapshot (created by Deploy)
    Write-Log -Level INFO -Message "Checking for enrollment policies to remove..."
    $snapEnrollIds = @()
    if ($snap.enrollmentPolicies) { $snapEnrollIds = @($snap.enrollmentPolicies | ForEach-Object { $_.id }) }
    try {
        $currentEnroll = @(Invoke-OktaApi -Path '/api/v1/policies?type=MFA_ENROLL')
        foreach ($ep in $currentEnroll) {
            if ($ep.name -like '*HLA*' -and $ep.id -notin $snapEnrollIds) {
                Write-Log -Level INFO -Message "Deleting enrollment policy '$($ep.name)' (created by Deploy)..."
                try {
                    # Delete rules first
                    $epRules = @(Invoke-OktaApi -Path "/api/v1/policies/$($ep.id)/rules")
                    foreach ($r in $epRules) {
                        try { Invoke-OktaApi -Path "/api/v1/policies/$($ep.id)/rules/$($r.id)" -Method DELETE | Out-Null } catch {}
                    }
                    try { Invoke-OktaApi -Path "/api/v1/policies/$($ep.id)/lifecycle/deactivate" -Method POST | Out-Null } catch {}
                    Invoke-OktaApi -Path "/api/v1/policies/$($ep.id)" -Method DELETE | Out-Null
                    Write-Log -Level OK -Message "Deleted enrollment policy '$($ep.name)'" -Action 'RestoreDeletePolicy'
                }
                catch {
                    Write-Log -Level WARN -Message "Failed to delete enrollment policy '$($ep.name)': $_" -Action 'RestoreDeletePolicy'
                    $restoreErrors++
                }
            }
        }
    } catch {}

    # 8. Delete sign-on policies NOT in snapshot (created by Deploy)
    Write-Log -Level INFO -Message "Checking for sign-on policies to remove..."
    $snapPolicyIds2 = @()
    if ($snap.signOnPolicies) { $snapPolicyIds2 = @($snap.signOnPolicies | ForEach-Object { $_.id }) }
    try {
        $currentPolicies2 = Find-OktaPolicies
        foreach ($p in @($currentPolicies2)) {
            if ($p.id -notin $snapPolicyIds2) {
                Write-Log -Level INFO -Message "Deleting sign-on policy '$($p.name)' (created by Deploy)..."
                try { Remove-OktaPolicy -PolicyId $p.id -PolicyName $p.name }
                catch {
                    Write-Log -Level WARN -Message "Failed to delete policy '$($p.name)': $_" -Action 'RestoreDeletePolicy'
                    $restoreErrors++
                }
            }
        }
    } catch {}

    # 9. Delete groups NOT in snapshot (created by Deploy)
    Write-Log -Level INFO -Message "Checking for groups to remove..."
    $snapGroupIds2 = @()
    if ($snap.groups) { $snapGroupIds2 = @($snap.groups | ForEach-Object { $_.id }) }
    try {
        $currentGroups2 = Find-OktaGroups
        foreach ($g in @($currentGroups2)) {
            if ($g.id -notin $snapGroupIds2) {
                Write-Log -Level INFO -Message "Deleting group '$($g.profile.name)' (created by Deploy)..."
                try { Remove-OktaGroup -GroupId $g.id -GroupName $g.profile.name }
                catch {
                    Write-Log -Level WARN -Message "Failed to delete group '$($g.profile.name)': $_" -Action 'RestoreDeleteGroup'
                    $restoreErrors++
                }
            }
        }
    } catch {}

    # 10. Delete users NOT in snapshot (created by Deploy)
    Write-Log -Level INFO -Message "Checking for users to remove..."
    $snapUserIds2 = @()
    if ($snap.users) { $snapUserIds2 = @($snap.users | ForEach-Object { $_.id }) }
    try {
        $currentUsers2 = Find-OktaUsers
        foreach ($u in @($currentUsers2)) {
            if ($u.id -notin $snapUserIds2) {
                Write-Log -Level INFO -Message "Deleting user '$($u.profile.login)' (created by Deploy)..."
                try { Remove-OktaUser -UserId $u.id -UserLogin $u.profile.login }
                catch {
                    Write-Log -Level WARN -Message "Failed to delete user '$($u.profile.login)': $_" -Action 'RestoreDeleteUser'
                    $restoreErrors++
                }
            }
        }
    } catch {}

    # 11. Delete role bindings not in snapshot (fix #9/#10 -- dependency order: bindings first)
    if ($bindingsToDelete.Count -gt 0) {
        Write-Log -Level INFO -Message "Removing $($bindingsToDelete.Count) role binding(s) not in snapshot..."
        foreach ($b in $bindingsToDelete) {
            try {
                Remove-OktaRoleBinding -BindingId $b.id -UserId $cpmUser.id
                Write-Log -Level OK -Message "Deleted role binding '$($b.id)'" -Action 'RestoreDeleteBinding'
            }
            catch {
                Write-Log -Level WARN -Message "Failed to delete role binding '$($b.id)': $_" -Action 'RestoreDeleteBinding'
                $restoreErrors++
            }
        }
    }

    # 12. Delete resource set not in snapshot
    if ($rsToDelete) {
        Write-Log -Level INFO -Message "Removing resource set '$($currentResourceSet.label)' (not in snapshot)..."
        try {
            Remove-OktaResourceSet -ResourceSetId $currentResourceSet.id
            Write-Log -Level OK -Message "Deleted resource set '$($currentResourceSet.label)'" -Action 'RestoreDeleteResourceSet'
        }
        catch {
            Write-Log -Level WARN -Message "Failed to delete resource set: $_" -Action 'RestoreDeleteResourceSet'
            $restoreErrors++
        }
    }

    # 13. Delete custom role not in snapshot
    if ($roleToDelete) {
        Write-Log -Level INFO -Message "Removing custom role '$($currentCustomRole.label)' (not in snapshot)..."
        try {
            Remove-OktaCustomRole -RoleId $currentCustomRole.id
            Write-Log -Level OK -Message "Deleted custom role '$($currentCustomRole.label)'" -Action 'RestoreDeleteRole'
        }
        catch {
            Write-Log -Level WARN -Message "Failed to delete custom role: $_" -Action 'RestoreDeleteRole'
            $restoreErrors++
        }
    }

    Write-Host ""
    if ($restoreErrors -eq 0) {
        Write-Log -Level OK -Message "Full restore complete. $restoreErrors error(s)." -Action 'RestoreComplete'
    }
    else {
        Write-Log -Level WARN -Message "Full restore complete with $restoreErrors error(s). Review log for details." -Action 'RestoreComplete'
    }
    Write-Log -Level INFO -Message "Run -Action Inspect to verify restored state." -Action 'RestoreComplete'
}

#endregion

#region Deploy Functions

function New-OktaUser {
    param(
        [Parameter(Mandatory)][string]$Login,
        [Parameter(Mandatory)][string]$FirstName,
        [Parameter(Mandatory)][string]$LastName,
        [Parameter(Mandatory)][string]$Password
    )

    # Check if exists
    $encodedSearch = [uri]::EscapeDataString("profile.login eq `"$Login`"")
    $existing = Invoke-OktaApi -Path "/api/v1/users?search=$encodedSearch&limit=1"
    if ($existing -and @($existing).Count -gt 0) {
        $user = @($existing)[0]
        Write-Log -Level SKIP -Message "User '$Login' already exists (id: $($user.id))" -Action 'CreateUser'
        return $user
    }

    if ($Script:IsDryRun) {
        Write-Log -Level INFO -Message "[WhatIf] Would create user: $Login" -Action 'CreateUser'
        return [PSCustomObject]@{ id = "WHATIF-USER-$Login"; profile = @{ login = $Login } }
    }

    $body = @{
        profile = @{
            firstName = $FirstName
            lastName  = $LastName
            email     = $Login
            login     = $Login
        }
        credentials = @{
            password = @{ value = $Password }
            recovery_question = @{
                question = 'What is the CyberArk safe name?'
                answer   = (New-SecurePassword -Length 16)
            }
        }
    }
    $user = Invoke-OktaApi -Path '/api/v1/users?activate=true' -Method POST -Body $body
    Write-Log -Level OK -Message "Created user: $Login (id: $($user.id))" `
        -Action 'CreateUser' -Fields @{ Username = $Login; UserId = $user.id }
    return $user
}

function Set-OktaAdminRole {
    param(
        [Parameter(Mandatory)][string]$UserId,
        [Parameter(Mandatory)][string]$UserLogin,
        [Parameter(Mandatory)][string]$RoleType
    )

    # Check existing roles
    try {
        $existingRoles = Invoke-OktaApi -Path "/api/v1/users/$UserId/roles"
        if ($existingRoles) {
            $hasRole = @($existingRoles) | Where-Object { $_.type -eq $RoleType }
            if ($hasRole) {
                Write-Log -Level SKIP -Message "User '$UserLogin' already has role $RoleType" -Action 'AssignRole'
                return
            }
        }
    }
    catch {}

    if ($Script:IsDryRun) {
        Write-Log -Level INFO -Message "[WhatIf] Would assign $RoleType to $UserLogin" -Action 'AssignRole'
        return
    }

    try {
        $body = @{ type = $RoleType }
        Invoke-OktaApi -Path "/api/v1/users/$UserId/roles" -Method POST -Body $body | Out-Null
        Write-Log -Level OK -Message "Assigned $RoleType to $UserLogin" `
            -Action 'AssignRole' -Fields @{ Username = $UserLogin; Role = $RoleType }
    }
    catch {
        if ($_ -match '403') {
            Write-Log -Level WARN -Message "Cannot assign $RoleType to $UserLogin (403 -- developer tenant limitation?). Assign manually in UI."
        }
        else { throw }
    }
}

function New-OktaGroup {
    param(
        [Parameter(Mandatory)][string]$Name,
        [string]$Description = ''
    )

    # Check if exists
    $encodedQ = [uri]::EscapeDataString($Name)
    $existing = Invoke-OktaApi -Path "/api/v1/groups?q=$encodedQ&limit=10"
    if ($existing) {
        $exact = @($existing) | Where-Object { $_.profile.name -eq $Name }
        if ($exact) {
            Write-Log -Level SKIP -Message "Group '$Name' already exists (id: $($exact.id))" -Action 'CreateGroup'
            return $exact
        }
    }

    if ($Script:IsDryRun) {
        Write-Log -Level INFO -Message "[WhatIf] Would create group: $Name" -Action 'CreateGroup'
        return [PSCustomObject]@{ id = "WHATIF-GROUP-$Name"; profile = @{ name = $Name } }
    }

    $body = @{
        profile = @{
            name        = $Name
            description = $Description
        }
    }
    $group = Invoke-OktaApi -Path '/api/v1/groups' -Method POST -Body $body
    Write-Log -Level OK -Message "Created group: $Name (id: $($group.id))" `
        -Action 'CreateGroup' -Fields @{ GroupName = $Name; GroupId = $group.id }
    return $group
}

function Add-OktaUserToGroup {
    param(
        [Parameter(Mandatory)][string]$GroupId,
        [Parameter(Mandatory)][string]$UserId,
        [string]$GroupName = '',
        [string]$UserLogin = ''
    )

    if ($Script:IsDryRun) {
        Write-Log -Level INFO -Message "[WhatIf] Would add $UserLogin to group $GroupName" -Action 'AddGroupMember'
        return
    }

    try {
        Invoke-OktaApi -Path "/api/v1/groups/$GroupId/users/$UserId" -Method PUT | Out-Null
        Write-Log -Level OK -Message "Added $UserLogin to $GroupName" `
            -Action 'AddGroupMember' -Fields @{ GroupName = $GroupName; Username = $UserLogin }
    }
    catch {
        if ($_ -match '404') {
            Write-Log -Level WARN -Message "Cannot add $UserLogin to $GroupName (group or user not found)"
        }
        else { throw }
    }
}

function New-OktaNetworkZone {
    param(
        [string[]]$GatewayIPs = @('10.0.0.0/8')
    )

    $zone = Find-OktaNetworkZone
    if ($zone) {
        Write-Log -Level SKIP -Message "Network zone '$Script:NETWORK_ZONE_NAME' already exists" -Action 'CreateZone'
        return $zone
    }

    if ($Script:IsDryRun) {
        Write-Log -Level INFO -Message "[WhatIf] Would create network zone: $Script:NETWORK_ZONE_NAME" -Action 'CreateZone'
        return [PSCustomObject]@{ id = "WHATIF-ZONE"; name = $Script:NETWORK_ZONE_NAME }
    }

    $body = @{
        type    = 'IP'
        name    = $Script:NETWORK_ZONE_NAME
        status  = 'ACTIVE'
        gateways = @(
            foreach ($ip in $GatewayIPs) {
                @{ type = 'CIDR'; value = $ip }
            }
        )
    }
    $created = Invoke-OktaApi -Path '/api/v1/zones' -Method POST -Body $body
    Write-Log -Level OK -Message "Created network zone: $Script:NETWORK_ZONE_NAME (id: $($created.id))" `
        -Action 'CreateZone' -Fields @{ ZoneId = $created.id }
    return $created
}

function New-OktaCustomRole {
    $existing = Find-OktaCustomRole
    if ($existing) { return $existing }

    if ($Script:IsDryRun) {
        Write-Log -Level INFO -Message "[WhatIf] Would create custom role: $Script:CUSTOM_ROLE_NAME" -Action 'CreateRole'
        return [PSCustomObject]@{ id = "WHATIF-ROLE" }
    }

    $body = @{
        label       = $Script:CUSTOM_ROLE_NAME
        description = 'Minimum-privilege role for CyberArk CPM password rotation. Can only manage user credentials within the scoped resource set.'
        permissions  = @(
            @{ label = 'okta.users.credentials.manage' }
            @{ label = 'okta.users.read' }
            @{ label = 'okta.groups.read' }
        )
    }
    $role = Invoke-OktaApi -Path '/api/v1/iam/roles' -Method POST -Body $body
    Write-Log -Level OK -Message "Created custom role: $Script:CUSTOM_ROLE_NAME (id: $($role.id))" `
        -Action 'CreateRole' -Fields @{ RoleId = $role.id }
    return $role
}

function New-OktaResourceSet {
    param([string]$UmbrellaGroupId)

    $existing = Find-OktaResourceSet
    if ($existing) { return $existing }

    if ($Script:IsDryRun) {
        Write-Log -Level INFO -Message "[WhatIf] Would create resource set: $Script:RESOURCE_SET_NAME" -Action 'CreateResourceSet'
        return [PSCustomObject]@{ id = "WHATIF-RS" }
    }

    $orgUrl = $Script:OktaBaseUrl
    $body = @{
        label       = $Script:RESOURCE_SET_NAME
        description = 'All CyberArk-vaulted HLA accounts (Tier 1 + 2 + 3). Scopes CPM credential management.'
        resources   = @(
            "$orgUrl/api/v1/groups/$UmbrellaGroupId"
        )
    }
    $rs = Invoke-OktaApi -Path '/api/v1/iam/resource-sets' -Method POST -Body $body
    Write-Log -Level OK -Message "Created resource set: $Script:RESOURCE_SET_NAME (id: $($rs.id))" `
        -Action 'CreateResourceSet' -Fields @{ ResourceSetId = $rs.id }
    return $rs
}

function New-OktaRoleBinding {
    param(
        [Parameter(Mandatory)][string]$ResourceSetId,
        [Parameter(Mandatory)][string]$RoleId,
        [Parameter(Mandatory)][string]$CpmUserId
    )

    if ($Script:IsDryRun) {
        Write-Log -Level INFO -Message "[WhatIf] Would bind custom role to CPM service account" -Action 'CreateBinding'
        return
    }

    $orgUrl = $Script:OktaBaseUrl
    $body = @{
        role    = "$orgUrl/api/v1/iam/roles/$RoleId"
        members = @(
            "$orgUrl/api/v1/users/$CpmUserId"
        )
    }
    try {
        Invoke-OktaApi -Path "/api/v1/iam/resource-sets/$ResourceSetId/bindings" -Method POST -Body $body | Out-Null
        Write-Log -Level OK -Message "Bound custom role to CPM service account" `
            -Action 'CreateBinding' -Fields @{ ResourceSetId = $ResourceSetId; RoleId = $RoleId; CpmUserId = $CpmUserId }
    }
    catch {
        if ($_ -match '409') {
            Write-Log -Level SKIP -Message "Role binding already exists" -Action 'CreateBinding'
        }
        else { throw }
    }
}

function New-OktaSignOnPolicy {
    param(
        [Parameter(Mandatory)][string]$Name,
        [string]$Description,
        [Parameter(Mandatory)][string]$GroupId,
        [int]$Priority,
        [hashtable[]]$Rules
    )

    # Check if exists -- if so, update session settings on ALLOW rules if they differ
    foreach ($policyType in @('ACCESS_POLICY', 'OKTA_SIGN_ON')) {
        try {
            $policies = Invoke-OktaApi -Path "/api/v1/policies?type=$policyType&limit=200"
            if ($policies) {
                $exact = @($policies) | Where-Object { $_.name -eq $Name }
                if ($exact) {
                    $polId = $exact.id
                    Write-Log -Level SKIP -Message "Sign-on policy '$Name' already exists (id: $polId)" -Action 'CreatePolicy'

                    # Update session settings on existing ALLOW rules if they differ from desired.
                    # Wrapped in separate try/catch so failures don't prevent the return.
                    try { if (-not $Script:IsDryRun -and $Rules) {
                        $existingRules = @(Invoke-OktaApi -Path "/api/v1/policies/$polId/rules")
                        foreach ($desiredRule in $Rules) {
                            $desiredSession = $desiredRule.actions.signon.session
                            if (-not $desiredSession -or $desiredRule.actions.signon.access -eq 'DENY') { continue }

                            # Match by rule name first, fallback to first ALLOW rule
                            $matchRule = @($existingRules) | Where-Object { $_.name -eq $desiredRule.name } | Select-Object -First 1
                            if (-not $matchRule) {
                                # Fallback: find the ALLOW rule (there should be exactly one per policy)
                                $matchRule = @($existingRules) | Where-Object {
                                    $_.actions.signon.access -eq 'ALLOW'
                                } | Select-Object -First 1
                            }
                            if (-not $matchRule) { continue }

                            $curSession = $matchRule.actions.signon.session
                            $curIdle     = if ($curSession.PSObject.Properties['maxSessionIdleMinutes'])     { $curSession.maxSessionIdleMinutes }     else { 0 }
                            $curLifetime = if ($curSession.PSObject.Properties['maxSessionLifetimeMinutes']) { $curSession.maxSessionLifetimeMinutes } else { 0 }
                            $wantIdle     = $desiredSession.maxSessionIdleMinutes
                            $wantLifetime = $desiredSession.maxSessionLifetimeMinutes

                            # Also check factorPromptMode
                            $curPrompt  = $matchRule.actions.signon.factorPromptMode
                            $wantPrompt = $desiredRule.actions.signon.factorPromptMode

                            if ($curIdle -eq $wantIdle -and $curLifetime -eq $wantLifetime -and $curPrompt -eq $wantPrompt) {
                                Write-Log -Level SKIP -Message "Rule '$($matchRule.name)' session settings already correct (idle=${curIdle}m, lifetime=${curLifetime}m, prompt=$curPrompt)" -Action 'UpdateSignOnRule'
                                continue
                            }

                            Write-Log -Level INFO -Message "Updating rule '$($matchRule.name)': idle ${curIdle}m->${wantIdle}m, lifetime ${curLifetime}m->${wantLifetime}m, prompt ${curPrompt}->${wantPrompt}"
                            $matchRule.actions.signon.session.maxSessionIdleMinutes     = $wantIdle
                            $matchRule.actions.signon.session.maxSessionLifetimeMinutes = $wantLifetime
                            $matchRule.actions.signon.factorPromptMode                 = $wantPrompt
                            $matchRule.actions.signon.rememberDeviceByDefault           = $desiredRule.actions.signon.rememberDeviceByDefault
                            try {
                                Invoke-OktaApi -Path "/api/v1/policies/$polId/rules/$($matchRule.id)" -Method PUT -Body $matchRule | Out-Null
                                Write-Log -Level OK -Message "Updated sign-on rule '$($matchRule.name)' session settings" -Action 'UpdateSignOnRule'
                            }
                            catch {
                                Write-Log -Level WARN -Message "Failed to update sign-on rule '$($matchRule.name)': $_" -Action 'UpdateSignOnRule'
                            }
                        }
                    } } catch {
                        Write-Log -Level WARN -Message "Could not update session settings for '$Name': $_" -Action 'UpdateSignOnRule'
                    }

                    return $exact
                }
            }
        }
        catch {}
    }

    if ($Script:IsDryRun) {
        Write-Log -Level INFO -Message "[WhatIf] Would create sign-on policy: $Name" -Action 'CreatePolicy'
        return [PSCustomObject]@{ id = "WHATIF-POLICY-$Name"; name = $Name }
    }

    $body = @{
        type        = 'OKTA_SIGN_ON'
        status      = 'ACTIVE'
        name        = $Name
        description = $Description
        priority    = $Priority
        conditions  = @{
            people = @{
                groups = @{
                    include = @($GroupId)
                }
            }
        }
    }
    $policy = Invoke-OktaApi -Path '/api/v1/policies' -Method POST -Body $body
    Write-Log -Level OK -Message "Created sign-on policy: $Name (id: $($policy.id))" `
        -Action 'CreatePolicy' -Fields @{ PolicyName = $Name; PolicyId = $policy.id }

    # Create rules
    foreach ($rule in $Rules) {
        $rule['type'] = 'SIGN_ON'
        try {
            $createdRule = Invoke-OktaApi -Path "/api/v1/policies/$($policy.id)/rules" -Method POST -Body $rule
            Write-Log -Level OK -Message "  Created rule: $($rule['name']) (id: $($createdRule.id))" `
                -Action 'CreatePolicyRule' -Fields @{ PolicyId = $policy.id; RuleName = $rule['name'] }
        }
        catch {
            Write-Log -Level WARN -Message "  Failed to create rule '$($rule['name'])': $_"
        }
    }

    return $policy
}

function ConvertFrom-IsoDuration {
    <#
    .SYNOPSIS
        Converts an ISO 8601 duration string to a human-readable description.
    .EXAMPLE
        ConvertFrom-IsoDuration 'PT0S'  -> "0 seconds (re-authenticates on every request -- PSM INCOMPATIBLE)"
        ConvertFrom-IsoDuration 'PT2H'  -> "2 hours"
        ConvertFrom-IsoDuration 'PT90M' -> "90 minutes (1 hour 30 minutes)"
    #>
    param([string]$Duration)

    if ([string]::IsNullOrWhiteSpace($Duration)) { return '(not set)' }

    $hours   = 0
    $minutes = 0
    $seconds = 0

    if ($Duration -match 'PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?') {
        if ($Matches[1]) { $hours   = [int]$Matches[1] }
        if ($Matches[2]) { $minutes = [int]$Matches[2] }
        if ($Matches[3]) { $seconds = [int]$Matches[3] }
    }
    else {
        return $Duration
    }

    $totalSeconds = $hours * 3600 + $minutes * 60 + $seconds

    if ($totalSeconds -eq 0) {
        return 'PT0S -- 0 seconds (re-authenticates on EVERY page load -- BREAKS PSM sessions)'
    }

    $parts = @()
    if ($hours   -gt 0) { $parts += "$hours hour$(if ($hours   -ne 1) { 's' })" }
    if ($minutes -gt 0) { $parts += "$minutes minute$(if ($minutes -ne 1) { 's' })" }
    if ($seconds -gt 0) { $parts += "$seconds second$(if ($seconds -ne 1) { 's' })" }
    $friendly = $parts -join ' '

    # Add total-minutes note if not already obvious
    $totalMinutes = [math]::Round($totalSeconds / 60)
    if ($hours -gt 0 -and $minutes -gt 0) {
        $friendly += " ($totalMinutes minutes total)"
    }

    return "$Duration -- $friendly"
}

function Get-IsoDurationSeconds {
    <#
    .SYNOPSIS
        Returns the total seconds represented by an ISO 8601 PT duration string.
        Returns -1 for PT0S or empty/null (special sentinel).
    #>
    param([string]$Duration)
    if ([string]::IsNullOrWhiteSpace($Duration)) { return 0 }
    $h = 0; $m = 0; $s = 0
    if ($Duration -match 'PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?') {
        if ($Matches[1]) { $h = [int]$Matches[1] }
        if ($Matches[2]) { $m = [int]$Matches[2] }
        if ($Matches[3]) { $s = [int]$Matches[3] }
    }
    return $h * 3600 + $m * 60 + $s
}

function Assert-ReauthCompliance {
    <#
    .SYNOPSIS
        Validates Tier*ReauthDuration values against NIST SP 800-53 AC-12 thresholds.

    .DESCRIPTION
        Three compliance levels:
          REFUSED  -- PT0S (breaks PSM sessions) or > PT12H (exceeds NIST AAL2/3 ceiling).
                      Script halts; implementor must fix the value.
          WARNING  -- Exceeds PAM best-practice maximum for the tier but <= PT12H.
                      Prints yellow warning citing NIST. Prompts Y/N unless -AcceptDefaults,
                      in which case the warning is printed but execution continues.
          OK       -- Within PAM best-practice bounds.

        NIST PAM best-practice maximums:
          Tier 1 (SuperAdmin): PT1H  (3600 s)
          Tier 2 (OrgAdmin):   PT2H  (7200 s)
          Tier 3 (Users):      PT2H  (7200 s)
        NIST AAL2/3 absolute ceiling (all tiers): PT12H (43200 s)
    #>
    param(
        [Parameter(Mandatory)][string]$TierLabel,
        [Parameter(Mandatory)][string]$Duration,
        [Parameter(Mandatory)][int]$RecommendedMaxSeconds,
        [switch]$AcceptDefaults
    )

    $nistCeilingSeconds = 43200   # PT12H -- NIST SP 800-63B AAL2/3 absolute maximum
    $durationSeconds    = Get-IsoDurationSeconds -Duration $Duration
    $friendlyDuration   = ConvertFrom-IsoDuration -Duration $Duration
    if ($RecommendedMaxSeconds -eq 3600)       { $maxIso = 'PT1H' }
    elseif ($RecommendedMaxSeconds -eq 7200)   { $maxIso = 'PT2H' }
    else { $maxIso = "PT$([int]($RecommendedMaxSeconds / 3600))H" }
    $friendlyMax = ConvertFrom-IsoDuration -Duration $maxIso

    # PT0S -- unconditional refusal
    if ($durationSeconds -eq 0) {
        Write-Host ""
        Write-Host "  [ERROR] $TierLabel ReauthDuration is PT0S." -ForegroundColor Red
        Write-Host "  PT0S forces re-authentication on every page load, which immediately" -ForegroundColor Red
        Write-Host "  terminates any active PSM browser session. This value is not allowed." -ForegroundColor Red
        Write-Host "  Use PT1H (Tier 1) or PT2H (Tier 2/3) as the minimum safe value." -ForegroundColor Red
        throw "ReauthDuration PT0S is not permitted for PSM-managed accounts."
    }

    # Above NIST AAL2/3 ceiling -- unconditional refusal
    if ($durationSeconds -gt $nistCeilingSeconds) {
        Write-Host ""
        Write-Host "  [ERROR] $TierLabel ReauthDuration ($friendlyDuration) exceeds the" -ForegroundColor Red
        Write-Host "  NIST SP 800-63B AAL2/3 absolute maximum of PT12H (12 hours)." -ForegroundColor Red
        Write-Host "  This limit cannot be overridden. Reduce the value to PT12H or below." -ForegroundColor Red
        throw "ReauthDuration exceeds NIST AAL2/3 ceiling of PT12H."
    }

    # Above tier PAM best-practice maximum -- warning with prompt
    if ($durationSeconds -gt $RecommendedMaxSeconds) {
        Write-Host ""
        Write-Host "  [COMPLIANCE WARNING]" -ForegroundColor Yellow
        Write-Host "  $TierLabel ReauthDuration: $friendlyDuration" -ForegroundColor Yellow
        Write-Host "  PAM best practice (NIST SP 800-53 AC-12 / SP 800-207): $friendlyMax" -ForegroundColor Yellow
        Write-Host "  A longer window increases the residual exposure of a stolen or orphaned" -ForegroundColor Yellow
        Write-Host "  browser session on a shared privileged account. The session will remain" -ForegroundColor Yellow
        Write-Host "  valid for the full duration even if the CyberArk checkout has ended." -ForegroundColor Yellow
        Write-Host "  Reference: NIST SP 800-53r5 AC-12, NIST SP 800-207 Section 2.1" -ForegroundColor Yellow
        Write-Host ""

        if (-not $AcceptDefaults) {
            $answer = Read-SecureInput -Prompt "  Accept non-compliant value for $TierLabel? [y/N]"
            if ($answer -notmatch '^[Yy]') {
                throw "Implementor declined non-compliant ReauthDuration for $TierLabel. Adjust the value and re-run."
            }
        }
        else {
            Write-Host "  (-AcceptDefaults set -- proceeding despite compliance warning)" -ForegroundColor Yellow
        }
    }
}

function Get-HlaGroupMap {
    <#
    .SYNOPSIS
        Returns a hashtable of HLA group name to Okta group ID for the 3 tier groups.
        Used by Inspect and Rollback to look up groups without a full Deploy context.
    #>
    $map = @{}
    try {
        $groups = @(Invoke-OktaApi -Path '/api/v1/groups?q=CyberArk-HLA&limit=25')
        foreach ($g in $groups) {
            $name = $g.profile.name
            if ($name -eq 'CyberArk-HLA-SuperAdmin' -or
                $name -eq 'CyberArk-HLA-OrgAdmin'   -or
                $name -eq 'CyberArk-HLA-Users') {
                $map[$name] = $g.id
            }
        }
    }
    catch {
        Write-Log -Level WARN -Message "Could not retrieve HLA groups: $_"
    }
    return $map
}

function Get-CurrentStep11State {
    <#
    .SYNOPSIS
        Reads the current Admin Console ACCESS_POLICY rules for all 3 HLA tier groups.
        Returns a PSCustomObject with PolicyId, PolicyName, and a Rules array.
    #>
    $result = [PSCustomObject]@{
        PolicyId   = $null
        PolicyName = $null
        Rules      = @()
    }

    try {
        $policies = @(Invoke-OktaApi -Path '/api/v1/policies?type=ACCESS_POLICY&limit=200')
        $policy = $policies | Where-Object { $_.name -eq 'Okta Admin Console' } | Select-Object -First 1
        if (-not $policy) { return $result }

        $result.PolicyId   = $policy.id
        $result.PolicyName = $policy.name

        $rules    = @(Invoke-OktaApi -Path "/api/v1/policies/$($policy.id)/rules")
        $groupMap = Get-HlaGroupMap

        $tierDefs = @(
            [PSCustomObject]@{ TierLabel = 'Tier 1 (SuperAdmin)'; GroupName = 'CyberArk-HLA-SuperAdmin'; RecommendedMaxSec = 3600 }
            [PSCustomObject]@{ TierLabel = 'Tier 2 (OrgAdmin)';   GroupName = 'CyberArk-HLA-OrgAdmin';   RecommendedMaxSec = 7200 }
            [PSCustomObject]@{ TierLabel = 'Tier 3 (Users)';      GroupName = 'CyberArk-HLA-Users';      RecommendedMaxSec = 7200 }
        )

        $ruleList = @()
        foreach ($td in $tierDefs) {
            $groupId = $groupMap[$td.GroupName]
            $rule    = $null
            if ($groupId) {
                $rule = $rules | Where-Object { $_.conditions.people.groups.include -contains $groupId } | Select-Object -First 1
            }
            $reauth = $null
            if ($rule -and $rule.PSObject.Properties['actions']) {
                $v = $rule.actions.appSignOn.verificationMethod
                if ($v -and $v.PSObject.Properties['reauthenticateIn']) { $reauth = $v.reauthenticateIn }
            }
            $ruleList += [PSCustomObject]@{
                TierLabel        = $td.TierLabel
                GroupName        = $td.GroupName
                GroupId          = $groupId
                RuleId           = if ($rule) { $rule.id }   else { $null }
                RuleName         = if ($rule) { $rule.name } else { '(no rule)' }
                ReauthIn         = $reauth
                RecommendedMaxSec = $td.RecommendedMaxSec
            }
        }
        $result.Rules = $ruleList
    }
    catch {
        Write-Log -Level WARN -Message "Could not read Step 11 state: $_"
    }
    return $result
}

function Get-CurrentStep10State {
    <#
    .SYNOPSIS
        Reads the current OKTA_SIGN_ON (Layer 1) session policy settings for each HLA tier.
        Returns an array of PSCustomObjects with idle, lifetime, MFA prompt, and reauth values.
    #>
    $tierPolicies = @(
        [PSCustomObject]@{ TierLabel = 'Tier 1 (SuperAdmin)'; PolicyName = $Script:POLICY_NAMES[1] }
        [PSCustomObject]@{ TierLabel = 'Tier 2 (OrgAdmin)';   PolicyName = $Script:POLICY_NAMES[2] }
        [PSCustomObject]@{ TierLabel = 'Tier 3 (Users)';      PolicyName = $Script:POLICY_NAMES[3] }
    )

    $allPolicies = @()
    try {
        $allPolicies = @(Invoke-OktaApi -Path '/api/v1/policies?type=OKTA_SIGN_ON&limit=200')
    }
    catch {
        Write-Log -Level WARN -Message "Could not retrieve sign-on policies: $_"
    }

    $result = @()
    foreach ($tp in $tierPolicies) {
        $policy = $allPolicies | Where-Object { $_.name -eq $tp.PolicyName } | Select-Object -First 1
        if (-not $policy) {
            $result += [PSCustomObject]@{
                TierLabel       = $tp.TierLabel
                PolicyName      = $tp.PolicyName
                PolicyFound     = $false
                IdleMinutes     = $null
                LifetimeMinutes = $null
                MfaPrompt       = $null
                MfaLifetimeMin  = $null
            }
            continue
        }

        $idle = $null; $lifetime = $null; $mfaPrompt = $null; $mfaLife = $null
        try {
            $rules     = @(Invoke-OktaApi -Path "/api/v1/policies/$($policy.id)/rules")
            $allowRule = $rules | Where-Object {
                $_.PSObject.Properties['actions'] -and
                $_.actions.PSObject.Properties['signon'] -and
                $_.actions.signon.access -eq 'ALLOW'
            } | Sort-Object priority | Select-Object -First 1

            if ($allowRule) {
                $s = $allowRule.actions.signon
                if ($s.PSObject.Properties['session']) {
                    $sess = $s.session
                    if ($sess.PSObject.Properties['maxSessionIdleMinutes'])     { $idle     = $sess.maxSessionIdleMinutes }
                    if ($sess.PSObject.Properties['maxSessionLifetimeMinutes']) { $lifetime = $sess.maxSessionLifetimeMinutes }
                }
                if ($s.PSObject.Properties['factorPromptMode']) { $mfaPrompt = $s.factorPromptMode }
                if ($s.PSObject.Properties['factorLifetime'])   { $mfaLife   = $s.factorLifetime }
            }
        }
        catch {
            Write-Log -Level WARN -Message "Could not read rules for policy $($policy.name): $_"
        }

        $result += [PSCustomObject]@{
            TierLabel       = $tp.TierLabel
            PolicyName      = $tp.PolicyName
            PolicyFound     = $true
            IdleMinutes     = $idle
            LifetimeMinutes = $lifetime
            MfaPrompt       = $mfaPrompt
            MfaLifetimeMin  = $mfaLife
        }
    }
    return $result
}

function Get-ComplianceTag {
    <#
    .SYNOPSIS
        Returns a formatted compliance status string for a given reauthenticateIn duration.
    #>
    param([int]$Seconds, [int]$RecommendedMaxSec)
    $nistCeiling = 43200
    if ($null -eq $Seconds -or $Seconds -lt 0) { return '[UNKNOWN]' }
    if ($Seconds -eq 0)                        { return '[REFUSED -- PT0S breaks sessions]' }
    if ($Seconds -gt $nistCeiling)             { return '[EXCEEDS NIST AAL2/3 MAX (PT12H)]' }
    if ($Seconds -gt $RecommendedMaxSec)       { return '[WARNING -- above PAM best practice]' }
    return '[COMPLIANT]'
}

function Save-RollbackSnapshot {
    <#
    .SYNOPSIS
        Writes a JSON snapshot of the current Step 11 ACCESS_POLICY rule state to the
        Rollbacks\ directory. Called automatically before any Step 11 changes.
    #>
    param([Parameter(Mandatory)][object]$Step11State)

    if (-not (Test-Path $Script:ROLLBACK_DIR)) {
        New-Item -ItemType Directory -Path $Script:ROLLBACK_DIR -Force | Out-Null
    }

    $ts      = Get-Date -Format 'yyyyMMdd-HHmmss'
    $corrId8 = $Script:CorrelationId.Substring(0, 8)
    $file    = Join-Path $Script:ROLLBACK_DIR "Deploy-OktaHLABootstrap-Step11-$ts-$corrId8.json"

    $payload = [ordered]@{
        timestamp     = (Get-Date -Format 'o')
        correlationId = $Script:CorrelationId
        scriptVersion = $Script:VERSION
        tenant        = $Script:OktaBaseUrl
        policyId      = $Step11State.PolicyId
        policyName    = $Step11State.PolicyName
        rules         = @($Step11State.Rules | ForEach-Object {
            [ordered]@{
                tierLabel        = $_.TierLabel
                groupName        = $_.GroupName
                groupId          = $_.GroupId
                ruleId           = $_.RuleId
                ruleName         = $_.RuleName
                reauthenticateIn = $_.ReauthIn
            }
        })
    }

    $payload | ConvertTo-Json -Depth 6 | Set-Content -Path $file -Encoding UTF8
    Write-Log -Level INFO -Message "Rollback snapshot saved: $file"
    return $file
}

function Invoke-Inspect {
    <#
    .SYNOPSIS
        Displays current Layer 1 (OKTA_SIGN_ON) and Layer 2 (ACCESS_POLICY) session
        settings for all HLA tiers with NIST compliance status tags. Read-only.
    #>
    Write-Host ""
    Write-Host "  ================================================================" -ForegroundColor Cyan
    Write-Host "  INSPECT: Current Okta HLA Session Settings" -ForegroundColor Cyan
    Write-Host "  ================================================================" -ForegroundColor Cyan
    Write-Host "  Tenant:    $Script:OktaBaseUrl" -ForegroundColor White
    Write-Host "  Timestamp: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor White
    Write-Host ""

    # --- LAYER 2: ACCESS_POLICY (Step 11) ---
    Write-Host "  LAYER 2: Admin Console ACCESS_POLICY (Step 11 -- reauthenticateIn)" -ForegroundColor Yellow
    Write-Host "  $('-' * 68)" -ForegroundColor DarkGray
    Write-Host "  Controls how long the Admin Console trusts MFA after login." -ForegroundColor DarkGray
    Write-Host "  PAM best practice: Tier 1 <= PT1H, Tier 2/3 <= PT2H. NIST max: PT12H." -ForegroundColor DarkGray
    Write-Host ""

    $state11 = Get-CurrentStep11State
    if (-not $state11.PolicyId) {
        Write-Host "  Admin Console ACCESS_POLICY not found." -ForegroundColor Yellow
        Write-Host "  (Integrator/developer tenants may not expose this policy via API.)" -ForegroundColor DarkGray
    }
    else {
        Write-Host ("  {0,-22} {1,-30} {2}" -f 'Tier', 'reauthenticateIn', 'Status') -ForegroundColor DarkGray
        Write-Host ("  {0,-22} {1,-30} {2}" -f ('-' * 21), ('-' * 29), ('-' * 30)) -ForegroundColor DarkGray
        foreach ($r in $state11.Rules) {
            $secs     = if ($r.ReauthIn) { Get-IsoDurationSeconds -Duration $r.ReauthIn } else { -1 }
            $tag      = Get-ComplianceTag -Seconds $secs -RecommendedMaxSec $r.RecommendedMaxSec
            $friendly = if ($r.ReauthIn) { ConvertFrom-IsoDuration -Duration $r.ReauthIn } else { '(no rule found)' }
            $tagColor = if ($tag -like '*COMPLIANT*' -and $tag -notlike '*WARNING*') { 'Green' } `
                        elseif ($tag -like '*WARNING*') { 'Yellow' } else { 'Red' }
            Write-Host ("  {0,-22} {1,-30}" -f $r.TierLabel, $friendly) -NoNewline -ForegroundColor White
            Write-Host " $tag" -ForegroundColor $tagColor
        }
        Write-Host ""
        Write-Host "  Policy: $($state11.PolicyName) (id: $($state11.PolicyId))" -ForegroundColor DarkGray
    }

    Write-Host ""

    # --- LAYER 1: OKTA_SIGN_ON (Step 10) ---
    Write-Host "  LAYER 1: Global Session Policies (OKTA_SIGN_ON, Step 10)" -ForegroundColor Yellow
    Write-Host "  $('-' * 68)" -ForegroundColor DarkGray
    Write-Host "  Controls session cookie idle timeout and absolute wall-clock lifetime." -ForegroundColor DarkGray
    Write-Host "  Idle resets on any authenticated request. Lifetime is absolute from login." -ForegroundColor DarkGray
    Write-Host ""

    $state10 = Get-CurrentStep10State
    foreach ($p in $state10) {
        Write-Host "  $($p.TierLabel)" -ForegroundColor White
        if (-not $p.PolicyFound) {
            Write-Host "    Policy not found: $($p.PolicyName)" -ForegroundColor Yellow
            Write-Host ""
            continue
        }
        $idleStr     = if ($null -ne $p.IdleMinutes)     { "$($p.IdleMinutes) min (rolling inactivity)" } else { '(unknown)' }
        $lifetimeStr = if ($null -ne $p.LifetimeMinutes) { "$($p.LifetimeMinutes) min (absolute wall-clock)" } else { '(unknown)' }
        $mfaStr      = if ($p.MfaPrompt)                 { $p.MfaPrompt } else { '(unknown)' }
        $reauthStr   = if ($null -ne $p.MfaLifetimeMin)  { "$($p.MfaLifetimeMin) min" } else { '(unknown)' }
        Write-Host "    Session Idle:     $idleStr" -ForegroundColor White
        Write-Host "    Session Lifetime: $lifetimeStr" -ForegroundColor White
        $mfaColor = if ($mfaStr -eq 'ALWAYS') { 'Green' } elseif ($mfaStr -eq 'DEVICE') { 'Yellow' } else { 'White' }
        Write-Host "    MFA Prompt:       " -NoNewline -ForegroundColor White
        Write-Host $mfaStr -NoNewline -ForegroundColor $mfaColor
        if ($mfaStr -eq 'DEVICE') { Write-Host " (WARNING: not appropriate for shared accounts -- use ALWAYS)" -ForegroundColor Yellow }
        else { Write-Host "" }
        Write-Host "    MFA Re-auth:      $reauthStr" -ForegroundColor White
        Write-Host ""
    }

    # --- LAYER 3: MFA Enrollment Policy (Step 5.5) ---
    Write-Host "  LAYER 3: MFA Enrollment Policy (Step 5.5 -- TOTP Authenticator & Enrollment)" -ForegroundColor Yellow
    Write-Host "  $('-' * 68)" -ForegroundColor DarkGray
    Write-Host "  Controls which users can self-enroll TOTP (provider: $Script:SELECTED_TOTP_KEY)." -ForegroundColor DarkGray
    Write-Host "  HLA accounts need $Script:SELECTED_TOTP_KEY REQUIRED, $Script:BLOCKED_TOTP_KEY NOT_ALLOWED." -ForegroundColor DarkGray
    Write-Host ""

    $inspPipeline = Get-OktaEnginePipeline
    Write-Host "  Tenant engine:  $inspPipeline" -ForegroundColor White
    Write-Host ""

    # Authenticator status (show selected provider)
    $inspAllAuth = @()
    try { $inspAllAuth = @(Invoke-OktaApi -Path '/api/v1/authenticators') } catch {}
    $inspAuthenticator = @($inspAllAuth) | Where-Object { $_.key -eq $Script:SELECTED_TOTP_KEY } | Select-Object -First 1
    if ($inspAuthenticator) {
        $authColor = if ($inspAuthenticator.status -eq 'ACTIVE') { 'Green' } else { 'Red' }
        $authTag   = if ($inspAuthenticator.status -eq 'ACTIVE') { '[OK -- required for CyberArk TOTP enrollment]' } `
                     else { '[WARNING -- cpm-simulator enroll-totp will fail]' }
        Write-Host "  $Script:SELECTED_TOTP_KEY authenticator:" -NoNewline -ForegroundColor White
        Write-Host (" {0}" -f $inspAuthenticator.status) -NoNewline -ForegroundColor $authColor
        Write-Host "  $authTag" -ForegroundColor $authColor
        Write-Host "  Authenticator id: $($inspAuthenticator.id)" -ForegroundColor DarkGray
    }
    else {
        Write-Host "  $Script:SELECTED_TOTP_KEY authenticator:  NOT FOUND  [ERROR -- tenant may not support TOTP or is Classic Engine]" -ForegroundColor Red
    }
    Write-Host ""

    # HLA enrollment policy
    $inspHlaPolicy = Find-OktaHLAEnrollmentPolicy
    if ($inspHlaPolicy) {
        Write-Host "  HLA Enrollment Policy:    $($inspHlaPolicy.name)  [FOUND]" -ForegroundColor Green
        Write-Host "  Policy id:                $($inspHlaPolicy.id)" -ForegroundColor DarkGray

        # Check selected TOTP provider setting in policy
        $hlaTotpOk = $false
        if ($inspPipeline -eq 'OIE' -and $inspHlaPolicy.PSObject.Properties['settings'] -and
            $inspHlaPolicy.settings.PSObject.Properties['authenticators']) {
            $selEntry = @($inspHlaPolicy.settings.authenticators) | Where-Object { $_.key -eq $Script:SELECTED_TOTP_KEY }
            if ($selEntry) {
                $hlaTotpOk = $selEntry.enroll.self -in @('REQUIRED', 'OPTIONAL')
                $hlaTotpColor = if ($hlaTotpOk) { 'Green' } else { 'Red' }
                Write-Host ("  $Script:SELECTED_TOTP_KEY setting (selected):  {0}" -f $selEntry.enroll.self) -ForegroundColor $hlaTotpColor
            }
            else { Write-Host "  $Script:SELECTED_TOTP_KEY setting (selected):  NOT IN POLICY  [WARNING]" -ForegroundColor Red }

            # Check blocked TOTP provider (should be NOT_ALLOWED)
            $blkEntry = @($inspHlaPolicy.settings.authenticators) | Where-Object { $_.key -eq $Script:BLOCKED_TOTP_KEY }
            if ($blkEntry) {
                $blkColor = if ($blkEntry.enroll.self -eq 'NOT_ALLOWED') { 'Green' } else { 'Red' }
                $blkTag   = if ($blkEntry.enroll.self -eq 'NOT_ALLOWED') { '[SECURE -- blocked]' } else { '[WARNING -- alternate factor enrollable by HLA users]' }
                Write-Host ("  $Script:BLOCKED_TOTP_KEY setting (blocked):  {0}  {1}" -f $blkEntry.enroll.self, $blkTag) -ForegroundColor $blkColor
            }
            else {
                Write-Host "  $Script:BLOCKED_TOTP_KEY setting (blocked):  NOT IN POLICY  [WARNING -- alternate factor may be enrollable]" -ForegroundColor Red
            }
        }
        else {
            Write-Host "  TOTP setting:             (Classic Engine -- check settings.factors)" -ForegroundColor Yellow
        }

        # Check rule groups
        try {
            $inspRules = @(Invoke-OktaApi -Path "/api/v1/policies/$($inspHlaPolicy.id)/rules")
            $groupMap  = Get-HlaGroupMap
            $hlaRule   = $inspRules | Where-Object { $_.name -eq $Script:HLA_ENROLLMENT_RULE_NAME } | Select-Object -First 1
            if ($hlaRule) {
                $included  = @($hlaRule.conditions.people.groups.include)
                $covered   = @()
                $missing   = @()
                foreach ($gname in @('CyberArk-HLA-SuperAdmin','CyberArk-HLA-OrgAdmin','CyberArk-HLA-Users')) {
                    $gid = $groupMap[$gname]
                    if ($gid -and $gid -in $included) { $covered += $gname } else { $missing += $gname }
                }
                $ruleColor = if ($missing.Count -eq 0) { 'Green' } else { 'Red' }
                Write-Host ("  Groups in rule:           {0}" -f ($covered -join ', ')) -ForegroundColor $ruleColor
                if ($missing.Count -gt 0) {
                    Write-Host ("  Missing from rule:        {0}  [WARNING]" -f ($missing -join ', ')) -ForegroundColor Red
                }
            }
            else {
                Write-Host "  Enrollment rule:          NOT FOUND  [WARNING -- policy exists but no HLA group rule]" -ForegroundColor Red
            }
        }
        catch {
            Write-Host "  Rule check:               Could not retrieve rules: $_" -ForegroundColor Yellow
        }
    }
    else {
        Write-Host "  HLA Enrollment Policy:    NOT FOUND  [WARNING -- run Deploy to create Step 5.5 policy]" -ForegroundColor Red
    }
    Write-Host ""

    # Default policy audit
    $inspDefaultPolicy = Get-OktaDefaultEnrollmentPolicy
    if ($inspDefaultPolicy) {
        $isRisk55 = Test-DefaultPolicyTOTPRisk -DefaultPolicy $inspDefaultPolicy -Pipeline $inspPipeline
        $defColor  = if ($isRisk55) { 'Red' } else { 'Green' }
        $defTag    = if ($isRisk55) { '[WARNING -- regular users can self-enroll TOTP]' } else { '[SECURE]' }
        $defSetting = Get-DefaultPolicyTOTPSetting -DefaultPolicy $inspDefaultPolicy -Pipeline $inspPipeline
        Write-Host "  Default Enrollment Policy: $($inspDefaultPolicy.name) (id: $($inspDefaultPolicy.id))" -ForegroundColor White
        Write-Host ("  google_otp in default:    {0}  {1}" -f $defSetting, $defTag) -ForegroundColor $defColor
    }
    else {
        Write-Host "  Default Enrollment Policy: NOT FOUND or not accessible" -ForegroundColor Yellow
    }
    Write-Host ""

    # --- Rollback snapshots (both Step 11 and Step 5.5) ---
    $snaps11  = @()
    $snaps55  = @()
    if (Test-Path $Script:ROLLBACK_DIR) {
        $snaps11 = @(Get-ChildItem -Path $Script:ROLLBACK_DIR -Filter 'Deploy-OktaHLABootstrap-Step11-*.json' |
            Sort-Object LastWriteTime -Descending)
        $snaps55 = @(Get-ChildItem -Path $Script:ROLLBACK_DIR -Filter 'Deploy-OktaHLABootstrap-Step5.5-*.json' |
            Sort-Object LastWriteTime -Descending)
    }
    $totalSnaps = $snaps11.Count + $snaps55.Count

    Write-Host "  ROLLBACK SNAPSHOTS ($totalSnaps available)" -ForegroundColor Yellow
    Write-Host "  $('-' * 68)" -ForegroundColor DarkGray

    if ($snaps55.Count -gt 0) {
        Write-Host "  Step 5.5 snapshots (TOTP policy):" -ForegroundColor White
        foreach ($s in $snaps55 | Select-Object -First 3) {
            $displayTs = $s.BaseName -replace '^Deploy-OktaHLABootstrap-Step5.5-', '' -replace '-[a-f0-9]{8}$', ''
            Write-Host "    $($s.Name)  ($displayTs)" -ForegroundColor Gray
        }
        if ($snaps55.Count -gt 3) { Write-Host "    ... and $($snaps55.Count - 3) more" -ForegroundColor DarkGray }
        Write-Host ""
    }
    if ($snaps11.Count -gt 0) {
        Write-Host "  Step 11 snapshots (ACCESS_POLICY session rules):" -ForegroundColor White
        foreach ($s in $snaps11 | Select-Object -First 3) {
            $displayTs = $s.BaseName -replace '^Deploy-OktaHLABootstrap-Step11-', '' -replace '-[a-f0-9]{8}$', ''
            Write-Host "    $($s.Name)  ($displayTs)" -ForegroundColor Gray
        }
        if ($snaps11.Count -gt 3) { Write-Host "    ... and $($snaps11.Count - 3) more" -ForegroundColor DarkGray }
        Write-Host ""
    }
    if ($totalSnaps -eq 0) {
        Write-Host "  None. Snapshots are created automatically during Deploy (Steps 5.5 and 11)." -ForegroundColor DarkGray
        Write-Host ""
    }
    Write-Host "  To rollback Step 5.5: .\Deploy-OktaHLABootstrap.ps1 -Action Rollback -RollbackFile '<Step5.5-snapshot>'" -ForegroundColor Gray
    Write-Host "  To rollback Step 11:  .\Deploy-OktaHLABootstrap.ps1 -Action Rollback [-RollbackFile '<Step11-snapshot>']" -ForegroundColor Gray
    Write-Host ""
}

function Invoke-Rollback {
    <#
    .SYNOPSIS
        Restores Step 11 ACCESS_POLICY rules from a rollback snapshot. Defaults to the
        most recent snapshot in Rollbacks\. Use -RollbackFile for a specific snapshot.
        Shows current-vs-snapshot diff and prompts for confirmation before applying.
    #>
    Write-Host ""
    Write-Host "  ================================================================" -ForegroundColor Cyan
    Write-Host "  ROLLBACK: Restore Step 11 ACCESS_POLICY Session Rules" -ForegroundColor Cyan
    Write-Host "  ================================================================" -ForegroundColor Cyan
    Write-Host ""

    # --- Locate snapshot ---
    $snapshotPath = $RollbackFile
    if ([string]::IsNullOrWhiteSpace($snapshotPath)) {
        if (-not (Test-Path $Script:ROLLBACK_DIR)) {
            Write-Log -Level ERROR -Message "Rollback directory not found: $Script:ROLLBACK_DIR"
            Write-Log -Level ERROR -Message "Snapshots are created automatically during Deploy. Run Deploy first."
            return
        }
        # Gather both Step11 and Step5.5 snapshots, sorted newest-first
        $allSnaps = @(Get-ChildItem -Path $Script:ROLLBACK_DIR -Filter 'Deploy-OktaHLABootstrap-Step*.json' |
            Sort-Object LastWriteTime -Descending)
        if ($allSnaps.Count -eq 0) {
            Write-Log -Level ERROR -Message "No rollback snapshots found in $Script:ROLLBACK_DIR. Run Deploy first."
            return
        }
        $snapshotPath = $allSnaps[0].FullName
        Write-Host "  Using latest snapshot: $($allSnaps[0].Name)" -ForegroundColor White
        if ($allSnaps.Count -gt 1) {
            Write-Host "  Other available snapshots:" -ForegroundColor DarkGray
            foreach ($s in $allSnaps | Select-Object -Skip 1 -First 5) {
                Write-Host "    $($s.Name)" -ForegroundColor DarkGray
            }
            Write-Host "  Use -RollbackFile to specify a different snapshot." -ForegroundColor DarkGray
        }
        Write-Host ""
    }

    if (-not (Test-Path $snapshotPath)) {
        Write-Log -Level ERROR -Message "Snapshot file not found: $snapshotPath"
        return
    }

    # --- Load snapshot and route by type ---
    $snapshot = Get-Content -Path $snapshotPath -Raw | ConvertFrom-Json

    # Detect snapshot type: Step5.5 snapshots have snapshotType == 'Step5.5'
    $snapshotType = 'Step11'
    if ($snapshot.PSObject.Properties['snapshotType'] -and $snapshot.snapshotType -eq 'Step5.5') {
        $snapshotType = 'Step5.5'
    }

    if ($snapshotType -eq 'Step5.5') {
        Invoke-Rollback55 -SnapshotPath $snapshotPath
        return
    }

    # --- Step 11 rollback (existing logic) ---
    Write-Host "  Snapshot metadata:" -ForegroundColor DarkGray
    Write-Host "    Timestamp:  $($snapshot.timestamp)" -ForegroundColor DarkGray
    Write-Host "    Script ver: $($snapshot.scriptVersion)" -ForegroundColor DarkGray
    Write-Host "    Corr ID:    $($snapshot.correlationId.Substring(0,8))" -ForegroundColor DarkGray
    Write-Host ""

    # --- Read current state ---
    $current11 = Get-CurrentStep11State
    if (-not $current11.PolicyId) {
        Write-Log -Level ERROR -Message "Admin Console ACCESS_POLICY not found -- cannot rollback."
        return
    }

    # --- Build diff ---
    Write-Host ("  {0,-22} {1,-28} {2}" -f 'Tier', 'Current', 'Snapshot (restore to)') -ForegroundColor DarkGray
    Write-Host ("  {0,-22} {1,-28} {2}" -f ('-' * 21), ('-' * 27), ('-' * 28)) -ForegroundColor DarkGray

    $hasChanges  = $false
    $changePairs = @()   # array of [currentRule, snapRule, currentReauth, snapReauth]

    foreach ($snapRule in $snapshot.rules) {
        $currentRule   = $current11.Rules | Where-Object { $_.GroupName -eq $snapRule.groupName } | Select-Object -First 1
        $currentReauth = if ($currentRule) { $currentRule.ReauthIn } else { $null }
        $snapReauth    = $snapRule.reauthenticateIn

        $currentLabel  = if ($currentReauth) { ConvertFrom-IsoDuration -Duration $currentReauth } else { '(no rule)' }
        $snapshotLabel = if ($snapReauth)    { ConvertFrom-IsoDuration -Duration $snapReauth }    else { '(none)' }
        $changed       = ($currentReauth -ne $snapReauth)
        if ($changed) { $hasChanges = $true }
        $marker        = if ($changed) { ' *' } else { '' }
        $lineColor     = if ($changed) { 'White' } else { 'DarkGray' }

        Write-Host ("  {0,-22} {1,-28} {2}{3}" -f $snapRule.tierLabel, $currentLabel, $snapshotLabel, $marker) -ForegroundColor $lineColor

        $changePairs += [PSCustomObject]@{
            CurrentRule   = $currentRule
            SnapRule      = $snapRule
            CurrentReauth = $currentReauth
            SnapReauth    = $snapReauth
            Changed       = $changed
        }
    }
    Write-Host "  (* = will change)" -ForegroundColor DarkGray
    Write-Host ""

    if (-not $hasChanges) {
        Write-Log -Level INFO -Message "Current settings already match snapshot -- no rollback needed."
        return
    }

    if ($Script:IsDryRun) {
        Write-Log -Level INFO -Message "[WhatIf] Would restore the above snapshot values. No changes made."
        return
    }

    # --- Confirm ---
    $doRollback = $false
    if ($AcceptDefaults) {
        $doRollback = $true
    }
    else {
        $answer = Read-SecureInput -Prompt "  Apply rollback (restores marked values)? [y/N]"
        $doRollback = ($answer -match '^[Yy]')
    }
    if (-not $doRollback) {
        Write-Log -Level INFO -Message "Rollback cancelled by user."
        return
    }

    # --- Apply ---
    foreach ($pair in $changePairs) {
        if (-not $pair.Changed) { continue }

        $cr       = $pair.CurrentRule
        $sr       = $pair.SnapRule
        $snapAuth = $pair.SnapReauth

        if (-not $cr -or -not $cr.RuleId) {
            Write-Log -Level WARN -Message "$($sr.tierLabel): no existing rule to update -- skipping"
            continue
        }

        $body = @{
            id       = $cr.RuleId
            type     = 'ACCESS_POLICY'
            status   = 'ACTIVE'
            name     = $cr.RuleName
            priority = 1
            system   = $false
            conditions = @{
                people    = @{ users = @{ exclude = @() }; groups = @{ include = @($cr.GroupId) } }
                network   = @{ connection = 'ANYWHERE' }
                riskScore = @{ level = 'ANY' }
                userType  = @{ include = @(); exclude = @() }
            }
            actions = @{
                appSignOn = @{
                    access = 'ALLOW'
                    verificationMethod = @{
                        factorMode       = '2FA'
                        type             = 'ASSURANCE'
                        reauthenticateIn = $snapAuth
                        constraints      = @(@{ knowledge = @{ required = $false }; possession = @{ required = $true } })
                    }
                    keepMeSignedIn = @{ postAuth = 'NOT_ALLOWED' }
                }
            }
        }

        try {
            Invoke-OktaApi -Path "/api/v1/policies/$($current11.PolicyId)/rules/$($cr.RuleId)" `
                -Method PUT -Body $body | Out-Null
            Write-Log -Level OK -Message "Rollback applied: $($sr.tierLabel) $($pair.CurrentReauth) -> $snapAuth" `
                -Action 'RollbackStep11' `
                -Fields @{ Tier = $sr.tierLabel; From = $pair.CurrentReauth; To = $snapAuth; SnapshotFile = $snapshotPath }
        }
        catch {
            Write-Log -Level WARN -Message "Failed to rollback $($sr.tierLabel): $_"
        }
    }

    Write-Log -Level OK -Message "Rollback complete. Run -Action Inspect to verify." -Action 'RollbackComplete'
}

function Set-AdminConsoleTierRules {
    <#
    .SYNOPSIS
        Creates or updates per-tier session rules on the Okta Admin Console
        Authentication Policy (ACCESS_POLICY).

    .DESCRIPTION
        The Admin Console has its own app-level policy that controls how long
        post-login authentication assurance is trusted before step-up MFA is
        required. This is SEPARATE from the Global Session Policy lifetime.

        SCOPE NOTICE: Rules added here target ONLY the named HLA tier groups
        (CyberArk-HLA-SuperAdmin, CyberArk-HLA-OrgAdmin, CyberArk-HLA-Users).
        All other Okta admin users are evaluated by later rules and are
        NOT affected by this step.

    .PARAMETER TierConfigs
        Array of hashtables, each with: GroupName, GroupId, ReauthDuration, RuleName, Priority
    #>
    param(
        [Parameter(Mandatory)]
        [hashtable[]]$TierConfigs
    )

    Write-Log -Level STEP -Message "--- Step 11: Configure Admin Console SESSION Rules (ACCESS_POLICY) ---"
    Write-Host ""
    Write-Host "  SCOPE NOTICE" -ForegroundColor Yellow
    Write-Host "  =============================================================" -ForegroundColor Yellow
    Write-Host "  The following changes apply ONLY to the named HLA groups." -ForegroundColor Yellow
    Write-Host "  Other Okta admin users are evaluated by separate rules" -ForegroundColor Yellow
    Write-Host "  and are NOT affected by this step." -ForegroundColor Yellow
    Write-Host "  =============================================================" -ForegroundColor Yellow
    Write-Host ""

    # Find the Okta Admin Console ACCESS_POLICY by name
    $adminConsolePolicy = $null
    try {
        $policies = Invoke-OktaApi -Path '/api/v1/policies?type=ACCESS_POLICY&limit=200'
        if ($policies) {
            $adminConsolePolicy = @($policies) | Where-Object { $_.name -eq 'Okta Admin Console' } | Select-Object -First 1
        }
    }
    catch {
        Write-Log -Level WARN -Message "Could not retrieve ACCESS_POLICY list: $_"
    }

    if (-not $adminConsolePolicy) {
        Write-Log -Level WARN -Message "Admin Console ACCESS_POLICY not found -- skipping Step 11."
        Write-Log -Level WARN -Message "This is expected on some developer/integrator tenants."
        Write-Log -Level WARN -Message "Configure manually: Okta Admin > Security > Authentication Policies > Okta Admin Console"
        return
    }

    $policyId = $adminConsolePolicy.id
    Write-Log -Level INFO -Message "Found Admin Console policy: $($adminConsolePolicy.name) (id: $policyId)"

    # Fetch existing rules
    $existingRules = @()
    try {
        $existingRules = @(Invoke-OktaApi -Path "/api/v1/policies/$policyId/rules")
    }
    catch {
        Write-Log -Level WARN -Message "Could not fetch existing rules: $_"
    }

    # Save rollback snapshot BEFORE making any changes (not in WhatIf -- no changes happen)
    if (-not $Script:IsDryRun) {
        $snapshotRules = @()
        foreach ($tier in $TierConfigs) {
            $er = $existingRules | Where-Object { $_.conditions.people.groups.include -contains $tier.GroupId } | Select-Object -First 1
            $currentReauth = $null
            if ($er -and $er.PSObject.Properties['actions']) {
                $v = $er.actions.appSignOn.verificationMethod
                if ($v -and $v.PSObject.Properties['reauthenticateIn']) { $currentReauth = $v.reauthenticateIn }
            }
            $snapshotRules += [PSCustomObject]@{
                TierLabel         = $tier.RuleName
                GroupName         = $tier.GroupName
                GroupId           = $tier.GroupId
                RuleId            = if ($er) { $er.id }   else { $null }
                RuleName          = if ($er) { $er.name } else { $tier.RuleName }
                ReauthIn          = $currentReauth
                RecommendedMaxSec = 7200
            }
        }
        $snapshotState = [PSCustomObject]@{
            PolicyId   = $policyId
            PolicyName = $adminConsolePolicy.name
            Rules      = $snapshotRules
        }
        Save-RollbackSnapshot -Step11State $snapshotState | Out-Null
    }

    foreach ($tier in $TierConfigs) {
        $groupId      = $tier.GroupId
        $groupName    = $tier.GroupName
        $ruleName     = $tier.RuleName
        $reauth       = $tier.ReauthDuration
        $priority     = $tier.Priority
        $friendlyReauth = ConvertFrom-IsoDuration $reauth

        Write-Host ""
        Write-Host "  Tier rule: $ruleName" -ForegroundColor Cyan
        Write-Host "    Group:              $groupName ($groupId)"
        Write-Host "    reauthenticateIn:   $friendlyReauth"

        # Check for an existing rule targeting this group
        $existingRule = $existingRules | Where-Object {
            $_.conditions.people.groups.include -contains $groupId
        } | Select-Object -First 1

        if ($existingRule) {
            $currentReauth  = $existingRule.actions.appSignOn.verificationMethod.reauthenticateIn
            $friendlyCurrent = ConvertFrom-IsoDuration $currentReauth

            Write-Host "    Current setting:    $friendlyCurrent"
            Write-Host "    Proposed setting:   $friendlyReauth"

            if ($currentReauth -eq $reauth) {
                Write-Log -Level SKIP -Message "Rule '$ruleName' already set to $reauth -- no change needed"
                continue
            }

            # Prompt for update confirmation (unless -AcceptDefaults)
            $doUpdate = $false
            if ($Script:IsDryRun) {
                Write-Log -Level INFO -Message "[WhatIf] Would update rule '$ruleName': $currentReauth -> $reauth"
                continue
            }
            elseif ($AcceptDefaults) {
                $doUpdate = $true
            }
            else {
                $answer = Read-SecureInput -Prompt "    Update '$ruleName' ($currentReauth -> $reauth)? [Y/n]"
                $doUpdate = ($answer -eq '' -or $answer -match '^[Yy]')
            }

            if (-not $doUpdate) {
                Write-Log -Level SKIP -Message "Skipped update for rule '$ruleName' (user declined)"
                continue
            }

            # Build updated rule body preserving all existing fields
            $updatedBody = @{
                id      = $existingRule.id
                type    = 'ACCESS_POLICY'
                status  = $existingRule.status
                name    = $existingRule.name
                priority = $existingRule.priority
                system  = $false
                conditions = @{
                    people    = @{
                        users  = @{ exclude = @() }
                        groups = @{ include = @($groupId) }
                    }
                    network   = @{ connection = 'ANYWHERE' }
                    riskScore = @{ level = 'ANY' }
                    userType  = @{ include = @(); exclude = @() }
                }
                actions = @{
                    appSignOn = @{
                        access = 'ALLOW'
                        verificationMethod = @{
                            factorMode       = '2FA'
                            type             = 'ASSURANCE'
                            reauthenticateIn = $reauth
                            constraints      = @(
                                @{
                                    knowledge  = @{ required = $false }
                                    possession = @{ required = $true }
                                }
                            )
                        }
                        keepMeSignedIn = @{ postAuth = 'NOT_ALLOWED' }
                    }
                }
            }

            try {
                Invoke-OktaApi -Path "/api/v1/policies/$policyId/rules/$($existingRule.id)" `
                    -Method PUT -Body $updatedBody | Out-Null
                Write-Log -Level OK -Message "Updated rule '$ruleName': $currentReauth -> $reauth" `
                    -Action 'UpdateAccessPolicyRule' `
                    -Fields @{ RuleName = $ruleName; PolicyId = $policyId; RuleId = $existingRule.id; OldReauth = $currentReauth; NewReauth = $reauth }
            }
            catch {
                Write-Log -Level WARN -Message "Failed to update rule '$ruleName': $_"
            }
        }
        else {
            # No existing rule for this group -- create one
            Write-Host "    (No existing rule for this group -- will create)"

            $doCreate = $false
            if ($Script:IsDryRun) {
                Write-Log -Level INFO -Message "[WhatIf] Would create rule '$ruleName' (reauthenticateIn=$reauth)"
                continue
            }
            elseif ($AcceptDefaults) {
                $doCreate = $true
            }
            else {
                $answer = Read-SecureInput -Prompt "    Create rule '$ruleName' (reauthenticateIn=$reauth)? [Y/n]"
                $doCreate = ($answer -eq '' -or $answer -match '^[Yy]')
            }

            if (-not $doCreate) {
                Write-Log -Level SKIP -Message "Skipped creation of rule '$ruleName' (user declined)"
                continue
            }

            $newRuleBody = @{
                type   = 'ACCESS_POLICY'
                status = 'ACTIVE'
                name   = $ruleName
                priority = $priority
                system = $false
                conditions = @{
                    people    = @{
                        users  = @{ exclude = @() }
                        groups = @{ include = @($groupId) }
                    }
                    network   = @{ connection = 'ANYWHERE' }
                    riskScore = @{ level = 'ANY' }
                    userType  = @{ include = @(); exclude = @() }
                }
                actions = @{
                    appSignOn = @{
                        access = 'ALLOW'
                        verificationMethod = @{
                            factorMode       = '2FA'
                            type             = 'ASSURANCE'
                            reauthenticateIn = $reauth
                            constraints      = @(
                                @{
                                    knowledge  = @{ required = $false }
                                    possession = @{ required = $true }
                                }
                            )
                        }
                        keepMeSignedIn = @{ postAuth = 'NOT_ALLOWED' }
                    }
                }
            }

            try {
                $created = Invoke-OktaApi -Path "/api/v1/policies/$policyId/rules" `
                    -Method POST -Body $newRuleBody
                Write-Log -Level OK -Message "Created rule '$ruleName' (id: $($created.id), reauthenticateIn=$reauth)" `
                    -Action 'CreateAccessPolicyRule' `
                    -Fields @{ RuleName = $ruleName; PolicyId = $policyId; RuleId = $created.id; Reauth = $reauth }
            }
            catch {
                Write-Log -Level WARN -Message "Failed to create rule '$ruleName': $_"
            }
        }
    }

    Write-Host ""
}

#region Step 5.5: TOTP Authenticator & Enrollment Policy

function Get-OktaEnginePipeline {
    <#
    .SYNOPSIS
        Returns 'OIE' if the tenant uses the Identity Engine, 'Classic' otherwise.
        Uses /api/v1/authenticators as the primary signal (OIE exposes it; Classic returns 404).
    #>
    try {
        $auth = Invoke-OktaApi -Path '/api/v1/authenticators'
        if ($null -ne $auth) { return 'OIE' }
    }
    catch {}
    try {
        $org = Invoke-OktaApi -Path '/api/v1/org'
        if ($org -and $org.PSObject.Properties['pipeline'] -and $org.pipeline -eq 'idx') { return 'OIE' }
    }
    catch {}
    return 'Classic'
}

function Find-OktaGoogleOtpAuthenticator {
    <#
    .SYNOPSIS
        Returns the google_otp authenticator object, or $null if not found.
    #>
    try {
        $authenticators = Invoke-OktaApi -Path '/api/v1/authenticators'
        if (-not $authenticators) { return $null }
        $match = @($authenticators) | Where-Object { $_.key -eq $Script:GOOGLE_OTP_KEY }
        if ($match) { return $match | Select-Object -First 1 }
        return $null
    }
    catch {
        Write-Log -Level WARN -Message "Cannot query /api/v1/authenticators: $_"
        return $null
    }
}

function Enable-OktaGoogleOtpAuthenticator {
    <#
    .SYNOPSIS
        Activates the google_otp authenticator at tenant level via lifecycle endpoint.
        Requires EXPLICIT Y/N -- does NOT auto-accept with -AcceptDefaults.
        Returns $true if activated (or WhatIf), $false if declined.
    #>
    param([Parameter(Mandatory)][object]$Authenticator)

    Write-Host ""
    Write-Host "  [TENANT-WIDE ACTION REQUIRED]" -ForegroundColor Yellow
    Write-Host "  The google_otp (software TOTP) authenticator is currently INACTIVE." -ForegroundColor Yellow
    Write-Host "  CyberArk PSM requires it to be ACTIVE so the CPM admin API can enroll" -ForegroundColor Yellow
    Write-Host "  TOTP seeds on HLA service accounts." -ForegroundColor Yellow
    Write-Host "  Activating this affects ALL users at the tenant level." -ForegroundColor Yellow
    Write-Host "  The HLA enrollment policy (Step 5.5b) will restrict self-enrollment" -ForegroundColor Yellow
    Write-Host "  to only the 3 CyberArk HLA groups." -ForegroundColor Yellow
    Write-Host ""

    if ($Script:IsDryRun) {
        Write-Log -Level INFO -Message "[WhatIf] Would activate google_otp authenticator (id: $($Authenticator.id))" -Action 'ActivateTOTPAuthenticator'
        return $true
    }

    # AcceptDefaults does NOT bypass this prompt -- tenant-wide change requires deliberate decision
    # -Force bypasses it for automated testing pipelines
    if ($Script:Force) {
        Write-Host "  [Force] Auto-accepting google_otp activation (-Force specified)" -ForegroundColor Yellow
        $answer = 'y'
    }
    else {
        $answer = Read-Host "  Activate google_otp authenticator tenant-wide? [y/N]"
    }
    if ($answer -notmatch '^[Yy]') {
        Write-Log -Level WARN -Message "Operator declined google_otp activation. cpm-simulator enroll-totp WILL FAIL." `
            -Action 'ActivateTOTPAuthenticator' -Fields @{ Decision = 'Declined'; AuthenticatorId = $Authenticator.id }
        Write-Host "  WARNING: google_otp remains INACTIVE." -ForegroundColor Yellow
        Write-Host "  Activate manually: Okta Admin > Security > Authenticators > Google Authenticator > Activate" -ForegroundColor Yellow
        return $false
    }

    try {
        Invoke-OktaApi -Path "/api/v1/authenticators/$($Authenticator.id)/lifecycle/activate" -Method POST | Out-Null
        Write-Log -Level OK -Message "google_otp authenticator activated (id: $($Authenticator.id))" `
            -Action 'ActivateTOTPAuthenticator' -Fields @{ AuthenticatorId = $Authenticator.id }
        return $true
    }
    catch {
        Write-Log -Level ERROR -Message "Failed to activate google_otp authenticator: $_" -Action 'ActivateTOTPAuthenticator'
        throw
    }
}

function Find-OktaHLAEnrollmentPolicy {
    <#
    .SYNOPSIS
        Finds the CyberArk HLA TOTP Enrollment Policy by exact name. Returns $null if not found.
    #>
    try {
        $policies = Invoke-OktaApi -Path '/api/v1/policies?type=MFA_ENROLL&limit=200'
        if (-not $policies) { return $null }
        $match = @($policies) | Where-Object { $_.name -eq $Script:HLA_ENROLLMENT_POLICY_NAME }
        if ($match) { return $match | Select-Object -First 1 }
        return $null
    }
    catch {
        Write-Log -Level WARN -Message "Cannot query MFA_ENROLL policies: $_"
        return $null
    }
}

function New-OktaHLAEnrollmentPolicy {
    <#
    .SYNOPSIS
        Creates the HLA TOTP enrollment policy (priority 1) and adds the group-scoping rule.
        Uses OIE (settings.authenticators) or Classic (settings.factors) structure as appropriate.
        Returns the created policy object.
    #>
    param(
        [Parameter(Mandatory)][string]$T1GroupId,
        [Parameter(Mandatory)][string]$T2GroupId,
        [Parameter(Mandatory)][string]$T3GroupId,
        [Parameter(Mandatory)][string]$Pipeline
    )

    Write-Log -Level INFO -Message "Creating HLA enrollment policy: $Script:HLA_ENROLLMENT_POLICY_NAME" -Action 'CreateEnrollmentPolicy'

    if ($Script:IsDryRun) {
        Write-Log -Level INFO -Message "[WhatIf] Would create MFA_ENROLL policy '$Script:HLA_ENROLLMENT_POLICY_NAME' (priority 1)"
        Write-Log -Level INFO -Message "[WhatIf] Would create enrollment rule scoped to CyberArk-HLA-SuperAdmin, CyberArk-HLA-OrgAdmin, CyberArk-HLA-Users"
        return [PSCustomObject]@{ id = 'WHATIF-ENROLL-POLICY'; name = $Script:HLA_ENROLLMENT_POLICY_NAME }
    }

    $policyBody = @{
        type        = 'MFA_ENROLL'
        name        = $Script:HLA_ENROLLMENT_POLICY_NAME
        description = 'Enables software TOTP enrollment exclusively for CyberArk HLA service accounts. Regular users are NOT covered by this policy.'
        priority    = 1
        status      = 'ACTIVE'
        conditions  = @{
            people = @{
                groups = @{
                    include = @($T1GroupId, $T2GroupId, $T3GroupId)
                }
            }
        }
    }

    if ($Pipeline -eq 'OIE') {
        # Selected TOTP provider = REQUIRED (enables enrollment + prevents user self-deletion)
        # Blocked TOTP provider  = NOT_ALLOWED (prevents weaker/alternate factor enrollment)
        # okta_password REQUIRED:  explicit for audit defensibility
        $policyBody['settings'] = @{
            type           = 'AUTHENTICATORS'
            authenticators = @(
                @{ key = 'okta_password';              enroll = @{ self = 'REQUIRED' } }
                @{ key = $Script:SELECTED_TOTP_KEY;    enroll = @{ self = 'REQUIRED' } }
                @{ key = $Script:BLOCKED_TOTP_KEY;     enroll = @{ self = 'NOT_ALLOWED' } }
            )
        }
    }
    else {
        Write-Log -Level WARN -Message "Classic Engine: using settings.factors structure (okta_verify blocking not available)" -Action 'CreateEnrollmentPolicy'
        $policyBody['settings'] = @{
            factors = @{ okta_otp = @{ enroll = @{ self = 'REQUIRED' } } }
        }
    }

    $policy = $null
    try {
        $policy = Invoke-OktaApi -Path '/api/v1/policies' -Method POST -Body $policyBody
        Write-Log -Level OK -Message "Created enrollment policy: $Script:HLA_ENROLLMENT_POLICY_NAME (id: $($policy.id))" `
            -Action 'CreateEnrollmentPolicy' -Fields @{ PolicyId = $policy.id }
    }
    catch {
        Write-Log -Level ERROR -Message "Failed to create enrollment policy: $_" -Action 'CreateEnrollmentPolicy'
        throw
    }

    # Add group-scoping rule
    $ruleBody = @{
        type     = 'MFA_ENROLL'
        name     = $Script:HLA_ENROLLMENT_RULE_NAME
        status   = 'ACTIVE'
        priority = 1
        conditions = @{
            people = @{
                users  = @{ exclude = @() }
                groups = @{ include = @($T1GroupId, $T2GroupId, $T3GroupId) }
            }
        }
        actions = @{ enroll = @{ self = 'CHALLENGE' } }
    }
    try {
        $rule = Invoke-OktaApi -Path "/api/v1/policies/$($policy.id)/rules" -Method POST -Body $ruleBody
        Write-Log -Level OK -Message "Created enrollment rule: $Script:HLA_ENROLLMENT_RULE_NAME (id: $($rule.id))" `
            -Action 'CreateEnrollmentRule' -Fields @{ PolicyId = $policy.id; RuleId = $rule.id }
    }
    catch {
        Write-Log -Level WARN -Message "Failed to create enrollment rule (add manually in Okta Admin UI): $_" -Action 'CreateEnrollmentRule'
    }

    return $policy
}

function Update-OktaHLAEnrollmentPolicy {
    <#
    .SYNOPSIS
        Verifies the HLA enrollment policy has the selected TOTP provider REQUIRED, the
        blocked provider NOT_ALLOWED, and all 3 HLA group IDs in the rule. Prompts to update
        if any are wrong. AcceptDefaults auto-confirms update.
    #>
    param(
        [Parameter(Mandatory)][object]$Policy,
        [Parameter(Mandatory)][string]$T1GroupId,
        [Parameter(Mandatory)][string]$T2GroupId,
        [Parameter(Mandatory)][string]$T3GroupId,
        [Parameter(Mandatory)][string]$Pipeline
    )

    $policyId          = $Policy.id
    $needsPolicyUpdate = $false
    $needsRuleUpdate   = $false

    # Check selected TOTP provider is REQUIRED/OPTIONAL in policy
    $selectedProviderOk = $false
    if ($Pipeline -eq 'OIE') {
        if ($Policy.PSObject.Properties['settings'] -and $Policy.settings.PSObject.Properties['authenticators']) {
            $sel = @($Policy.settings.authenticators) | Where-Object { $_.key -eq $Script:SELECTED_TOTP_KEY }
            if ($sel -and $sel.enroll.self -in @('REQUIRED', 'OPTIONAL')) { $selectedProviderOk = $true }
        }
    }
    else {
        if ($Policy.PSObject.Properties['settings'] -and $Policy.settings.PSObject.Properties['factors']) {
            $f = $Policy.settings.factors
            if ($f.PSObject.Properties['okta_otp'] -and $f.okta_otp.enroll.self -in @('REQUIRED', 'OPTIONAL')) { $selectedProviderOk = $true }
        }
    }
    if (-not $selectedProviderOk) { $needsPolicyUpdate = $true }

    # Check blocked TOTP provider is NOT_ALLOWED
    $blockedProviderOk = $false
    if ($Pipeline -eq 'OIE' -and $Policy.PSObject.Properties['settings'] -and
        $Policy.settings.PSObject.Properties['authenticators']) {
        $blk = @($Policy.settings.authenticators) | Where-Object { $_.key -eq $Script:BLOCKED_TOTP_KEY }
        if ($blk -and $blk.enroll.self -eq 'NOT_ALLOWED') { $blockedProviderOk = $true }
    }
    if ($Pipeline -eq 'OIE' -and -not $blockedProviderOk) { $needsPolicyUpdate = $true }

    # Check rule group scoping
    $rules = @()
    try { $rules = @(Invoke-OktaApi -Path "/api/v1/policies/$policyId/rules") } catch {}
    $existingRule = $rules | Where-Object { $_.name -eq $Script:HLA_ENROLLMENT_RULE_NAME } | Select-Object -First 1
    if (-not $existingRule) {
        $existingRule = $rules | Where-Object {
            $inc = @($_.conditions.people.groups.include)
            ($T1GroupId -in $inc) -or ($T2GroupId -in $inc) -or ($T3GroupId -in $inc)
        } | Select-Object -First 1
    }

    $needsRuleUpdate = $false
    if ($existingRule) {
        $included = @($existingRule.conditions.people.groups.include)
        foreach ($gid in @($T1GroupId, $T2GroupId, $T3GroupId)) {
            if ($gid -notin $included) { $needsRuleUpdate = $true; break }
        }
    }
    else { $needsRuleUpdate = $true }

    if (-not $needsPolicyUpdate -and -not $needsRuleUpdate) {
        Write-Log -Level SKIP -Message "HLA enrollment policy already correct -- no changes needed" -Action 'VerifyEnrollmentPolicy'
        return
    }

    Write-Host "  HLA enrollment policy requires updates:" -ForegroundColor Yellow
    if ($needsPolicyUpdate -and -not $selectedProviderOk) { Write-Host "    - Policy authenticators: $Script:SELECTED_TOTP_KEY not REQUIRED/OPTIONAL" -ForegroundColor Yellow }
    if ($needsPolicyUpdate -and -not $blockedProviderOk -and $Pipeline -eq 'OIE') { Write-Host "    - Policy authenticators: $Script:BLOCKED_TOTP_KEY not NOT_ALLOWED (alternate factor enrollment risk)" -ForegroundColor Yellow }
    if ($needsRuleUpdate)   { Write-Host "    - Rule scoping: missing HLA group ID(s) in rule conditions" -ForegroundColor Yellow }
    Write-Host ""

    if ($Script:IsDryRun) {
        Write-Log -Level INFO -Message "[WhatIf] Would update HLA enrollment policy" -Action 'UpdateEnrollmentPolicy'
        return
    }

    $doUpdate = $false
    if ($AcceptDefaults) { $doUpdate = $true }
    else {
        $answer = Read-Host "  Update HLA enrollment policy? [Y/n]"
        $doUpdate = ($answer -eq '' -or $answer -match '^[Yy]')
    }
    if (-not $doUpdate) {
        Write-Log -Level WARN -Message "Operator declined HLA enrollment policy update -- policy may be misconfigured" -Action 'UpdateEnrollmentPolicy'
        return
    }

    if ($needsPolicyUpdate) {
        $pri = if ($Policy.PSObject.Properties['priority']) { $Policy.priority } else { 1 }
        $updBody = @{
            type     = 'MFA_ENROLL'
            name     = $Policy.name
            status   = 'ACTIVE'
            priority = $pri
        }
        if ($Pipeline -eq 'OIE') {
            $updBody['settings'] = @{
                type = 'AUTHENTICATORS'
                authenticators = @(
                    @{ key = 'okta_password';              enroll = @{ self = 'REQUIRED' } }
                    @{ key = $Script:SELECTED_TOTP_KEY;    enroll = @{ self = 'REQUIRED' } }
                    @{ key = $Script:BLOCKED_TOTP_KEY;     enroll = @{ self = 'NOT_ALLOWED' } }
                )
            }
        }
        else {
            $updBody['settings'] = @{ factors = @{ okta_otp = @{ enroll = @{ self = 'REQUIRED' } } } }
        }
        try {
            Invoke-OktaApi -Path "/api/v1/policies/$policyId" -Method PUT -Body $updBody | Out-Null
            Write-Log -Level OK -Message "Updated enrollment policy: $Script:SELECTED_TOTP_KEY=REQUIRED, $Script:BLOCKED_TOTP_KEY=NOT_ALLOWED" -Action 'UpdateEnrollmentPolicy'
        }
        catch { Write-Log -Level WARN -Message "Failed to update policy settings: $_" }
    }

    if ($needsRuleUpdate) {
        $ruleBody = @{
            type = 'MFA_ENROLL'; name = $Script:HLA_ENROLLMENT_RULE_NAME; status = 'ACTIVE'; priority = 1
            conditions = @{ people = @{ users = @{ exclude = @() }; groups = @{ include = @($T1GroupId, $T2GroupId, $T3GroupId) } } }
            actions    = @{ enroll = @{ self = 'CHALLENGE' } }
        }
        try {
            if ($existingRule) {
                $ruleBody['id'] = $existingRule.id
                Invoke-OktaApi -Path "/api/v1/policies/$policyId/rules/$($existingRule.id)" -Method PUT -Body $ruleBody | Out-Null
                Write-Log -Level OK -Message "Updated enrollment rule: all 3 HLA groups included" -Action 'UpdateEnrollmentRule'
            }
            else {
                $newRule = Invoke-OktaApi -Path "/api/v1/policies/$policyId/rules" -Method POST -Body $ruleBody
                Write-Log -Level OK -Message "Created enrollment rule: $Script:HLA_ENROLLMENT_RULE_NAME (id: $($newRule.id))" -Action 'CreateEnrollmentRule'
            }
        }
        catch { Write-Log -Level WARN -Message "Failed to update/create enrollment rule: $_" }
    }
}

function Get-OktaDefaultEnrollmentPolicy {
    <#
    .SYNOPSIS
        Returns the catchall MFA_ENROLL policy (the one that covers all users not matched
        by higher-priority policies). Typically named 'Default Policy'.
    #>
    try {
        $policies = Invoke-OktaApi -Path '/api/v1/policies?type=MFA_ENROLL&limit=200'
        if (-not $policies) { return $null }
        # Exclude our HLA policy
        $others = @($policies) | Where-Object { $_.name -ne $Script:HLA_ENROLLMENT_POLICY_NAME }
        if (-not $others) { return $null }
        # Prefer explicit 'Default Policy' name, otherwise take highest priority number (lowest priority = catchall)
        $match = $others | Where-Object { $_.name -eq 'Default Policy' } | Select-Object -First 1
        if ($match) { return $match }
        return $others | Sort-Object { if ($_.PSObject.Properties['priority']) { [int]$_.priority } else { 0 } } -Descending | Select-Object -First 1
    }
    catch {
        Write-Log -Level WARN -Message "Cannot query default enrollment policy: $_"
        return $null
    }
}

function Test-DefaultPolicyTOTPRisk {
    <#
    .SYNOPSIS
        Returns $true if the default MFA_ENROLL policy has google_otp set to OPTIONAL or REQUIRED.
    #>
    param([Parameter(Mandatory)][object]$DefaultPolicy, [string]$Pipeline = 'OIE')

    if ($Pipeline -eq 'OIE') {
        if ($DefaultPolicy.PSObject.Properties['settings'] -and
            $DefaultPolicy.settings.PSObject.Properties['authenticators']) {
            $otp = @($DefaultPolicy.settings.authenticators) | Where-Object { $_.key -eq $Script:GOOGLE_OTP_KEY }
            if ($otp -and $otp.enroll.self -in @('OPTIONAL', 'REQUIRED')) { return $true }
        }
    }
    else {
        if ($DefaultPolicy.PSObject.Properties['settings'] -and
            $DefaultPolicy.settings.PSObject.Properties['factors']) {
            $f = $DefaultPolicy.settings.factors
            if ($f.PSObject.Properties['okta_otp'] -and $f.okta_otp.enroll.self -in @('OPTIONAL', 'REQUIRED')) { return $true }
        }
    }
    return $false
}

function Get-DefaultPolicyTOTPSetting {
    <#
    .SYNOPSIS
        Returns the current google_otp enrollment setting string from the default policy.
        Returns 'DISABLED/absent' if not found.
    #>
    param([Parameter(Mandatory)][object]$DefaultPolicy, [string]$Pipeline = 'OIE')

    if ($Pipeline -eq 'OIE') {
        if ($DefaultPolicy.PSObject.Properties['settings'] -and
            $DefaultPolicy.settings.PSObject.Properties['authenticators']) {
            $otp = @($DefaultPolicy.settings.authenticators) | Where-Object { $_.key -eq $Script:GOOGLE_OTP_KEY }
            if ($otp) { return $otp.enroll.self }
        }
    }
    else {
        if ($DefaultPolicy.PSObject.Properties['settings'] -and
            $DefaultPolicy.settings.PSObject.Properties['factors']) {
            $f = $DefaultPolicy.settings.factors
            if ($f.PSObject.Properties['okta_otp']) { return $f.okta_otp.enroll.self }
        }
    }
    return 'DISABLED/absent'
}

function Disable-DefaultPolicyTOTP {
    <#
    .SYNOPSIS
        Sets google_otp to NOT_ALLOWED in the default MFA_ENROLL policy.
        Requires EXPLICIT Y confirmation even when -AcceptDefaults is set.
        This change affects ALL users in the tenant.
        Returns $true if applied, $false if declined or WhatIf.
    #>
    param([Parameter(Mandatory)][object]$DefaultPolicy, [string]$Pipeline = 'OIE')

    # Idempotent: skip if google_otp is already NOT_ALLOWED or absent
    $currentSetting = Get-DefaultPolicyTOTPSetting -DefaultPolicy $DefaultPolicy -Pipeline $Pipeline
    if ($currentSetting -eq 'NOT_ALLOWED' -or $currentSetting -eq 'DISABLED/absent') {
        Write-Log -Level SKIP -Message "Default policy google_otp already $currentSetting -- no action needed" -Action 'DisableDefaultTOTP'
        return $false
    }

    if ($Script:IsDryRun) {
        Write-Log -Level INFO -Message "[WhatIf] Would set google_otp to NOT_ALLOWED in default policy '$($DefaultPolicy.name)'" -Action 'DisableDefaultTOTP'
        return $false
    }

    # AcceptDefaults does NOT apply -- this is a tenant-wide change requiring deliberate decision
    # -Force bypasses it for automated testing pipelines
    if ($Script:Force) {
        Write-Host "  [Force] Auto-accepting default policy TOTP disable (-Force specified)" -ForegroundColor Yellow
        $answer = 'y'
    }
    else {
        $answer = Read-Host "  Disable google_otp in default policy (affects ALL tenant users)? [y/N]"
    }
    if ($answer -notmatch '^[Yy]') {
        Write-Log -Level WARN -Message "Operator declined: google_otp risk in default policy remains unresolved" `
            -Action 'DisableDefaultTOTP' -Fields @{ Decision = 'Declined'; PolicyId = $DefaultPolicy.id }
        return $false
    }

    $policyId = $DefaultPolicy.id

    # Fresh GET by ID to ensure we have the complete policy object with all fields.
    # The list endpoint may return objects that serialize differently in PS 5.1.
    $freshPolicy = Invoke-OktaApi -Path "/api/v1/policies/$policyId"
    if (-not $freshPolicy) {
        Write-Log -Level WARN -Message "Could not re-fetch default policy by ID $policyId" -Action 'DisableDefaultTOTP'
        return $false
    }

    $pri = if ($freshPolicy.PSObject.Properties['priority']) { $freshPolicy.priority } else { 99 }

    # Build PUT body from the fresh GET -- include description and conditions as-is
    # (required for default policy PUT -- E0000077 without them)
    $updBody = @{ type = 'MFA_ENROLL'; name = $freshPolicy.name; status = 'ACTIVE'; priority = $pri }
    if ($freshPolicy.PSObject.Properties['description'] -and $freshPolicy.description) {
        $updBody['description'] = [string]$freshPolicy.description
    }
    if ($freshPolicy.PSObject.Properties['conditions']) {
        $updBody['conditions'] = $freshPolicy.conditions
    }

    if ($Pipeline -eq 'OIE') {
        # Preserve all existing authenticators, overwrite google_otp entry
        $existingAuth = @()
        if ($freshPolicy.PSObject.Properties['settings'] -and
            $freshPolicy.settings.PSObject.Properties['authenticators']) {
            # Reconstruct each entry with only key + enroll.self to avoid Okta rejecting
            # read-only fields (e.g. _links, id) that may be present on API response objects.
            $existingAuth = @($freshPolicy.settings.authenticators) |
                Where-Object { $_.key -ne $Script:GOOGLE_OTP_KEY } |
                ForEach-Object { @{ key = [string]$_.key; enroll = @{ self = [string]$_.enroll.self } } }
        }
        $existingAuth += @{ key = $Script:GOOGLE_OTP_KEY; enroll = @{ self = 'NOT_ALLOWED' } }
        $updBody['settings'] = @{ type = 'AUTHENTICATORS'; authenticators = $existingAuth }
    }
    else {
        $updBody['settings'] = @{ factors = @{ okta_otp = @{ enroll = @{ self = 'NOT_ALLOWED' } } } }
    }

    try {
        Invoke-OktaApi -Path "/api/v1/policies/$policyId" -Method PUT -Body $updBody | Out-Null
        Write-Log -Level OK -Message "Default policy '$($DefaultPolicy.name)': google_otp set to NOT_ALLOWED (DISABLED)" `
            -Action 'DisableDefaultTOTP' -Fields @{ PolicyId = $policyId; PolicyName = $DefaultPolicy.name }
        return $true
    }
    catch {
        Write-Log -Level WARN -Message "Failed to disable google_otp in default policy: $_" -Action 'DisableDefaultTOTP'
        return $false
    }
}

function Get-HlaAccountFactors {
    <#
    .SYNOPSIS
        Audits enrolled factors for each HLA service account.
        WARNs on non-TOTP factors or missing TOTP. Does NOT delete any factors.
        Returns array of audit result objects.
    #>
    param([hashtable]$HlaUsers)

    $auditResults = [System.Collections.Generic.List[object]]::new()

    foreach ($login in $HlaUsers.Keys) {
        $user = $HlaUsers[$login]
        if (-not $user -or $user.id -like 'WHATIF-*') { continue }

        $factors = @()
        try {
            $rawFactors = Invoke-OktaApi -Path "/api/v1/users/$($user.id)/factors"
            # Explicit null guard: @($null) returns @() in PS 5.1, which is correct for "no factors",
            # but we log the raw return so false-negatives are diagnosable.
            $factors = if ($null -eq $rawFactors) { @() } else { @($rawFactors) }
            Write-Log -Level DEBUG -Message "  FactorAudit: $login (id: $($user.id)) => $($factors.Count) factor(s) returned by API" -Action 'FactorAudit'
        }
        catch {
            $auditResults.Add([PSCustomObject]@{ Login = $login; Status = 'ERROR'; Detail = "Factor query failed: $_" })
            continue
        }

        $totpFactors    = @($factors | Where-Object { $_.factorType -eq 'token:software:totp' -and $_.status -eq 'ACTIVE' })
        $nonTotpFactors = @($factors | Where-Object { $_.factorType -ne 'token:software:totp' })

        if ($factors.Count -eq 0) {
            $auditResults.Add([PSCustomObject]@{ Login = $login; Status = 'INFO';  Detail = 'No factors enrolled (expected on fresh deploy -- run enroll-totp after deploy)' })
        }
        elseif ($totpFactors.Count -eq 1 -and $nonTotpFactors.Count -eq 0) {
            $provider = $totpFactors[0].provider
            $expectedProvider = if ($Script:SELECTED_TOTP_KEY -eq 'okta_verify') { 'OKTA' } else { 'GOOGLE' }
            if ($provider -eq $expectedProvider) {
                $auditResults.Add([PSCustomObject]@{ Login = $login; Status = 'OK';    Detail = "$Script:SELECTED_TOTP_KEY TOTP only -- correct" })
            }
            elseif ($provider -in @('OKTA', 'GOOGLE')) {
                $auditResults.Add([PSCustomObject]@{ Login = $login; Status = 'WARN';  Detail = "Enrolled with provider=$provider but TOTPProvider=$($Script:SELECTED_TOTP_KEY) -- re-run enroll-totp to align" })
            }
            else {
                $auditResults.Add([PSCustomObject]@{ Login = $login; Status = 'WARN';  Detail = "Unknown provider=$provider -- verify in Okta Admin UI" })
            }
        }
        elseif ($totpFactors.Count -ge 1 -and $nonTotpFactors.Count -gt 0) {
            $types = ($nonTotpFactors | ForEach-Object { $_.factorType }) -join ', '
            $auditResults.Add([PSCustomObject]@{ Login = $login; Status = 'WARN';  Detail = "TOTP + non-TOTP enrolled ($types) -- PSM challenge order unpredictable" })
        }
        elseif ($totpFactors.Count -eq 0 -and $nonTotpFactors.Count -gt 0) {
            $types = ($nonTotpFactors | ForEach-Object { $_.factorType }) -join ', '
            $auditResults.Add([PSCustomObject]@{ Login = $login; Status = 'WARN';  Detail = "Non-TOTP factors only ($types) -- PSM will fail to authenticate" })
        }
        elseif ($totpFactors.Count -gt 1) {
            $auditResults.Add([PSCustomObject]@{ Login = $login; Status = 'WARN';  Detail = "Multiple TOTP factors ($($totpFactors.Count)) -- unexpected; verify in Okta Admin UI" })
        }
        else {
            $auditResults.Add([PSCustomObject]@{ Login = $login; Status = 'INFO';  Detail = 'TOTP found but not ACTIVE (may be PENDING_ACTIVATION)' })
        }
    }

    return $auditResults.ToArray()
}

function Save-Step55RollbackSnapshot {
    <#
    .SYNOPSIS
        Writes a JSON snapshot of pre-change Step 5.5 state to Rollbacks\.
        The snapshot drives intelligent rollback: distinguishes fresh-deploy from update.
    #>
    param(
        [bool]$GoogleOtpActivatedByThisRun,
        [string]$GoogleOtpAuthenticatorId = '',
        [string]$GoogleOtpStatusBefore    = '',
        [bool]$HlaEnrollmentPolicyCreatedByThisRun,
        [string]$HlaEnrollmentPolicyId    = '',
        [string]$HlaEnrollmentRuleId      = '',
        [string]$DefaultPolicyId          = '',
        [string]$DefaultPolicyName        = '',
        [string]$DefaultPolicyPreRunGoogleOtpSetting = '',
        [bool]$DefaultPolicyModifiedByThisRun
    )

    if (-not (Test-Path $Script:ROLLBACK_DIR)) {
        New-Item -ItemType Directory -Path $Script:ROLLBACK_DIR -Force | Out-Null
    }

    $ts      = Get-Date -Format 'yyyyMMdd-HHmmss'
    $corrId8 = $Script:CorrelationId.Substring(0, 8)
    $file    = Join-Path $Script:ROLLBACK_DIR "Deploy-OktaHLABootstrap-Step5.5-$ts-$corrId8.json"

    $payload = [ordered]@{
        snapshotType  = 'Step5.5'
        timestamp     = (Get-Date -Format 'o')
        correlationId = $Script:CorrelationId
        scriptVersion = $Script:VERSION
        tenant        = $Script:OktaBaseUrl
        googleOtpAuthenticator = [ordered]@{
            id                 = $GoogleOtpAuthenticatorId
            statusBefore       = $GoogleOtpStatusBefore
            activatedByThisRun = $GoogleOtpActivatedByThisRun
        }
        hlaEnrollmentPolicy = [ordered]@{
            id               = $HlaEnrollmentPolicyId
            ruleId           = $HlaEnrollmentRuleId
            name             = $Script:HLA_ENROLLMENT_POLICY_NAME
            createdByThisRun = $HlaEnrollmentPolicyCreatedByThisRun
        }
        defaultPolicy = [ordered]@{
            id                     = $DefaultPolicyId
            name                   = $DefaultPolicyName
            preRunGoogleOtpSetting = $DefaultPolicyPreRunGoogleOtpSetting
            modifiedByThisRun      = $DefaultPolicyModifiedByThisRun
        }
        rollbackNote  = 'See docs/planning/STEP-5.5-TOTP-ENROLLMENT-POLICY.md for rollback procedure.'
    }

    $payload | ConvertTo-Json -Depth 6 | Set-Content -Path $file -Encoding UTF8
    Write-Log -Level INFO -Message "Step 5.5 rollback snapshot saved: $file" -Action 'SaveStep55Snapshot'
    return $file
}

function Invoke-Rollback55 {
    <#
    .SYNOPSIS
        Rolls back Step 5.5 changes from a snapshot.

        ROLLBACK BEHAVIOR:
        - Fresh deploy (google_otp activated + policy created by this run):
          Deletes the HLA enrollment policy AND deactivates google_otp at tenant level.
        - Partial deploy (policy created, google_otp was already active):
          Deletes the HLA enrollment policy, leaves google_otp active.
        - Update only (policy existed before, we modified it):
          Warns that full restore is not supported; provides manual guidance.

        In all cases, operator is shown an impact assessment and must confirm explicitly.
    #>
    param([Parameter(Mandatory)][string]$SnapshotPath)

    Write-Host ""
    Write-Host "  ================================================================" -ForegroundColor Cyan
    Write-Host "  ROLLBACK: Step 5.5 -- TOTP Authenticator & Enrollment Policy" -ForegroundColor Cyan
    Write-Host "  ================================================================" -ForegroundColor Cyan
    Write-Host ""

    $snapshot = Get-Content -Path $SnapshotPath -Raw | ConvertFrom-Json
    Write-Host "  Snapshot details:" -ForegroundColor DarkGray
    Write-Host "    Timestamp:  $($snapshot.timestamp)" -ForegroundColor DarkGray
    Write-Host "    Script ver: $($snapshot.scriptVersion)" -ForegroundColor DarkGray
    Write-Host "    Tenant:     $($snapshot.tenant)" -ForegroundColor DarkGray
    Write-Host ""

    $googleOtpId        = $snapshot.googleOtpAuthenticator.id
    $googleOtpActivated = $snapshot.googleOtpAuthenticator.activatedByThisRun -eq $true
    $policyId           = $snapshot.hlaEnrollmentPolicy.id
    $ruleId             = $snapshot.hlaEnrollmentPolicy.ruleId
    $policyCreated      = $snapshot.hlaEnrollmentPolicy.createdByThisRun -eq $true
    $defaultPolicyId    = $snapshot.defaultPolicy.id
    $defaultModified    = $snapshot.defaultPolicy.modifiedByThisRun -eq $true
    $defaultPreRun      = $snapshot.defaultPolicy.preRunGoogleOtpSetting

    # --- Impact assessment ---
    Write-Host "  ROLLBACK IMPACT ASSESSMENT" -ForegroundColor Yellow
    Write-Host "  $('-' * 62)" -ForegroundColor DarkGray
    Write-Host ""

    if ($googleOtpActivated -and $policyCreated) {
        Write-Host "  FRESH DEPLOYMENT detected -- full Step 5.5 was applied." -ForegroundColor White
        Write-Host "  Rollback will:" -ForegroundColor White
        Write-Host "    [1] DELETE the HLA TOTP enrollment policy (id: $policyId)" -ForegroundColor Yellow
        Write-Host "    [2] DEACTIVATE google_otp authenticator tenant-wide (id: $googleOtpId)" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "  [ALERT] Deactivating google_otp is a TENANT-WIDE change." -ForegroundColor Red
        Write-Host "  On a fresh lab tenant this is safe. On a shared tenant, verify" -ForegroundColor Red
        Write-Host "  no other users have google_otp enrolled before deactivating." -ForegroundColor Red
    }
    elseif ($policyCreated -and -not $googleOtpActivated) {
        Write-Host "  PARTIAL DEPLOYMENT: google_otp was already ACTIVE before this run." -ForegroundColor White
        Write-Host "  Rollback will:" -ForegroundColor White
        Write-Host "    [1] DELETE the HLA TOTP enrollment policy (id: $policyId)" -ForegroundColor Yellow
        Write-Host "    [2] Leave google_otp ACTIVE (it was active before this run)" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "  [ALERT] After rollback, google_otp remains active at tenant level" -ForegroundColor Yellow
        Write-Host "  but with no scoped HLA policy. Verify the default enrollment policy" -ForegroundColor Yellow
        Write-Host "  does NOT have google_otp set to OPTIONAL/REQUIRED." -ForegroundColor Yellow
    }
    else {
        Write-Host "  POLICY UPDATE: The HLA enrollment policy pre-existed this run." -ForegroundColor White
        Write-Host "  Full automated rollback is not supported for this case." -ForegroundColor White
        Write-Host ""
        Write-Host "  Manual rollback steps:" -ForegroundColor White
        Write-Host "    Okta Admin > Security > Authenticators > Enrollment" -ForegroundColor DarkGray
        Write-Host "    Policy: $Script:HLA_ENROLLMENT_POLICY_NAME (id: $policyId)" -ForegroundColor DarkGray
        Write-Host "    Restore the group list and google_otp setting to their prior state." -ForegroundColor DarkGray
        Write-Host ""
        Write-Host "  [ALERT] TOTP seeds enrolled on HLA accounts during this run are NOT" -ForegroundColor Yellow
        Write-Host "  removed by rollback. Run 'cpm-simulator enroll-totp' to re-manage." -ForegroundColor Yellow
        Write-Log -Level WARN -Message "Step 5.5 rollback: pre-existing policy -- manual action required. See snapshot for details." -Action 'Rollback55Manual'
        return
    }

    if ($defaultModified -and $defaultPolicyId) {
        Write-Host ""
        Write-Host "  ADDITIONALLY: Default enrollment policy was modified." -ForegroundColor Yellow
        Write-Host "  Restore google_otp to '$defaultPreRun' manually:" -ForegroundColor White
        Write-Host "    Okta Admin > Security > Authenticators > Enrollment > Default Policy" -ForegroundColor DarkGray
        Write-Host "  (Automated restore of this change is not supported -- operator verification required.)" -ForegroundColor DarkGray
    }

    Write-Host ""

    if ($Script:IsDryRun) {
        Write-Log -Level INFO -Message "[WhatIf] Step 5.5 rollback would apply the above changes -- no changes made."
        return
    }

    # Explicit confirmation -- no AcceptDefaults; -Force bypasses for automation
    if ($Script:Force) {
        Write-Host "  [Force] Auto-accepting Step 5.5 rollback (-Force specified)" -ForegroundColor Yellow
        $answer = 'y'
    }
    else {
        $answer = Read-Host "  Apply Step 5.5 rollback? [y/N]"
    }
    if ($answer -notmatch '^[Yy]') {
        Write-Log -Level INFO -Message "Step 5.5 rollback cancelled by operator."
        return
    }

    Write-Host ""

    # Step 1: Delete HLA enrollment policy (rule first, then policy)
    if ($policyId) {
        Write-Log -Level INFO -Message "Deleting HLA enrollment policy (id: $policyId)..."
        if ($ruleId) {
            try {
                Invoke-OktaApi -Path "/api/v1/policies/$policyId/rules/$ruleId" -Method DELETE | Out-Null
                Write-Log -Level OK -Message "Deleted enrollment rule (id: $ruleId)" -Action 'Rollback55DeleteRule'
            }
            catch { Write-Log -Level WARN -Message "Could not delete rule $ruleId (may already be gone): $_" }
        }
        try {
            Invoke-OktaApi -Path "/api/v1/policies/$policyId/lifecycle/deactivate" -Method POST | Out-Null
        }
        catch {}
        try {
            Invoke-OktaApi -Path "/api/v1/policies/$policyId" -Method DELETE | Out-Null
            Write-Log -Level OK -Message "Deleted HLA enrollment policy (id: $policyId)" -Action 'Rollback55DeletePolicy'
        }
        catch {
            Write-Log -Level WARN -Message "Failed to delete HLA enrollment policy: $_" -Action 'Rollback55DeletePolicy'
        }
    }

    # Step 1.5: Remove google_otp from default enrollment policy BEFORE deactivating.
    # Okta returns E0000148 ("Cannot modify/disable this authenticator because it is
    # enabled in one or more policies") if any active policy still references it.
    # The HLA enrollment policy was already deleted above; the default policy may still
    # have google_otp set to OPTIONAL or REQUIRED from a prior deploy run.
    if ($googleOtpActivated -and $googleOtpId -and $defaultPolicyId) {
        Write-Log -Level INFO -Message "Clearing google_otp from default enrollment policy (prerequisite for deactivate, id: $defaultPolicyId)..."
        try {
            $defPol = Invoke-OktaApi -Path "/api/v1/policies/$defaultPolicyId"
            if ($defPol) {
                $pipeline = Get-OktaEnginePipeline
                $defPri   = if ($defPol.PSObject.Properties['priority']) { [int]$defPol.priority } else { 99 }
                $cleanAuth = @()
                if ($pipeline -eq 'OIE' -and
                    $defPol.PSObject.Properties['settings'] -and
                    $defPol.settings.PSObject.Properties['authenticators']) {
                    # Reconstruct entries with only key + enroll.self (no read-only fields in PUT body)
                    $cleanAuth = @($defPol.settings.authenticators) |
                        Where-Object { $_.key -ne $Script:GOOGLE_OTP_KEY } |
                        ForEach-Object { @{ key = [string]$_.key; enroll = @{ self = [string]$_.enroll.self } } }
                }
                # Set google_otp NOT_ALLOWED (harmless if it was already absent or DISABLED)
                $cleanAuth += @{ key = $Script:GOOGLE_OTP_KEY; enroll = @{ self = 'NOT_ALLOWED' } }
                $defUpdBody = @{
                    type     = 'MFA_ENROLL'
                    name     = $defPol.name
                    status   = 'ACTIVE'
                    priority = $defPri
                    settings = @{ type = 'AUTHENTICATORS'; authenticators = $cleanAuth }
                }
                # Echo back description and conditions (required for default policy PUT -- E0000077)
                # Roundtrip conditions through JSON to strip PSObject metadata
                if ($defPol.PSObject.Properties['description'] -and $defPol.description) {
                    $defUpdBody['description'] = [string]$defPol.description
                }
                if ($defPol.PSObject.Properties['conditions']) {
                    $condJson = $defPol.conditions | ConvertTo-Json -Depth 10 -Compress
                    $defUpdBody['conditions'] = $condJson | ConvertFrom-Json
                }
                Invoke-OktaApi -Path "/api/v1/policies/$defaultPolicyId" -Method PUT -Body $defUpdBody | Out-Null
                Write-Log -Level OK -Message "Default policy: google_otp set to NOT_ALLOWED (ready for authenticator deactivate)" -Action 'Rollback55CleanDefaultPolicy'
            }
            else {
                Write-Log -Level WARN -Message "Default policy id $defaultPolicyId not found -- skipping pre-clean (deactivate may fail)" -Action 'Rollback55CleanDefaultPolicy'
            }
        }
        catch {
            Write-Log -Level WARN -Message "Could not clear google_otp from default policy: $_" -Action 'Rollback55CleanDefaultPolicy'
            Write-Log -Level WARN -Message "If deactivate fails below with E0000148, manually remove google_otp from Default Enrollment Policy first."
        }
    }

    # Step 2: Deactivate google_otp authenticator (only if activated by this run)
    if ($googleOtpActivated -and $googleOtpId) {
        Write-Log -Level INFO -Message "Deactivating google_otp authenticator (id: $googleOtpId) at tenant level..."
        try {
            Invoke-OktaApi -Path "/api/v1/authenticators/$googleOtpId/lifecycle/deactivate" -Method POST | Out-Null
            Write-Log -Level OK -Message "google_otp authenticator deactivated" -Action 'Rollback55DeactivateAuthenticator'
        }
        catch {
            Write-Log -Level WARN -Message "Failed to deactivate google_otp: $_" -Action 'Rollback55DeactivateAuthenticator'
            Write-Log -Level WARN -Message "Deactivate manually: Okta Admin > Security > Authenticators > Google Authenticator > Deactivate"
        }
    }

    Write-Log -Level OK -Message "Step 5.5 rollback complete. Run -Action Inspect to verify." -Action 'Rollback55Complete'
}

function Invoke-Step55 {
    <#
    .SYNOPSIS
        Orchestrates Step 5.5: TOTP Authenticator & Enrollment Policy.
        Provider-aware: uses $TOTPProvider to select authenticator key.
        Sub-steps:
          5.5a -- Authenticator check/activation (provider-dependent)
          5.5b -- HLA enrollment policy create/verify
          5.5c -- Default policy audit (GOOGLE only -- security risk check)
          5.5d -- Per-account factor audit (warn-only; never deletes factors)
    #>
    param(
        [Parameter(Mandatory)][string]$T1GroupId,
        [Parameter(Mandatory)][string]$T2GroupId,
        [Parameter(Mandatory)][string]$T3GroupId,
        [hashtable]$HlaUsers = @{},
        [ValidateSet('GOOGLE', 'OKTA')]
        [string]$TOTPProvider = 'OKTA'
    )

    Write-Log -Level STEP -Message "--- Step 5.5: TOTP Authenticator & Enrollment Policy ---"
    Write-Host ""
    Write-Host "  SECURITY CONTEXT" -ForegroundColor Yellow
    Write-Host "  =============================================================" -ForegroundColor Yellow
    Write-Host "  TOTP Provider: $TOTPProvider ($Script:SELECTED_TOTP_KEY)" -ForegroundColor Yellow
    if ($TOTPProvider -eq 'GOOGLE') {
        Write-Host "  google_otp (software TOTP / RFC 6238) is weaker than Okta" -ForegroundColor Yellow
        Write-Host "  Verify push or FIDO2. It must be restricted to CyberArk HLA" -ForegroundColor Yellow
        Write-Host "  groups ONLY. Enabling it globally downgrades all tenant users." -ForegroundColor Yellow
    }
    else {
        Write-Host "  okta_verify TOTP (RFC 6238) -- standard authenticator." -ForegroundColor Yellow
        Write-Host "  Enrollment restricted to CyberArk HLA groups via policy." -ForegroundColor Yellow
    }
    Write-Host "  =============================================================" -ForegroundColor Yellow
    Write-Host ""

    # --- Detect OIE vs Classic Engine ---
    $pipeline = Get-OktaEnginePipeline
    Write-Log -Level INFO -Message "Tenant engine: $pipeline"
    if ($pipeline -eq 'Classic') {
        Write-Log -Level WARN -Message "Classic Engine detected -- Step 5.5 support is limited (OIE required for full policy management)"
    }

    # State tracking for rollback snapshot and deploy summary
    $selectedAuthenticator           = $null
    $googleOtpActivatedByThisRun     = $false
    $googleOtpStatusBefore           = 'NOT_FOUND'
    # Keep these variable names for backward-compat with rollback snapshot schema
    $googleOtpAuthenticator          = $null
    $hlaPolicy                   = $null
    $hlaEnrollmentPolicyCreated  = $false
    $hlaEnrollmentRuleId         = $null
    $defaultPolicy               = $null
    $defaultPolicyPreRunSetting  = ''
    $defaultPolicyModified       = $false

    # ---- 5.5a: Authenticator Check ----
    Write-Log -Level INFO -Message "5.5a: Checking $Script:SELECTED_TOTP_KEY authenticator status..."

    # Fetch all authenticators and find the selected one
    $allAuthenticators = @()
    try { $allAuthenticators = @(Invoke-OktaApi -Path '/api/v1/authenticators') } catch {}
    $selectedAuthenticator = @($allAuthenticators) | Where-Object { $_.key -eq $Script:SELECTED_TOTP_KEY } | Select-Object -First 1

    if ($TOTPProvider -eq 'GOOGLE') {
        # GOOGLE path: may need tenant-wide activation (existing behavior with prompts)
        $googleOtpAuthenticator = $selectedAuthenticator

        if (-not $googleOtpAuthenticator) {
            Write-Log -Level WARN -Message "google_otp authenticator NOT FOUND in /api/v1/authenticators" -Action 'Step55a'
            Write-Log -Level WARN -Message "Tenant may be Classic Engine. cpm-simulator enroll-totp will fail without an active google_otp authenticator."
            Write-SIEMLog -Level 'WARN' -Message "Step 5.5a: google_otp not found" -Action 'Step55a' -Fields @{ Pipeline = $pipeline; Outcome = 'NotFound' }
            $Script:Step55Status = @{
                AuthenticatorStatus = 'NOT_FOUND'; PolicyStatus = 'SKIPPED'; BlockedProviderStatus = 'N/A'
                DefaultPolicyStatus = 'SKIPPED';  FactorAuditStatus = 'SKIPPED'; OverallOK = $false
            }
            if (-not (Confirm-UserChoice -Prompt "  Continue without google_otp authenticator?" -Default 'N')) {
                throw "Step 5.5 aborted: google_otp not found. TOTP enrollment cannot proceed."
            }
            Write-Log -Level WARN -Message "Continuing without google_otp -- TOTP enrollment will fail at CPM step."
            return
        }

        $googleOtpStatusBefore = $googleOtpAuthenticator.status
        Write-Log -Level INFO -Message "google_otp authenticator: id=$($googleOtpAuthenticator.id)  status=$googleOtpStatusBefore"

        if ($googleOtpStatusBefore -eq 'INACTIVE') {
            $activated = Enable-OktaGoogleOtpAuthenticator -Authenticator $googleOtpAuthenticator
            if ($activated) { $googleOtpActivatedByThisRun = $true }
        }
        else {
            Write-Log -Level OK -Message "google_otp authenticator is already ACTIVE" -Action 'Step55a'
        }
    }
    else {
        # OKTA path: okta_verify is usually already active -- just verify
        if (-not $selectedAuthenticator) {
            Write-Log -Level WARN -Message "okta_verify authenticator NOT FOUND in /api/v1/authenticators" -Action 'Step55a'
            Write-Log -Level WARN -Message "This is unusual for OIE tenants. Check Okta Admin > Security > Authenticators."
            Write-SIEMLog -Level 'WARN' -Message "Step 5.5a: okta_verify not found" -Action 'Step55a' -Fields @{ Pipeline = $pipeline; Outcome = 'NotFound' }
            $Script:Step55Status = @{
                AuthenticatorStatus = 'NOT_FOUND'; PolicyStatus = 'SKIPPED'; BlockedProviderStatus = 'N/A'
                DefaultPolicyStatus = 'SKIPPED';  FactorAuditStatus = 'SKIPPED'; OverallOK = $false
            }
            if (-not (Confirm-UserChoice -Prompt "  Continue without okta_verify authenticator?" -Default 'N')) {
                throw "Step 5.5 aborted: okta_verify not found. TOTP enrollment cannot proceed."
            }
            Write-Log -Level WARN -Message "Continuing without okta_verify -- TOTP enrollment will fail at CPM step."
            return
        }

        $selectedStatus = $selectedAuthenticator.status
        Write-Log -Level INFO -Message "okta_verify authenticator: id=$($selectedAuthenticator.id)  status=$selectedStatus"

        if ($selectedStatus -eq 'ACTIVE') {
            Write-Log -Level OK -Message "okta_verify authenticator is already ACTIVE -- no tenant-wide changes needed" -Action 'Step55a'
        }
        else {
            Write-Log -Level WARN -Message "okta_verify authenticator is $selectedStatus -- it must be activated before TOTP enrollment" -Action 'Step55a'
            Write-Host "  okta_verify is $selectedStatus. Activate it via Okta Admin > Security > Authenticators." -ForegroundColor Yellow
            if (-not (Confirm-UserChoice -Prompt "  Continue with $selectedStatus okta_verify?" -Default 'N')) {
                throw "Step 5.5 aborted: okta_verify is $selectedStatus."
            }
        }
        # For rollback snapshot compatibility, capture google_otp state if it exists
        $googleOtpAuthenticator = @($allAuthenticators) | Where-Object { $_.key -eq $Script:GOOGLE_OTP_KEY } | Select-Object -First 1
        if ($googleOtpAuthenticator) { $googleOtpStatusBefore = $googleOtpAuthenticator.status }
    }

    Write-SIEMLog -Level 'INFO' -Message "Step 5.5a complete" -Action 'Step55a' `
        -Fields @{ Provider = $TOTPProvider; StatusBefore = $(if ($TOTPProvider -eq 'GOOGLE') { $googleOtpStatusBefore } else { $selectedAuthenticator.status }); Activated = $googleOtpActivatedByThisRun }

    # ---- 5.5b: HLA Enrollment Policy ----
    Write-Log -Level INFO -Message "5.5b: Checking HLA enrollment policy..."
    $hlaPolicy = Find-OktaHLAEnrollmentPolicy

    # Pre-change snapshot (before any policy create/update)
    $defaultPolicy = Get-OktaDefaultEnrollmentPolicy
    if ($defaultPolicy) {
        $defaultPolicyPreRunSetting = Get-DefaultPolicyTOTPSetting -DefaultPolicy $defaultPolicy -Pipeline $pipeline
    }

    if (-not $hlaPolicy) {
        Write-Log -Level INFO -Message "HLA enrollment policy not found -- creating..."

        # Save initial snapshot with empty policy ID (will update after creation)
        Save-Step55RollbackSnapshot `
            -GoogleOtpActivatedByThisRun $googleOtpActivatedByThisRun `
            -GoogleOtpAuthenticatorId    $googleOtpAuthenticator.id `
            -GoogleOtpStatusBefore       $googleOtpStatusBefore `
            -HlaEnrollmentPolicyCreatedByThisRun $true `
            -HlaEnrollmentPolicyId       '' `
            -HlaEnrollmentRuleId         '' `
            -DefaultPolicyId             $(if ($defaultPolicy) { $defaultPolicy.id } else { '' }) `
            -DefaultPolicyName           $(if ($defaultPolicy) { $defaultPolicy.name } else { '' }) `
            -DefaultPolicyPreRunGoogleOtpSetting $defaultPolicyPreRunSetting `
            -DefaultPolicyModifiedByThisRun $false | Out-Null

        $hlaPolicy = New-OktaHLAEnrollmentPolicy -T1GroupId $T1GroupId -T2GroupId $T2GroupId `
            -T3GroupId $T3GroupId -Pipeline $pipeline
        $hlaEnrollmentPolicyCreated = $true

        # Re-save snapshot with real IDs once policy is created
        if ($hlaPolicy -and $hlaPolicy.id -notlike 'WHATIF-*') {
            try {
                $rules = @(Invoke-OktaApi -Path "/api/v1/policies/$($hlaPolicy.id)/rules")
                $hlRule = $rules | Where-Object { $_.name -eq $Script:HLA_ENROLLMENT_RULE_NAME } | Select-Object -First 1
                $hlaEnrollmentRuleId = if ($hlRule) { $hlRule.id } else { '' }
            }
            catch { $hlaEnrollmentRuleId = '' }

            Save-Step55RollbackSnapshot `
                -GoogleOtpActivatedByThisRun $googleOtpActivatedByThisRun `
                -GoogleOtpAuthenticatorId    $googleOtpAuthenticator.id `
                -GoogleOtpStatusBefore       $googleOtpStatusBefore `
                -HlaEnrollmentPolicyCreatedByThisRun $true `
                -HlaEnrollmentPolicyId       $hlaPolicy.id `
                -HlaEnrollmentRuleId         $hlaEnrollmentRuleId `
                -DefaultPolicyId             $(if ($defaultPolicy) { $defaultPolicy.id } else { '' }) `
                -DefaultPolicyName           $(if ($defaultPolicy) { $defaultPolicy.name } else { '' }) `
                -DefaultPolicyPreRunGoogleOtpSetting $defaultPolicyPreRunSetting `
                -DefaultPolicyModifiedByThisRun $false | Out-Null
        }
        Write-SIEMLog -Level 'INFO' -Message "Step 5.5b: HLA enrollment policy created" -Action 'Step55b' `
            -Fields @{ Outcome = 'Created'; PolicyId = $(if ($hlaPolicy) { $hlaPolicy.id } else { 'WhatIf' }) }
    }
    else {
        Write-Log -Level INFO -Message "HLA enrollment policy exists (id: $($hlaPolicy.id)) -- verifying..."

        Save-Step55RollbackSnapshot `
            -GoogleOtpActivatedByThisRun $googleOtpActivatedByThisRun `
            -GoogleOtpAuthenticatorId    $googleOtpAuthenticator.id `
            -GoogleOtpStatusBefore       $googleOtpStatusBefore `
            -HlaEnrollmentPolicyCreatedByThisRun $false `
            -HlaEnrollmentPolicyId       $hlaPolicy.id `
            -HlaEnrollmentRuleId         '' `
            -DefaultPolicyId             $(if ($defaultPolicy) { $defaultPolicy.id } else { '' }) `
            -DefaultPolicyName           $(if ($defaultPolicy) { $defaultPolicy.name } else { '' }) `
            -DefaultPolicyPreRunGoogleOtpSetting $defaultPolicyPreRunSetting `
            -DefaultPolicyModifiedByThisRun $false | Out-Null

        Update-OktaHLAEnrollmentPolicy -Policy $hlaPolicy -T1GroupId $T1GroupId `
            -T2GroupId $T2GroupId -T3GroupId $T3GroupId -Pipeline $pipeline
        Write-SIEMLog -Level 'INFO' -Message "Step 5.5b: HLA enrollment policy verified/updated" -Action 'Step55b' `
            -Fields @{ Outcome = 'VerifiedOrUpdated'; PolicyId = $hlaPolicy.id }
    }

    # ---- 5.5c: Default Policy Audit ----
    if ($TOTPProvider -eq 'GOOGLE') {
        Write-Log -Level INFO -Message "5.5c: Auditing default enrollment policy for google_otp risk..."
    }
    else {
        Write-Log -Level OK -Message "5.5c: Default policy audit skipped -- okta_verify is a standard authenticator (no tenant-wide risk)" -Action 'Step55c'
        Write-SIEMLog -Level 'INFO' -Message "Step 5.5c: skipped (OKTA provider)" -Action 'Step55c' -Fields @{ Outcome = 'SkippedOktaProvider' }
    }

    if ($TOTPProvider -eq 'GOOGLE' -and $defaultPolicy) {
        $isRisk = Test-DefaultPolicyTOTPRisk -DefaultPolicy $defaultPolicy -Pipeline $pipeline
        if ($isRisk) {
            Write-Host ""
            Write-Host "  =============================================================" -ForegroundColor Red
            Write-Host "  [SECURITY WARNING]" -ForegroundColor Red
            Write-Host "  The DEFAULT MFA enrollment policy has google_otp set to" -ForegroundColor Red
            Write-Host "  OPTIONAL or REQUIRED. ALL Okta users in this tenant can" -ForegroundColor Red
            Write-Host "  self-enroll software TOTP (Google Authenticator, Authy, etc.)." -ForegroundColor Red
            Write-Host "  This is weaker than Okta Verify push (device-bound) or FIDO2." -ForegroundColor Red
            Write-Host ""
            Write-Host "  Default policy: $($defaultPolicy.name) (id: $($defaultPolicy.id))" -ForegroundColor Yellow
            Write-Host "  Recommended:    Set google_otp to DISABLED in the default policy." -ForegroundColor Yellow
            Write-Host "  =============================================================" -ForegroundColor Red
            Write-Host ""

            $modified = Disable-DefaultPolicyTOTP -DefaultPolicy $defaultPolicy -Pipeline $pipeline
            $defaultPolicyModified = $modified

            if ($modified) {
                Write-SIEMLog -Level 'INFO' -Message "Step 5.5c: default policy google_otp disabled" -Action 'Step55c' `
                    -Fields @{ Outcome = 'DefaultTOTPDisabled'; PolicyId = $defaultPolicy.id }
                # Re-save snapshot now that we know the default policy was modified
                $finalSnapshotFile = Save-Step55RollbackSnapshot `
                    -GoogleOtpActivatedByThisRun $googleOtpActivatedByThisRun `
                    -GoogleOtpAuthenticatorId    $googleOtpAuthenticator.id `
                    -GoogleOtpStatusBefore       $googleOtpStatusBefore `
                    -HlaEnrollmentPolicyCreatedByThisRun $hlaEnrollmentPolicyCreated `
                    -HlaEnrollmentPolicyId       $(if ($hlaPolicy) { $hlaPolicy.id } else { '' }) `
                    -HlaEnrollmentRuleId         $hlaEnrollmentRuleId `
                    -DefaultPolicyId             $defaultPolicy.id `
                    -DefaultPolicyName           $defaultPolicy.name `
                    -DefaultPolicyPreRunGoogleOtpSetting $defaultPolicyPreRunSetting `
                    -DefaultPolicyModifiedByThisRun $true
                Write-Log -Level INFO -Message "Final rollback snapshot updated: $finalSnapshotFile"
            }
            else {
                Write-SIEMLog -Level 'WARN' -Message "Step 5.5c: default policy TOTP risk unresolved (operator declined)" -Action 'Step55c' `
                    -Fields @{ Outcome = 'RiskUnresolved'; PolicyId = $defaultPolicy.id }
            }
        }
        else {
            Write-Log -Level OK -Message "Default enrollment policy: google_otp is DISABLED/absent -- secure" -Action 'Step55c'
            Write-SIEMLog -Level 'INFO' -Message "Step 5.5c: default policy secure" -Action 'Step55c' -Fields @{ Outcome = 'Secure' }
        }
    }
    elseif ($TOTPProvider -eq 'GOOGLE' -and -not $defaultPolicy) {
        Write-Log -Level WARN -Message "Default enrollment policy not found -- skipping default policy audit" -Action 'Step55c'
    }

    # ---- 5.5d: HLA Account Factor Audit ----
    Write-Log -Level INFO -Message "5.5d: Auditing enrolled factors on HLA accounts..."
    $factorAuditResults = @()

    if ($Script:IsDryRun) {
        Write-Log -Level INFO -Message "[WhatIf] Skipping factor audit (user IDs are WhatIf placeholders)"
    }
    elseif ($HlaUsers.Count -eq 0) {
        Write-Log -Level INFO -Message "No HLA users passed to factor audit -- skipping"
    }
    else {
        $factorAuditResults = Get-HlaAccountFactors -HlaUsers $HlaUsers
        $warnCount = 0; $okCount = 0; $infoCount = 0
        foreach ($r in $factorAuditResults) {
            $color = switch ($r.Status) { 'OK' { 'Green' } 'WARN' { 'Yellow' } 'ERROR' { 'Red' } default { 'Cyan' } }
            Write-Host ("    {0,-38} [{1}] {2}" -f $r.Login, $r.Status, $r.Detail) -ForegroundColor $color
            switch ($r.Status) { 'OK' { $okCount++ } 'WARN' { $warnCount++ } 'INFO' { $infoCount++ } }
        }
        Write-Host ""
        if ($warnCount -gt 0) {
            Write-Log -Level WARN -Message "5.5d Factor audit: $okCount OK / $warnCount WARNING(s) / $infoCount INFO" -Action 'Step55d'
            Write-Log -Level WARN -Message "  Remove non-TOTP factors via: cpm-simulator enroll-totp <account> (deletes all factors then re-enrolls TOTP)"
        }
        else {
            Write-Log -Level OK -Message "5.5d Factor audit: $okCount OK / $infoCount INFO (fresh deploy -- run enroll-totp after Invoke-OktaHLAVaultSetup)" -Action 'Step55d'
        }
        Write-SIEMLog -Level $(if ($warnCount -gt 0) { 'WARN' } else { 'INFO' }) `
            -Message "Step 5.5d: factor audit complete" -Action 'Step55d' `
            -Fields @{ OK = $okCount; Warnings = $warnCount; Info = $infoCount }
    }

    # ---- Populate Script-scoped status for Deploy Summary and Inspect ----
    # For OKTA provider, check selectedAuthenticator; for GOOGLE, check googleOtpAuthenticator
    $authRef = if ($TOTPProvider -eq 'GOOGLE') { $googleOtpAuthenticator } else { $selectedAuthenticator }
    $authStatusStr = if (-not $authRef)                    { 'NOT_FOUND' } `
                     elseif ($googleOtpActivatedByThisRun)  { 'ACTIVATED_THIS_RUN' } `
                     else                                   { 'ALREADY_ACTIVE' }
    $polStatusStr  = if ($hlaEnrollmentPolicyCreated)     { 'CREATED' } `
                     elseif ($hlaPolicy)                    { 'VERIFIED' } `
                     else                                   { 'SKIPPED' }
    $defStatusStr  = if ($TOTPProvider -eq 'OKTA')          { 'N/A (OKTA provider)' } `
                     elseif (-not $defaultPolicy)           { 'NOT_FOUND' } `
                     elseif ($defaultPolicyModified)        { 'REMEDIATED' } `
                     else {
                         $isRiskFinal = $defaultPolicy -and (Test-DefaultPolicyTOTPRisk -DefaultPolicy $defaultPolicy -Pipeline $pipeline)
                         if ($isRiskFinal) { 'RISK_UNRESOLVED' } else { 'SECURE' }
                     }
    $factAuditStr  = if ($Script:IsDryRun)                    { 'SKIPPED (WhatIf)' } `
                     elseif ($factorAuditResults.Count -eq 0)  { 'NO_ACCOUNTS' } `
                     else {
                         $wc = @($factorAuditResults | Where-Object { $_.Status -eq 'WARN' }).Count
                         if ($wc -gt 0) { "$wc WARNING(s)" } else { 'OK' }
                     }

    # Determine blocked provider status in HLA policy
    $blkStatusStr = 'N/A'
    if ($pipeline -eq 'OIE' -and $hlaPolicy -and $hlaPolicy.PSObject.Properties['settings'] -and
        $hlaPolicy.settings.PSObject.Properties['authenticators']) {
        $blkEntry = @($hlaPolicy.settings.authenticators) | Where-Object { $_.key -eq $Script:BLOCKED_TOTP_KEY }
        if ($blkEntry) { $blkStatusStr = $blkEntry.enroll.self }
        else           { $blkStatusStr = 'NOT_IN_POLICY' }
    }

    $Script:Step55Status = @{
        AuthenticatorStatus   = $authStatusStr
        PolicyStatus          = $polStatusStr
        BlockedProviderStatus = $blkStatusStr
        DefaultPolicyStatus   = $defStatusStr
        FactorAuditStatus     = $factAuditStr
        OverallOK             = ($authStatusStr -ne 'NOT_FOUND' -and $polStatusStr -ne 'SKIPPED' -and $defStatusStr -notin @('RISK_UNRESOLVED', 'NOT_FOUND'))
    }

    Write-Log -Level INFO -Message "Step 5.5 complete: Provider=$TOTPProvider  Auth=$authStatusStr  Policy=$polStatusStr  Blocked=$blkStatusStr  Default=$defStatusStr  FactorAudit=$factAuditStr" `
        -Action 'StepComplete' -Fields @{ Step = '5.5'; Provider = $TOTPProvider; AuthStatus = $authStatusStr; PolicyStatus = $polStatusStr; BlockedProvider = $blkStatusStr; DefaultStatus = $defStatusStr }
}

#endregion Step 5.5

#endregion

#region Teardown Functions

function Remove-OktaPolicy {
    param([Parameter(Mandatory)][object]$Policy)
    $policyId   = $Policy.id
    $policyName = $Policy.name

    Write-Log -Level STEP -Message "Tearing down policy: $policyName ($policyId)"

    if ($Script:IsDryRun) {
        Write-Log -Level INFO -Message "[WhatIf] Would delete policy: $policyName" -Action 'DeletePolicy'
        return
    }

    # Step 1: Get and delete all rules (except default)
    try {
        $rules = Invoke-OktaApi -Path "/api/v1/policies/$policyId/rules"
        if ($rules) {
            foreach ($r in @($rules)) {
                if ($r.system -eq $true) {
                    Write-Log -Level SKIP -Message "  Skipping system rule: $($r.name)"
                    continue
                }
                Write-Log -Level INFO -Message "  Deleting rule: $($r.name) ($($r.id))"
                Invoke-OktaApi -Path "/api/v1/policies/$policyId/rules/$($r.id)" -Method DELETE | Out-Null
            }
        }
    }
    catch {
        Write-Log -Level WARN -Message "  Error listing/deleting rules for $policyName : $_"
    }

    # Step 2: Deactivate policy
    try {
        Invoke-OktaApi -Path "/api/v1/policies/$policyId/lifecycle/deactivate" -Method POST | Out-Null
        Write-Log -Level INFO -Message "  Deactivated policy: $policyName"
    }
    catch {
        Write-Log -Level DEBUG -Message "  Policy deactivation returned error (may already be inactive): $_"
    }

    # Step 3: Delete policy
    Invoke-OktaApi -Path "/api/v1/policies/$policyId" -Method DELETE | Out-Null
    Write-Log -Level OK -Message "  Deleted policy: $policyName" `
        -Action 'DeletePolicy' -Fields @{ PolicyName = $policyName; PolicyId = $policyId }
}

function Remove-OktaToken {
    param([Parameter(Mandatory)][object]$Token)
    $tokenId   = $Token.id
    $tokenName = $Token.name

    if ($Script:IsDryRun) {
        Write-Log -Level INFO -Message "[WhatIf] Would revoke token: $tokenName" -Action 'RevokeToken'
        return
    }

    Invoke-OktaApi -Path "/api/v1/api-tokens/$tokenId" -Method DELETE | Out-Null
    Write-Log -Level OK -Message "Revoked token: $tokenName ($tokenId)" `
        -Action 'RevokeToken' -Fields @{ TokenName = $tokenName; TokenId = $tokenId }
}

function Remove-OktaRoleBinding {
    param(
        [Parameter(Mandatory)][string]$UserId,
        [Parameter(Mandatory)][object]$Binding
    )
    $bindingId = $Binding.id

    if ($Script:IsDryRun) {
        Write-Log -Level INFO -Message "[WhatIf] Would remove role binding $bindingId from user $UserId" -Action 'DeleteBinding'
        return
    }

    Invoke-OktaApi -Path "/api/v1/users/$UserId/roles/$bindingId" -Method DELETE | Out-Null
    Write-Log -Level OK -Message "Removed role binding $bindingId from user $UserId" `
        -Action 'DeleteBinding' -Fields @{ UserId = $UserId; BindingId = $bindingId }
}

function Remove-OktaResourceSet {
    param([Parameter(Mandatory)][object]$ResourceSet)
    $rsId = $ResourceSet.id

    if ($Script:IsDryRun) {
        Write-Log -Level INFO -Message "[WhatIf] Would delete resource set: $($ResourceSet.label)" -Action 'DeleteResourceSet'
        return
    }

    Invoke-OktaApi -Path "/api/v1/iam/resource-sets/$rsId" -Method DELETE | Out-Null
    Write-Log -Level OK -Message "Deleted resource set: $($ResourceSet.label) ($rsId)" `
        -Action 'DeleteResourceSet' -Fields @{ ResourceSetId = $rsId }
}

function Remove-OktaCustomRole {
    param([Parameter(Mandatory)][object]$Role)
    $roleId = $Role.id

    if ($Script:IsDryRun) {
        Write-Log -Level INFO -Message "[WhatIf] Would delete custom role: $($Role.label)" -Action 'DeleteRole'
        return
    }

    Invoke-OktaApi -Path "/api/v1/iam/roles/$roleId" -Method DELETE | Out-Null
    Write-Log -Level OK -Message "Deleted custom role: $($Role.label) ($roleId)" `
        -Action 'DeleteRole' -Fields @{ RoleId = $roleId }
}

function Remove-OktaNetworkZone {
    param([Parameter(Mandatory)][object]$Zone)
    $zoneId = $Zone.id

    if ($Script:IsDryRun) {
        Write-Log -Level INFO -Message "[WhatIf] Would delete network zone: $($Zone.name)" -Action 'DeleteZone'
        return
    }

    # Deactivate first
    try {
        Invoke-OktaApi -Path "/api/v1/zones/$zoneId/lifecycle/deactivate" -Method POST | Out-Null
        Write-Log -Level INFO -Message "  Deactivated zone: $($Zone.name)"
    }
    catch {
        Write-Log -Level DEBUG -Message "  Zone deactivation error (may already be inactive): $_"
    }

    Invoke-OktaApi -Path "/api/v1/zones/$zoneId" -Method DELETE | Out-Null
    Write-Log -Level OK -Message "Deleted network zone: $($Zone.name) ($zoneId)" `
        -Action 'DeleteZone' -Fields @{ ZoneId = $zoneId; ZoneName = $Zone.name }
}

function Remove-OktaGroup {
    param([Parameter(Mandatory)][object]$Group)
    $groupId   = $Group.id
    $groupName = $Group.profile.name

    if ($Script:IsDryRun) {
        Write-Log -Level INFO -Message "[WhatIf] Would delete group: $groupName" -Action 'DeleteGroup'
        return
    }

    # Deleting a group implicitly removes memberships
    Invoke-OktaApi -Path "/api/v1/groups/$groupId" -Method DELETE | Out-Null
    Write-Log -Level OK -Message "Deleted group: $groupName ($groupId)" `
        -Action 'DeleteGroup' -Fields @{ GroupName = $groupName; GroupId = $groupId }
}

function Remove-OktaUser {
    param([Parameter(Mandatory)][object]$User)
    $userId    = $User.id
    $userLogin = $User.profile.login
    $status    = $User.status

    if ($Script:IsDryRun) {
        Write-Log -Level INFO -Message "[WhatIf] Would deactivate+delete user: $userLogin" -Action 'DeleteUser'
        return
    }

    # Step 1: Remove admin role assignments (prevents orphaned role references)
    try {
        $roles = Invoke-OktaApi -Path "/api/v1/users/$userId/roles"
        if ($roles) {
            foreach ($r in @($roles)) {
                Write-Log -Level INFO -Message "  Removing admin role $($r.type) from $userLogin"
                try {
                    Invoke-OktaApi -Path "/api/v1/users/$userId/roles/$($r.id)" -Method DELETE | Out-Null
                }
                catch {
                    Write-Log -Level DEBUG -Message "  Could not remove role $($r.type): $_"
                }
            }
        }
    }
    catch {}

    # Step 2: Deactivate (if not already DEPROVISIONED)
    if ($status -ne 'DEPROVISIONED') {
        try {
            Invoke-OktaApi -Path "/api/v1/users/$userId/lifecycle/deactivate" -Method POST | Out-Null
            Write-Log -Level INFO -Message "  Deactivated user: $userLogin"
        }
        catch {
            Write-Log -Level DEBUG -Message "  Deactivation error: $_"
        }
    }

    # Step 3: Delete (permanently remove)
    Invoke-OktaApi -Path "/api/v1/users/$userId" -Method DELETE | Out-Null
    Write-Log -Level OK -Message "Deleted user: $userLogin ($userId)" `
        -Action 'DeleteUser' -Fields @{ Username = $userLogin; UserId = $userId }
}

#endregion

#region Main Workflows

function Invoke-Deploy {
    Write-Log -Level STEP -Message "=== DEPLOY: Okta HLA 3-Tier Infrastructure ===" -Action 'DeployStart'

    # --- Pre-Deploy Snapshot: Capture ALL current state before any modifications ---
    Write-Log -Level STEP -Message "--- Pre-Deploy: Capturing comprehensive state snapshot ---"
    $preDeployFile = $null
    try {
        $preDeployFile = Save-PreDeploySnapshot
    }
    catch {
        Write-Log -Level WARN -Message "Pre-deploy snapshot failed: $_. Deploy will continue without snapshot."
    }

    # --- Pre-flight: Validate session duration compliance (NIST SP 800-53 AC-12) ---
    Write-Log -Level INFO -Message "Validating session duration compliance..."
    $nistAccept = [switch]$AcceptDefaults
    Assert-ReauthCompliance -TierLabel 'Tier 1 (SuperAdmin)' -Duration $Tier1ReauthDuration `
        -RecommendedMaxSeconds 3600  -AcceptDefaults:$nistAccept   # 3600s = PT1H
    Assert-ReauthCompliance -TierLabel 'Tier 2 (OrgAdmin)'   -Duration $Tier2ReauthDuration `
        -RecommendedMaxSeconds 7200  -AcceptDefaults:$nistAccept   # 7200s = PT2H
    Assert-ReauthCompliance -TierLabel 'Tier 3 (Users)'       -Duration $Tier3ReauthDuration `
        -RecommendedMaxSeconds 7200  -AcceptDefaults:$nistAccept   # 7200s = PT2H

    $domain = $OktaDomain
    $createdUsers  = @{}    # login -> user object
    $createdGroups = @{}    # name -> group object
    $stepErrors    = 0      # running count of validation failures

    # --- Step 1: Create User Accounts ---
    Write-Log -Level STEP -Message "--- Step 1: Create User Accounts ($($Script:USER_DEFS.Count) accounts) ---"
    foreach ($def in $Script:USER_DEFS) {
        $login = "$($Script:ACCOUNT_FILTER)$($def.Code.ToLower())@$domain"
        $pw = New-SecurePassword -Length 20
        $user = New-OktaUser -Login $login -FirstName $def.First -LastName $def.Last -Password $pw
        $createdUsers[$login] = $user

        if (-not $Script:IsDryRun -and $user.id -notlike 'WHATIF-*') {
            Write-Log -Level DEBUG -Message "  Password for $login stored in memory (will NOT be logged)"
        }

        # Validate user was created
        if (-not (Confirm-StepResult -StepName "Create user $($def.Code)" -ResourceType 'User' `
                -ResourceId $user.id -ValidationPath "/api/v1/users/$($user.id)")) {
            $stepErrors++
        }
    }
    Write-Log -Level INFO -Message "Step 1 complete: $($createdUsers.Count) user(s) processed ($stepErrors error(s))" `
        -Action 'StepComplete' -Fields @{ Step = 1; Count = $createdUsers.Count; Errors = $stepErrors }

    # --- Step 2: Assign Admin Roles ---
    Write-Log -Level STEP -Message "--- Step 2: Assign Admin Roles ---"
    $roleCount = 0
    foreach ($def in $Script:USER_DEFS) {
        if (-not $def.Role) { continue }   # CPM service account gets custom role later
        $login = "$($Script:ACCOUNT_FILTER)$($def.Code.ToLower())@$domain"
        $user  = $createdUsers[$login]

        # Handle HLA primary role override (only for first Super Admin)
        $roleType = $def.Role
        if ($def.Code -match '^S\d+$' -and $def.Code -eq ($Script:USER_DEFS | Where-Object { $_.Code -match '^S\d+$' } | Select-Object -First 1).Code) {
            if ($HlaPrimaryRole -ne 'SUPER_ADMIN') {
                Write-Log -Level WARN -Message "HlaPrimaryRole is $HlaPrimaryRole -- $($def.Code) will get $HlaPrimaryRole instead of SUPER_ADMIN"
                $roleType = $HlaPrimaryRole
            }
        }

        Set-OktaAdminRole -UserId $user.id -UserLogin $login -RoleType $roleType
        $roleCount++
    }
    Write-Log -Level INFO -Message "Step 2 complete: $roleCount role assignment(s) processed" `
        -Action 'StepComplete' -Fields @{ Step = 2; Count = $roleCount }

    # --- Step 3: Create Groups ---
    # Determine which groups are actually needed based on selected account types
    $neededGroups = [System.Collections.Generic.HashSet[string]]::new()
    # Always need umbrella group if any tiered accounts exist
    $hasTieredAccounts = ($Script:USER_DEFS | Where-Object { $_.Tier -in @(1,2,3) }).Count -gt 0
    foreach ($def in $Script:USER_DEFS) {
        if ($def.Group) { $null = $neededGroups.Add($def.Group) }
    }
    if ($hasTieredAccounts) { $null = $neededGroups.Add('CyberArk-Vaulted-Admins') }

    Write-Log -Level STEP -Message "--- Step 3: Create Groups ($($neededGroups.Count) groups) ---"
    $groupDescriptions = @{
        'CyberArk-HLA-SuperAdmin' = 'Tier 1: Super Admin HLA account(s). CyberArk safe: Okta-HLA-SuperAdmin.'
        'CyberArk-HLA-OrgAdmin'   = 'Tier 2: Org Admin HLA account(s). CyberArk safe: Okta-HLA-OrgAdmin.'
        'CyberArk-HLA-Users'      = 'Tier 3: Help desk / app admin accounts. CyberArk safe: Okta-HLA-Users.'
        'CyberArk-Vaulted-Admins' = 'Umbrella group: ALL CyberArk-vaulted admin accounts (Tier 1+2+3).'
        'Break-Glass-Admins'      = 'Emergency break-glass accounts. Any authentication triggers SOC alert.'
    }
    foreach ($gName in $Script:GROUP_NAMES) {
        if ($gName -notin $neededGroups) {
            Write-Log -Level SKIP -Message "Group '$gName' not needed (no matching accounts)"
            continue
        }
        $desc = $groupDescriptions[$gName]
        $group = New-OktaGroup -Name $gName -Description $desc
        $createdGroups[$gName] = $group

        # Validate group was created
        if ($group -and $group.id -notlike 'WHATIF-*') {
            Confirm-StepResult -StepName "Create group $gName" -ResourceType 'Group' `
                -ResourceId $group.id -ValidationPath "/api/v1/groups/$($group.id)" | Out-Null
        }
    }
    Write-Log -Level INFO -Message "Step 3 complete: $($createdGroups.Count) group(s) created" `
        -Action 'StepComplete' -Fields @{ Step = 3; Count = $createdGroups.Count }

    # --- Step 4: Add Users to Groups ---
    Write-Log -Level STEP -Message "--- Step 4: Add Users to Groups ---"
    $membershipCount = 0
    foreach ($def in $Script:USER_DEFS) {
        $login = "$($Script:ACCOUNT_FILTER)$($def.Code.ToLower())@$domain"
        $user  = $createdUsers[$login]

        # Primary tier group
        if ($def.Group -and $createdGroups.ContainsKey($def.Group)) {
            $group = $createdGroups[$def.Group]
            if ($group) {
                Add-OktaUserToGroup -GroupId $group.id -UserId $user.id -GroupName $def.Group -UserLogin $login
                $membershipCount++
            }
        }

        # Umbrella group (all tier 1-3 accounts, not BG/RO/CPM)
        if ($def.Tier -in @(1, 2, 3) -and $createdGroups.ContainsKey('CyberArk-Vaulted-Admins')) {
            $umbrellaGroup = $createdGroups['CyberArk-Vaulted-Admins']
            if ($umbrellaGroup) {
                Add-OktaUserToGroup -GroupId $umbrellaGroup.id -UserId $user.id `
                    -GroupName 'CyberArk-Vaulted-Admins' -UserLogin $login
                $membershipCount++
            }
        }
    }
    Write-Log -Level INFO -Message "Step 4 complete: $membershipCount group membership(s) processed" `
        -Action 'StepComplete' -Fields @{ Step = 4; Count = $membershipCount }

    # --- Step 5: Create Network Zone ---
    Write-Log -Level STEP -Message "--- Step 5: Create Network Zone ---"

    # Prompt for CIDRs interactively
    $gatewayIPs = @('10.0.0.0/8')
    if (-not $AcceptDefaults -and -not $Script:IsDryRun) {
        Write-Host ""
        Write-Host "  Enter gateway/egress IP CIDRs for the CyberArk-Infrastructure network zone." -ForegroundColor DarkGray
        Write-Host "  These should be the CyberArk CPM, PSM, and admin VPN egress IPs." -ForegroundColor DarkGray
        Write-Host "  Enter one CIDR per line. Press Enter on a blank line when done." -ForegroundColor DarkGray
        Write-Host "  Leave blank to use placeholder (10.0.0.0/8) and update later." -ForegroundColor DarkGray
        Write-Host ""

        $customIPs = [System.Collections.Generic.List[string]]::new()
        $ipIdx = 1
        do {
            $ip = Read-Host "  Gateway IP $ipIdx (CIDR, e.g. 10.1.2.3/32)"
            if ([string]::IsNullOrWhiteSpace($ip)) { break }
            # Basic CIDR validation
            if ($ip -match '^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/\d{1,2}$') {
                $customIPs.Add($ip.Trim())
                $ipIdx++
            }
            else {
                Write-Host "  Invalid CIDR format. Expected: x.x.x.x/xx" -ForegroundColor Yellow
            }
        } while ($true)

        if ($customIPs.Count -gt 0) {
            $gatewayIPs = $customIPs.ToArray()
            Write-Log -Level INFO -Message "Using $($gatewayIPs.Count) custom gateway IP(s): $($gatewayIPs -join ', ')"
        }
        else {
            Write-Log -Level WARN -Message "Using placeholder IPs (10.0.0.0/8). Update with real CIDRs after deploy."
        }
    }
    else {
        Write-Log -Level WARN -Message "Network zone uses placeholder IPs (10.0.0.0/8). Update with real CIDRs after deploy."
    }

    $zone = New-OktaNetworkZone -GatewayIPs $gatewayIPs
    if ($zone -and $zone.id -notlike 'WHATIF-*') {
        Confirm-StepResult -StepName "Create network zone" -ResourceType 'Zone' `
            -ResourceId $zone.id -ValidationPath "/api/v1/zones/$($zone.id)" | Out-Null
    }
    Write-Log -Level INFO -Message "Step 5 complete: network zone created" `
        -Action 'StepComplete' -Fields @{ Step = 5; ZoneId = $(if ($zone) { $zone.id } else { 'N/A' }) }

    # --- Step 5.5: TOTP Authenticator & Enrollment Policy ---
    # Requires HLA groups to exist (Step 3) and uses group IDs from $createdGroups.
    # Must run BEFORE CPM enrollment steps so the policy is in place when enroll-totp is called.
    $t1g55 = if ($createdGroups.ContainsKey('CyberArk-HLA-SuperAdmin') -and $createdGroups['CyberArk-HLA-SuperAdmin'].id -notlike 'WHATIF-*') { $createdGroups['CyberArk-HLA-SuperAdmin'].id } else { 'PLACEHOLDER-T1' }
    $t2g55 = if ($createdGroups.ContainsKey('CyberArk-HLA-OrgAdmin')   -and $createdGroups['CyberArk-HLA-OrgAdmin'].id   -notlike 'WHATIF-*') { $createdGroups['CyberArk-HLA-OrgAdmin'].id   } else { 'PLACEHOLDER-T2' }
    $t3g55 = if ($createdGroups.ContainsKey('CyberArk-HLA-Users')      -and $createdGroups['CyberArk-HLA-Users'].id      -notlike 'WHATIF-*') { $createdGroups['CyberArk-HLA-Users'].id      } else { 'PLACEHOLDER-T3' }

    # Build a filtered hashtable of HLA tier 1-3 accounts for the factor audit
    $hlaUsersForAudit = @{}
    foreach ($def in $Script:USER_DEFS) {
        if ($def.Tier -in @(1, 2, 3)) {
            $auditLogin = "$($Script:ACCOUNT_FILTER)$($def.Code.ToLower())@$domain"
            if ($createdUsers.ContainsKey($auditLogin)) {
                $hlaUsersForAudit[$auditLogin] = $createdUsers[$auditLogin]
            }
        }
    }

    try {
        Invoke-Step55 -T1GroupId $t1g55 -T2GroupId $t2g55 -T3GroupId $t3g55 -HlaUsers $hlaUsersForAudit -TOTPProvider $TOTPProvider
    }
    catch {
        Write-Log -Level WARN -Message "Step 5.5 encountered an error: $_"
        Write-Log -Level WARN -Message "Continuing with remaining deploy steps -- review TOTP policy manually."
        $Script:Step55Status = @{
            AuthenticatorStatus = 'ERROR'; PolicyStatus = 'ERROR'; BlockedProviderStatus = 'UNKNOWN'
            DefaultPolicyStatus = 'UNKNOWN'; FactorAuditStatus = 'SKIPPED'; OverallOK = $false
        }
    }

    # --- Step 7: Create Custom Admin Role ---
    Write-Log -Level STEP -Message "--- Step 7: Create Custom Admin Role ---"
    $customRole = $null
    try {
        $customRole = New-OktaCustomRole
        if ($customRole -and $customRole.id -notlike 'WHATIF-*') {
            Confirm-StepResult -StepName "Create custom role" -ResourceType 'Role' `
                -ResourceId $customRole.id -ValidationPath "/api/v1/iam/roles/$($customRole.id)" | Out-Null
        }
    }
    catch {
        # Custom role creation requires Okta IAM licensing. Integrator/developer tenants
        # may return HTTP 400 if the feature is not available. Steps 8/9 (resource set
        # and role binding) will be skipped automatically since $customRole is null.
        Write-Log -Level WARN -Message "Step 7 skipped: custom role creation failed -- IAM licensing may not be available on this tenant."
        Write-Log -Level WARN -Message "  Error: $_"
        Write-Log -Level WARN -Message "  Steps 8 and 9 (resource set / role binding) will also be skipped."
        Write-Log -Level WARN -Message "  In production, ensure Okta Custom Admin Roles are licensed before running Deploy."
    }

    # --- Step 8: Create Resource Set ---
    Write-Log -Level STEP -Message "--- Step 8: Create Resource Set ---"
    $umbrellaGroup = $createdGroups['CyberArk-Vaulted-Admins']
    $resourceSet = $null
    if ($umbrellaGroup) {
        $resourceSet = New-OktaResourceSet -UmbrellaGroupId $umbrellaGroup.id
        if ($resourceSet -and $resourceSet.id -notlike 'WHATIF-*') {
            Confirm-StepResult -StepName "Create resource set" -ResourceType 'ResourceSet' `
                -ResourceId $resourceSet.id -ValidationPath "/api/v1/iam/resource-sets/$($resourceSet.id)" | Out-Null
        }
    }
    else {
        Write-Log -Level WARN -Message "No umbrella group created (no tiered accounts) -- skipping resource set"
    }

    # --- Step 9: Bind Custom Role to CPM Service Account ---
    Write-Log -Level STEP -Message "--- Step 9: Bind Custom Role to CPM Service Account ---"
    # Find the CPM user (may be CPM01, CPM02, etc.)
    $cpmDef = $Script:USER_DEFS | Where-Object { $_.Code -match '^CPM\d+$' } | Select-Object -First 1
    if ($cpmDef -and $customRole -and $resourceSet) {
        $cpmLogin = "$($Script:ACCOUNT_FILTER)$($cpmDef.Code.ToLower())@$domain"
        $cpmUser  = $createdUsers[$cpmLogin]
        if ($cpmUser) {
            New-OktaRoleBinding -ResourceSetId $resourceSet.id -RoleId $customRole.id -CpmUserId $cpmUser.id
        }
        else {
            Write-Log -Level WARN -Message "CPM user $cpmLogin not found in created users -- skipping role binding"
        }
    }
    else {
        Write-Log -Level WARN -Message "CPM service account, custom role, or resource set not available -- skipping role binding"
    }

    # --- Step 10: Create Sign-On Policies ---
    # Only create policies for groups that were actually created
    $bgGroup   = if ($createdGroups.ContainsKey('Break-Glass-Admins'))      { $createdGroups['Break-Glass-Admins'] }      else { $null }
    $t1Group   = if ($createdGroups.ContainsKey('CyberArk-HLA-SuperAdmin')) { $createdGroups['CyberArk-HLA-SuperAdmin'] } else { $null }
    $t2Group   = if ($createdGroups.ContainsKey('CyberArk-HLA-OrgAdmin'))   { $createdGroups['CyberArk-HLA-OrgAdmin'] }   else { $null }
    $t3Group   = if ($createdGroups.ContainsKey('CyberArk-HLA-Users'))      { $createdGroups['CyberArk-HLA-Users'] }      else { $null }

    $policyCount = @($bgGroup, $t1Group, $t2Group, $t3Group | Where-Object { $_ }).Count
    Write-Log -Level STEP -Message "--- Step 10: Create Sign-On Policies ($policyCount policies) ---"

    $zoneId = if ($zone -and $zone.id -notlike 'WHATIF-*') { $zone.id } else { 'PLACEHOLDER_ZONE_ID' }

    # Policy 1: Break-Glass (Priority 1)
    if ($bgGroup) {
        New-OktaSignOnPolicy -Name $Script:POLICY_NAMES[0] `
            -Description 'Emergency access policy. Any login triggers SOC alert.' `
            -GroupId $bgGroup.id -Priority 1 -Rules @(
                @{
                    name       = 'Emergency Access - Anywhere with MFA'
                    status     = 'ACTIVE'
                    conditions = @{ network = @{ connection = 'ANYWHERE' } }
                    actions    = @{
                        signon = @{
                            access                 = 'ALLOW'
                            requireFactor          = $true
                            factorPromptMode       = 'ALWAYS'
                            rememberDeviceByDefault = $false
                            session                = @{
                                usePersistentCookie = $false
                                maxSessionIdleMinutes    = 30
                                maxSessionLifetimeMinutes = 60
                            }
                        }
                    }
                }
            )
    }

    # Policy 2: Tier 1 Super Admin (Priority 2)
    if ($t1Group) {
        New-OktaSignOnPolicy -Name $Script:POLICY_NAMES[1] `
            -Description 'Most restrictive: CyberArk-managed Super Admin access.' `
            -GroupId $t1Group.id -Priority 2 -Rules @(
                @{
                    name       = 'Allow Corporate Network - Always MFA'
                    status     = 'ACTIVE'
                    conditions = @{ network = @{ connection = 'ZONE'; include = @($zoneId) } }
                    actions    = @{
                        signon = @{
                            access                 = 'ALLOW'
                            requireFactor          = $true
                            factorPromptMode       = 'ALWAYS'
                            rememberDeviceByDefault = $false
                            session                = @{
                                usePersistentCookie = $false
                                maxSessionIdleMinutes     = $Tier1IdleMinutes
                                maxSessionLifetimeMinutes = $Tier1LifetimeMinutes
                            }
                        }
                    }
                },
                @{
                    name       = 'Deny Non-Corporate Access'
                    status     = 'ACTIVE'
                    conditions = @{ network = @{ connection = 'ZONE'; exclude = @($zoneId) } }
                    actions    = @{ signon = @{ access = 'DENY' } }
                }
            )
    }

    # Policy 3: Tier 2 Org Admin (Priority 3)
    if ($t2Group) {
        New-OktaSignOnPolicy -Name $Script:POLICY_NAMES[2] `
            -Description 'Standard HLA: CyberArk-managed Org Admin access.' `
            -GroupId $t2Group.id -Priority 3 -Rules @(
                @{
                    name       = 'Allow Corporate Network - Always MFA'
                    status     = 'ACTIVE'
                    conditions = @{ network = @{ connection = 'ZONE'; include = @($zoneId) } }
                    actions    = @{
                        signon = @{
                            access                 = 'ALLOW'
                            requireFactor          = $true
                            factorPromptMode       = 'ALWAYS'
                            rememberDeviceByDefault = $false
                            session                = @{
                                usePersistentCookie = $false
                                maxSessionIdleMinutes     = $Tier2IdleMinutes
                                maxSessionLifetimeMinutes = $Tier2LifetimeMinutes
                            }
                        }
                    }
                },
                @{
                    name       = 'Deny Non-Corporate Access'
                    status     = 'ACTIVE'
                    conditions = @{ network = @{ connection = 'ZONE'; exclude = @($zoneId) } }
                    actions    = @{ signon = @{ access = 'DENY' } }
                }
            )
    }

    # Policy 4: Tier 3 Operational Users (Priority 4)
    if ($t3Group) {
        New-OktaSignOnPolicy -Name $Script:POLICY_NAMES[3] `
            -Description 'Standard HLA: CyberArk-managed help desk and app admin access.' `
            -GroupId $t3Group.id -Priority 4 -Rules @(
                @{
                    name       = 'Allow Corporate Network - Always MFA'
                    status     = 'ACTIVE'
                    conditions = @{ network = @{ connection = 'ZONE'; include = @($zoneId) } }
                    actions    = @{
                        signon = @{
                            access                 = 'ALLOW'
                            requireFactor          = $true
                            factorPromptMode       = 'ALWAYS'
                            rememberDeviceByDefault = $false
                            session                = @{
                                usePersistentCookie = $false
                                maxSessionIdleMinutes     = $Tier3IdleMinutes
                                maxSessionLifetimeMinutes = $Tier3LifetimeMinutes
                            }
                        }
                    }
                },
                @{
                    name       = 'Deny Non-Corporate Access'
                    status     = 'ACTIVE'
                    conditions = @{ network = @{ connection = 'ZONE'; exclude = @($zoneId) } }
                    actions    = @{ signon = @{ access = 'DENY' } }
                }
            )
    }

    # --- Step 11: Admin Console ACCESS_POLICY per-tier session rules ---
    # This is separate from the Global Session Policy (Step 10).
    # It controls app-level re-auth trust duration for the Admin Console ONLY.
    # See parameter help and .NOTES for full explanation.
    $tierRuleConfigs = @(
        @{
            GroupName      = 'CyberArk-HLA-SuperAdmin'
            GroupId        = if ($t1Group -and $t1Group.id -notlike 'WHATIF-*') { $t1Group.id } else { $null }
            RuleName       = 'Tier 1: SuperAdmin HLA - PSM Session'
            ReauthDuration = $Tier1ReauthDuration
            Priority       = 1
        },
        @{
            GroupName      = 'CyberArk-HLA-OrgAdmin'
            GroupId        = if ($t2Group -and $t2Group.id -notlike 'WHATIF-*') { $t2Group.id } else { $null }
            RuleName       = 'Tier 2: OrgAdmin HLA - PSM Session'
            ReauthDuration = $Tier2ReauthDuration
            Priority       = 2
        },
        @{
            GroupName      = 'CyberArk-HLA-Users'
            GroupId        = if ($t3Group -and $t3Group.id -notlike 'WHATIF-*') { $t3Group.id } else { $null }
            RuleName       = 'Tier 3: Operational HLA - PSM Session'
            ReauthDuration = $Tier3ReauthDuration
            Priority       = 3
        }
    )

    # Filter to tiers where we have a real group ID
    $activeTierConfigs = @($tierRuleConfigs | Where-Object { $_.GroupId })
    if ($activeTierConfigs.Count -gt 0) {
        Set-AdminConsoleTierRules -TierConfigs $activeTierConfigs
    }
    else {
        Write-Log -Level WARN -Message "No HLA groups available for Step 11 -- skipping Admin Console policy rules."
    }

    # --- Output Resource IDs ---
    Write-Host ""
    Write-Host "  =============================================" -ForegroundColor White
    Write-Host "  RESOURCE IDS (for cpm-config.yaml)" -ForegroundColor White
    Write-Host "  =============================================" -ForegroundColor White
    Write-Host ""
    foreach ($login in ($createdUsers.Keys | Sort-Object)) {
        $u = $createdUsers[$login]
        $code = ($login -replace "^$([regex]::Escape($Script:ACCOUNT_FILTER))" -replace "@.*$")
        Write-Log -Level INFO -Message "  ${code}_id: $($u.id)"
    }
    foreach ($gn in ($createdGroups.Keys | Sort-Object)) {
        $g = $createdGroups[$gn]
        $shortName = $gn.ToLower() -replace '[^a-z0-9]', '_'
        Write-Log -Level INFO -Message "  ${shortName}_id: $($g.id)"
    }
    if ($zone) { Write-Log -Level INFO -Message "  trusted_network_zone_id: $($zone.id)" }
    if ($customRole) { Write-Log -Level INFO -Message "  custom_role_id: $($customRole.id)" }
    if ($resourceSet) { Write-Log -Level INFO -Message "  resource_set_id: $($resourceSet.id)" }

    # --- Final Validation Summary ---
    Write-Host ""
    Write-Host "  =============================================" -ForegroundColor White
    Write-Host "  DEPLOY SUMMARY" -ForegroundColor White
    Write-Host "  =============================================" -ForegroundColor White
    Write-Host ""
    Write-Log -Level INFO -Message "  Users created:          $($createdUsers.Count)"
    Write-Log -Level INFO -Message "  Groups created:         $($createdGroups.Count)"
    Write-Log -Level INFO -Message "  Group memberships set:  $membershipCount"
    Write-Log -Level INFO -Message "  Network zone:           $(if ($zone) { $zone.id } else { 'N/A' })"
    Write-Log -Level INFO -Message "  Custom admin role:      $(if ($customRole) { $customRole.id } else { 'N/A' })"
    Write-Log -Level INFO -Message "  Resource set:           $(if ($resourceSet) { $resourceSet.id } else { 'N/A' })"
    Write-Log -Level INFO -Message "  Sign-on policies:       $policyCount"

    # Step 5.5 summary
    if ($Script:Step55Status) {
        $s55 = $Script:Step55Status
        $authColor = if ($s55.AuthenticatorStatus -eq 'ALREADY_ACTIVE') { 'Green' } `
                     elseif ($s55.AuthenticatorStatus -eq 'ACTIVATED_THIS_RUN') { 'Yellow' } else { 'Red' }
        $polColor  = if ($s55.PolicyStatus -in @('CREATED','VERIFIED')) { 'Green' } else { 'Yellow' }
        $defColor  = if ($s55.DefaultPolicyStatus -eq 'SECURE')       { 'Green' } `
                     elseif ($s55.DefaultPolicyStatus -eq 'REMEDIATED') { 'Green' } `
                     elseif ($s55.DefaultPolicyStatus -like 'N/A*')     { 'DarkGray' } `
                     elseif ($s55.DefaultPolicyStatus -eq 'RISK_UNRESOLVED') { 'Red' } else { 'Yellow' }
        $audColor  = if ($s55.FactorAuditStatus -eq 'OK' -or $s55.FactorAuditStatus -like '*INFO*') { 'Green' } `
                     elseif ($s55.FactorAuditStatus -like '*WARNING*') { 'Yellow' } else { 'DarkGray' }

        $blkColor  = if ($s55.BlockedProviderStatus -eq 'NOT_ALLOWED') { 'Green' } `
                     elseif ($s55.BlockedProviderStatus -eq 'N/A') { 'DarkGray' } else { 'Red' }

        Write-Host "  Step 5.5 TOTP Policy (provider: $Script:SELECTED_TOTP_KEY):" -ForegroundColor White
        Write-Host ("    $Script:SELECTED_TOTP_KEY authenticator:  {0}" -f $s55.AuthenticatorStatus) -ForegroundColor $authColor
        Write-Host ("    HLA enrollment policy:     {0}" -f $s55.PolicyStatus)        -ForegroundColor $polColor
        Write-Host ("    $Script:BLOCKED_TOTP_KEY (HLA policy):  {0}" -f $s55.BlockedProviderStatus) -ForegroundColor $blkColor
        Write-Host ("    Default policy:            {0}" -f $s55.DefaultPolicyStatus) -ForegroundColor $defColor
        Write-Host ("    Factor audit:              {0}" -f $s55.FactorAuditStatus)   -ForegroundColor $audColor

        if ($s55.DefaultPolicyStatus -eq 'RISK_UNRESOLVED') {
            Write-Host "    [!] Default policy still allows regular users to enroll TOTP." -ForegroundColor Red
            Write-Host "        Resolve via -Action Inspect > Security Warning section." -ForegroundColor Red
        }
        if ($s55.FactorAuditStatus -like '*WARNING*') {
            Write-Host "    [!] Some HLA accounts have non-TOTP factors enrolled." -ForegroundColor Yellow
            Write-Host "        Run: cpm-simulator enroll-totp <account> to remediate." -ForegroundColor Yellow
        }
        Write-Host "    Rollback: -Action Rollback (Step5.5 snapshots available in Rollbacks\)" -ForegroundColor DarkGray
        Write-Host ""
    }

    if ($stepErrors -gt 0) {
        Write-Log -Level WARN -Message "  Validation errors:      $stepErrors (review log for details)"
    }
    else {
        Write-Log -Level OK -Message "  Validation errors:      0"
    }

    Write-Log -Level STEP -Message "=== DEPLOY COMPLETE ===" -Action 'DeployComplete' `
        -Fields @{ Users = $createdUsers.Count; Groups = $createdGroups.Count; Policies = $policyCount; Errors = $stepErrors }

    # --- Next Steps ---
    Write-Host ""
    Write-Host "  NEXT STEPS:" -ForegroundColor Yellow
    $cpmDef2 = $Script:USER_DEFS | Where-Object { $_.Code -match '^CPM\d+$' } | Select-Object -First 1
    if ($cpmDef2) {
        $cpmLogin2 = "$($Script:ACCOUNT_FILTER)$($cpmDef2.Code.ToLower())@$domain"
        Write-Log -Level WARN -Message "  1. Create SSWS token by logging into Okta as: $cpmLogin2"
    }
    if ($gatewayIPs -contains '10.0.0.0/8') {
        Write-Log -Level WARN -Message "  2. Update network zone CIDRs with real enterprise egress IPs"
    }
    Write-Log -Level WARN -Message "  3. Run Invoke-OktaHLAVaultSetup.ps1 for CyberArk-side onboarding"
}

function Invoke-Teardown {
    Write-Log -Level STEP -Message "=== TEARDOWN: Discovering Okta HLA Resources ===" -Action 'TeardownStart'

    # Phase 1: Discover all resources
    $policies    = Find-OktaPolicies
    $tokens      = Find-OktaTokens
    $zone        = Find-OktaNetworkZone
    $groups      = Find-OktaGroups
    $users       = Find-OktaUsers
    $customRole  = Find-OktaCustomRole
    $resourceSet = Find-OktaResourceSet

    # Find CPM user for role binding discovery
    $cpmUser = $users | Where-Object { $_.profile.login -like '*cpm*' } | Select-Object -First 1
    $bindings = @()
    if ($cpmUser) {
        $bindings = Find-OktaRoleBindings -CpmUserId $cpmUser.id
    }

    # Phase 2: Display summary
    Write-Host ""
    Write-Host "  =============================================" -ForegroundColor White
    Write-Host "  DISCOVERED RESOURCES" -ForegroundColor White
    Write-Host "  =============================================" -ForegroundColor White
    Write-Host ""

    $categories = [ordered]@{}
    $catIndex = 0

    if ($policies.Count -gt 0) {
        $catIndex++
        $desc = "Sign-On Policies ($($policies.Count)): $(($policies | ForEach-Object { $_.name }) -join ', ')"
        $categories["policies"] = @{ Index = $catIndex; Label = $desc; Items = $policies }
    }
    if ($tokens.Count -gt 0) {
        $catIndex++
        $desc = "SSWS API Tokens ($(@($tokens).Count)): $((@($tokens) | ForEach-Object { $_.name }) -join ', ')"
        $categories["tokens"] = @{ Index = $catIndex; Label = $desc; Items = $tokens }
    }
    if ($bindings.Count -gt 0) {
        $catIndex++
        $desc = "Role Bindings ($($bindings.Count)) on CPM user $($cpmUser.profile.login)"
        $categories["bindings"] = @{ Index = $catIndex; Label = $desc; Items = $bindings; CpmUserId = $cpmUser.id }
    }
    if ($resourceSet) {
        $catIndex++
        $desc = "Resource Set: $($resourceSet.label)"
        $categories["resourceset"] = @{ Index = $catIndex; Label = $desc; Items = @($resourceSet) }
    }
    if ($customRole) {
        $catIndex++
        $desc = "Custom Admin Role: $($customRole.label)"
        $categories["role"] = @{ Index = $catIndex; Label = $desc; Items = @($customRole) }
    }
    if ($zone) {
        $catIndex++
        $desc = "Network Zone: $($zone.name)"
        $categories["zone"] = @{ Index = $catIndex; Label = $desc; Items = @($zone) }
    }
    if ($groups.Count -gt 0) {
        $catIndex++
        $desc = "Groups ($($groups.Count)): $(($groups | ForEach-Object { $_.profile.name }) -join ', ')"
        $categories["groups"] = @{ Index = $catIndex; Label = $desc; Items = $groups }
    }
    if ($users.Count -gt 0) {
        $catIndex++
        $desc = "User Accounts ($($users.Count)): $(($users | ForEach-Object { $_.profile.login }) -join ', ')"
        $categories["users"] = @{ Index = $catIndex; Label = $desc; Items = $users }
    }

    if ($categories.Count -eq 0) {
        Write-Log -Level INFO -Message "No HLA resources found in this Okta tenant. Nothing to tear down."
        return
    }

    $labels = @($categories.Values | ForEach-Object { $_.Label })
    $selected = Show-SelectionMenu -Items $labels -Title 'Select resource categories to TEAR DOWN (dependency-safe order)' -AllByDefault

    if ($selected.Count -eq 0) {
        Write-Log -Level INFO -Message "No categories selected. Teardown cancelled."
        return
    }

    # Confirmation gate
    $selectedLabels = $selected | ForEach-Object { "  - $($labels[$_])" }
    Write-Host ""
    Write-Host "  The following will be PERMANENTLY DELETED:" -ForegroundColor Red
    $selectedLabels | ForEach-Object { Write-Host $_ -ForegroundColor Yellow }
    Write-Host ""

    if (-not (Confirm-UserChoice -Prompt "  Proceed with teardown?" -Default 'N')) {
        Write-Log -Level INFO -Message "Teardown cancelled by user."
        return
    }

    # Phase 3: Execute teardown in dependency-safe order
    # Order: policies -> tokens -> bindings -> resource set -> role -> zone -> groups -> users
    $catKeys = @($categories.Keys)

    foreach ($idx in $selected) {
        $key = $catKeys[$idx]
        $cat = $categories[$key]

        switch ($key) {
            'policies' {
                Write-Log -Level STEP -Message "--- Removing Sign-On Policies ---"
                foreach ($p in $cat.Items) { Remove-OktaPolicy -Policy $p }
            }
            'tokens' {
                Write-Log -Level STEP -Message "--- Revoking SSWS Tokens ---"
                foreach ($t in @($cat.Items)) { Remove-OktaToken -Token $t }
            }
            'bindings' {
                Write-Log -Level STEP -Message "--- Removing Role Bindings ---"
                foreach ($b in $cat.Items) {
                    Remove-OktaRoleBinding -UserId $cat.CpmUserId -Binding $b
                }
            }
            'resourceset' {
                Write-Log -Level STEP -Message "--- Removing Resource Set ---"
                Remove-OktaResourceSet -ResourceSet $cat.Items[0]
            }
            'role' {
                Write-Log -Level STEP -Message "--- Removing Custom Admin Role ---"
                Remove-OktaCustomRole -Role $cat.Items[0]
            }
            'zone' {
                Write-Log -Level STEP -Message "--- Removing Network Zone ---"
                Remove-OktaNetworkZone -Zone $cat.Items[0]
            }
            'groups' {
                Write-Log -Level STEP -Message "--- Removing Groups ---"
                foreach ($g in $cat.Items) { Remove-OktaGroup -Group $g }
            }
            'users' {
                Write-Log -Level STEP -Message "--- Removing User Accounts ---"
                foreach ($u in $cat.Items) { Remove-OktaUser -User $u }
            }
        }
    }

    Write-Log -Level STEP -Message "=== TEARDOWN COMPLETE ===" -Action 'TeardownComplete'
}

#endregion

#region Main

function Main {
    Write-Host ""
    Write-Host "  ================================================================" -ForegroundColor White
    Write-Host "  Deploy-OktaHLABootstrap v$Script:VERSION" -ForegroundColor White
    Write-Host "  CR: CHG00XXXXX -- Okta HLA 3-Tier Privileged Account Architecture" -ForegroundColor DarkGray
    Write-Host "  Correlation ID: $Script:CorrelationId" -ForegroundColor DarkGray
    Write-Host "  ================================================================" -ForegroundColor White
    Write-Host ""

    # IsDryRun and Force are resolved at script scope (before Main is called)
    if ($Script:IsDryRun) {
        Write-Host "  *** DRY-RUN MODE: No changes will be made ***" -ForegroundColor Yellow
        Write-Host ""
    }
    if ($Script:Force) {
        Write-Host "  *** FORCE MODE: Tenant-wide Step 5.5 prompts will be auto-accepted ***" -ForegroundColor Yellow
        Write-Host ""
    }

    # Initialize SIEM logging
    Initialize-SIEMLogging -LogDir $SIEMLogPath
    Write-SIEMLog -Level 'INFO' -Message "Script started: Action=$Action" -Action 'ScriptStart' `
        -Fields @{ Action = $Action; DryRun = $Script:IsDryRun; Version = $Script:VERSION }

    # Resolve API token
    $token = $ApiToken
    if ([string]::IsNullOrWhiteSpace($token)) {
        $token = $env:OKTA_API_TOKEN
    }
    if ([string]::IsNullOrWhiteSpace($token)) {
        $token = Get-SecureInput -Prompt 'Enter Okta SSWS API token'
    }
    if ([string]::IsNullOrWhiteSpace($token)) {
        throw 'No Okta API token provided. Set -ApiToken, $env:OKTA_API_TOKEN, or enter when prompted.'
    }

    # Resolve domain
    $domain = $OktaDomain
    if ([string]::IsNullOrWhiteSpace($domain)) {
        $domain = $env:OKTA_DOMAIN
    }
    if ([string]::IsNullOrWhiteSpace($domain)) {
        $domain = Read-Host 'Enter Okta domain (e.g. yourorg.okta.com)'
    }
    if ([string]::IsNullOrWhiteSpace($domain)) {
        throw 'No Okta domain provided.'
    }
    # Strip protocol if provided
    $domain = $domain -replace '^https?://' -replace '/$'

    # Initialize session
    Initialize-OktaSession -Token $token -Domain $domain
    Write-Log -Level INFO -Message "Okta session initialized: $domain"

    # Validate connectivity
    Write-Log -Level INFO -Message "Validating Okta API connectivity..."
    try {
        $org = Invoke-OktaApi -Path '/api/v1/org' -Strict
        # .name may be absent on developer/integrator tenants -- use null-safe access
        $orgName    = if ($org.PSObject.Properties['name']     -and $null -ne $org.name)     { $org.name }     else { '(integrator tenant)' }
        $orgSubdomain = if ($org.PSObject.Properties['subdomain'] -and $null -ne $org.subdomain) { $org.subdomain } else { $domain }
        Write-Log -Level OK -Message "Connected to: $orgName ($orgSubdomain)"
    }
    catch {
        throw "Cannot connect to Okta at $domain : $_"
    }

    # Pre-flight: validate API permissions.
    # Inspect is read-only -- skip permission check and dispatch directly.
    if ($Action -eq 'Inspect') {
        Invoke-Inspect
        return
    }

    $effectiveAction = if ($Action -eq 'WhatIf') { 'Deploy' } elseif ($Action -in @('Rollback', 'Restore')) { 'Deploy' } else { $Action }
    if (-not (Test-ApiPermissions -RequiredAction $effectiveAction)) {
        Write-Log -Level ERROR -Message "Pre-flight check failed. Aborting." -Action 'PreFlightAbort'
        return
    }

    # Dispatch
    switch ($Action) {
        'Deploy' {
            # Interactive account configuration
            if (-not (Build-UserDefinitions)) {
                Write-Log -Level INFO -Message "Deploy cancelled during account configuration."
                return
            }
            if ($Script:USER_DEFS.Count -eq 0) {
                Write-Log -Level WARN -Message "No accounts configured. Nothing to deploy."
                return
            }
            Invoke-Deploy
        }
        'WhatIf' {
            # Interactive account configuration (still prompted so you see the plan)
            if (-not (Build-UserDefinitions)) {
                Write-Log -Level INFO -Message "WhatIf cancelled during account configuration."
                return
            }
            if ($Script:USER_DEFS.Count -eq 0) {
                Write-Log -Level WARN -Message "No accounts configured. Nothing to simulate."
                return
            }
            Invoke-Deploy
        }
        'Teardown' {
            Invoke-Teardown
        }
        'Inspect' {
            Invoke-Inspect
        }
        'Rollback' {
            Invoke-Rollback
        }
        'Restore' {
            if (-not $RollbackFile) {
                # Find most recent PreDeploy snapshot (both .enc and .json)
                $preDeployFiles = @(Get-ChildItem -Path $Script:ROLLBACK_DIR -Filter 'Deploy-OktaHLABootstrap-PreDeploy-*' -ErrorAction SilentlyContinue |
                    Where-Object { $_.Extension -in @('.json', '.enc') } |
                    Sort-Object LastWriteTime -Descending)
                if ($preDeployFiles.Count -eq 0) {
                    Write-Log -Level ERROR -Message "No PreDeploy snapshots found in $Script:ROLLBACK_DIR. Run a Deploy first to create one."
                    return
                }
                Write-Host ""
                Write-Host "  Available PreDeploy snapshots:" -ForegroundColor White
                for ($i = 0; $i -lt [Math]::Min($preDeployFiles.Count, 5); $i++) {
                    $f = $preDeployFiles[$i]
                    $tag = if ($i -eq 0) { ' [LATEST]' } else { '' }
                    $encTag = if ($f.Extension -eq '.enc') { ' (encrypted)' } else { '' }
                    Write-Host ("    {0}  {1}{2}{3}" -f ($i + 1), $f.Name, $tag, $encTag) -ForegroundColor DarkGray
                }
                Write-Host ""
                $RollbackFile = $preDeployFiles[0].FullName
                Write-Log -Level INFO -Message "Using latest PreDeploy snapshot: $RollbackFile"
            }
            # Validate snapshot integrity before restore
            $validation = Test-PreDeploySnapshot -SnapshotPath $RollbackFile
            if (-not $validation.Valid) {
                Write-Log -Level ERROR -Message "Snapshot validation failed: $($validation.Reason)"
                Write-Log -Level ERROR -Message "Cannot restore from a corrupted or invalid snapshot."
                return
            }
            $encStatus = if ($validation.Encrypted) { ', decrypted OK' } else { '' }
            Write-Log -Level OK -Message "Snapshot validated (checksum OK, schema v$($validation.Document.schemaVersion)$encStatus)"
            Invoke-RestorePreDeploy -SnapshotPath $RollbackFile
        }
    }

    Write-SIEMLog -Level 'INFO' -Message "Script completed: Action=$Action" -Action 'ScriptComplete' `
        -Fields @{ Action = $Action; DryRun = $Script:IsDryRun }

    if ($Script:SIEMEnabled) {
        Write-Log -Level INFO -Message "SIEM log: $Script:SIEMLogFile"
        Write-Log -Level INFO -Message "Validate with: .\Test-SIEMLog.ps1 -LogFile '$Script:SIEMLogFile'"
    }
}

# Entry point
try {
    Main
}
catch {
    Write-SIEMLog -Level 'ERROR' -Message "FATAL: $_" -Action 'ScriptError'
    Write-Host "`n[FATAL] $_" -ForegroundColor Red
    Write-Host $_.ScriptStackTrace -ForegroundColor DarkGray
    exit 1
}
