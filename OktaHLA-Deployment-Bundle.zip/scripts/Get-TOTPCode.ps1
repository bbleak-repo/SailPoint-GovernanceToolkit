#Requires -Version 5.1
<#
.SYNOPSIS
    Computes a live TOTP code from a Base32-encoded seed.
    Standalone operator utility for tabletop testing, break-glass reconstruction,
    and seed verification.

.DESCRIPTION
    Implements RFC 6238 (TOTP) and RFC 4226 (HOTP) using pure PowerShell and .NET
    cryptography. No external dependencies.

    Use cases:
      - Verify a TOTP seed is correct before committing it to CyberArk
      - Generate a code for tabletop break-glass testing
      - Compute the code for a seed stored in an otpauth:// URI
      - Show countdown to the next TOTP window

.PARAMETER Seed
    Base32-encoded TOTP shared secret. Accepts seeds with or without padding (=).
    If not provided, the script prompts securely.

.PARAMETER TOTPUri
    An otpauth:// URI. Extracts the seed from the URI automatically.
    Example: otpauth://totp/Issuer:user@example.com?secret=JBSWY3DPEHPK3PXP&...

.PARAMETER Digits
    Number of output digits. Default: 6.

.PARAMETER TimeStep
    TOTP time step in seconds. Default: 30.

.PARAMETER Watch
    Continuously display the current code and countdown, refreshing every second.
    Press Ctrl+C to stop.

.PARAMETER ShowURI
    Display the full otpauth:// URI for QR code generation (requires -Issuer and -Account).

.PARAMETER Issuer
    Issuer name for otpauth:// URI generation (used with -ShowURI).

.PARAMETER Account
    Account name for otpauth:// URI generation (used with -ShowURI).

.EXAMPLE
    .\Get-TOTPCode.ps1 -Seed JBSWY3DPEHPK3PXP
    Prints the current 6-digit TOTP code.

.EXAMPLE
    .\Get-TOTPCode.ps1 -Seed JBSWY3DPEHPK3PXP -Watch
    Continuously shows the current code with a live countdown.

.EXAMPLE
    .\Get-TOTPCode.ps1 -TOTPUri "otpauth://totp/Okta:user@corp.okta.com?secret=JBSWY3DPEHPK3PXP&issuer=Okta"
    Extracts seed from URI and shows the current code.

.EXAMPLE
    .\Get-TOTPCode.ps1 -Seed JBSWY3DPEHPK3PXP -ShowURI -Issuer "MyOrg" -Account "user@myorg.okta.com"
    Shows the current code and prints an otpauth:// URI for QR printing.

.NOTES
    No credentials are written to disk by this script.
    For break-glass use: seed must be retrieved from physical Envelope A per Break-Glass SOP.
#>
[CmdletBinding(DefaultParameterSetName = 'Seed')]
param(
    [Parameter(ParameterSetName = 'Seed', Position = 0)]
    [string]$Seed,

    [Parameter(Mandatory, ParameterSetName = 'URI')]
    [string]$TOTPUri,

    [int]$Digits   = 6,
    [int]$TimeStep = 30,

    [switch]$Watch,
    [switch]$ShowURI,

    [Parameter(ParameterSetName = 'Seed')]
    [string]$Issuer,

    [Parameter(ParameterSetName = 'Seed')]
    [string]$Account
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function ConvertFrom-Base32 {
    param([string]$Base32)
    $Base32 = $Base32.ToUpperInvariant().TrimEnd('=')
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'
    $bits = ''
    foreach ($c in $Base32.ToCharArray()) {
        $idx = $alphabet.IndexOf($c)
        if ($idx -lt 0) { throw "Invalid Base32 character: '$c'" }
        $bits += [Convert]::ToString($idx, 2).PadLeft(5, '0')
    }
    $bytes = [System.Collections.Generic.List[byte]]::new()
    for ($i = 0; $i + 8 -le $bits.Length; $i += 8) {
        $bytes.Add([Convert]::ToByte($bits.Substring($i, 8), 2))
    }
    return $bytes.ToArray()
}

function Get-TOTPCode {
    param(
        [Parameter(Mandatory)][string]$SeedParam,
        [int]$DigitsParam   = 6,
        [int]$TimeStepParam = 30
    )
    $keyBytes     = ConvertFrom-Base32 -Base32 $SeedParam
    $unixTime     = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    $counter      = [long][Math]::Floor($unixTime / $TimeStepParam)
    $counterBytes = [System.BitConverter]::GetBytes($counter)
    if ([BitConverter]::IsLittleEndian) { [Array]::Reverse($counterBytes) }
    $hmac   = [System.Security.Cryptography.HMACSHA1]::new($keyBytes)
    $hash   = $hmac.ComputeHash($counterBytes)
    $hmac.Dispose()
    $offset = $hash[$hash.Length - 1] -band 0x0F
    $otp    = (($hash[$offset]     -band 0x7F) -shl 24) -bor
              (($hash[$offset + 1] -band 0xFF) -shl 16) -bor
              (($hash[$offset + 2] -band 0xFF) -shl  8) -bor
              (($hash[$offset + 3] -band 0xFF))
    return ($otp % [Math]::Pow(10, $DigitsParam)).ToString().PadLeft($DigitsParam, '0')
}

function Get-RemainingSeconds {
    param([int]$TimeStepParam = 30)
    return $TimeStepParam - ([int](([DateTimeOffset]::UtcNow.ToUnixTimeSeconds()) % $TimeStepParam))
}

function Extract-SeedFromUri {
    param([string]$Uri)
    if ($Uri -match '[?&]secret=([A-Z2-7a-z]+)') {
        return $Matches[1].ToUpperInvariant()
    }
    throw "Could not extract 'secret' parameter from URI: $Uri"
}

# Resolve seed
$resolvedSeed = $null

if ($PSCmdlet.ParameterSetName -eq 'URI') {
    $resolvedSeed = Extract-SeedFromUri -Uri $TOTPUri
    Write-Host "Extracted seed from URI." -ForegroundColor DarkGray
}
elseif (-not [string]::IsNullOrWhiteSpace($Seed)) {
    $resolvedSeed = $Seed.Trim()
}
else {
    $bstr = $null
    $ss   = Read-Host -Prompt 'Enter TOTP seed (Base32)' -AsSecureString
    $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($ss)
    try { $resolvedSeed = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr).Trim() }
    finally { [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
}

# Validate by attempting decode
try { $null = ConvertFrom-Base32 -Base32 $resolvedSeed }
catch { Write-Error "Invalid Base32 seed: $_"; exit 1 }

# Show URI if requested
if ($ShowURI -and $Issuer -and $Account) {
    $enc = [uri]::EscapeDataString
    $uri = "otpauth://totp/$($enc.Invoke("$Issuer`:$Account"))?secret=$resolvedSeed&issuer=$($enc.Invoke($Issuer))&algorithm=SHA1&digits=$Digits&period=$TimeStep"
    Write-Host ''
    Write-Host 'otpauth:// URI (paste into QR generator):' -ForegroundColor Cyan
    Write-Host $uri
    Write-Host ''
}

# Single shot or watch mode
if (-not $Watch) {
    $code      = Get-TOTPCode -SeedParam $resolvedSeed -DigitsParam $Digits -TimeStepParam $TimeStep
    $remaining = Get-RemainingSeconds -TimeStepParam $TimeStep
    Write-Host ''
    Write-Host "Code    : $code" -ForegroundColor Green
    Write-Host "Expires : ${remaining}s remaining in this window"
    Write-Host ''
}
else {
    Write-Host ''
    Write-Host 'Watching TOTP codes (Ctrl+C to stop)...' -ForegroundColor Cyan
    Write-Host ''
    $lastCode = ''
    while ($true) {
        $code      = Get-TOTPCode -SeedParam $resolvedSeed -DigitsParam $Digits -TimeStepParam $TimeStep
        $remaining = Get-RemainingSeconds -TimeStepParam $TimeStep
        $bar       = ('#' * $remaining).PadRight($TimeStep)
        if ($code -ne $lastCode) {
            Write-Host ''
            Write-Host "  Code: $code   [$bar] ${remaining}s" -ForegroundColor Green
            $lastCode = $code
        }
        else {
            Write-Host "`r  Code: $code   [$bar] ${remaining}s" -ForegroundColor Green -NoNewline
        }
        Start-Sleep -Milliseconds 500
    }
}
