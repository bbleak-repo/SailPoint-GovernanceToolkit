#Requires -Version 5.1
<#
.SYNOPSIS
    Creates a complete CyberArk Okta HLA vault structure: safe (if missing) +
    three linked accounts (target HLA, SSWS token bearer, TOTP seed bearer).

.DESCRIPTION
    Implements the automated path described in docs/OktaHLA-VaultStructure.md.
    Idempotent: existing accounts are detected and updated instead of duplicated;
    safe is created only if missing; admin-owner group is auto-added on safe
    create (anti-orphan).

    Three accounts created per HLA (in this order, since the target links to
    the other two):
      1. SSWS token bearer (LogonAccount + ReconcileAccount target)
      2. TOTP seed bearer (TOTPAccount target)
      3. Target HLA (Okta admin user, password rotated by V6/V7 platform)

    The target's LinkedAccounts are wired automatically post-create.

.PARAMETER PVWAUrl
    PVWA base URL (e.g., https://tenant.privilegecloud.cyberark.cloud).
    /PasswordVault is added at request time -- do not include it.

.PARAMETER PVWAToken
    Pre-obtained Bearer or session token (skips authentication).

.PARAMETER SafeName
    Safe name (e.g., 'Okta-HLA-acme'). Created if it does not exist.

.PARAMETER SafeAdminGroup
    Admin group auto-added as Owner on safe create. Default:
    'Privilege Cloud Administrators'.

.PARAMETER OktaDomain
    Okta tenant domain (e.g., 'yourtenant.okta.com'). Becomes the Address
    on all three accounts.

.PARAMETER HLAUsername
    Okta admin user login (e.g., 'okta-superadmin-01@example.com').
    Becomes the Username on the target account and the basis for the
    other two account names.

.PARAMETER HLAPassword
    Current Okta password for the HLA. SecureString. CPM will rotate this
    on next cycle once the platform is associated.

.PARAMETER OktaUserId
    The Okta directory _id for this user (e.g., '00uABCDEFGHIJKLMNOPQ').
    Stored as a custom property on the target account; consumed by V6/V7
    platforms at rotation time.

.PARAMETER SSWSTokenAccountName
    Name of the SSWS token bearer account. If omitted, derived as
    "{HLAUsername}-token". Reused across HLAs in the same safe is fine
    (one token can rotate many users) -- pass an explicit shared name.

.PARAMETER SSWSToken
    Okta SSWS API token with okta.users.manage scope. SecureString.
    Stored as the password of the SSWS token account.

.PARAMETER TOTPAccountName
    Name of the TOTP seed bearer account. If omitted, derived as
    "{HLAUsername}-totp". Per-HLA -- TOTP seeds are user-specific.

.PARAMETER TOTPSeed
    Base32 TOTP seed for this HLA. SecureString. Stored as the password
    of the TOTP account; read by PSM TOTPToken.exe at session launch.

.PARAMETER PlatformId
    Platform ID for the target HLA account. Default: 'OktaCloudWSChains'.
    Use 'OktaCloudTPC' for V6.

.PARAMETER SecretsPlatformId
    Platform ID for the SSWS token and TOTP seed accounts. Default:
    'CyberArkVault' (no auto-rotation -- secrets rotated manually via
    Okta UI when needed).

.PARAMETER VerifyAfterCreate
    If specified, triggers a Verify on the target account after creation
    to confirm the linkages and credentials work end-to-end.

.EXAMPLE
    $okPass    = Read-Host -AsSecureString 'Okta password for HLA'
    $sswsToken = Read-Host -AsSecureString 'Okta SSWS API token'
    $totpSeed  = Read-Host -AsSecureString 'TOTP base32 seed'

    .\New-OktaHLAAccount.ps1 `
        -PVWAUrl  'https://yourtenant.privilegecloud.cyberark.cloud' `
        -PVWAToken $token `
        -SafeName 'Okta-HLA-acme' `
        -OktaDomain 'yourtenant.okta.com' `
        -HLAUsername 'okta-superadmin-01@example.com' `
        -HLAPassword $okPass `
        -OktaUserId '00uABCDEFGHIJKLMNOPQ' `
        -SSWSToken $sswsToken `
        -TOTPSeed  $totpSeed `
        -PlatformId 'OktaCloudWSChains' `
        -VerifyAfterCreate

.NOTES
    PVWA REST endpoints used:
      POST /api/Safes                          (safe create)
      POST /api/Safes/{name}/Members           (anti-orphan owner)
      POST /api/Accounts                       (account create)
      GET  /api/Accounts?search=...            (idempotency check)
      PATCH /api/Accounts/{id}                 (update existing)
      POST /api/Accounts/{id}/LinkAccount      (wire linked accounts)
      POST /api/Accounts/{id}/Verify           (optional final verify)
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory)][string]$PVWAUrl,
    [Parameter(Mandatory)][string]$PVWAToken,

    [Parameter(Mandatory)][string]$SafeName,
    [string]$SafeAdminGroup = 'Privilege Cloud Administrators',

    [Parameter(Mandatory)][string]$OktaDomain,

    [Parameter(Mandatory)][string]$HLAUsername,
    [Parameter(Mandatory)][SecureString]$HLAPassword,
    [Parameter(Mandatory)][string]$OktaUserId,

    [string]$SSWSTokenAccountName,
    [Parameter(Mandatory)][SecureString]$SSWSToken,

    [string]$TOTPAccountName,
    [Parameter(Mandatory)][SecureString]$TOTPSeed,

    [string]$PlatformId = 'OktaCloudWSChains',
    [string]$SecretsPlatformId = 'CyberArkVault',

    [switch]$VerifyAfterCreate
)

$ErrorActionPreference = 'Stop'

#region Logging
function Write-Step {
    param([string]$Message, [string]$Level = 'INFO')
    $colors = @{ INFO='White'; WARN='Yellow'; ERROR='Red'; OK='Green'; SKIP='DarkGray'; STEP='Cyan' }
    $color = if ($colors.ContainsKey($Level)) { $colors[$Level] } else { 'White' }
    $ts = Get-Date -Format 'HH:mm:ss'
    Write-Host "[$ts][$Level] $Message" -ForegroundColor $color
}
#endregion

#region SecureString helpers
function ConvertTo-PlainText {
    param([SecureString]$Secure)
    $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($Secure)
    try { [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr) }
    finally { [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
}
#endregion

#region PVWA HTTP
function Initialize-PVWASession {
    $normalized = $PVWAUrl.TrimEnd('/') -replace '/PasswordVault$',''
    $authHeader = if ($PVWAToken -match '^ey') { "Bearer $PVWAToken" } else { $PVWAToken }
    $Script:PVWA = @{
        Base = "$normalized/PasswordVault"
        AuthHeader = $authHeader
    }
}

function Invoke-PVWA {
    param(
        [Parameter(Mandatory)][string]$Path,
        [ValidateSet('GET','POST','PUT','PATCH','DELETE')][string]$Method = 'GET',
        [object]$Body = $null,
        [int]$TimeoutSec = 120
    )
    $uri = "$($Script:PVWA.Base)$Path"
    $params = @{
        Uri = $uri
        Method = $Method
        Headers = @{ Authorization = $Script:PVWA.AuthHeader }
        ContentType = 'application/json'
        TimeoutSec = $TimeoutSec
        UseBasicParsing = $true
    }
    if ($null -ne $Body) {
        $params['Body'] = ($Body | ConvertTo-Json -Depth 10 -Compress)
    }
    try {
        return Invoke-RestMethod @params
    }
    catch {
        $status = $null
        $errBody = ''
        if ($_.Exception.Response) {
            $status = [int]$_.Exception.Response.StatusCode
            try {
                $stream = $_.Exception.Response.GetResponseStream()
                $reader = [System.IO.StreamReader]::new($stream)
                $errBody = $reader.ReadToEnd()
            } catch {}
        }
        $err = New-Object -TypeName PSObject -Property @{
            StatusCode = $status
            Body = $errBody
            Message = $_.Exception.Message
        }
        # Re-throw with structured detail
        $detail = "PVWA $Method $Path -> HTTP $status. Body: $errBody"
        throw [System.Exception]::new($detail, $_.Exception)
    }
}
#endregion

#region Safe operations
function Test-Safe {
    param([string]$Name)
    try {
        $resp = Invoke-PVWA -Path "/api/Safes/$([uri]::EscapeDataString($Name))"
        return $resp
    } catch {
        if ($_.Exception.Message -match 'HTTP 404') { return $null }
        throw
    }
}

function New-Safe {
    param([string]$Name)
    $existing = Test-Safe -Name $Name
    if ($existing) {
        Write-Step "Safe '$Name' already exists -- skipping create" -Level SKIP
        return $existing
    }
    Write-Step "Creating safe '$Name'..." -Level STEP
    if ($PSCmdlet.ShouldProcess($Name, 'POST /api/Safes')) {
        $body = @{
            safeName = $Name
            description = "Okta HLA -- $OktaDomain"
            olacEnabled = $false
            managingCPM = ''
            numberOfDaysRetention = 30
        }
        $resp = Invoke-PVWA -Path '/api/Safes' -Method POST -Body $body
        Write-Step "Safe '$Name' created" -Level OK

        # Anti-orphan: add admin-owner immediately
        Write-Step "Adding admin-owner group '$SafeAdminGroup' as Owner..." -Level STEP
        $ownerBody = @{
            memberName = $SafeAdminGroup
            searchIn = 'Vault'
            permissions = @{
                useAccounts = $true; retrieveAccounts = $true; listAccounts = $true
                addAccounts = $true; updateAccountContent = $true; updateAccountProperties = $true
                initiateCPMAccountManagementOperations = $true; specifyNextAccountContent = $true
                renameAccounts = $true; deleteAccounts = $true; unlockAccounts = $true
                manageSafe = $true; manageSafeMembers = $true; backupSafe = $true
                viewAuditLog = $true; viewSafeMembers = $true
                accessWithoutConfirmation = $true; createFolders = $true
                deleteFolders = $true; moveAccountsAndFolders = $true
                requestsAuthorizationLevel1 = $true; requestsAuthorizationLevel2 = $false
            }
        }
        try {
            Invoke-PVWA -Path "/api/Safes/$([uri]::EscapeDataString($Name))/Members" -Method POST -Body $ownerBody | Out-Null
            Write-Step "Anti-orphan owner added" -Level OK
        }
        catch {
            Write-Step "WARNING: failed to add admin-owner group ($($_.Exception.Message)). Add manually before deleting the creating account!" -Level WARN
        }
        return $resp
    }
}
#endregion

#region Account operations
function Find-Account {
    param([string]$Name, [string]$Safe)
    # Search by exact name within the safe
    $search = [uri]::EscapeDataString($Name)
    $safeQ = [uri]::EscapeDataString($Safe)
    $resp = Invoke-PVWA -Path "/api/Accounts?search=$search&filter=safeName eq $safeQ"
    if ($resp.value) {
        return $resp.value | Where-Object { $_.name -eq $Name } | Select-Object -First 1
    }
    return $null
}

function Set-Account {
    <#
        Idempotent: create if missing, update if present.
        Returns the account object.
    #>
    param(
        [string]$Name,
        [string]$Safe,
        [string]$Platform,
        [string]$Address,
        [string]$Username,
        [SecureString]$Password,
        [hashtable]$ExtraProperties = @{}
    )

    $existing = Find-Account -Name $Name -Safe $Safe
    $passPlain = ConvertTo-PlainText -Secure $Password

    if ($existing) {
        Write-Step "Account '$Name' exists -- updating password + properties" -Level INFO
        if ($PSCmdlet.ShouldProcess($Name, 'PATCH /api/Accounts')) {
            # Update password via dedicated endpoint
            $pwBody = @{ NewCredentials = $passPlain; ChangeImmediately = $false }
            Invoke-PVWA -Path "/api/Accounts/$($existing.id)/Password/Update" -Method POST -Body $pwBody | Out-Null
            # Update properties (if any changed)
            if ($ExtraProperties.Count -gt 0) {
                $patchOps = @()
                foreach ($k in $ExtraProperties.Keys) {
                    $patchOps += @{ op = 'replace'; path = "/platformAccountProperties/$k"; value = $ExtraProperties[$k] }
                }
                Invoke-PVWA -Path "/api/Accounts/$($existing.id)" -Method PATCH -Body $patchOps | Out-Null
            }
        }
        return $existing
    }

    Write-Step "Creating account '$Name' (platform $Platform)..." -Level STEP
    $body = @{
        name = $Name
        address = $Address
        userName = $Username
        platformId = $Platform
        safeName = $Safe
        secretType = 'password'
        secret = $passPlain
        platformAccountProperties = $ExtraProperties
    }
    if ($PSCmdlet.ShouldProcess($Name, 'POST /api/Accounts')) {
        $resp = Invoke-PVWA -Path '/api/Accounts' -Method POST -Body $body
        Write-Step "Account '$Name' created (id=$($resp.id))" -Level OK
        return $resp
    }
}

function Add-LinkedAccount {
    <#
        Wires a linked-account association on a target account.
        ExtraPasswordIndex: 1 = LogonAccount, 2 = TOTPAccount, 3 = ReconcileAccount
        per the platform's <LinkedPasswords> declaration.
    #>
    param(
        [Parameter(Mandatory)][string]$TargetAccountId,
        [Parameter(Mandatory)][int]$ExtraPasswordIndex,
        [Parameter(Mandatory)][string]$LinkedAccountName,
        [Parameter(Mandatory)][string]$LinkedSafeName,
        [string]$LinkedFolder = 'Root'
    )
    $body = @{
        safe = $LinkedSafeName
        extraPasswordIndex = $ExtraPasswordIndex
        name = $LinkedAccountName
        folder = $LinkedFolder
    }
    Write-Step "  Linking ExtraPass$ExtraPasswordIndex -> $LinkedAccountName" -Level INFO
    if ($PSCmdlet.ShouldProcess("$TargetAccountId/LinkAccount[$ExtraPasswordIndex]", 'POST /api/Accounts/{id}/LinkAccount')) {
        Invoke-PVWA -Path "/api/Accounts/$TargetAccountId/LinkAccount" -Method POST -Body $body | Out-Null
    }
}

function Invoke-AccountVerify {
    param([string]$AccountId)
    Write-Step "Triggering Verify on account $AccountId..." -Level STEP
    if ($PSCmdlet.ShouldProcess($AccountId, 'POST /api/Accounts/{id}/Verify')) {
        Invoke-PVWA -Path "/api/Accounts/$AccountId/Verify" -Method POST | Out-Null
        Write-Step "Verify queued. Check CPM log + account status in PVWA." -Level OK
    }
}
#endregion

#region Main
function Main {
    Write-Step "===== New-OktaHLAAccount =====" -Level STEP
    Write-Step "  PVWA:     $PVWAUrl" -Level INFO
    Write-Step "  Safe:     $SafeName" -Level INFO
    Write-Step "  HLA:      $HLAUsername" -Level INFO
    Write-Step "  Okta:     $OktaDomain" -Level INFO
    Write-Step "  Platform: $PlatformId" -Level INFO

    Initialize-PVWASession

    # Derive default account names
    if (-not $SSWSTokenAccountName) { $SSWSTokenAccountName = "$HLAUsername-token" }
    if (-not $TOTPAccountName)      { $TOTPAccountName      = "$HLAUsername-totp"  }

    # Step 1: ensure safe exists
    New-Safe -Name $SafeName | Out-Null

    # Step 2: SSWS token bearer (LogonAccount + ReconcileAccount target)
    Write-Step "[1/3] SSWS token account..." -Level STEP
    $sswsAccount = Set-Account `
        -Name $SSWSTokenAccountName -Safe $SafeName -Platform $SecretsPlatformId `
        -Address $OktaDomain -Username 'okta-rotation-token' -Password $SSWSToken

    # Step 3: TOTP seed bearer (TOTPAccount target)
    Write-Step "[2/3] TOTP seed account..." -Level STEP
    $totpAccount = Set-Account `
        -Name $TOTPAccountName -Safe $SafeName -Platform $SecretsPlatformId `
        -Address $OktaDomain -Username 'okta-totp-seed' -Password $TOTPSeed

    # Step 4: target HLA (the actual Okta admin user)
    Write-Step "[3/3] Target HLA account..." -Level STEP
    $targetName = $HLAUsername
    $targetAccount = Set-Account `
        -Name $targetName -Safe $SafeName -Platform $PlatformId `
        -Address $OktaDomain -Username $HLAUsername -Password $HLAPassword `
        -ExtraProperties @{ OktaUserId = $OktaUserId }

    # Step 5: wire links (LogonAccount=1, TOTPAccount=2, ReconcileAccount=3)
    Write-Step "Wiring linked accounts on target $($targetAccount.id)..." -Level STEP
    Add-LinkedAccount -TargetAccountId $targetAccount.id -ExtraPasswordIndex 1 -LinkedAccountName $SSWSTokenAccountName -LinkedSafeName $SafeName
    Add-LinkedAccount -TargetAccountId $targetAccount.id -ExtraPasswordIndex 2 -LinkedAccountName $TOTPAccountName       -LinkedSafeName $SafeName
    Add-LinkedAccount -TargetAccountId $targetAccount.id -ExtraPasswordIndex 3 -LinkedAccountName $SSWSTokenAccountName -LinkedSafeName $SafeName

    Write-Step "All three accounts created and linked" -Level OK

    if ($VerifyAfterCreate) {
        Invoke-AccountVerify -AccountId $targetAccount.id
    }

    Write-Step "===== Done =====" -Level OK
    Write-Host ""
    Write-Host "Next steps:" -ForegroundColor Cyan
    Write-Host "  - In PVWA, open the target account ($targetName) and confirm 'Associated Accounts' shows all three links"
    Write-Host "  - Click Change to trigger an end-to-end rotation test"
    Write-Host "  - Once Change succeeds, the safe is ready for PSM session brokering"
}

Main
#endregion
