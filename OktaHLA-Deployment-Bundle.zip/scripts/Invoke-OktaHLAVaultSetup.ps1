#Requires -Version 5.1
<#
.SYNOPSIS
    Automates CyberArk PAM configuration for Okta HLA 3-Tier privileged account management.

.DESCRIPTION
    v3.1.0 -- Production hardening, security fixes, WhatIf accuracy.

    v3.1 Changes:
      - OAuth2ClientSecret parameter accepts both plain string and SecureString
        (matches Invoke-CALicenseAnalyzer-v4 pattern for flexibility).
      - Clear-SensitiveString documentation corrected: .NET string immutability means byte-level
        zeroing is not possible; function now honestly documents its limitations.
      - Temp password generation uses rejection sampling for unbiased random character selection
        (eliminates modulo bias from byte % charset-length).
      - RNGCryptoServiceProvider replaced with RandomNumberGenerator.Create() (non-obsolete on
        .NET 6+ / PS 7.2+, still works on PS 5.1).
      - New-TOTPUri: replaced fragile method-group assignment with direct [uri]::EscapeDataString
        calls for reliability.
      - New-HLAVaultGroup: added 404 handling so missing /api/UserGroups endpoint falls through
        to create instead of throwing.
      - Vault group creation now correctly tracks Skipped operations.
      - Fixed double-counted Register-Operation in Phase 1 platform import.
      - Invoke-PVWARequest WhatIf mode now allows GET requests through for accurate idempotency
        checks. Only write methods (POST/PUT/PATCH/DELETE) are suppressed.
      - Okta session headers and sensitive tokens cleared in finally block on script exit.
      - Vault group filter query encoding cleaned up to avoid double-encoding risk.

    v3.0.0 -- Multi-auth (Privilege Cloud + on-prem), CyberArk-only mode, production hardening.

    v3.0 Features:
      - Multi-method PVWA auth: CyberArk, LDAP, RADIUS, Windows (on-prem), OAuth2 PKCE,
        OAuth2 Client Credentials (Privilege Cloud), pre-obtained tokens.
        Auto-detects on-prem vs Privilege Cloud from PVWAUrl.
      - CA.Auth toolkit integration: delegates to CyberArkToolbox CA.Auth when available,
        falls back to inline auth when not.
      - CyberArk-only mode (-SkipOktaDiscovery): deploys safes, permissions, vault groups,
        and platform without requiring an Okta SSWS token. Re-run later to onboard accounts.
      - TLS 1.2 enforcement for PS 5.1 compatibility.
      - Session resilience: 401 re-authentication, exponential backoff with jitter,
        PS 5.1/PS 7 compatible error body extraction.
      - Deployment summary: tracks Created/Skipped/Updated/Failed/Verified counts.
      - Credential hygiene: sensitive strings cleared from memory after use.
      - Okta pagination via Link header parsing (replaces page-count heuristic).
      - TOTP seed display gated behind user confirmation (ReplaceTOTP recovery).

    v2.0.0 -- Dynamic Okta discovery, TOTP enrollment, CPM token self-minting, multi-tenant.

    Dynamically discovers Okta HLA accounts using a provided SSWS token, enrolls TOTP factors
    via the Okta API (RFC 6238, pure PowerShell), self-mints a CPM SSWS token via a context-switch
    flow, and onboards all accounts into CyberArk with correct safe permissions, vault groups,
    and linked account configuration.

    Automates (Steps 1.3-1.5, 2, 3, 4, 5, 6, 7, 8, 9 of CR CHG00YYYYY):
      - OktaCloud platform ZIP creation, import, and activation
      - 4 safes per tenant (Passwords, MFAKeys, CPM-ServiceAccounts, BreakGlass)
      - Safe permission assignment for all members
      - 2 shared vault groups (Okta-HLA-Users, Okta-HLA-Approvers)
      - CPM SSWS token self-minted via Path B context-switch
      - HLA password accounts onboarded (tiers controlled by -IncludeTiers)
      - TOTP seed accounts enrolled via Okta API and onboarded
      - Linked account configuration (ExtraPass 1/2/3 per HLA account)
      - Break-glass audit record with otpauth:// QR URI output
      - Verification pass + Record of IDs

    Multi-tenant: safe names include TenantId. Platform and vault groups are shared.
    Idempotent: GET-before-POST throughout. Re-running is safe.

    Manual steps (1.1, 1.2, 1.6, 10, 12.3-12.5) are printed as a formatted checklist.

.PARAMETER OktaToken
    SSWS API token for Okta. Must have at minimum Org Admin privilege to enumerate users.
    Super Admin privilege enables CPM token self-minting (Path B) and full tier enumeration.
    If not provided, the script prompts securely at startup.

.PARAMETER PVWAUrl
    Base URL of the PVWA (e.g. https://cyberark.corp.com). No trailing slash.
    If not provided, the script prompts at startup.

.PARAMETER PVWACredential
    PSCredential for PVWA authentication. If not provided, the script prompts at startup.

.PARAMETER TenantId
    Short identifier for this Okta tenant, used in safe names (e.g. "acme" -> Okta-acme-HLA-Passwords).
    Auto-derived from the OktaDomain subdomain. Script prompts for confirmation before proceeding.

.PARAMETER AccountFilter
    Prefix used to identify HLA service accounts when enumerating Okta users.
    Default: 'svc-okta-'. Accounts not matching this prefix are ignored.

.PARAMETER PasswordSafeName
    Override the default safe name for HLA password accounts.
    Default: Okta-{TenantId}-HLA-Passwords

.PARAMETER MFASafeName
    Override the default safe name for TOTP/MFA seed accounts.
    Default: Okta-{TenantId}-HLA-MFAKeys

.PARAMETER CPMSafeName
    Override the default safe name for CPM service account (SSWS token).
    Default: Okta-{TenantId}-CPM-ServiceAccounts

.PARAMETER BGSafeName
    Override the default safe name for the break-glass audit record.
    Default: Okta-{TenantId}-BreakGlass

.PARAMETER UsersGroupName
    CyberArk vault group for HLA users (checkout permissions). Default: Okta-HLA-Users

.PARAMETER ApproversGroupName
    CyberArk vault group for approvers (dual-control). Default: Okta-HLA-Approvers

.PARAMETER IncludeTiers
    Which HLA tiers to onboard. Default: 1,2,3 (all tiers).
    Example: -IncludeTiers 2,3 skips Super Admin accounts.

.PARAMETER IncludeReadOnly
    Include Read-Only Admin accounts (Okta role: READ_ONLY_ADMIN). Off by default.

.PARAMETER EnrollTOTP
    Enroll TOTP factors for discovered accounts via the Okta API.
    Requires Super Admin token. Each enrollment produces a seed stored in CyberArk.

.PARAMETER TOTPProvider
    TOTP provider for Okta factor enrollment. OKTA uses the okta_verify TOTP authenticator
    (standard, default). GOOGLE uses google_otp (no push capability, requires tenant-wide
    activation via Deploy-OktaHLABootstrap.ps1 Step 5.5). Must match the -TOTPProvider
    value used in Deploy-OktaHLABootstrap.ps1.
    Default: OKTA

.PARAMETER ReplaceTOTP
    Comma-separated list of Okta usernames to re-enroll TOTP for (recovery scenario).
    Resets the existing TOTP factor and re-enrolls. Pulls CPM credential from CCP if -CCPUrl provided.

.PARAMETER CCPUrl
    URL of the CyberArk Central Credential Provider for retrieving the CPM service account
    credential during TOTP replace operations.

.PARAMETER CCPAppId
    Application ID registered in the CCP for this script.

.PARAMETER Simulate
    Routes all simulator writes (TOTP seeds, passwords) to the CPM simulator instead of
    the real CyberArk vault. Used for lab/development testing.
    Requires the CPM simulator to be installed at SimulatorPath.

.PARAMETER SimulatorPath
    Path to the CPM simulator directory containing 'src/cli.py'.
    Auto-detected from common locations if not provided.

.PARAMETER SkipPlatformImport
    Skip Steps 1.3-1.5 (platform ZIP creation, import, activation).
    Use when the OktaCloud platform is already present in the vault.

.PARAMETER PlatformSourceDirectory
    Directory containing the 3 OktaCloud platform files for ZIP creation.
    Default: ../cpm-simulator/cpm-plugin/platform (relative to this script).

.PARAMETER VerifyOnly
    Skip all creation steps and run only the verification pass (Phase 4).
    Prints the Record of IDs for an existing setup.

.PARAMETER GenerateBGQR
    Output an otpauth:// URI for the break-glass account for QR printing / tabletop testing.
    The TOTP seed is NOT stored in CyberArk for break-glass -- physical envelope only.
    Requires Super Admin token to enroll the BG factor.

.PARAMETER ConfigPath
    Path to a legacy JSON config file (OktaHLASetup-Sample.json format).
    Backward-compatible fallback. Dynamic discovery takes precedence when -OktaToken is provided.

.EXAMPLE
    .\Invoke-OktaHLAVaultSetup.ps1 -WhatIf
    Prompts for tokens/URLs, validates config and connectivity, prints what would be created.

.EXAMPLE
    .\Invoke-OktaHLAVaultSetup.ps1 -OktaToken $env:OKTA_API_TOKEN -PVWAUrl https://cyberark.corp.com
    Interactive setup: prompts for PVWA credential and naming confirmation, then runs full setup.

.EXAMPLE
    .\Invoke-OktaHLAVaultSetup.ps1 -EnrollTOTP -IncludeTiers 2,3
    Onboards Tier 2 and 3 accounts only, enrolls TOTP for each.

.EXAMPLE
    .\Invoke-OktaHLAVaultSetup.ps1 -Simulate -SimulatorPath ..\cpm-simulator
    Full setup routed to CPM simulator for lab testing.

.EXAMPLE
    .\Invoke-OktaHLAVaultSetup.ps1 -ReplaceTOTP "svc-okta-h01@corp.okta.com" -CCPUrl https://ccp.corp.com -CCPAppId OktaSetup
    Re-enrolls TOTP for a single account (recovery scenario), pulling CPM cred from CCP.

.NOTES
    Version:    3.1.0
    Requires:   CyberArk PAS v12.2+ (TOTP linked account support)
    Auth:       Vault Administrator or equivalent
    SECURITY:   Never store SSWS tokens or vault credentials in files at rest.
    CR Ref:     CHG00YYYYY -- Configure CyberArk PAM for Okta HLA 3-Tier PAM
#>
[CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'High', DefaultParameterSetName = 'Deploy')]
param(
    [Parameter(ParameterSetName = 'Deploy')]
    [Parameter(ParameterSetName = 'Replace')]
    [Parameter(ParameterSetName = 'VerifyOnly')]
    [Parameter(ParameterSetName = 'Teardown')]
    [string]$OktaToken,

    [Parameter(ParameterSetName = 'Deploy')]
    [Parameter(ParameterSetName = 'Replace')]
    [Parameter(ParameterSetName = 'VerifyOnly')]
    [Parameter(ParameterSetName = 'Teardown')]
    [string]$OktaDomain,

    [Parameter(ParameterSetName = 'Deploy')]
    [Parameter(ParameterSetName = 'Replace')]
    [Parameter(ParameterSetName = 'VerifyOnly')]
    [Parameter(ParameterSetName = 'Teardown')]
    [string]$PVWAUrl,

    [Parameter(ParameterSetName = 'Deploy')]
    [Parameter(ParameterSetName = 'Replace')]
    [Parameter(ParameterSetName = 'VerifyOnly')]
    [Parameter(ParameterSetName = 'Teardown')]
    [System.Management.Automation.PSCredential]$PVWACredential,

    # PVWA authentication method. Auto detects Privilege Cloud vs on-prem.
    [Parameter(ParameterSetName = 'Deploy')]
    [Parameter(ParameterSetName = 'Replace')]
    [Parameter(ParameterSetName = 'VerifyOnly')]
    [Parameter(ParameterSetName = 'Teardown')]
    [ValidateSet('Auto', 'CyberArk', 'LDAP', 'RADIUS', 'Windows', 'OAuth2_PKCE', 'OAuth2_ClientCredentials', 'Token')]
    [string]$AuthMethod = 'Auto',

    # Pre-obtained PVWA token (skips all PVWA auth flows).
    [Parameter(ParameterSetName = 'Deploy')]
    [Parameter(ParameterSetName = 'Replace')]
    [Parameter(ParameterSetName = 'VerifyOnly')]
    [Parameter(ParameterSetName = 'Teardown')]
    [string]$PVWAToken,

    # Type of pre-obtained token: Session (CyberArk native) or Bearer (OAuth2/Identity).
    [Parameter(ParameterSetName = 'Deploy')]
    [Parameter(ParameterSetName = 'Replace')]
    [Parameter(ParameterSetName = 'VerifyOnly')]
    [Parameter(ParameterSetName = 'Teardown')]
    [ValidateSet('Session', 'Bearer')]
    [string]$PVWATokenType = 'Session',

    # CyberArk Identity tenant URL for OAuth2 flows (Privilege Cloud).
    [Parameter(ParameterSetName = 'Deploy')]
    [Parameter(ParameterSetName = 'Replace')]
    [Parameter(ParameterSetName = 'VerifyOnly')]
    [Parameter(ParameterSetName = 'Teardown')]
    [Alias('IdentityTenantUrl')]
    [string]$TenantUrl,

    # OAuth2 Client ID (for Client Credentials flow).
    # Alias: -OAuth2ClientId (backward compat)
    [Parameter(ParameterSetName = 'Deploy')]
    [Parameter(ParameterSetName = 'Replace')]
    [Parameter(ParameterSetName = 'VerifyOnly')]
    [Parameter(ParameterSetName = 'Teardown')]
    [Alias('OAuth2ClientId')]
    [string]$ClientId,

    # OAuth2 Client Secret (for Client Credentials flow).
    # Accepts both plain string and SecureString for flexibility.
    # Alias: -OAuth2ClientSecret (backward compat)
    [Parameter(ParameterSetName = 'Deploy')]
    [Parameter(ParameterSetName = 'Replace')]
    [Parameter(ParameterSetName = 'VerifyOnly')]
    [Parameter(ParameterSetName = 'Teardown')]
    [Alias('OAuth2ClientSecret')]
    $ClientSecret,

    [Parameter(ParameterSetName = 'Deploy')]
    [Parameter(ParameterSetName = 'Replace')]
    [string]$TenantId,

    [Parameter(ParameterSetName = 'Deploy')]
    [string]$AccountFilter = 'svc-okta-',

    [Parameter(ParameterSetName = 'Deploy')]
    [string]$PasswordSafeName,

    [Parameter(ParameterSetName = 'Deploy')]
    [string]$MFASafeName,

    [Parameter(ParameterSetName = 'Deploy')]
    [string]$CPMSafeName,

    [Parameter(ParameterSetName = 'Deploy')]
    [string]$BGSafeName,

    [Parameter(ParameterSetName = 'Deploy')]
    [string]$UsersGroupName = 'Okta-HLA-Users',

    [Parameter(ParameterSetName = 'Deploy')]
    [string]$ApproversGroupName = 'Okta-HLA-Approvers',

    # Admin group added as full owner (ManageSafe + ManageSafeMembers) to every safe.
    # Prevents orphaned safes if the creating OAuth2 service account is later removed.
    # Default: "Privilege Cloud Administrators" (standard Privilege Cloud group).
    # Change to "Vault Admins" for self-hosted PAS.
    [Parameter(ParameterSetName = 'Deploy')]
    [string]$SafeAdminGroup = 'Privilege Cloud Administrators',

    [Parameter(ParameterSetName = 'Deploy')]
    [ValidateSet(1, 2, 3)]
    [int[]]$IncludeTiers = @(1, 2, 3),

    [Parameter(ParameterSetName = 'Deploy')]
    [switch]$IncludeReadOnly,

    [Parameter(ParameterSetName = 'Deploy')]
    [switch]$EnrollTOTP,

    # TOTP provider for Okta factor enrollment. OKTA = okta_verify TOTP (default,
    # standard authenticator). GOOGLE = google_otp (no push, requires tenant-wide
    # activation). Must match the -TOTPProvider used in Deploy-OktaHLABootstrap.ps1.
    [Parameter(ParameterSetName = 'Deploy')]
    [Parameter(ParameterSetName = 'Replace')]
    [ValidateSet('GOOGLE', 'OKTA')]
    [string]$TOTPProvider = 'OKTA',

    [Parameter(Mandatory, ParameterSetName = 'Replace')]
    [string[]]$ReplaceTOTP,

    [Parameter(ParameterSetName = 'Replace')]
    [string]$CCPUrl,

    [Parameter(ParameterSetName = 'Replace')]
    [string]$CCPAppId,

    [Parameter(ParameterSetName = 'Deploy')]
    [switch]$Simulate,

    [Parameter(ParameterSetName = 'Deploy')]
    [string]$SimulatorPath,

    [Parameter(ParameterSetName = 'Deploy')]
    [switch]$SkipPlatformImport,

    [Parameter(ParameterSetName = 'Deploy')]
    [string]$PlatformSourceDirectory,

    [Parameter(Mandatory, ParameterSetName = 'VerifyOnly')]
    [switch]$VerifyOnly,

    [Parameter(ParameterSetName = 'Deploy')]
    [switch]$GenerateBGQR,

    [Parameter(ParameterSetName = 'Legacy')]
    [ValidateScript({ Test-Path $_ -PathType Leaf })]
    [string]$ConfigPath,

    # Skip Okta API calls entirely. Deploys CyberArk-side resources only (safes, permissions,
    # vault groups, platform). Use when you do not have an Okta SSWS token yet or want to
    # pre-stage the CyberArk infrastructure before Okta account onboarding.
    # Re-run later WITHOUT this switch to discover and onboard Okta accounts.
    [Parameter(ParameterSetName = 'Deploy')]
    [switch]$SkipOktaDiscovery,

    # Suppresses interactive naming/confirmation prompts and accepts all defaults.
    # Intended for CI pipelines and WhatIf dry-runs. NOT for production use.
    [Parameter(ParameterSetName = 'Deploy')]
    [Parameter(ParameterSetName = 'Replace')]
    [Parameter(ParameterSetName = 'VerifyOnly')]
    [Parameter(ParameterSetName = 'Teardown')]
    [switch]$AcceptDefaults,

    # Directory for SIEM JSON log output. Defaults to a 'Logs' folder next to this script.
    # Pass an empty string to disable file logging (toolkit-only or console-only mode).
    [Parameter(ParameterSetName = 'Deploy')]
    [Parameter(ParameterSetName = 'Replace')]
    [Parameter(ParameterSetName = 'VerifyOnly')]
    [Parameter(ParameterSetName = 'Teardown')]
    [string]$SIEMLogPath,

    # Teardown: remove CyberArk-side resources created by this script.
    # Removes accounts, safes, platform, vault groups, and connection components
    # in dependency-safe reverse order. Does NOT revoke Okta TOTP seeds.
    [Parameter(Mandatory, ParameterSetName = 'Teardown')]
    [switch]$Teardown,

    # TenantId is needed for teardown to resolve safe names.
    [Parameter(ParameterSetName = 'Teardown')]
    [string]$TeardownTenantId,

    # Show detailed help and exit.
    [Parameter(ParameterSetName = 'Deploy')]
    [Parameter(ParameterSetName = 'Replace')]
    [Parameter(ParameterSetName = 'VerifyOnly')]
    [Parameter(ParameterSetName = 'Teardown')]
    [Parameter(ParameterSetName = 'Legacy')]
    [Alias('h','?')]
    [switch]$Help
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# Enforce TLS 1.2+ -- older PS 5.1 sessions may default to TLS 1.0
if ([Net.ServicePointManager]::SecurityProtocol -notmatch 'Tls12') {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
}

#region Constants

$Script:VERSION          = '3.1.0'
$Script:TOTP_PLATFORM    = 'MFA Device Keys - TOTP'
$Script:OKTA_PLATFORM    = 'OktaCloud'
$Script:CPM_ACCOUNT_NAME = 'okta-cpm-ssws-token'
$Script:BG_SUFFIX        = '-bg01'
$Script:TOTP_SUFFIX      = '_totp'
$Script:EXTRA_PASS_LOGON      = 1   # SSWS token (CPM logon)
$Script:EXTRA_PASS_TOTP       = 2   # TOTP seed (PSM MFA injection)
$Script:EXTRA_PASS_RECONCILE  = 3   # SSWS token (CPM reconcile, same as logon)

# Operation counters for deployment summary
$Script:OpCounts = @{
    Created  = 0
    Skipped  = 0
    Updated  = 0
    Failed   = 0
    Verified = 0
}

# Auth method constants
$Script:AUTH_METHODS = @('Auto', 'CyberArk', 'LDAP', 'RADIUS', 'Windows', 'OAuth2_PKCE', 'OAuth2_ClientCredentials', 'Token')

# Okta role strings returned by GET /api/v1/users/{id}/roles
$Script:ROLE_SUPER_ADMIN  = 'SUPER_ADMIN'
$Script:ROLE_ORG_ADMIN    = 'ORG_ADMIN'
$Script:ROLE_APP_ADMIN    = 'APP_ADMIN'
$Script:ROLE_HELP_DESK    = 'HELP_DESK_ADMIN'
$Script:ROLE_READ_ONLY    = 'READ_ONLY_ADMIN'

$Script:TIER_MAP = @{
    $Script:ROLE_SUPER_ADMIN = 1
    $Script:ROLE_ORG_ADMIN   = 2
    $Script:ROLE_APP_ADMIN   = 3
    $Script:ROLE_HELP_DESK   = 3
    $Script:ROLE_READ_ONLY   = 0   # 0 = ReadOnly (not in 1-3)
}

$Script:CorrelationId = [guid]::NewGuid().ToString()

# SIEM / structured logging state
$Script:SIEMEnabled          = $false
$Script:SIEMLogFile          = $null
$Script:SIEMToolkitAvailable = $false

#endregion

#region Utility

function Get-FirstNonNull {
    param([object[]]$Values)
    foreach ($v in $Values) {
        if ($null -ne $v -and $v -ne '') { return $v }
    }
    return $null
}

function Clear-SensitiveString {
    <#
    .SYNOPSIS
        Releases a string variable reference and requests garbage collection.
    .DESCRIPTION
        .NET strings are immutable -- the original bytes cannot be zeroed in place.
        This function nulls the reference and hints GC to reclaim the unreferenced
        copy sooner. It does NOT guarantee the secret is wiped from managed heap.
        For true zeroing, use SecureString end-to-end or Marshal pinning.
        Named Clear- (not Zero-) to avoid implying byte-level erasure.
    #>
    param([ref]$StringRef)
    if ($null -ne $StringRef.Value -and $StringRef.Value -is [string] -and $StringRef.Value.Length -gt 0) {
        $StringRef.Value = $null
    }
    [System.GC]::Collect()
}

function Register-Operation {
    <#
    .SYNOPSIS
        Increments the operation counter for deployment summary tracking.
    #>
    param(
        [ValidateSet('Created','Skipped','Updated','Failed','Verified')]
        [string]$Type
    )
    $Script:OpCounts[$Type]++
}

function Write-DeploymentSummary {
    <#
    .SYNOPSIS
        Prints the deployment summary table showing created/skipped/updated/failed/verified counts.
    #>
    param([int]$DurationSeconds = 0)

    Write-Host ''
    Write-Host '================================================================' -ForegroundColor White
    Write-Host ' DEPLOYMENT SUMMARY' -ForegroundColor White
    Write-Host '================================================================' -ForegroundColor White
    Write-Host ("  {0,-15} {1}" -f 'Created:',  $Script:OpCounts.Created)  -ForegroundColor Green
    Write-Host ("  {0,-15} {1}" -f 'Skipped:',  $Script:OpCounts.Skipped)  -ForegroundColor DarkGray
    Write-Host ("  {0,-15} {1}" -f 'Updated:',  $Script:OpCounts.Updated)  -ForegroundColor Yellow
    Write-Host ("  {0,-15} {1}" -f 'Failed:',   $Script:OpCounts.Failed)   -ForegroundColor Red
    Write-Host ("  {0,-15} {1}" -f 'Verified:',  $Script:OpCounts.Verified) -ForegroundColor Cyan
    Write-Host ("  {0,-15} {1}s" -f 'Duration:', $DurationSeconds)
    Write-Host '================================================================' -ForegroundColor White
    Write-Host ''

    Write-SIEMLog -Level 'INFO' -Action 'DeploymentSummary' -Message 'Deployment summary' `
        -Fields @{
            Created  = $Script:OpCounts.Created
            Skipped  = $Script:OpCounts.Skipped
            Updated  = $Script:OpCounts.Updated
            Failed   = $Script:OpCounts.Failed
            Verified = $Script:OpCounts.Verified
            DurationSeconds = $DurationSeconds
        }
}

function Test-IsPrivilegeCloud {
    <#
    .SYNOPSIS
        Returns $true if the PVWA URL indicates a CyberArk Privilege Cloud tenant.
    #>
    param([string]$Url)
    return ($Url -match 'privilegecloud\.cyberark\.cloud' -or $Url -match 'cyberark\.cloud')
}

function Initialize-SIEMLogging {
    <#
    .SYNOPSIS
        Initialises structured SIEM logging. Writes a daily rotating JSON log file
        whose schema matches CA.Logging for direct Splunk/SIEM ingestion.
        Optionally integrates with the CyberArkToolbox CA.Logging module when available.
    .PARAMETER LogDir
        Target directory for log files. Defaults to a 'Logs' subfolder next to this script.
        Pass an empty string to disable file logging (toolkit-only or console-only mode).
    #>
    param([string]$LogDir = '')

    # Resolve log directory
    if ([string]::IsNullOrWhiteSpace($LogDir)) {
        $LogDir = Join-Path $PSScriptRoot 'Logs'
    }

    # Attempt to create and validate the directory
    try {
        if (-not (Test-Path $LogDir)) {
            New-Item $LogDir -ItemType Directory -Force -WhatIf:$false | Out-Null
        }
        $dateStr = Get-Date -Format 'yyyy-MM-dd'
        $Script:SIEMLogFile = Join-Path $LogDir "OktaHLASetup_${dateStr}_$($Script:CorrelationId.Substring(0,8)).json"
        $Script:SIEMEnabled = $true
    }
    catch {
        Write-Host "[SIEM] Cannot create log directory '$LogDir': $_  -- file logging disabled" -ForegroundColor Yellow
        $Script:SIEMEnabled = $false
        return
    }

    # Discover CA.Logging toolkit module (optional; enhances toolkit log aggregation)
    $Script:SIEMToolkitAvailable = $false
    $candidatePaths = @(
        # Relative: ../../CyberARK/CyberArkToolbox/Modules/CA.Core from this script's parent
        (Join-Path (Split-Path (Split-Path $PSScriptRoot -Parent) -Parent) `
            'CyberARK\CyberArkToolbox\Modules\CA.Core\CA.Logging.psm1'),
        (Join-Path $HOME `
            'Documents\Projects\CyberARK\CyberArkToolbox\Modules\CA.Core\CA.Logging.psm1'),
        # macOS/Linux path variant
        (Join-Path $HOME `
            'Documents/Projects/CyberARK/CyberArkToolbox/Modules/CA.Core/CA.Logging.psm1')
    )
    foreach ($mp in $candidatePaths) {
        if (Test-Path $mp -ErrorAction SilentlyContinue) {
            try {
                Import-Module $mp -Force -ErrorAction Stop
                if (Get-Command Write-CALog -ErrorAction SilentlyContinue) {
                    $Script:SIEMToolkitAvailable = $true
                    break
                }
            }
            catch {}
        }
    }
    # Also try by module name if installed in PSModulePath
    if (-not $Script:SIEMToolkitAvailable) {
        try {
            Import-Module CA.Logging -ErrorAction SilentlyContinue
            if (Get-Command Write-CALog -ErrorAction SilentlyContinue) {
                $Script:SIEMToolkitAvailable = $true
            }
        }
        catch {}
    }

    $modeStr = if ($Script:SIEMToolkitAvailable) { 'CA.Logging + local JSON' } else { 'local JSON only' }
    Write-Host "[SIEM] $modeStr  ->  $Script:SIEMLogFile" -ForegroundColor DarkGray

    # Discover CA.Auth toolkit module (optional; enables multi-method PVWA auth)
    $Script:CAAuthAvailable = $false
    $authCandidatePaths = @(
        (Join-Path (Split-Path (Split-Path $PSScriptRoot -Parent) -Parent) `
            'CyberARK\CyberArkToolbox\Modules\CA.Core\CA.Auth.psm1'),
        (Join-Path $HOME `
            'Documents\Projects\CyberARK\CyberArkToolbox\Modules\CA.Core\CA.Auth.psm1'),
        (Join-Path $HOME `
            'Documents/Projects/CyberARK/CyberArkToolbox/Modules/CA.Core/CA.Auth.psm1')
    )
    foreach ($ap in $authCandidatePaths) {
        if (Test-Path $ap -ErrorAction SilentlyContinue) {
            try {
                Import-Module $ap -Force -ErrorAction Stop -WarningAction SilentlyContinue
                if (Get-Command Connect-CAPVWASession -ErrorAction SilentlyContinue) {
                    $Script:CAAuthAvailable = $true
                    break
                }
            }
            catch {}
        }
    }
    if (-not $Script:CAAuthAvailable) {
        try {
            Import-Module CA.Auth -ErrorAction SilentlyContinue
            if (Get-Command Connect-CAPVWASession -ErrorAction SilentlyContinue) {
                $Script:CAAuthAvailable = $true
            }
        }
        catch {}
    }
    $authModeStr = if ($Script:CAAuthAvailable) { 'CA.Auth (multi-method)' } else { 'inline (CyberArk/Token)' }
    Write-Host "[Auth] PVWA auth: $authModeStr" -ForegroundColor DarkGray
}

function Write-SIEMLog {
    <#
    .SYNOPSIS
        Emits one flat JSON log entry to the SIEM log file.
        Schema is compatible with CA.Logging for Splunk/SIEM parsing.
        Also routes to the CA.Logging toolkit when available.
    .PARAMETER Level
        Log level matching Write-SetupLog: INFO, WARN, ERROR, SKIP, OK, STEP, DEBUG.
        Mapped to CA.Logging severities: ERROR/WARN/DEBUG pass through; all others -> INFO.
    .PARAMETER Message
        Human-readable message (required).
    .PARAMETER Action
        Short verb-noun event name for SIEM analytics (e.g. 'CreateSafe', 'OnboardHLAAccount').
    .PARAMETER Fields
        Optional hashtable of additional key-value pairs appended to the JSON entry.
    #>
    param(
        [string]$Level   = 'INFO',
        [string]$Message = '',
        [string]$Action  = '',
        [hashtable]$Fields = $null
    )
    if (-not $Script:SIEMEnabled) { return }

    $severity = switch ($Level) {
        'ERROR' { 'ERROR' }
        'WARN'  { 'WARN' }
        'DEBUG' { 'DEBUG' }
        default { 'INFO' }
    }

    $user  = if ($env:USERNAME) { $env:USERNAME } elseif ($env:USER) { $env:USER } else { 'Unknown' }
    $hname = if ($env:COMPUTERNAME) { $env:COMPUTERNAME } elseif ($env:HOSTNAME) { $env:HOSTNAME } else { $env:NAME }

    $entry = [ordered]@{
        Timestamp     = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
        Severity      = $severity
        Component     = 'OktaHLAVaultSetup'
        Version       = $Script:VERSION
        Action        = $Action
        Message       = $Message
        CorrelationID = $Script:CorrelationId
        User          = $user
        Environment   = 'OktaHLASetup'
        Host          = $hname
        WhatIf        = if ($WhatIfPreference) { $true } else { $false }
    }
    if ($Fields) {
        foreach ($k in $Fields.Keys) { $entry[$k] = $Fields[$k] }
    }

    $json = $entry | ConvertTo-Json -Compress -Depth 5
    # -WhatIf:$false ensures SIEM log writes happen even when the script runs with -WhatIf.
    try { Add-Content -Path $Script:SIEMLogFile -Value $json -Encoding UTF8 -WhatIf:$false -ErrorAction SilentlyContinue } catch {}

    # Also route to CA.Logging toolkit if module is loaded
    if ($Script:SIEMToolkitAvailable) {
        try {
            Write-CALog -Message $Message -Severity $severity -Component 'OktaHLAVaultSetup' `
                -Action $Action -CorrelationID $Script:CorrelationId -AdditionalFields $Fields
        }
        catch {}
    }
}

function Write-SetupLog {
    param(
        [ValidateSet('INFO','WARN','ERROR','SKIP','OK','STEP','DEBUG')]
        [string]$Level = 'INFO',
        [string]$Message,
        # Optional SIEM action tag (e.g. 'CreateSafe'). Passed through to Write-SIEMLog.
        [string]$Action = '',
        # Optional structured fields for SIEM enrichment. Passed through to Write-SIEMLog.
        [hashtable]$Fields = $null
    )
    $ts    = Get-Date -Format 'HH:mm:ss'
    $corr  = $Script:CorrelationId.Substring(0,8)
    $color = switch ($Level) {
        'INFO'  { 'Cyan' }
        'WARN'  { 'Yellow' }
        'ERROR' { 'Red' }
        'SKIP'  { 'DarkGray' }
        'OK'    { 'Green' }
        'STEP'  { 'White' }
        'DEBUG' { 'DarkGray' }
    }
    Write-Host "[$ts][$corr][$Level] $Message" -ForegroundColor $color
    Write-SIEMLog -Level $Level -Message $Message -Action $Action -Fields $Fields
}

function Get-SecureInput {
    param([string]$Prompt)
    $ss = Read-Host -Prompt $Prompt -AsSecureString
    $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($ss)
    try { return [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr) }
    finally { [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
}

function ConvertFrom-SecureStringPlain {
    <#
    .SYNOPSIS
        Converts a SecureString to its plaintext value. PS 5.1 compatible.
    #>
    param([Parameter(Mandatory)][SecureString]$Secure)
    $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($Secure)
    try { return [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr) }
    finally { [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
}

function Confirm-UserChoice {
    param(
        [string]$Prompt,
        [string]$Default = 'Y'
    )
    $indicator = if ($Default -eq 'Y') { '[Y/n]' } else { '[y/N]' }
    $response  = Read-Host "$Prompt $indicator"
    if ([string]::IsNullOrWhiteSpace($response)) { $response = $Default }
    return $response.Trim().ToUpper() -eq 'Y'
}

function Get-TOTPWindowSafe {
    <#
    .SYNOPSIS
        Returns the number of seconds remaining in the current 30-second TOTP window.
        If fewer than $MinSeconds remain, waits for the next window boundary before returning.
    #>
    param([int]$MinSeconds = 5)
    $remaining = 30 - ([int](([DateTimeOffset]::UtcNow.ToUnixTimeSeconds()) % 30))
    if ($remaining -lt $MinSeconds) {
        Write-SetupLog -Level INFO -Message "TOTP window boundary in ${remaining}s -- waiting for next window..."
        Start-Sleep -Seconds ($remaining + 1)
    }
    return 30 - ([int](([DateTimeOffset]::UtcNow.ToUnixTimeSeconds()) % 30))
}

#endregion

#region TOTP Engine (RFC 6238, pure PowerShell, PS 5.1 compatible)

function ConvertFrom-Base32 {
    <#
    .SYNOPSIS
        Decodes a Base32-encoded string to a byte array (RFC 4648, no padding required).
    #>
    param([string]$Base32)

    $Base32 = $Base32.ToUpperInvariant().TrimEnd('=')
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'
    $bits = ''
    foreach ($c in $Base32.ToCharArray()) {
        $idx = $alphabet.IndexOf($c)
        if ($idx -lt 0) { throw "Invalid Base32 character: '$c'" }
        $bits += [Convert]::ToString($idx, 2).PadLeft(5, '0')
    }
    $bytes = [System.Collections.Generic.List[byte]]::new()
    for ($i = 0; $i + 8 -le $bits.Length; $i += 8) {
        $bytes.Add([Convert]::ToByte($bits.Substring($i, 8), 2))
    }
    return $bytes.ToArray()
}

function Get-TOTPCode {
    <#
    .SYNOPSIS
        Computes the current TOTP code (RFC 6238 / HOTP with time counter).
    .PARAMETER Seed
        Base32-encoded TOTP shared secret.
    .PARAMETER TimeStep
        TOTP time step in seconds. Default: 30.
    .PARAMETER Digits
        Number of output digits. Default: 6.
    #>
    param(
        [Parameter(Mandatory)]
        [string]$Seed,
        [int]$TimeStep = 30,
        [int]$Digits   = 6
    )

    $keyBytes     = ConvertFrom-Base32 -Base32 $Seed
    $unixTime     = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    $counter      = [long][Math]::Floor($unixTime / $TimeStep)
    $counterBytes = [System.BitConverter]::GetBytes($counter)
    if ([BitConverter]::IsLittleEndian) { [Array]::Reverse($counterBytes) }

    $hmac   = [System.Security.Cryptography.HMACSHA1]::new($keyBytes)
    $hash   = $hmac.ComputeHash($counterBytes)
    $hmac.Dispose()

    $offset = $hash[$hash.Length - 1] -band 0x0F
    $otp    = (($hash[$offset]     -band 0x7F) -shl 24) -bor
              (($hash[$offset + 1] -band 0xFF) -shl 16) -bor
              (($hash[$offset + 2] -band 0xFF) -shl  8) -bor
              (($hash[$offset + 3] -band 0xFF))

    return ($otp % [Math]::Pow(10, $Digits)).ToString().PadLeft($Digits, '0')
}

function New-TOTPUri {
    <#
    .SYNOPSIS
        Generates an otpauth:// URI suitable for QR code printing.
    #>
    param(
        [Parameter(Mandatory)][string]$Issuer,
        [Parameter(Mandatory)][string]$AccountName,
        [Parameter(Mandatory)][string]$Seed,
        [int]$Digits   = 6,
        [int]$TimeStep = 30
    )
    $label  = [uri]::EscapeDataString("${Issuer}:${AccountName}")
    $issEnc = [uri]::EscapeDataString($Issuer)
    return "otpauth://totp/${label}?secret=$Seed&issuer=${issEnc}&algorithm=SHA1&digits=$Digits&period=$TimeStep"
}

#endregion

#region Okta API

$Script:OktaHeaders = $null
$Script:OktaActiveDomain = $null
$Script:OktaBaseUrl = $null
$Script:OktaTokenLevel = $null   # 'SuperAdmin' or 'OrgAdmin' or 'Limited'
$Script:OktaTokenOwner = $null   # @{ Id; Login } -- set by Resolve-OktaTokenLevel

function Initialize-OktaSession {
    param(
        [Parameter(Mandatory)][string]$Token,
        [Parameter(Mandatory)][string]$Domain
    )
    $Script:OktaActiveDomain = $Domain
    $Script:OktaBaseUrl = "https://$Domain"
    $Script:OktaHeaders = @{
        'Authorization' = "SSWS $Token"
        'Accept'        = 'application/json'
        'Content-Type'  = 'application/json'
        'X-Okta-Correlation-Id' = $Script:CorrelationId
    }
}

function Invoke-OktaRequest {
    param(
        [Parameter(Mandatory)][string]$Path,
        [ValidateSet('GET','POST','PUT','DELETE')][string]$Method = 'GET',
        [object]$Body = $null,
        [int]$MaxRetries = 3
    )
    $url = "$Script:OktaBaseUrl$Path"
    $attempt = 0
    do {
        $attempt++
        try {
            $params = @{
                Uri     = $url
                Method  = $Method
                Headers = $Script:OktaHeaders
                UseBasicParsing = $true
            }
            if ($null -ne $Body) {
                $params['Body'] = ($Body | ConvertTo-Json -Depth 10)
            }
            $resp = Invoke-WebRequest @params
            if ($resp.Content) {
                return ($resp.Content | ConvertFrom-Json)
            }
            return $null
        }
        catch {
            $status = $null
            if ($_.Exception.Response) {
                $status = [int]$_.Exception.Response.StatusCode
            }
            if ($status -in @(429, 503) -and $attempt -lt $MaxRetries) {
                # Prefer Okta's Retry-After header (seconds) over fixed backoff
                $retryAfter = 0
                try {
                    $raHeader = $_.Exception.Response.Headers
                    if ($null -ne $raHeader) {
                        $raValues = $raHeader.GetValues('Retry-After')
                        if ($raValues -and $raValues.Count -gt 0) {
                            $retryAfter = [int]$raValues[0]
                        }
                    }
                }
                catch {}
                if ($retryAfter -lt 1) {
                    $retryAfter = 2 * $attempt
                }
                # Cap at 60s to avoid indefinite waits
                if ($retryAfter -gt 60) { $retryAfter = 60 }
                Write-SetupLog -Level WARN -Message "Okta $Method $Path => $status. Retry $attempt/$MaxRetries in ${retryAfter}s..."
                Start-Sleep -Seconds $retryAfter
            }
            else {
                $errBody = ''
                try {
                    $stream = $_.Exception.Response.GetResponseStream()
                    $reader = [System.IO.StreamReader]::new($stream)
                    $errBody = $reader.ReadToEnd()
                }
                catch {}
                throw "Okta API $Method $Path failed (HTTP $status): $errBody`n$($_.Exception.Message)"
            }
        }
    } while ($attempt -lt $MaxRetries)
}

function Get-OktaOrgInfo {
    Write-SetupLog -Level DEBUG -Message 'GET /api/v1/org'
    return Invoke-OktaRequest -Path '/api/v1/org'
}

function Get-OktaMe {
    Write-SetupLog -Level DEBUG -Message 'GET /api/v1/users/me'
    return Invoke-OktaRequest -Path '/api/v1/users/me'
}

function Get-OktaUserRoles {
    param([Parameter(Mandatory)][string]$UserId)
    Write-SetupLog -Level DEBUG -Message "GET /api/v1/users/$UserId/roles"
    try {
        return Invoke-OktaRequest -Path "/api/v1/users/$UserId/roles"
    }
    catch {
        # 403 = insufficient privilege (e.g. Org Admin calling on Super Admin)
        if ($_ -match 'HTTP 403') {
            Write-SetupLog -Level WARN -Message "Cannot read roles for user $UserId (403 -- likely higher privilege than caller)"
            return @()
        }
        throw
    }
}

function Resolve-OktaTokenLevel {
    <#
    .SYNOPSIS
        Determines whether the SSWS token belongs to a Super Admin, Org Admin, or limited user.
        Sets $Script:OktaTokenLevel and $Script:OktaTokenOwner and returns the level.
    #>
    Write-SetupLog -Level INFO -Message 'Resolving Okta token privilege level...'
    $me = Get-OktaMe
    # Okta user object: login lives at profile.login, not top-level
    $meLogin = try { $me.profile.login } catch { try { $me.login } catch { $me.id } }
    Write-SetupLog -Level DEBUG -Message "Token owner: $meLogin ($($me.id))"

    # Store token owner for later use (e.g., Phase 6 CPM token identity check)
    $Script:OktaTokenOwner = @{
        Id    = $me.id
        Login = $meLogin
    }

    try {
        $roles = Get-OktaUserRoles -UserId $me.id
        $roleTypes = $roles | ForEach-Object { $_.type }

        if ($Script:ROLE_SUPER_ADMIN -in $roleTypes) {
            $Script:OktaTokenLevel = 'SuperAdmin'
        }
        elseif ($Script:ROLE_ORG_ADMIN -in $roleTypes) {
            $Script:OktaTokenLevel = 'OrgAdmin'
        }
        else {
            $Script:OktaTokenLevel = 'Limited'
        }
    }
    catch {
        # If we can't read roles at all, assume limited
        $Script:OktaTokenLevel = 'Limited'
        Write-SetupLog -Level WARN -Message "Could not determine token role level. Assuming Limited. $_"
    }

    Write-SetupLog -Level INFO -Message "Okta token level: $Script:OktaTokenLevel (owner: $meLogin)"
    return $Script:OktaTokenLevel
}

function Get-OktaUsers {
    <#
    .SYNOPSIS
        Returns all active Okta users whose login matches the given filter prefix.
        Handles Okta pagination automatically.
    #>
    param(
        [Parameter(Mandatory)][string]$Filter,
        [int]$PageLimit = 200
    )
    Write-SetupLog -Level INFO -Message "Enumerating Okta users matching '$Filter'..."
    $allUsers = [System.Collections.Generic.List[object]]::new()
    # Okta does not allow mixing 'filter' and 'search' parameters -- combine into a single search expression
    $encodedSearch = [uri]::EscapeDataString("status eq `"ACTIVE`" and profile.login sw `"$Filter`"")
    $nextUrl = "/api/v1/users?search=$encodedSearch&limit=$PageLimit"

    do {
        # Use Invoke-WebRequest directly to access Link headers for pagination
        $rawUrl = "$Script:OktaBaseUrl$nextUrl"
        $resp = Invoke-WebRequest -Uri $rawUrl -Method GET -Headers $Script:OktaHeaders -UseBasicParsing
        $page = $null
        if ($resp.Content) { $page = $resp.Content | ConvertFrom-Json }
        if ($page) { foreach ($u in $page) { $allUsers.Add($u) } }

        # Parse Okta Link header for next page (rel="next")
        $nextUrl = $null
        $linkHeader = $null
        try { $linkHeader = $resp.Headers['Link'] } catch {}
        if ($linkHeader) {
            # Link header format: <https://...>; rel="next", <https://...>; rel="self"
            $linkStr = if ($linkHeader -is [array]) { $linkHeader -join ', ' } else { $linkHeader }
            if ($linkStr -match '<([^>]+)>;\s*rel="next"') {
                $fullNextUrl = $Matches[1]
                # Convert absolute URL back to relative path for consistency
                $nextUrl = $fullNextUrl -replace [regex]::Escape($Script:OktaBaseUrl), ''
            }
        }
    } while ($null -ne $nextUrl)

    Write-SetupLog -Level INFO -Message "Found $($allUsers.Count) active user(s) matching '$Filter'"
    return $allUsers.ToArray()
}

function Get-OktaUserFactors {
    param([Parameter(Mandatory)][string]$UserId)
    Write-SetupLog -Level DEBUG -Message "GET /api/v1/users/$UserId/factors"
    return Invoke-OktaRequest -Path "/api/v1/users/$UserId/factors"
}

function Invoke-OktaTOTPEnrollment {
    <#
    .SYNOPSIS
        Enrolls a TOTP (token:software:totp) factor for an Okta user.
        Returns the sharedSecret from the activation object.
        Requires Super Admin token.
    .OUTPUTS
        Hashtable with keys: FactorId, SharedSecret, TOTPUri
    #>
    param(
        [Parameter(Mandatory)][string]$UserId,
        [Parameter(Mandatory)][string]$UserLogin,
        [Parameter(Mandatory)][string]$OrgName,
        [switch]$Activate
    )

    Write-SetupLog -Level INFO -Message "Enrolling TOTP factor for user: $UserLogin"

    if ($WhatIfPreference) {
        Write-SetupLog -Level INFO -Message "[WhatIf] Would POST /api/v1/users/$UserId/factors (enroll TOTP for $UserLogin)"
        return @{
            FactorId     = "WHATIF-FACTOR-$UserLogin"
            SharedSecret = "WHATIFBASE32SEED"
            TOTPUri      = "otpauth://totp/WhatIf:$UserLogin?secret=WHATIFBASE32SEED"
        }
    }

    # Check for existing active TOTP factor
    $existing = Get-OktaUserFactors -UserId $UserId
    $activeTOTP = $existing | Where-Object { $_.factorType -eq 'token:software:totp' -and $_.status -eq 'ACTIVE' }
    if ($activeTOTP) {
        Write-SetupLog -Level WARN -Message "User $UserLogin already has an active TOTP factor (id: $($activeTOTP.id)). Use -ReplaceTOTP to reset."
        return $null
    }

    # Enroll (server-side generated secret)
    $providerValue = if ($TOTPProvider -eq 'OKTA') { 'OKTA' } else { 'GOOGLE' }
    $body = @{ factorType = 'token:software:totp'; provider = $providerValue }
    $enrolled = Invoke-OktaRequest -Path "/api/v1/users/$UserId/factors" -Method POST -Body $body

    $factorId    = $enrolled.id
    $sharedSec   = $enrolled._embedded.activation.sharedSecret
    if (-not $sharedSec) {
        throw "TOTP enrollment for $UserLogin did not return a sharedSecret. Response: $($enrolled | ConvertTo-Json -Depth 5)"
    }

    Write-SetupLog -Level INFO -Message "TOTP factor enrolled for $UserLogin (factorId: $factorId). Activating..."

    # Activate with retry -- TOTP codes are time-sensitive (30s windows).
    # If the code is generated near a window boundary, Okta may reject it.
    # Retry up to 3 times, waiting for a fresh window before each attempt.
    $maxActivationAttempts = 3
    $activated = $null
    for ($activationAttempt = 1; $activationAttempt -le $maxActivationAttempts; $activationAttempt++) {
        $null = Get-TOTPWindowSafe -MinSeconds 8
        $code = Get-TOTPCode -Seed $sharedSec
        $activateBody = @{ passCode = $code }
        try {
            $activated = Invoke-OktaRequest -Path "/api/v1/users/$UserId/factors/$factorId/lifecycle/activate" -Method POST -Body $activateBody
            if ($activated.status -eq 'ACTIVE') {
                break
            }
            Write-SetupLog -Level WARN -Message "TOTP activation attempt $activationAttempt/$maxActivationAttempts for $UserLogin returned status '$($activated.status)'"
        }
        catch {
            Write-SetupLog -Level WARN -Message "TOTP activation attempt $activationAttempt/$maxActivationAttempts for $UserLogin failed: $($_.Exception.Message)"
            if ($activationAttempt -ge $maxActivationAttempts) { throw }
        }
    }

    if ($null -eq $activated -or $activated.status -ne 'ACTIVE') {
        throw "TOTP activation for $UserLogin failed after $maxActivationAttempts attempts. Last status: $(if ($activated) { $activated.status } else { 'null' })"
    }

    Write-SetupLog -Level OK -Message "TOTP factor ACTIVE for $UserLogin" `
        -Action 'OktaTOTPEnroll' -Fields @{ Username = $UserLogin; UserId = $UserId; FactorId = $factorId }

    $uri = New-TOTPUri -Issuer $OrgName -AccountName $UserLogin -Seed $sharedSec

    return @{
        FactorId     = $factorId
        SharedSecret = $sharedSec
        TOTPUri      = $uri
    }
}

function Invoke-OktaTOTPReset {
    <#
    .SYNOPSIS
        Resets (deletes) an existing TOTP factor so it can be re-enrolled.
    #>
    param(
        [Parameter(Mandatory)][string]$UserId,
        [Parameter(Mandatory)][string]$UserLogin
    )
    $factors = Get-OktaUserFactors -UserId $UserId
    $totp    = $factors | Where-Object { $_.factorType -eq 'token:software:totp' }
    if (-not $totp) {
        Write-SetupLog -Level SKIP -Message "No TOTP factor found for $UserLogin -- nothing to reset"
        return
    }
    foreach ($f in $totp) {
        Write-SetupLog -Level WARN -Message "Deleting TOTP factor $($f.id) for $UserLogin"
        if (-not $WhatIfPreference) {
            Invoke-OktaRequest -Path "/api/v1/users/$UserId/factors/$($f.id)" -Method DELETE
        }
        else { Write-SetupLog -Level INFO -Message "[WhatIf] Would DELETE /api/v1/users/$UserId/factors/$($f.id)" }
    }
}

function New-OktaAPIToken {
    <#
    .SYNOPSIS
        Self-mints an SSWS API token for the CPM service user via Path B:
          1. As SA: set a temporary password on the CPM user
          2. Authenticate as CPM user via /api/v1/authn (primary auth, no MFA)
          3. Create a session via /api/v1/sessions
          4. POST /api/v1/api/tokens with session cookie
          5. As SA: force-expire the CPM user's password (restore MFA-gated state)
        Returns the new SSWS token string.
    #>
    param(
        [Parameter(Mandatory)][string]$CPMUserId,
        [Parameter(Mandatory)][string]$CPMUserLogin,
        [Parameter(Mandatory)][string]$TokenName
    )

    if ($Script:OktaTokenLevel -ne 'SuperAdmin') {
        throw "New-OktaAPIToken requires a Super Admin token. Current level: $Script:OktaTokenLevel"
    }

    Write-SetupLog -Level INFO -Message "Path B: Minting CPM SSWS token for $CPMUserLogin..."

    # Step 1: Set a temp password (random, 20 chars)
    $chars    = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$'
    $charLen  = $chars.Length   # 66
    # Rejection sampling: discard bytes >= largest multiple of charLen to eliminate modulo bias
    $maxUnbiased = 256 - (256 % $charLen)   # 256 - (256 % 66) = 198
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    $tempPassChars = [System.Collections.Generic.List[char]]::new(20)
    $buf = New-Object byte[] 1
    while ($tempPassChars.Count -lt 20) {
        $rng.GetBytes($buf)
        if ($buf[0] -lt $maxUnbiased) {
            $tempPassChars.Add($chars[$buf[0] % $charLen])
        }
    }
    $tempPass = -join $tempPassChars
    $rng.Dispose()

    $setPassBody = @{ credentials = @{ password = @{ value = $tempPass } } }
    Write-SetupLog -Level INFO -Message "Setting temporary password on CPM user $CPMUserLogin..."
    if (-not $WhatIfPreference) {
        Invoke-OktaRequest -Path "/api/v1/users/$CPMUserId" -Method PUT -Body $setPassBody | Out-Null
    }
    else {
        Write-SetupLog -Level INFO -Message "[WhatIf] Would PUT /api/v1/users/$CPMUserId to set temp password"
        return "WHATIF-CPM-SSWS-TOKEN-PLACEHOLDER"
    }

    try {
        # Step 2: Primary authentication as CPM user
        $authnBody = @{ username = $CPMUserLogin; password = $tempPass }
        $authn = Invoke-WebRequest -Uri "$Script:OktaBaseUrl/api/v1/authn" `
            -Method POST `
            -Headers @{ 'Content-Type' = 'application/json'; 'Accept' = 'application/json' } `
            -Body ($authnBody | ConvertTo-Json) `
            -UseBasicParsing
        $authnResp = $authn.Content | ConvertFrom-Json
        $sessionToken = $authnResp.sessionToken
        if (-not $sessionToken) { throw "Primary auth for $CPMUserLogin did not return a sessionToken" }

        # Step 3: Create a session
        $sessionBody = @{ sessionToken = $sessionToken }
        $sessionResp = Invoke-WebRequest -Uri "$Script:OktaBaseUrl/api/v1/sessions" `
            -Method POST `
            -Headers @{ 'Content-Type' = 'application/json'; 'Accept' = 'application/json' } `
            -Body ($sessionBody | ConvertTo-Json) `
            -UseBasicParsing `
            -SessionVariable 'cpmSession'
        $sessionData = $sessionResp.Content | ConvertFrom-Json
        Write-SetupLog -Level DEBUG -Message "CPM session created: $($sessionData.id)"

        # Step 4: Mint API token using the session cookie
        $tokenBody = @{ name = $TokenName }
        $tokenResp = Invoke-WebRequest -Uri "$Script:OktaBaseUrl/api/v1/api/tokens" `
            -Method POST `
            -Headers @{ 'Content-Type' = 'application/json'; 'Accept' = 'application/json' } `
            -Body ($tokenBody | ConvertTo-Json) `
            -WebSession $cpmSession `
            -UseBasicParsing
        $tokenData = $tokenResp.Content | ConvertFrom-Json
        $newToken = $tokenData.token
        if (-not $newToken) { throw "API token creation for $CPMUserLogin did not return a token" }
        Write-SetupLog -Level OK -Message "CPM SSWS token minted successfully (token id: $($tokenData.id))"

        # Step 5: Force-expire password to restore CPM user's normal state
        Write-SetupLog -Level INFO -Message "Expiring temp password for $CPMUserLogin..."
        Invoke-OktaRequest -Path "/api/v1/users/$CPMUserId/lifecycle/expire_password" -Method POST | Out-Null

        return $newToken
    }
    catch {
        # Attempt to expire password even on failure so the CPM user is not left with a known password
        try {
            Invoke-OktaRequest -Path "/api/v1/users/$CPMUserId/lifecycle/expire_password" -Method POST | Out-Null
        }
        catch {
            Write-SetupLog -Level WARN -Message "Could not expire temp password for $CPMUserId after failure. Expire it manually."
        }
        throw
    }
}

#endregion

#region PVWA API

$Script:PVWASession  = $null
$Script:PVWABaseUrl  = $null

function Connect-PVWA {
    <#
    .SYNOPSIS
        Connects to PVWA using the specified authentication method.
        v3.0: Supports CyberArk, LDAP, RADIUS, Windows (on-prem), OAuth2 PKCE,
        OAuth2 Client Credentials (Privilege Cloud), pre-obtained tokens,
        and CA.Auth toolkit delegation.
    #>
    param(
        [Parameter(Mandatory)][string]$Url,
        [System.Management.Automation.PSCredential]$Credential,
        [string]$AuthMethod = 'Auto',
        [string]$Token,
        [string]$TokenType = 'Session',
        [string]$IdentityTenantUrl,
        [string]$ClientId,
        # Accepts either SecureString or plain string (legacy callers) for the OAuth2 client secret.
        [object]$ClientSecret
    )
    # Normalize URL: strip trailing /PasswordVault if user included it
    # (Invoke-PVWARequest adds /PasswordVault at request time to avoid doubling)
    $normalizedUrl = $Url.TrimEnd('/')
    if ($normalizedUrl -match '/PasswordVault$') {
        $normalizedUrl = $normalizedUrl -replace '/PasswordVault$', ''
        Write-SetupLog -Level DEBUG -Message "Stripped /PasswordVault from URL: $normalizedUrl"
    }
    $Script:PVWABaseUrl = $normalizedUrl
    $isCloud = Test-IsPrivilegeCloud -Url $Script:PVWABaseUrl

    # Store auth params for re-auth on 401
    $Script:PVWAAuthParams = @{
        Url              = $Url
        Credential       = $Credential
        AuthMethod       = $AuthMethod
        Token            = $Token
        TokenType        = $TokenType
        IdentityTenantUrl = $IdentityTenantUrl
        ClientId         = $ClientId
        ClientSecret     = $ClientSecret
    }

    # --- Pre-obtained token (fastest path) ---
    if ($Token) {
        Write-SetupLog -Level INFO -Message "Using pre-obtained $TokenType token for PVWA"
        $headerValue = if ($TokenType -eq 'Bearer') { "Bearer $Token" } else { $Token }
        $Script:PVWASession = @{
            Token     = $headerValue
            TokenType = $TokenType
            BaseUrl   = $Script:PVWABaseUrl
        }
        Write-SetupLog -Level OK -Message "PVWA session established (pre-obtained $TokenType token)"
        return
    }

    # --- CA.Auth toolkit delegation (when available) ---
    if ($Script:CAAuthAvailable) {
        Write-SetupLog -Level INFO -Message "Delegating PVWA auth to CA.Auth toolkit (method: $AuthMethod)..."
        try {
            $caAuthParams = @{ PVWAUrl = $Script:PVWABaseUrl }
            if ($Credential)       { $caAuthParams['Credential'] = $Credential }
            if ($IdentityTenantUrl) { $caAuthParams['TenantUrl'] = $IdentityTenantUrl }
            if ($ClientId)         { $caAuthParams['ClientId'] = $ClientId }
            if ($ClientSecret)     { $caAuthParams['ClientSecret'] = $ClientSecret }
            if ($AuthMethod -ne 'Auto') { $caAuthParams['AuthMethod'] = $AuthMethod }

            $caSession = Connect-CAPVWASession @caAuthParams
            $Script:PVWASession = @{
                Token     = $caSession.Token
                TokenType = if ($caSession.TokenType) { $caSession.TokenType } else { 'Session' }
                BaseUrl   = $Script:PVWABaseUrl
                ExpiresAt = $caSession.ExpiresAt
            }
            Write-SetupLog -Level OK -Message "PVWA auth via CA.Auth successful (method: $($caSession.Method))"
            return
        }
        catch {
            Write-SetupLog -Level WARN -Message "CA.Auth delegation failed: $($_.Exception.Message). Falling back to inline auth."
        }
    }

    # --- Auto-detect method ---
    if ($AuthMethod -eq 'Auto') {
        if ($ClientId -and $ClientSecret) {
            $AuthMethod = 'OAuth2_ClientCredentials'
            Write-SetupLog -Level INFO -Message "Auto-detected OAuth2 Client Credentials (client_id provided)"
        }
        elseif ($isCloud) {
            $AuthMethod = 'OAuth2_PKCE'
            Write-SetupLog -Level INFO -Message "Auto-detected Privilege Cloud -- using OAuth2"
        }
        elseif ($Credential) {
            $AuthMethod = 'CyberArk'
            Write-SetupLog -Level INFO -Message "Auto-detected on-prem with credential -- using CyberArk auth"
        }
        else {
            # Default to OAuth2 PKCE as the most common path
            $AuthMethod = 'OAuth2_PKCE'
            Write-SetupLog -Level INFO -Message "Defaulting to OAuth2 auth (override with -AuthMethod if needed)"
        }
    }

    # --- OAuth2 Client Credentials ---
    if ($AuthMethod -eq 'OAuth2_ClientCredentials') {
        if (-not $IdentityTenantUrl) {
            $IdentityTenantUrl = Read-Host 'Identity Tenant URL (e.g. https://abc1234.id.cyberark.cloud)'
        }
        if (-not $ClientId)     { $ClientId = Read-Host 'OAuth2 Client ID' }
        if (-not $ClientSecret) { $ClientSecret = Get-SecureInput -Prompt 'OAuth2 Client Secret' }

        # Resolve SecureString to plaintext for the HTTP body
        $clientSecretPlain = if ($ClientSecret -is [SecureString]) {
            ConvertFrom-SecureStringPlain -Secure $ClientSecret
        } else { $ClientSecret }

        Write-SetupLog -Level INFO -Message "Authenticating via OAuth2 Client Credentials to $IdentityTenantUrl..."
        # Privilege Cloud requires /oauth2/platformtoken for PVWA-scoped API access.
        # The standard /oauth2/token returns an Identity-scoped token without PVWA permissions.
        # The old /oauth2/token/oag-token endpoint is not valid for Privilege Cloud tenants.
        $tokenUrl = "$($IdentityTenantUrl.TrimEnd('/'))/oauth2/platformtoken"
        # URL-encode credentials to handle special characters (@ % ? : etc.)
        $encodedId     = [System.Net.WebUtility]::UrlEncode($ClientId)
        $encodedSecret = [System.Net.WebUtility]::UrlEncode($clientSecretPlain)
        $tokenBodyStr  = "grant_type=client_credentials&client_id=$encodedId&client_secret=$encodedSecret"
        $tokenResp = Invoke-RestMethod -Uri $tokenUrl -Method POST `
            -Body $tokenBodyStr -ContentType 'application/x-www-form-urlencoded' -UseBasicParsing
        Clear-SensitiveString -StringRef ([ref]$clientSecretPlain)
        $Script:PVWASession = @{
            Token     = "Bearer $($tokenResp.access_token)"
            TokenType = 'Bearer'
            BaseUrl   = $Script:PVWABaseUrl
            ExpiresAt = (Get-Date).AddSeconds($tokenResp.expires_in - 60)
        }
        Write-SetupLog -Level OK -Message "PVWA OAuth2 Client Credentials auth successful"
        return
    }

    # --- OAuth2 PKCE (needs CA.Auth or fall back to token prompt) ---
    if ($AuthMethod -eq 'OAuth2_PKCE') {
        Write-SetupLog -Level INFO -Message "OAuth2 PKCE selected but CA.Auth toolkit not available."
        Write-Host ''
        Write-Host '  To authenticate, provide a Bearer token from one of:' -ForegroundColor Yellow
        Write-Host '    - CyberArk Identity portal (Admin > Settings > API Keys)' -ForegroundColor DarkGray
        Write-Host '    - psPAS: Get-PASSession | Select -Expand SessionToken' -ForegroundColor DarkGray
        Write-Host '    - Identity CLI: cyberark-identity auth' -ForegroundColor DarkGray
        Write-Host ''
        $fallbackToken = Get-SecureInput -Prompt '  Paste Bearer token (or press Enter to try Client Credentials instead)'
        if (-not [string]::IsNullOrWhiteSpace($fallbackToken)) {
            $Script:PVWASession = @{
                Token     = "Bearer $fallbackToken"
                TokenType = 'Bearer'
                BaseUrl   = $Script:PVWABaseUrl
            }
            Write-SetupLog -Level OK -Message "PVWA session established (interactive Bearer token)"
            return
        }
        # Fall through to Client Credentials prompt
        Write-SetupLog -Level INFO -Message "No Bearer token -- trying OAuth2 Client Credentials..."
        if (-not $IdentityTenantUrl) {
            $IdentityTenantUrl = Read-Host '  Identity Tenant URL (e.g. https://abc1234.id.cyberark.cloud)'
        }
        $ClientId     = Read-Host '  OAuth2 Client ID'
        $ClientSecret = Read-Host -Prompt '  OAuth2 Client Secret' -AsSecureString
        if ($ClientId -and $ClientSecret) {
            $clientSecretPlain2 = if ($ClientSecret -is [SecureString]) {
                ConvertFrom-SecureStringPlain -Secure $ClientSecret
            } else { $ClientSecret }
            $tokenUrl = "$($IdentityTenantUrl.TrimEnd('/'))/oauth2/token/oag-token"
            $tokenBody = @{
                grant_type    = 'client_credentials'
                client_id     = $ClientId
                client_secret = $clientSecretPlain2
            }
            $tokenResp = Invoke-RestMethod -Uri $tokenUrl -Method POST `
                -Body $tokenBody -ContentType 'application/x-www-form-urlencoded' -UseBasicParsing
            Clear-SensitiveString -StringRef ([ref]$clientSecretPlain2)
            $Script:PVWASession = @{
                Token     = "Bearer $($tokenResp.access_token)"
                TokenType = 'Bearer'
                BaseUrl   = $Script:PVWABaseUrl
                ExpiresAt = (Get-Date).AddSeconds($tokenResp.expires_in - 60)
            }
            Write-SetupLog -Level OK -Message "PVWA OAuth2 Client Credentials auth successful"
            return
        }
        throw "No PVWA authentication credentials provided. Cannot continue without PVWA access."
    }

    # --- Legacy interactive auth (CyberArk, LDAP, RADIUS, Windows) ---
    # Kept for on-prem environments where these methods still work.
    if (-not $Credential) {
        Write-SetupLog -Level WARN -Message "Auth method '$AuthMethod' requires credentials."
        if (-not $WhatIfPreference) {
            $Credential = Get-Credential -Message "PVWA credentials for $AuthMethod auth"
        }
        if (-not $Credential) {
            throw "No credential provided for auth method '$AuthMethod'."
        }
    }

    $authEndpoint = switch ($AuthMethod) {
        'CyberArk' { '/PasswordVault/api/Auth/CyberArk/Logon' }
        'LDAP'     { '/PasswordVault/api/Auth/LDAP/Logon' }
        'RADIUS'   { '/PasswordVault/api/Auth/RADIUS/Logon' }
        'Windows'  { '/PasswordVault/api/Auth/Windows/Logon' }
        default    { throw "Unsupported auth method: $AuthMethod" }
    }

    $body = @{
        username = $Credential.UserName
        password = $Credential.GetNetworkCredential().Password
    }
    Write-SetupLog -Level INFO -Message "Authenticating to PVWA at $Script:PVWABaseUrl (method: $AuthMethod)..."
    $resp = Invoke-RestMethod -Uri "$Script:PVWABaseUrl$authEndpoint" `
        -Method POST `
        -Body ($body | ConvertTo-Json) `
        -ContentType 'application/json' `
        -UseBasicParsing
    $bodyPassword = $body.password
    Clear-SensitiveString -StringRef ([ref]$bodyPassword)
    $body.password = $null

    $tokenValue = if ($resp -is [string]) { $resp.Trim('"') } else { $resp }
    $Script:PVWASession = @{
        Token     = $tokenValue
        TokenType = 'Session'
        BaseUrl   = $Script:PVWABaseUrl
    }
    Write-SetupLog -Level OK -Message "PVWA authentication successful (method: $AuthMethod)"
}

function Disconnect-PVWA {
    if (-not $Script:PVWASession) { return }
    try {
        # Logoff is session cleanup, not a data-modifying operation.
        # Call directly via Invoke-WebRequest to bypass Invoke-PVWARequest's WhatIf suppression.
        $url = "$($Script:PVWASession.BaseUrl)/PasswordVault/api/Auth/Logoff"
        $headers = @{ 'Authorization' = $Script:PVWASession.Token; 'Content-Type' = 'application/json' }
        try {
            Invoke-WebRequest -Uri $url -Method POST -Headers $headers -UseBasicParsing | Out-Null
        }
        catch {}  # Best-effort; session may have expired
        Write-SetupLog -Level INFO -Message "PVWA session closed"
    }
    catch { Write-SetupLog -Level WARN -Message "PVWA logoff failed (session may have expired): $_" }
    finally { $Script:PVWASession = $null }
}

function Get-PVWAErrorBody {
    <#
    .SYNOPSIS
        Extracts the error body from a WebException, handling both PS 5.1 and PS 7 patterns.
    #>
    param([System.Management.Automation.ErrorRecord]$ErrorRecord)

    # PS 7 path: ErrorDetails.Message is populated automatically
    if ($ErrorRecord.ErrorDetails -and $ErrorRecord.ErrorDetails.Message) {
        return $ErrorRecord.ErrorDetails.Message
    }
    # PS 5.1 path: read the response stream
    try {
        if ($ErrorRecord.Exception.Response) {
            $stream = $ErrorRecord.Exception.Response.GetResponseStream()
            if ($null -ne $stream) {
                $reader = [System.IO.StreamReader]::new($stream)
                $body = $reader.ReadToEnd()
                $reader.Dispose()
                return $body
            }
        }
    }
    catch {}
    return ''
}

function Invoke-PVWARequest {
    param(
        [Parameter(Mandatory)][string]$Path,
        [ValidateSet('GET','POST','PUT','PATCH','DELETE')][string]$Method = 'GET',
        [object]$Body = $null,
        [int]$MaxRetries = 3
    )
    # In WhatIf mode, write operations (POST/PUT/PATCH/DELETE) are suppressed.
    # GETs are allowed through so idempotency checks ("does this safe already exist?")
    # return accurate results and the WhatIf output reflects true delta.
    if ($WhatIfPreference -and $Method -ne 'GET') {
        Write-SetupLog -Level DEBUG -Message "[WhatIf] Suppressed $Method $Path"
        return $null
    }

    if (-not $Script:PVWASession) {
        if ($WhatIfPreference) {
            Write-SetupLog -Level DEBUG -Message "[WhatIf] No PVWA session -- cannot execute GET $Path"
            return $null
        }
        throw "Not connected to PVWA. Call Connect-PVWA first."
    }

    $url = "$($Script:PVWASession.BaseUrl)/PasswordVault$Path"
    $tokenType = if ($Script:PVWASession.TokenType) { $Script:PVWASession.TokenType } else { 'Session' }
    $authHeader = $Script:PVWASession.Token
    $headers = @{
        'Authorization'          = $authHeader
        'Content-Type'           = 'application/json'
        'X-PVWA-Correlation-Id'  = $Script:CorrelationId
    }

    $attempt = 0
    do {
        $attempt++
        try {
            $params = @{
                Uri     = $url
                Method  = $Method
                Headers = $headers
                UseBasicParsing = $true
            }
            if ($null -ne $Body) { $params['Body'] = ($Body | ConvertTo-Json -Depth 10) }

            $resp = Invoke-WebRequest @params
            if ($resp.Content) { return ($resp.Content | ConvertFrom-Json) }
            return $null
        }
        catch {
            $status = $null
            if ($_.Exception.PSObject.Properties.Match('Response').Count -gt 0 -and
                $null -ne $_.Exception.Response) {
                $status = [int]$_.Exception.Response.StatusCode
            }

            # 401: attempt re-authentication once (session may have expired during long runs)
            if ($status -eq 401 -and $attempt -eq 1 -and $Script:PVWAAuthParams) {
                Write-SetupLog -Level WARN -Message "PVWA $Method $Path => 401 (session expired). Re-authenticating..."
                try {
                    Connect-PVWA @Script:PVWAAuthParams
                    # Update headers with new token
                    $headers['Authorization'] = $Script:PVWASession.Token
                    continue
                }
                catch {
                    Write-SetupLog -Level ERROR -Message "Re-authentication failed: $($_.Exception.Message)"
                }
            }

            # 429/503: retryable with exponential backoff + jitter
            if ($status -in @(429, 503) -and $attempt -lt $MaxRetries) {
                $baseWait = [Math]::Pow(2, $attempt)
                $jitter   = (Get-Random -Minimum 0 -Maximum 1000) / 1000.0
                $wait     = [int]($baseWait + $jitter)
                if ($wait -gt 60) { $wait = 60 }
                Write-SetupLog -Level WARN -Message "PVWA $Method $Path => $status. Retry $attempt/$MaxRetries in ${wait}s..."
                Start-Sleep -Seconds $wait
            }
            else {
                $errBody = Get-PVWAErrorBody -ErrorRecord $_
                throw "PVWA $Method $Path failed (HTTP $status): $errBody"
            }
        }
    } while ($attempt -lt $MaxRetries)
}

#endregion

#region Pre-flight and Naming

function Resolve-TenantId {
    param([string]$OktaDomain, [string]$UserProvided)
    if ($UserProvided) { return $UserProvided.ToLower() }
    # Derive from subdomain: "integrator-5941494.okta.com" -> "integrator-5941494"
    $derived = $OktaDomain.Split('.')[0].ToLower()
    return $derived
}

function Resolve-NamingDefaults {
    <#
    .SYNOPSIS
        Builds a naming hashtable from parameters and TenantId.
        Prompts the user to confirm or override each name.
    #>
    param(
        [string]$TenantId,
        [string]$PasswordSafe,
        [string]$MFASafe,
        [string]$CPMSafe,
        [string]$BGSafe,
        [string]$UsersGroup,
        [string]$ApproversGroup
    )

    $defaults = @{
        PasswordSafe    = Get-FirstNonNull @($PasswordSafe, "Okta-$TenantId-HLA-Passwords")
        MFASafe         = Get-FirstNonNull @($MFASafe, "Okta-$TenantId-HLA-MFAKeys")
        CPMSafe         = Get-FirstNonNull @($CPMSafe, "Okta-$TenantId-CPM-ServiceAccounts")
        BGSafe          = Get-FirstNonNull @($BGSafe, "Okta-$TenantId-BreakGlass")
        UsersGroup      = Get-FirstNonNull @($UsersGroup, 'Okta-HLA-Users')
        ApproversGroup  = Get-FirstNonNull @($ApproversGroup, 'Okta-HLA-Approvers')
    }

    Write-Host ''
    Write-Host '--- Naming Confirmation ---' -ForegroundColor White
    Write-Host "TenantId        : $TenantId"
    Write-Host "Password Safe   : $($defaults.PasswordSafe)"
    Write-Host "MFA Safe        : $($defaults.MFASafe)"
    Write-Host "CPM Safe        : $($defaults.CPMSafe)"
    Write-Host "BreakGlass Safe : $($defaults.BGSafe)"
    Write-Host "Users Group     : $($defaults.UsersGroup)"
    Write-Host "Approvers Group : $($defaults.ApproversGroup)"
    Write-Host ''

    if ($AcceptDefaults) {
        Write-SetupLog -Level INFO -Message 'AcceptDefaults: using naming defaults without prompting'
    }
    elseif (-not (Confirm-UserChoice -Prompt 'Accept these names?' -Default 'Y')) {
        foreach ($key in @($defaults.Keys | Sort-Object)) {
            $override = Read-Host "  $key [$($defaults[$key])]"
            if (-not [string]::IsNullOrWhiteSpace($override)) { $defaults[$key] = $override.Trim() }
        }
    }
    return $defaults
}

function Show-PreflightSummary {
    param(
        [hashtable]$Config
    )
    Write-Host ''
    Write-Host '============================================================' -ForegroundColor White
    Write-Host " Okta HLA Vault Setup v$Script:VERSION -- Pre-flight Summary" -ForegroundColor White
    Write-Host '============================================================' -ForegroundColor White
    Write-Host "  PVWA URL        : $($Config.PVWAUrl)"
    Write-Host "  Okta Domain     : $($Config.OktaDomain)"
    Write-Host "  Token Level     : $Script:OktaTokenLevel"
    Write-Host "  TenantId        : $($Config.TenantId)"
    Write-Host "  Tiers in scope  : $($Config.IncludeTiers -join ',')"
    Write-Host "  Enroll TOTP     : $($Config.EnrollTOTP)"
    Write-Host "  Simulate        : $($Config.Simulate)"
    Write-Host "  WhatIf          : $($WhatIfPreference)"
    Write-Host '------------------------------------------------------------' -ForegroundColor DarkGray
    Write-Host "  Password Safe   : $($Config.Naming.PasswordSafe)"
    Write-Host "  MFA Safe        : $($Config.Naming.MFASafe)"
    Write-Host "  CPM Safe        : $($Config.Naming.CPMSafe)"
    Write-Host "  BreakGlass Safe : $($Config.Naming.BGSafe)"
    Write-Host "  Users Group     : $($Config.Naming.UsersGroup)"
    Write-Host "  Approvers Group : $($Config.Naming.ApproversGroup)"
    Write-Host '============================================================' -ForegroundColor White
    Write-Host ''
}

function Confirm-Proceed {
    param([hashtable]$Config)
    Show-PreflightSummary -Config $Config
    if ($WhatIfPreference) {
        Write-SetupLog -Level INFO -Message '[WhatIf] Validation complete. No changes will be made.'
        return $true
    }
    if ($AcceptDefaults) {
        Write-SetupLog -Level INFO -Message 'AcceptDefaults: proceeding without confirmation prompt'
        return $true
    }
    return (Confirm-UserChoice -Prompt 'Proceed with setup?' -Default 'Y')
}

#endregion

#region Platform Import

function Test-PVWAConnectivity {
    <#
    .SYNOPSIS
        Tests PVWA connectivity by trying multiple endpoints in order.
        /api/Server/Verify is preferred but not available on all versions.
        Falls back to /api/ComponentsMonitoringDetails/Safes (lightweight GET).
        Returns the response from the first successful endpoint.
    #>
    Write-SetupLog -Level INFO -Message 'Testing PVWA connectivity...'

    # Try primary endpoint
    try {
        $resp = Invoke-PVWARequest -Path '/api/Server/Verify'
        Write-SetupLog -Level OK -Message "PVWA reachable. Version: $($resp.ServerVersion)"
        return $resp
    }
    catch {
        Write-SetupLog -Level DEBUG -Message "Server/Verify not available: $($_.Exception.Message)"
    }

    # Fallback: lightweight safe listing (limit 1) -- works on all versions
    try {
        $resp = Invoke-PVWARequest -Path '/api/Safes?limit=1'
        $safeCount = if ($null -ne $resp -and $resp.Total) { $resp.Total } else { 'unknown' }
        Write-SetupLog -Level OK -Message "PVWA reachable (via Safes endpoint). Total safes: $safeCount"
        return $resp
    }
    catch {
        Write-SetupLog -Level DEBUG -Message "Safes endpoint also failed: $($_.Exception.Message)"
    }

    # Both failed -- throw with diagnostic info
    $testUrl = "$($Script:PVWASession.BaseUrl)/PasswordVault/api/Server/Verify"
    throw "PVWA not reachable at $($Script:PVWASession.BaseUrl). Tested: /api/Server/Verify and /api/Safes. Verify the URL does not include /PasswordVault (it is added automatically). Expected format: https://tenant.privilegecloud.cyberark.cloud"
}

function Test-CyberArkPlatform {
    param([string]$PlatformId = $Script:OKTA_PLATFORM)
    try {
        $resp = Invoke-PVWARequest -Path "/api/Platforms/Targets/$([uri]::EscapeDataString($PlatformId))"
        return $resp
    }
    catch {
        if ($_ -match 'HTTP 404') { return $null }
        throw
    }
}

function Test-CyberArkBasePlatform {
    <#
    .SYNOPSIS
        Verifies the parent platform referenced by Policy-OktaCloud.xml's
        PlatformBaseID is present in the vault before the OktaCloud import.

        Custom REST API platforms inherit from a parent platform (typically
        SampleRestAPIPlatform from CyberArk's REST API Framework marketplace
        zip) via the PlatformBaseID attribute. If the parent is not imported,
        the OktaCloud import will fail with "base platform not found".

        The parent platform can (and should) be left Active=No after import.
        It's a template parent, not an end-user platform; deactivating it
        keeps it out of end-user platform lists while preserving inheritance.

        Fix if absent: download Plugin.RestAPIFramework-vXX.X.X.X-Master.zip
        from CyberArk Marketplace and import via PVWA > Administration >
        Platform Management > Import Platform.
    #>
    param([Parameter(Mandatory)][string]$SourceDirectory)

    $policyXmlPath = Join-Path $SourceDirectory 'Policy-OktaCloud.xml'
    if (-not (Test-Path $policyXmlPath)) {
        Write-SetupLog -Level WARN -Message "Policy-OktaCloud.xml not found at $policyXmlPath; skipping base-platform check"
        return
    }

    try {
        $policyXml = [xml](Get-Content -Raw -Path $policyXmlPath)
        $basePlatformId = $policyXml.Device.Policies.Policy.PlatformBaseID
    }
    catch {
        Write-SetupLog -Level WARN -Message "Could not parse Policy-OktaCloud.xml to read PlatformBaseID: $($_.Exception.Message). Skipping base-platform check."
        return
    }

    if ([string]::IsNullOrWhiteSpace($basePlatformId)) {
        Write-SetupLog -Level INFO -Message "Policy-OktaCloud.xml has no PlatformBaseID attribute; skipping base-platform check"
        return
    }

    if ($basePlatformId -eq $Script:OKTA_PLATFORM) {
        Write-SetupLog -Level WARN -Message "Policy-OktaCloud.xml uses self-referential PlatformBaseID='$basePlatformId'. This is not the documented CyberArk pattern; the recommended parent is 'SampleRestAPIPlatform' from the REST API Framework marketplace zip."
        return
    }

    Write-SetupLog -Level INFO -Message "Checking base platform '$basePlatformId' is present in vault..."
    try {
        $base = Test-CyberArkPlatform -PlatformId $basePlatformId
    }
    catch {
        Write-SetupLog -Level WARN -Message "Could not verify base platform '$basePlatformId' (PVWA query failed): $($_.Exception.Message). Proceeding; CyberArk will reject the import if the base is missing."
        return
    }

    if ($null -eq $base) {
        throw "Base platform '$basePlatformId' not found in vault. The OktaCloud platform inherits from it via Policy-OktaCloud.xml's PlatformBaseID, so import will fail. Fix: download Plugin.RestAPIFramework-vXX.X.X.X-Master.zip from CyberArk Marketplace and import via PVWA > Administration > Platform Management > Import Platform. The base platform can be left Active=No after import."
    }

    Write-SetupLog -Level OK -Message "Base platform '$basePlatformId' present (required parent for REST API platforms)"
}

function Test-PlatformPlaceholders {
    <#
    .SYNOPSIS
        Validates that OktaCloudConfiguration.xml uses the REST API Applications CPM
        Plugin Framework placeholder grammar for the SSWS Authorization header.

        Correct grammar (per CyberArk REST API placeholder docs):
          - {{logonaccount\password}}                          (LogonAccount, PropertyIndex 1)
          - {{reconcileaccount\password}}                      (ReconcileAccount, PropertyIndex 3)
          - {{logonaccountORreconcileaccount\password}}        (OR-fallback)
        Account-type tokens MUST be lowercase; separator MUST be backslash.

        Legacy CPM placeholders (NOT defined in the REST API framework -- reported
        as "not defined" by CPM at runtime; the underlying cause of prior error 8014
        reports where swapping between {{ExtraPass1}} and {{ExtraPass3}} only
        changed which wrong name was rejected):
          - {{ExtraPass1}}, {{ExtraPass3}}
          - {{ExtraPass1.Password}}
          - {{LogonPassword}}

        If the wrong placeholder is used, the Authorization header is sent as
        literal text and all CPM operations silently fail with 401 from Okta.
    #>
    param([Parameter(Mandatory)][string]$SourceDirectory)

    $configFile = Join-Path $SourceDirectory 'OktaCloudConfiguration.xml'
    if (-not (Test-Path $configFile)) { return }

    $content = Get-Content -Path $configFile -Raw

    # CyberArk's static CPMXMLFileValidator regex-scans the ENTIRE file including
    # XML comments. Legacy placeholders (e.g. {{ExtraPass1.Password}}) accidentally
    # left in a documentation comment block will cause platform import to fail with
    # "Invalid placeholder key format" / "Failed to replace placeholders in manifest
    # file". Detect this case and warn before deploy.
    $commentMatches = [regex]::Matches($content, '(?s)<!--(.*?)-->')
    $commentPlaceholders = New-Object System.Collections.Generic.HashSet[string]
    foreach ($cm in $commentMatches) {
        foreach ($ph in [regex]::Matches($cm.Groups[1].Value, '\{\{[^}]+\}\}')) {
            [void]$commentPlaceholders.Add($ph.Value)
        }
    }
    if ($commentPlaceholders.Count -gt 0) {
        Write-SetupLog -Level WARN -Message "OktaCloudConfiguration.xml has $($commentPlaceholders.Count) placeholder pattern(s) inside XML comments: $(($commentPlaceholders | Sort-Object) -join ', '). CyberArk's CPMXMLFileValidator regex-scans entire files including comments and will reject any unrecognized placeholder name -- even legacy examples kept only for documentation. Remove the {{ }} wrapping from comments and use plain text references instead."
    }

    # Strip XML comments before the live-XML scans below -- otherwise the legacy
    # detector double-counts comment-embedded examples (already flagged above).
    $scan = [regex]::Replace($content, '(?s)<!--.*?-->', '')

    # Detect any legacy ExtraPass-style or LogonPassword placeholder in live XML
    # (i.e. outside comments). The REST API framework does not recognize any of
    # these and will report them as not defined.
    $legacyHits = [regex]::Matches(
        $scan,
        '\{\{(ExtraPass\d+(\.Password)?|LogonPassword)\}\}'
    ) | ForEach-Object { $_.Value } | Select-Object -Unique
    if ($legacyHits.Count -gt 0) {
        Write-SetupLog -Level ERROR -Message "OktaCloudConfiguration.xml contains legacy CPM placeholders not defined by the REST API Plugin Framework: $($legacyHits -join ', '). Replace with REST API grammar, e.g. {{logonaccount\password}}. See header comment in the file for full grammar details."
    }

    # Look for REST API grammar references to a linked-account password. Pattern matches
    # both single and OR-chained account types, with an optional |modifier suffix.
    $restApiPattern = '\{\{(?:[a-z]+(?:OR[a-z]+)*)\\password(?:\|[A-Za-z]+)*\}\}'
    $restApiHits = [regex]::Matches($scan, $restApiPattern) |
        ForEach-Object { $_.Value } | Select-Object -Unique

    if ($restApiHits.Count -gt 0) {
        Write-SetupLog -Level INFO -Message "Platform SSWS placeholder validated (REST API grammar): $($restApiHits -join ', ')"
    }
    elseif ($legacyHits.Count -eq 0) {
        Write-SetupLog -Level WARN -Message "OktaCloudConfiguration.xml does not contain a recognizable SSWS placeholder. Expected REST API grammar like {{logonaccount\password}} in the Authorization header."
    }
}

function Import-CyberArkPlatform {
    param([Parameter(Mandatory)][string]$SourceDirectory)

    $files = @(
        'OktaCloudConfiguration.xml',
        'Policy-OktaCloud.ini',
        'Policy-OktaCloud.xml'
    )
    foreach ($f in $files) {
        if (-not (Test-Path (Join-Path $SourceDirectory $f))) {
            throw "Platform file not found: $(Join-Path $SourceDirectory $f)"
        }
    }

    # Pre-import sanity checks: parent platform must exist in vault, and the
    # config XML must use the REST API placeholder grammar (no legacy ExtraPass).
    Test-CyberArkBasePlatform -SourceDirectory $SourceDirectory
    Test-PlatformPlaceholders -SourceDirectory $SourceDirectory

    $zipPath = Join-Path ([System.IO.Path]::GetTempPath()) "OktaCloud-$(Get-Date -Format yyyyMMddHHmmss).zip"
    Write-SetupLog -Level INFO -Message "Creating platform ZIP at $zipPath..."
    $filePaths = $files | ForEach-Object { Join-Path $SourceDirectory $_ }
    Compress-Archive -Path $filePaths -DestinationPath $zipPath -Force

    $zipBytes  = [System.IO.File]::ReadAllBytes($zipPath)
    $b64       = [Convert]::ToBase64String($zipBytes)
    Remove-Item $zipPath -Force -ErrorAction SilentlyContinue

    Write-SetupLog -Level INFO -Message "Importing OktaCloud platform to PVWA..."
    if (-not $WhatIfPreference) {
        $resp = Invoke-PVWARequest -Path '/api/Platforms/Import' -Method POST -Body @{ ImportFile = $b64 }
        Write-SetupLog -Level OK -Message "Platform imported: $($resp.PlatformID)"
        return $resp
    }
    else {
        Write-SetupLog -Level INFO -Message '[WhatIf] Would POST /api/Platforms/Import'
        return $null
    }
}

function Enable-CyberArkPlatform {
    param([string]$PlatformId = $Script:OKTA_PLATFORM)
    Write-SetupLog -Level INFO -Message "Activating platform $PlatformId..."
    if (-not $WhatIfPreference) {
        Invoke-PVWARequest -Path "/api/Platforms/Targets/$([uri]::EscapeDataString($PlatformId))/Activate" -Method POST | Out-Null

        # Verify the platform is actually active after activation
        $platformState = Test-CyberArkPlatform -PlatformId $PlatformId
        if ($null -eq $platformState) {
            throw "Platform $PlatformId not found after activation attempt. Import may have failed silently."
        }
        $platformActive = $false
        if ($platformState.Active -eq $true) {
            $platformActive = $true
        }
        elseif ($null -ne $platformState.Details -and $platformState.Details.Active -eq $true) {
            $platformActive = $true
        }
        if (-not $platformActive) {
            throw "Platform $PlatformId exists but is not Active after activation. Current state: $($platformState | ConvertTo-Json -Depth 3 -Compress)"
        }

        Write-SetupLog -Level OK -Message "Platform $PlatformId activated and verified"
    }
    else { Write-SetupLog -Level INFO -Message "[WhatIf] Would POST /api/Platforms/Targets/$PlatformId/Activate" }
}

#endregion

#region PSM Connection Components

function Get-WebFormXmlPath {
    <#
    .SYNOPSIS
        Resolves the path to a WebFormFields XML file in the psm/okta-oie-webform directory.
    #>
    param(
        [ValidateSet('Hardened','Native','PreConnect')]
        [string]$Variant = 'Hardened'
    )
    $fileName = switch ($Variant) {
        'Hardened'   { 'PSM-OktaOIE-WebForm-Hardened.xml' }
        'Native'     { 'PSM-OktaOIE-WebForm-Native.xml' }
        'PreConnect' { 'PSM-OktaOIE-WebForm-PreConnect.xml' }
    }
    $candidates = @(
        (Join-Path (Join-Path $PSScriptRoot '..\psm\okta-oie-webform') $fileName),
        (Join-Path (Join-Path $PSScriptRoot '..\..\psm\okta-oie-webform') $fileName)
    )
    foreach ($c in $candidates) {
        if (Test-Path $c) { return (Resolve-Path $c).Path }
    }
    return $null
}

function Test-ConnectionComponent {
    <#
    .SYNOPSIS
        Checks if a PSM connection component exists in PVWA by ID.
        Returns the component object or $null.
    #>
    param([Parameter(Mandatory)][string]$ComponentId)
    try {
        $result = Invoke-PVWARequest -Path "/api/ConnectionComponents/$([uri]::EscapeDataString($ComponentId))"
        return $result
    }
    catch {
        if ($_ -match 'HTTP 404') { return $null }
        # Some PVWA versions don't support direct GET by ID -- try list endpoint
        try {
            $all = Invoke-PVWARequest -Path '/api/ConnectionComponents'
            if ($null -ne $all) {
                $components = if ($all.ConnectionComponents) { $all.ConnectionComponents } else { $all }
                $match = $components | Where-Object {
                    $_.Id -eq $ComponentId -or $_.ConnectionComponentID -eq $ComponentId
                }
                return $match
            }
        }
        catch {}
        return $null
    }
}

function Import-ConnectionComponentFromXml {
    <#
    .SYNOPSIS
        Deploys a PSM connection component from a WebFormFields XML definition.
        Tries three approaches in order:
          1. Direct API: POST /api/ConnectionComponents (create) + PUT properties
             -- most reliable for Privilege Cloud
          2. ZIP Import: POST /api/ConnectionComponents/Import
             -- works on-prem v12.2+
          3. Manual steps: prints exact PVWA admin console instructions
    .OUTPUTS
        $true if deployment succeeded via API, $false if manual steps were printed.
    #>
    param(
        [Parameter(Mandatory)][string]$XmlPath,
        [Parameter(Mandatory)][string]$ComponentId
    )

    Write-SetupLog -Level INFO -Message "Deploying connection component '$ComponentId' from $XmlPath..."

    if ($WhatIfPreference) {
        Write-SetupLog -Level INFO -Message "[WhatIf] Would deploy connection component from $XmlPath"
        return $true
    }

    # Parse the XML to extract properties
    $ccProperties = @{}
    $webFormFields = ''
    $displayName = $ComponentId
    try {
        [xml]$ccXml = Get-Content $XmlPath -Raw
        $node = $ccXml.ConnectionComponent
        foreach ($prop in $node.Properties.Property) {
            $ccProperties[$prop.Name] = $prop.Value
        }
        if ($ccProperties.ContainsKey('WebFormFields')) {
            $webFormFields = $ccProperties['WebFormFields']
        }
        if ($ccProperties.ContainsKey('DisplayName')) {
            $displayName = $ccProperties['DisplayName']
        }
    }
    catch {
        Write-SetupLog -Level WARN -Message "Could not parse XML: $($_.Exception.Message)"
    }

    # ---- Approach 1: Direct API (create + configure) ----
    # Most reliable for Privilege Cloud -- creates the component shell, then sets properties.
    try {
        Write-SetupLog -Level INFO -Message "Trying direct API creation for '$ComponentId'..."
        $createBody = @{
            Id            = $ComponentId
            DisplayName   = $displayName
            ComponentType = 'WebApplication'
        }
        $createResult = Invoke-PVWARequest -Path '/api/ConnectionComponents' -Method POST -Body $createBody

        if ($null -ne $createResult) {
            Write-SetupLog -Level OK -Message "Connection component '$ComponentId' created via API"

            # Set properties (LogonURL, timeouts, WebFormFields, etc.)
            $propsToSet = @{
                LogonURL                       = Get-FirstNonNull @($ccProperties['LogonURL'], 'https://{Address}')
                WebAppType                     = Get-FirstNonNull @($ccProperties['WebAppType'], 'Web')
                ActionTimeout                  = Get-FirstNonNull @($ccProperties['ActionTimeout'], '15')
                PageLoadTimeout                = Get-FirstNonNull @($ccProperties['PageLoadTimeout'], '30')
                ConnectionComponentInitTimeout = Get-FirstNonNull @($ccProperties['ConnectionComponentInitTimeout'], '60')
                EnableAdvancedDebugging        = Get-FirstNonNull @($ccProperties['EnableAdvancedDebugging'], 'No')
                EnableTrace                    = Get-FirstNonNull @($ccProperties['EnableTrace'], 'No')
                EnforceCertificateValidation   = Get-FirstNonNull @($ccProperties['EnforceCertificateValidation'], 'Yes')
            }
            if ($webFormFields) { $propsToSet['WebFormFields'] = $webFormFields }

            try {
                Invoke-PVWARequest -Path "/api/ConnectionComponents/$([uri]::EscapeDataString($ComponentId))" -Method PUT -Body $propsToSet | Out-Null
                Write-SetupLog -Level OK -Message "Properties configured on '$ComponentId'"
            }
            catch {
                Write-SetupLog -Level WARN -Message "Component created but property configuration failed: $($_.Exception.Message)"
                Write-SetupLog -Level INFO -Message 'WebFormFields may need to be set manually in PVWA admin console.'
            }

            Register-Operation -Type Created
            return $true
        }
    }
    catch {
        $errMsg = $_.Exception.Message
        if ($errMsg -match '409' -or $errMsg -match 'already exists' -or $errMsg -match 'ITATS') {
            Write-SetupLog -Level SKIP -Message "'$ComponentId' already exists (409 from create)"
            Register-Operation -Type Skipped
            return $true
        }
        Write-SetupLog -Level DEBUG -Message "Direct API creation failed: $errMsg"
    }

    # ---- Approach 2: ZIP Import ----
    # Works on-prem v12.2+. May not work in Privilege Cloud.
    $tempDir = $null
    $tempZip = $null
    try {
        Write-SetupLog -Level INFO -Message "Trying ZIP import for '$ComponentId'..."
        $tempDir  = Join-Path ([System.IO.Path]::GetTempPath()) "ca-cc-import-$([guid]::NewGuid().ToString('N').Substring(0,8))"
        $tempZip  = "$tempDir.zip"
        New-Item $tempDir -ItemType Directory -Force | Out-Null
        Copy-Item $XmlPath (Join-Path $tempDir (Split-Path $XmlPath -Leaf)) -Force

        if (Get-Command Compress-Archive -ErrorAction SilentlyContinue) {
            Compress-Archive -Path "$tempDir\*" -DestinationPath $tempZip -Force
        }
        else {
            Add-Type -AssemblyName System.IO.Compression.FileSystem
            [System.IO.Compression.ZipFile]::CreateFromDirectory($tempDir, $tempZip)
        }

        $zipBytes  = [System.IO.File]::ReadAllBytes($tempZip)
        $zipBase64 = [Convert]::ToBase64String($zipBytes)

        $importBody = @{ ImportFile = $zipBase64 }
        try {
            $null = Invoke-PVWARequest -Path '/api/ConnectionComponents/Import' -Method POST -Body $importBody
            Write-SetupLog -Level OK -Message "Connection component '$ComponentId' imported via ZIP"
            Register-Operation -Type Created
            return $true
        }
        catch {
            Write-SetupLog -Level DEBUG -Message "ConnectionComponents/Import failed: $($_.Exception.Message)"
        }

        try {
            $null = Invoke-PVWARequest -Path '/api/Platforms/Import' -Method POST -Body $importBody
            Write-SetupLog -Level OK -Message "Connection component '$ComponentId' imported via Platforms/Import"
            Register-Operation -Type Created
            return $true
        }
        catch {
            Write-SetupLog -Level DEBUG -Message "Platforms/Import failed: $($_.Exception.Message)"
        }
    }
    catch {
        Write-SetupLog -Level DEBUG -Message "ZIP import failed: $($_.Exception.Message)"
    }
    finally {
        if ($tempDir -and (Test-Path $tempDir))  { Remove-Item $tempDir -Recurse -Force -ErrorAction SilentlyContinue }
        if ($tempZip -and (Test-Path $tempZip))  { Remove-Item $tempZip -Force -ErrorAction SilentlyContinue }
    }

    # ---- Approach 3: Manual steps (fallback) ----
    Write-SetupLog -Level WARN -Message "API deployment not available for '$ComponentId'. Manual steps below."
    Write-Host ''
    Write-Host '--- Manual Connection Component Deployment ---' -ForegroundColor Yellow
    Write-Host "  Component: $ComponentId ($displayName)" -ForegroundColor White
    Write-Host ''
    Write-Host '  In PVWA Admin Console:' -ForegroundColor DarkGray
    Write-Host '  1. Administration > Configuration Options > Privileged Session Management' -ForegroundColor DarkGray
    Write-Host '     > Configured PSM Servers > {Your PSM Server} > Connection Components > Add' -ForegroundColor DarkGray
    Write-Host "  2. Component ID: $ComponentId" -ForegroundColor White
    Write-Host '  3. Type: WebApplication' -ForegroundColor White
    Write-Host "  4. DisplayName: $displayName" -ForegroundColor White
    Write-Host '  5. Set these properties:' -ForegroundColor DarkGray
    Write-Host '     LogonURL = https://{Address}' -ForegroundColor White
    Write-Host '     ActionTimeout = 15' -ForegroundColor White
    Write-Host '     PageLoadTimeout = 30' -ForegroundColor White
    Write-Host '     ConnectionComponentInitTimeout = 60' -ForegroundColor White
    Write-Host '  6. WebFormFields -- copy the full content from:' -ForegroundColor DarkGray
    Write-Host "     $XmlPath" -ForegroundColor Cyan
    Write-Host '     (the <Property Name="WebFormFields"> block, ~300 lines)' -ForegroundColor DarkGray
    Write-Host '  7. Capabilities > Add: LogonAccount' -ForegroundColor DarkGray
    Write-Host '  8. Platforms > OktaCloud > PSM Connection Components > Add > ' -NoNewline
    Write-Host "$ComponentId" -ForegroundColor White
    Write-Host ''
    Register-Operation -Type Failed
    return $false
}

function Add-PlatformConnectionComponent {
    <#
    .SYNOPSIS
        Associates a connection component with the OktaCloud platform.
    #>
    param(
        [string]$PlatformId = $Script:OKTA_PLATFORM,
        [Parameter(Mandatory)][string]$ComponentId
    )

    Write-SetupLog -Level INFO -Message "Associating '$ComponentId' with platform '$PlatformId'..."

    if ($WhatIfPreference) {
        Write-SetupLog -Level INFO -Message "[WhatIf] Would associate '$ComponentId' with '$PlatformId'"
        return
    }

    try {
        # Get current platform PSM configuration
        $psmConfig = Invoke-PVWARequest -Path "/api/Platforms/Targets/$([uri]::EscapeDataString($PlatformId))/PrivilegedSessionManagement"
        if ($null -ne $psmConfig) {
            # Check if already associated
            $existing = $psmConfig.PSMConnectors | Where-Object { $_.PSMConnectorID -eq $ComponentId }
            if ($existing) {
                Write-SetupLog -Level SKIP -Message "'$ComponentId' already associated with platform '$PlatformId'"
                Register-Operation -Type Skipped
                return
            }
        }
    }
    catch {
        Write-SetupLog -Level DEBUG -Message "Could not read platform PSM config: $($_.Exception.Message)"
    }

    # Try to add the association
    try {
        $body = @{
            PSMConnectorID = $ComponentId
            Enabled        = $true
        }
        Invoke-PVWARequest -Path "/api/Platforms/Targets/$([uri]::EscapeDataString($PlatformId))/PrivilegedSessionManagement" -Method PUT -Body $body | Out-Null
        Write-SetupLog -Level OK -Message "'$ComponentId' associated with platform '$PlatformId'"
        Register-Operation -Type Created
    }
    catch {
        Write-SetupLog -Level WARN -Message "Could not auto-associate via API: $($_.Exception.Message)"
        Write-Host "  Manual step: Platforms > OktaCloud > PSM Connection Components > Add > $ComponentId" -ForegroundColor Yellow
    }
}

function Get-PSMServers {
    <#
    .SYNOPSIS
        Discovers configured PSM servers from PVWA.
        Returns an array of PSM server objects with Id and Name.
    #>
    Write-SetupLog -Level INFO -Message 'Discovering configured PSM servers...'

    if ($WhatIfPreference) {
        Write-SetupLog -Level INFO -Message '[WhatIf] Would query PSM servers'
        return @()
    }

    # Try multiple API endpoints (varies by CyberArk version and deployment type)
    $servers = @()

    # Privilege Cloud: ComponentsMonitoringDetails
    try {
        $monitoring = Invoke-PVWARequest -Path '/api/ComponentsMonitoringDetails/PSM'
        if ($null -ne $monitoring) {
            $components = if ($monitoring.Components) { $monitoring.Components } elseif ($monitoring.ComponentsDetails) { $monitoring.ComponentsDetails } else { $monitoring }
            foreach ($comp in $components) {
                $serverId   = Get-FirstNonNull @($comp.ComponentID, $comp.ComponentName, $comp.ServerID, $comp.ServerName)
                $serverName = Get-FirstNonNull @($comp.ComponentName, $comp.ServerName, $comp.ComponentID)
                if ($serverId) {
                    $servers += [PSCustomObject]@{
                        Id          = $serverId
                        Name        = $serverName
                        Connected   = if ($null -ne $comp.Connected) { $comp.Connected } else { $null }
                        LastSeen    = $comp.LastLogonDate
                    }
                }
            }
        }
    }
    catch {
        Write-SetupLog -Level DEBUG -Message "ComponentsMonitoringDetails/PSM not available: $($_.Exception.Message)"
    }

    # On-prem: try admin configuration endpoint
    if ($servers.Count -eq 0) {
        try {
            $psmConfig = Invoke-PVWARequest -Path '/api/Configuration/PrivilegedSessionManagement/ConfiguredPSMServers'
            if ($null -ne $psmConfig) {
                $psmList = if ($psmConfig.ConfiguredPSMServers) { $psmConfig.ConfiguredPSMServers } else { $psmConfig }
                foreach ($psm in $psmList) {
                    $serverId = Get-FirstNonNull @($psm.Id, $psm.PSMServerID, $psm.Name)
                    if ($serverId) {
                        $servers += [PSCustomObject]@{
                            Id          = $serverId
                            Name        = Get-FirstNonNull @($psm.Name, $psm.Id)
                            Connected   = $null
                            LastSeen    = $null
                        }
                    }
                }
            }
        }
        catch {
            Write-SetupLog -Level DEBUG -Message "ConfiguredPSMServers endpoint not available: $($_.Exception.Message)"
        }
    }

    if ($servers.Count -eq 0) {
        Write-SetupLog -Level WARN -Message 'Could not discover PSM servers via API. Server targeting will be skipped.'
    }
    else {
        Write-SetupLog -Level INFO -Message "Discovered $($servers.Count) PSM server(s)"
    }
    return $servers
}

function Add-ConnectionComponentToPSMServer {
    <#
    .SYNOPSIS
        Adds a connection component to a specific PSM server's configuration.
    #>
    param(
        [Parameter(Mandatory)][string]$PSMServerId,
        [Parameter(Mandatory)][string]$ComponentId
    )

    if ($WhatIfPreference) {
        Write-SetupLog -Level INFO -Message "[WhatIf] Would add '$ComponentId' to PSM server '$PSMServerId'"
        return $true
    }

    try {
        # Check if already configured on this server
        $serverConfig = $null
        try {
            $serverConfig = Invoke-PVWARequest -Path "/api/Configuration/PrivilegedSessionManagement/ConfiguredPSMServers/$([uri]::EscapeDataString($PSMServerId))/ConnectionComponents"
        }
        catch {}

        if ($null -ne $serverConfig) {
            $components = if ($serverConfig.ConnectionComponents) { $serverConfig.ConnectionComponents } else { $serverConfig }
            $existing = $components | Where-Object {
                $_.ConnectionComponentID -eq $ComponentId -or $_.Id -eq $ComponentId
            }
            if ($existing) {
                Write-SetupLog -Level SKIP -Message "'$ComponentId' already on PSM server '$PSMServerId'"
                Register-Operation -Type Skipped
                return $true
            }
        }

        # Add the connection component to this server
        $body = @{
            ConnectionComponentID = $ComponentId
            Enabled               = $true
        }
        Invoke-PVWARequest -Path "/api/Configuration/PrivilegedSessionManagement/ConfiguredPSMServers/$([uri]::EscapeDataString($PSMServerId))/ConnectionComponents" -Method POST -Body $body | Out-Null
        Write-SetupLog -Level OK -Message "'$ComponentId' added to PSM server '$PSMServerId'"
        Register-Operation -Type Created
        return $true
    }
    catch {
        Write-SetupLog -Level WARN -Message "Could not add '$ComponentId' to PSM server '$PSMServerId': $($_.Exception.Message)"
        Register-Operation -Type Failed
        return $false
    }
}

function Select-PSMServers {
    <#
    .SYNOPSIS
        Interactive PSM server selection. Discovers servers, presents a menu,
        returns the selected server IDs.
    #>
    param([string]$Purpose = 'connection component deployment')

    $servers = Get-PSMServers
    if ($servers.Count -eq 0) { return @() }

    if ($AcceptDefaults -or $WhatIfPreference) {
        Write-SetupLog -Level INFO -Message "AcceptDefaults: targeting all $($servers.Count) PSM server(s)"
        return $servers
    }

    Write-Host ''
    Write-Host "--- PSM Server Selection ($Purpose) ---" -ForegroundColor White
    Write-Host '  Which PSM servers should receive the connection components?' -ForegroundColor DarkGray
    Write-Host ''

    for ($i = 0; $i -lt $servers.Count; $i++) {
        $s = $servers[$i]
        $statusStr = ''
        if ($null -ne $s.Connected) {
            $statusStr = if ($s.Connected) { ' [Connected]' } else { ' [Disconnected]' }
        }
        $color = if ($s.Connected -eq $false) { 'Yellow' } else { 'DarkGray' }
        Write-Host "    $($i + 1). $($s.Name) (ID: $($s.Id))$statusStr" -ForegroundColor $color
    }

    Write-Host ''
    Write-Host '  Enter server numbers (comma-separated), or "all" for all servers.' -ForegroundColor DarkGray
    Write-Host "  Example: 1,2  or  all  or  <Enter> for all" -ForegroundColor DarkGray
    Write-Host ''

    $serverInput = Read-Host "  Target servers [all]"
    if ([string]::IsNullOrWhiteSpace($serverInput) -or $serverInput.Trim().ToLower() -eq 'all') {
        Write-SetupLog -Level INFO -Message "Targeting all $($servers.Count) PSM server(s)"
        return $servers
    }

    $selected = @()
    foreach ($num in ($serverInput -split '[,\s]+')) {
        $idx = 0
        if ([int]::TryParse($num.Trim(), [ref]$idx) -and $idx -ge 1 -and $idx -le $servers.Count) {
            $selected += $servers[$idx - 1]
        }
        else {
            Write-SetupLog -Level WARN -Message "Invalid server number: $num"
        }
    }

    if ($selected.Count -eq 0) {
        Write-SetupLog -Level WARN -Message 'No valid servers selected. Skipping server-level targeting.'
    }
    else {
        Write-SetupLog -Level INFO -Message "Targeting $($selected.Count) PSM server(s): $(($selected | ForEach-Object { $_.Name }) -join ', ')"
    }
    return $selected
}

#endregion

#region Safes

function Test-CyberArkSafe {
    param([Parameter(Mandatory)][string]$SafeName)
    try {
        return Invoke-PVWARequest -Path "/api/Safes/$([uri]::EscapeDataString($SafeName))"
    }
    catch {
        if ($_ -match 'HTTP 404') { return $null }
        throw
    }
}

function New-HLASafe {
    param(
        [Parameter(Mandatory)][string]$SafeName,
        [string]$Description = '',
        [int]$NumberOfDaysRetention = 30,
        [int]$NumberOfVersionsRetention = 5,
        [string]$CPMName = 'PasswordManager'
    )

    $existing = Test-CyberArkSafe -SafeName $SafeName
    if ($existing) {
        Write-SetupLog -Level SKIP -Message "Safe '$SafeName' already exists -- skipping create"
        Register-Operation -Type Skipped
        return $existing
    }

    Write-SetupLog -Level INFO -Message "Creating safe: $SafeName"

    $body = @{
        SafeName                  = $SafeName
        Description               = $Description
        OLACEnabled               = $false
        ManagingCPM               = $CPMName
        NumberOfDaysRetention     = $NumberOfDaysRetention
        NumberOfVersionsRetention = $NumberOfVersionsRetention
    }

    if (-not $WhatIfPreference) {
        $resp = Invoke-PVWARequest -Path '/api/Safes' -Method POST -Body $body
        Write-SetupLog -Level OK -Message "Safe '$SafeName' created" -Action 'CreateSafe' -Fields @{ SafeName = $SafeName }
        Register-Operation -Type Created
        return $resp
    }
    else {
        Write-SetupLog -Level INFO -Message "[WhatIf] Would POST /api/Safes for '$SafeName'"
        return $null
    }
}

function Get-SafePermissions {
    <#
    .SYNOPSIS
        Returns the permission hashtable for a given safe + member combination.
        Permissions are hardcoded from CR CHG00YYYYY Step 3.
    #>
    param(
        [ValidateSet('Passwords','MFAKeys','CPMServiceAccounts','BreakGlass')]
        [string]$SafeRole,
        [ValidateSet('CPMUser','PSMUser','UsersGroup','ApproversGroup','SafeAdmin')]
        [string]$MemberRole
    )

    # Permissions are defined as sets; unspecified = $false
    $perms = @{
        listAccounts                              = $false
        useAccounts                               = $false
        retrieveAccounts                          = $false
        viewSafeMembers                           = $false
        accessWithoutConfirmation                 = $false
        updateAccountContent                      = $false
        updateAccountProperties                   = $false
        initiateCPMAccountManagementOperations    = $false
        specifyNextAccountContent                 = $false
        renameAccounts                            = $false
        deleteOrArchiveAccounts                   = $false
        unlockAccounts                            = $false
        manageSafe                                = $false
        manageSafeMembers                         = $false
        backupSafe                                = $false
        viewAuditLog                              = $false
        createFolders                             = $false
        deleteFolders                             = $false
        moveAccountsAndFolders                    = $false
        requestsAuthorizationLevel1               = $false
        requestsAuthorizationLevel2               = $false
    }

    $key = "$SafeRole::$MemberRole"
    switch ($key) {
        # Okta-{TenantId}-HLA-Passwords
        'Passwords::UsersGroup' {
            $perms.listAccounts  = $true
            $perms.useAccounts   = $true
        }
        'Passwords::CPMUser' {
            $perms.listAccounts                           = $true
            $perms.useAccounts                            = $true
            $perms.retrieveAccounts                       = $true
            $perms.accessWithoutConfirmation              = $true
            $perms.updateAccountContent                   = $true
            $perms.updateAccountProperties                = $true
            $perms.initiateCPMAccountManagementOperations = $true
            $perms.renameAccounts                         = $true
        }
        'Passwords::PSMUser' {
            $perms.listAccounts             = $true
            $perms.useAccounts              = $true
            $perms.retrieveAccounts         = $true
            $perms.accessWithoutConfirmation = $true
        }

        # Okta-{TenantId}-HLA-MFAKeys
        'MFAKeys::UsersGroup' {
            $perms.listAccounts  = $true
            $perms.useAccounts   = $true
        }
        'MFAKeys::PSMUser' {
            $perms.listAccounts             = $true
            $perms.useAccounts              = $true
            $perms.retrieveAccounts         = $true
            $perms.accessWithoutConfirmation = $true
        }

        # Okta-{TenantId}-CPM-ServiceAccounts
        'CPMServiceAccounts::CPMUser' {
            $perms.listAccounts                           = $true
            $perms.useAccounts                            = $true
            $perms.retrieveAccounts                       = $true
            $perms.accessWithoutConfirmation              = $true
            $perms.updateAccountContent                   = $true
            $perms.updateAccountProperties                = $true
            $perms.initiateCPMAccountManagementOperations = $true
        }
        'CPMServiceAccounts::ApproversGroup' {
            $perms.listAccounts     = $true
            $perms.useAccounts      = $true
            $perms.retrieveAccounts = $true
        }

        # Okta-{TenantId}-BreakGlass
        'BreakGlass::ApproversGroup' {
            $perms.listAccounts               = $true
            $perms.useAccounts                = $true
            $perms.retrieveAccounts           = $true
            $perms.requestsAuthorizationLevel1 = $true
            # Intentionally NO accessWithoutConfirmation
        }

        # SafeAdmin: Full ownership permissions for admin group (prevents orphaned safes).
        # Applied to Privilege Cloud Administrators or equivalent on ALL safe types.
        # This ensures the safe always has a reachable owner even if the creating
        # OAuth2 service account is later deleted or disabled.
        { $_ -match '::SafeAdmin$' } {
            $perms.listAccounts                           = $true
            $perms.useAccounts                            = $true
            $perms.retrieveAccounts                       = $true
            $perms.viewSafeMembers                        = $true
            $perms.accessWithoutConfirmation              = $true
            $perms.updateAccountContent                   = $true
            $perms.updateAccountProperties                = $true
            $perms.initiateCPMAccountManagementOperations = $true
            $perms.specifyNextAccountContent              = $true
            $perms.renameAccounts                         = $true
            $perms.deleteOrArchiveAccounts                = $true
            $perms.unlockAccounts                         = $true
            $perms.manageSafe                             = $true
            $perms.manageSafeMembers                      = $true
            $perms.backupSafe                             = $true
            $perms.viewAuditLog                           = $true
            $perms.createFolders                          = $true
            $perms.deleteFolders                          = $true
            $perms.moveAccountsAndFolders                 = $true
        }

        default {
            Write-SetupLog -Level WARN -Message "No permission mapping for $key -- returning empty permissions"
        }
    }
    return $perms
}

function Set-HLASafeMembers {
    param(
        [Parameter(Mandatory)][string]$SafeName,
        [Parameter(Mandatory)][string]$MemberName,
        [Parameter(Mandatory)][hashtable]$Permissions,
        [ValidateSet('User','Group')][string]$MemberType = 'User'
    )

    # Check existing -- if member already exists, compare permissions and update if they differ
    try {
        $existing = Invoke-PVWARequest -Path "/api/Safes/$([uri]::EscapeDataString($SafeName))/Members/$([uri]::EscapeDataString($MemberName))"
        if ($null -ne $existing) {
            $permissionDrift = $false
            foreach ($key in $Permissions.Keys) {
                $currentVal = $null
                if ($existing.Permissions -is [hashtable]) {
                    $currentVal = $existing.Permissions[$key]
                }
                elseif ($null -ne $existing.Permissions) {
                    $currentVal = $existing.Permissions.$key
                }
                if ($currentVal -ne $Permissions[$key]) {
                    $permissionDrift = $true
                    Write-SetupLog -Level WARN -Message "Permission drift on '$MemberName' in '$SafeName': $key expected=$($Permissions[$key]) actual=$currentVal"
                    break
                }
            }
            if (-not $permissionDrift) {
                Write-SetupLog -Level SKIP -Message "Safe member '$MemberName' in '$SafeName' already exists with correct permissions -- skipping"
                Register-Operation -Type Skipped
                return $existing
            }
            Write-SetupLog -Level INFO -Message "Updating permissions for '$MemberName' in '$SafeName' (drift detected)"
            if (-not $WhatIfPreference) {
                $updateBody = @{ Permissions = $Permissions }
                $resp = Invoke-PVWARequest -Path "/api/Safes/$([uri]::EscapeDataString($SafeName))/Members/$([uri]::EscapeDataString($MemberName))" -Method PUT -Body $updateBody
                Write-SetupLog -Level OK -Message "Permissions updated for '$MemberName' in '$SafeName'"
                Register-Operation -Type Updated
                return $resp
            }
            else {
                Write-SetupLog -Level INFO -Message "[WhatIf] Would PUT updated permissions for '$MemberName' in '$SafeName'"
                return $null
            }
        }
    }
    catch {
        if ($_ -notmatch 'HTTP 404') { throw }
    }

    Write-SetupLog -Level INFO -Message "Adding member '$MemberName' to safe '$SafeName' (type: $MemberType)"
    $body = @{
        MemberName  = $MemberName
        MemberType  = $MemberType
        Permissions = $Permissions
    }

    if (-not $WhatIfPreference) {
        $resp = Invoke-PVWARequest -Path "/api/Safes/$([uri]::EscapeDataString($SafeName))/Members" -Method POST -Body $body
        Write-SetupLog -Level OK -Message "Member '$MemberName' added to '$SafeName'"
        Register-Operation -Type Created
        return $resp
    }
    else {
        Write-SetupLog -Level INFO -Message "[WhatIf] Would POST member '$MemberName' to safe '$SafeName'"
        return $null
    }
}

#endregion

#region Vault Groups

function New-HLAVaultGroup {
    param(
        [Parameter(Mandatory)][string]$GroupName,
        [string]$Description = ''
    )

    # Check existing
    try {
        $encodedName = [uri]::EscapeDataString($GroupName)
        $search = Invoke-PVWARequest -Path "/api/UserGroups?filter=groupName+eq+%22${encodedName}%22"
        if ($null -ne $search -and $search.value -and $search.value.Count -gt 0) {
            Write-SetupLog -Level SKIP -Message "Vault group '$GroupName' already exists -- skipping"
            Register-Operation -Type Skipped
            return $search.value[0]
        }
    }
    catch {
        if ($_ -match 'HTTP 404') {
            Write-SetupLog -Level DEBUG -Message "UserGroups endpoint returned 404 -- proceeding to create '$GroupName'"
        }
        else { throw }
    }

    Write-SetupLog -Level INFO -Message "Creating vault group: $GroupName"
    $body = @{ GroupName = $GroupName; Description = $Description; GroupType = 'Vault' }

    if (-not $WhatIfPreference) {
        $resp = Invoke-PVWARequest -Path '/api/UserGroups' -Method POST -Body $body
        Write-SetupLog -Level OK -Message "Vault group '$GroupName' created (id: $($resp.id))"
        return $resp
    }
    else {
        Write-SetupLog -Level INFO -Message "[WhatIf] Would POST /api/UserGroups for '$GroupName'"
        return $null
    }
}

#endregion

#region Account Classification

function Resolve-AccountTier {
    <#
    .SYNOPSIS
        Determines the HLA tier for an Okta user.
        Primary: Okta role assignment. Fallback: username suffix convention.
        Warns if they disagree.
    #>
    param(
        [Parameter(Mandatory)][object]$OktaUser,
        [string]$AccountFilter
    )
    $login  = $OktaUser.profile.login
    $userId = $OktaUser.id

    # Primary: Okta roles
    $roles = $null
    $tierFromRole = $null
    try {
        $roles = Get-OktaUserRoles -UserId $userId
        foreach ($r in $roles) {
            if ($Script:TIER_MAP.ContainsKey($r.type)) {
                $mapped = $Script:TIER_MAP[$r.type]
                # Highest privilege wins (lowest tier number)
                if ($null -eq $tierFromRole -or $mapped -lt $tierFromRole) {
                    $tierFromRole = $mapped
                }
            }
        }
    }
    catch {
        Write-SetupLog -Level WARN -Message "Could not read roles for $login`: $_"
    }

    # Fallback: naming convention
    # svc-okta-s = Tier 1, svc-okta-o = Tier 2, svc-okta-h / svc-okta-a = Tier 3
    $tierFromName = $null
    $suffix = $login.Split('@')[0].ToLower()
    if     ($suffix -match '-s\d+$') { $tierFromName = 1 }
    elseif ($suffix -match '-o\d+$') { $tierFromName = 2 }
    elseif ($suffix -match '-h\d+$') { $tierFromName = 3 }
    elseif ($suffix -match '-a\d+$') { $tierFromName = 3 }
    elseif ($suffix -match '-r\d+$') { $tierFromName = 0 }  # ReadOnly

    # Warn on mismatch
    if ($null -ne $tierFromRole -and $null -ne $tierFromName -and $tierFromRole -ne $tierFromName) {
        Write-SetupLog -Level WARN -Message "$login`: Tier from Okta role ($tierFromRole) != tier from naming ($tierFromName). Using Okta role."
    }

    $finalTier = Get-FirstNonNull @($tierFromRole, $tierFromName)
    if ($null -eq $finalTier) {
        Write-SetupLog -Level WARN -Message "$login`: Could not determine tier -- defaulting to Tier 3"
        $finalTier = 3
    }
    return [int]$finalTier
}

function Get-OktaHLAAccounts {
    <#
    .SYNOPSIS
        Enumerates Okta users matching AccountFilter, resolves tiers, and filters by IncludeTiers.
        Returns an array of account objects ready for onboarding.
    #>
    param(
        [string]$Filter,
        [int[]]$IncludeTiers,
        [switch]$IncludeReadOnly
    )

    $oktaUsers = Get-OktaUsers -Filter $Filter
    $accounts  = [System.Collections.Generic.List[object]]::new()

    foreach ($u in $oktaUsers) {
        $tier = Resolve-AccountTier -OktaUser $u -AccountFilter $Filter
        # ReadOnly = tier 0
        if ($tier -eq 0) {
            if (-not $IncludeReadOnly) {
                Write-SetupLog -Level SKIP -Message "$($u.profile.login) is ReadOnly -- skipped (use -IncludeReadOnly to include)"
                continue
            }
        }
        elseif ($tier -notin $IncludeTiers) {
            Write-SetupLog -Level SKIP -Message "$($u.profile.login) is Tier $tier -- not in -IncludeTiers ($($IncludeTiers -join ','))"
            continue
        }

        $accounts.Add([PSCustomObject]@{
            Login    = $u.profile.login
            OktaId   = $u.id
            Tier     = $tier
            Address  = $Script:OktaActiveDomain
        })
    }

    Write-SetupLog -Level INFO -Message "$($accounts.Count) account(s) in scope for onboarding"
    return $accounts.ToArray()
}

function Get-SafeDelta {
    <#
    .SYNOPSIS
        Compares Okta-discovered accounts against existing CyberArk accounts in the safe.
        Returns only accounts not yet present in CyberArk (new additions).
    #>
    param(
        [Parameter(Mandatory)][object[]]$OktaAccounts,
        [Parameter(Mandatory)][string]$SafeName
    )
    try {
        $existing = Invoke-PVWARequest -Path "/api/Accounts?safeName=$([uri]::EscapeDataString($SafeName))&limit=1000"
        $existingLogins = @{}
        foreach ($a in $(if ($null -ne $existing) { $existing.value } else { @() })) { $existingLogins[$a.userName] = $true }

        $delta = $OktaAccounts | Where-Object { -not $existingLogins.ContainsKey($_.Login) }
        Write-SetupLog -Level INFO -Message "Safe delta for '$SafeName': $($delta.Count) new account(s) of $($OktaAccounts.Count) discovered"
        return @($delta)
    }
    catch {
        if ($_ -match 'HTTP 404') {
            Write-SetupLog -Level INFO -Message "Safe '$SafeName' does not yet exist -- all $($OktaAccounts.Count) accounts are new"
            return $OktaAccounts
        }
        throw
    }
}

#endregion

#region Account Onboarding

function Add-HLAAccount {
    <#
    .SYNOPSIS
        Onboards an HLA password account to CyberArk.
        Returns the created account object (with .id for later linking).
    #>
    param(
        [Parameter(Mandatory)][string]$Username,
        [Parameter(Mandatory)][string]$Address,
        [Parameter(Mandatory)][string]$SafeName,
        [Parameter(Mandatory)][string]$Password,
        [string]$PlatformId = $Script:OKTA_PLATFORM,
        [string]$OktaUserId = '',
        [int]$Tier = 3
    )

    # Check if already exists
    try {
        $search = Invoke-PVWARequest -Path "/api/Accounts?safeName=$([uri]::EscapeDataString($SafeName))&search=$([uri]::EscapeDataString($Username))"
        $match  = $(if ($null -ne $search) { $search.value } else { @() }) | Where-Object { $_.userName -eq $Username -and $_.address -eq $Address }
        if ($match) {
            Write-SetupLog -Level SKIP -Message "HLA account '$Username' already in '$SafeName' (id: $($match.id))"
            Register-Operation -Type Skipped
            return $match
        }
    }
    catch { throw }

    Write-SetupLog -Level INFO -Message "Onboarding HLA account: $Username (Tier $Tier)"

    $body = @{
        name                       = "$Address-$Username"
        address                    = $Address
        userName                   = $Username
        platformId                 = $PlatformId
        safeName                   = $SafeName
        secretType                 = 'password'
        secret                     = $Password
        platformAccountProperties  = @{
            OktaUserId = $OktaUserId
            Tier       = $Tier.ToString()
        }
    }

    if (-not $WhatIfPreference) {
        $resp = Invoke-PVWARequest -Path '/api/Accounts' -Method POST -Body $body
        Write-SetupLog -Level OK -Message "HLA account '$Username' onboarded (id: $($resp.id))" `
            -Action 'OnboardHLAAccount' -Fields @{ Username = $Username; Tier = $Tier; SafeName = $SafeName; AccountId = $resp.id }
        Register-Operation -Type Created
        return $resp
    }
    else {
        Write-SetupLog -Level INFO -Message "[WhatIf] Would POST /api/Accounts for '$Username'" `
            -Action 'OnboardHLAAccount' -Fields @{ Username = $Username; Tier = $Tier; SafeName = $SafeName; AccountId = "WHATIF-$Username" }
        return [PSCustomObject]@{ id = "WHATIF-$Username"; userName = $Username; address = $Address }
    }
}

function Add-TOTPAccount {
    <#
    .SYNOPSIS
        Onboards a TOTP seed account to the MFA safe.
        Uses the built-in TOTP platform and secretType='key'.
    #>
    param(
        [Parameter(Mandatory)][string]$Username,
        [Parameter(Mandatory)][string]$Address,
        [Parameter(Mandatory)][string]$SafeName,
        [Parameter(Mandatory)][string]$TOTPSeed,
        [string]$PlatformId = $Script:TOTP_PLATFORM
    )

    $totpUser = "$Username$Script:TOTP_SUFFIX"

    # Check if already exists
    try {
        $search = Invoke-PVWARequest -Path "/api/Accounts?safeName=$([uri]::EscapeDataString($SafeName))&search=$([uri]::EscapeDataString($totpUser))"
        $match  = $(if ($null -ne $search) { $search.value } else { @() }) | Where-Object { $_.userName -eq $totpUser -and $_.address -eq $Address }
        if ($match) {
            Write-SetupLog -Level SKIP -Message "TOTP account '$totpUser' already in '$SafeName' (id: $($match.id))"
            return $match
        }
    }
    catch { throw }

    Write-SetupLog -Level INFO -Message "Onboarding TOTP account: $totpUser"

    $body = @{
        name       = "$Address-$totpUser"
        address    = $Address
        userName   = $totpUser
        platformId = $PlatformId
        safeName   = $SafeName
        secretType = 'key'
        secret     = $TOTPSeed
    }

    if (-not $WhatIfPreference) {
        $resp = Invoke-PVWARequest -Path '/api/Accounts' -Method POST -Body $body
        Write-SetupLog -Level OK -Message "TOTP account '$totpUser' onboarded (id: $($resp.id))" `
            -Action 'OnboardTOTPAccount' -Fields @{ Username = $totpUser; SafeName = $SafeName; AccountId = $resp.id }
        return $resp
    }
    else {
        Write-SetupLog -Level INFO -Message "[WhatIf] Would POST /api/Accounts for '$totpUser'" `
            -Action 'OnboardTOTPAccount' -Fields @{ Username = $totpUser; SafeName = $SafeName; AccountId = "WHATIF-TOTP-$totpUser" }
        return [PSCustomObject]@{ id = "WHATIF-TOTP-$totpUser"; userName = $totpUser; address = $Address }
    }
}

function Add-SSWSAccount {
    <#
    .SYNOPSIS
        Onboards the CPM SSWS API token account to the CPM safe.
    #>
    param(
        [Parameter(Mandatory)][string]$SafeName,
        [Parameter(Mandatory)][string]$Address,
        [Parameter(Mandatory)][string]$TokenValue,
        [string]$AccountUsername = $Script:CPM_ACCOUNT_NAME,
        [string]$PlatformId      = $Script:OKTA_PLATFORM
    )

    # Check if already exists
    try {
        $search = Invoke-PVWARequest -Path "/api/Accounts?safeName=$([uri]::EscapeDataString($SafeName))&search=$([uri]::EscapeDataString($AccountUsername))"
        $match  = $(if ($null -ne $search) { $search.value } else { @() }) | Where-Object { $_.userName -eq $AccountUsername }
        if ($match) {
            Write-SetupLog -Level SKIP -Message "SSWS account '$AccountUsername' already in '$SafeName' (id: $($match.id))"
            return $match
        }
    }
    catch { throw }

    Write-SetupLog -Level INFO -Message "Onboarding SSWS token account: $AccountUsername"

    $body = @{
        name       = "$Address-$AccountUsername"
        address    = $Address
        userName   = $AccountUsername
        platformId = $PlatformId
        safeName   = $SafeName
        secretType = 'password'
        secret     = $TokenValue
    }

    if (-not $WhatIfPreference) {
        $resp = Invoke-PVWARequest -Path '/api/Accounts' -Method POST -Body $body
        Write-SetupLog -Level OK -Message "SSWS account '$AccountUsername' onboarded (id: $($resp.id))"
        return $resp
    }
    else {
        Write-SetupLog -Level INFO -Message "[WhatIf] Would POST /api/Accounts for '$AccountUsername'"
        return [PSCustomObject]@{ id = "WHATIF-SSWS"; userName = $AccountUsername; address = $Address }
    }
}

function Add-BreakGlassRecord {
    <#
    .SYNOPSIS
        Onboards the break-glass audit record to the BreakGlass safe.
        IMPORTANT: Does NOT store the real credential. The password field should be a
        placeholder. Real BG credential is in a physical sealed envelope per BG SOP.
    #>
    param(
        [Parameter(Mandatory)][string]$SafeName,
        [Parameter(Mandatory)][string]$Address,
        [Parameter(Mandatory)][string]$Username,
        [string]$PlaceholderPassword = 'PLACEHOLDER-SEE-BREAK-GLASS-SOP',
        [string]$PlatformId          = $Script:OKTA_PLATFORM
    )

    try {
        $search = Invoke-PVWARequest -Path "/api/Accounts?safeName=$([uri]::EscapeDataString($SafeName))&search=$([uri]::EscapeDataString($Username))"
        $match  = $(if ($null -ne $search) { $search.value } else { @() }) | Where-Object { $_.userName -eq $Username }
        if ($match) {
            Write-SetupLog -Level SKIP -Message "Break-glass record '$Username' already in '$SafeName' (id: $($match.id))"
            return $match
        }
    }
    catch { throw }

    Write-SetupLog -Level WARN -Message "Onboarding BREAK-GLASS AUDIT RECORD for $Username -- password is a placeholder only"
    Write-SetupLog -Level WARN -Message "Real BG credential is stored in a physical sealed envelope. See Break-Glass SOP."

    $body = @{
        name       = "$Address-$Username"
        address    = $Address
        userName   = $Username
        platformId = $PlatformId
        safeName   = $SafeName
        secretType = 'password'
        secret     = $PlaceholderPassword
    }

    if (-not $WhatIfPreference) {
        $resp = Invoke-PVWARequest -Path '/api/Accounts' -Method POST -Body $body
        Write-SetupLog -Level OK -Message "Break-glass audit record onboarded (id: $($resp.id))"
        return $resp
    }
    else {
        Write-SetupLog -Level INFO -Message "[WhatIf] Would POST break-glass record for $Username"
        return [PSCustomObject]@{ id = "WHATIF-BG"; userName = $Username; address = $Address }
    }
}

function Set-LinkedAccount {
    <#
    .SYNOPSIS
        Sets an ExtraPassword linked account on an HLA account.
        Idempotent: checks for existing link before POST. Handles 409 (already linked) gracefully.
    .PARAMETER HLAAccountId
        The CyberArk account ID of the HLA password account.
    .PARAMETER ExtraPasswordIndex
        1 = SSWS logon, 2 = TOTP seed, 3 = SSWS reconcile
    .PARAMETER LinkedSafeName
        Safe containing the linked account.
    .PARAMETER LinkedAccountName
        Username of the linked account (as stored in CyberArk).
    #>
    param(
        [Parameter(Mandatory)][string]$HLAAccountId,
        [Parameter(Mandatory)][int]$ExtraPasswordIndex,
        [Parameter(Mandatory)][string]$LinkedSafeName,
        [Parameter(Mandatory)][string]$LinkedAccountName,
        [string]$FolderName = 'Root'
    )

    # Check if link already exists by reading the account and inspecting linked accounts
    try {
        $acctDetail = Invoke-PVWARequest -Path "/api/Accounts/$([uri]::EscapeDataString($HLAAccountId))"
        if ($null -ne $acctDetail) {
            # CyberArk returns linked accounts in platformAccountProperties or via separate endpoint
            # Check the extraPassXSafe/extraPassXName properties if they exist
            $existingSafe = $null
            $existingName = $null
            if ($acctDetail.platformAccountProperties) {
                $props = $acctDetail.platformAccountProperties
                $existingSafe = $props."ExtraPass${ExtraPasswordIndex}Safe"
                $existingName = $props."ExtraPass${ExtraPasswordIndex}Name"
            }
            if ($existingSafe -eq $LinkedSafeName -and $existingName -eq $LinkedAccountName) {
                Write-SetupLog -Level SKIP -Message "ExtraPass$ExtraPasswordIndex already linked to '$LinkedAccountName' on account $HLAAccountId"
                Register-Operation -Type Skipped
                return
            }
        }
    }
    catch {
        # If we can't check, proceed with the POST and let it fail gracefully
        Write-SetupLog -Level DEBUG -Message "Could not pre-check link state for $HLAAccountId`: $($_.Exception.Message)"
    }

    Write-SetupLog -Level INFO -Message "Linking ExtraPass$ExtraPasswordIndex -> '$LinkedAccountName' on account $HLAAccountId"

    $body = @{
        extraPasswordIndex = $ExtraPasswordIndex
        safeName           = $LinkedSafeName
        name               = $LinkedAccountName
        folderName         = $FolderName
    }

    if (-not $WhatIfPreference) {
        try {
            Invoke-PVWARequest -Path "/api/Accounts/$([uri]::EscapeDataString($HLAAccountId))/LinkAccount" -Method POST -Body $body | Out-Null
            Write-SetupLog -Level OK -Message "ExtraPass$ExtraPasswordIndex linked on account $HLAAccountId" `
                -Action 'LinkAccount' -Fields @{ HLAAccountId = $HLAAccountId; ExtraPasswordIndex = $ExtraPasswordIndex; LinkedAccount = $LinkedAccountName }
            Register-Operation -Type Created
        }
        catch {
            if ($_ -match 'HTTP 409' -or $_ -match 'already linked' -or $_ -match 'ITATS049E') {
                Write-SetupLog -Level SKIP -Message "ExtraPass$ExtraPasswordIndex already linked on account $HLAAccountId (409/already exists)"
                Register-Operation -Type Skipped
            }
            else {
                Write-SetupLog -Level ERROR -Message "Failed to link ExtraPass$ExtraPasswordIndex on $HLAAccountId`: $($_.Exception.Message)"
                Register-Operation -Type Failed
            }
        }
    }
    else {
        Write-SetupLog -Level INFO -Message "[WhatIf] Would POST LinkAccount ExtraPass$ExtraPasswordIndex on $HLAAccountId"
    }
}

#endregion

#region Simulator Integration

function Find-SimulatorPath {
    $candidates = @(
        $SimulatorPath,
        (Join-Path $PSScriptRoot '..\cpm-simulator'),
        (Join-Path $PSScriptRoot '..\..\cpm-simulator')
    )
    foreach ($c in $candidates) {
        if ($c -and (Test-Path (Join-Path $c 'src\cli.py'))) {
            return (Resolve-Path $c).Path
        }
    }
    return $null
}

function Write-SeedToSimulator {
    param(
        [Parameter(Mandatory)][string]$SimPath,
        [Parameter(Mandatory)][string]$Username,
        [Parameter(Mandatory)][string]$Seed
    )
    Write-SetupLog -Level INFO -Message "[Simulate] Writing TOTP seed for $Username to CPM simulator"
    if ($WhatIfPreference) {
        Write-SetupLog -Level INFO -Message "[WhatIf] Would run: python -m src.cli import-totp-seed --username $Username"
        return
    }
    $envFile = Join-Path $SimPath '.env'
    $vaultPass = ''
    if (Test-Path $envFile) {
        $lines = Get-Content $envFile
        foreach ($l in $lines) {
            if ($l -match '^CPM_VAULT_PASSPHRASE=(.+)$') { $vaultPass = $Matches[1]; break }
        }
    }
    if (-not $vaultPass) {
        $vaultPass = Get-SecureInput -Prompt 'CPM simulator vault passphrase'
    }

    $env:CPM_VAULT_PASSPHRASE = $vaultPass
    $prevDir = $PWD
    try {
        Set-Location $SimPath
        $result = python -m src.cli import-totp-seed --username $Username --seed $Seed 2>&1
        if ($LASTEXITCODE -ne 0) {
            throw "Simulator import-totp-seed failed for $Username`: $result"
        }
        Write-SetupLog -Level OK -Message "[Simulate] TOTP seed written for $Username"
    }
    finally {
        Remove-Item env:CPM_VAULT_PASSPHRASE -ErrorAction SilentlyContinue
        Set-Location $prevDir
    }
}

#endregion

#region Break-Glass

function Export-BreakGlassQRUri {
    param(
        [Parameter(Mandatory)][string]$Username,
        [Parameter(Mandatory)][string]$OrgName,
        [Parameter(Mandatory)][string]$Seed
    )
    $uri = New-TOTPUri -Issuer $OrgName -AccountName $Username -Seed $Seed

    Write-Host ''
    Write-Host '================================================================' -ForegroundColor Yellow
    Write-Host ' BREAK-GLASS TOTP -- PHYSICAL ENVELOPE A' -ForegroundColor Yellow
    Write-Host '================================================================' -ForegroundColor Yellow
    Write-Host " Account : $Username" -ForegroundColor Yellow
    Write-Host " Org     : $OrgName" -ForegroundColor Yellow
    Write-Host ''
    Write-Host ' otpauth:// URI (print as QR, store in Envelope A):'
    Write-Host " $uri" -ForegroundColor Cyan
    Write-Host ''
    Write-Host ' SECURITY INSTRUCTIONS:' -ForegroundColor Yellow
    Write-Host '  1. Print this URI as a QR code and laminate it.'
    Write-Host '  2. Seal in physical Envelope A (TOTP seed only).'
    Write-Host '  3. Store Envelope A in fire-rated safe, separate from Envelope B (password).'
    Write-Host '  4. Envelope B (password) stored separately per Break-Glass SOP.'
    Write-Host '  5. Neither envelope alone is sufficient -- both required for access.'
    Write-Host '  6. Do NOT store the TOTP seed in CyberArk for the break-glass account.'
    Write-Host '  7. A dedicated spare phone (pre-enrolled) must be in the physical safe.'
    Write-Host '================================================================' -ForegroundColor Yellow
    Write-Host ''

    return $uri
}

#endregion

#region Verification

function Test-SetupVerification {
    param([hashtable]$Config, [hashtable]$RecordOfIds)

    Write-SetupLog -Level STEP -Message '=== Phase 4: Verification ==='
    $errors = [System.Collections.Generic.List[string]]::new()

    # Safes
    foreach ($safeName in @($Config.Naming.PasswordSafe, $Config.Naming.MFASafe, $Config.Naming.CPMSafe, $Config.Naming.BGSafe)) {
        $safe = Test-CyberArkSafe -SafeName $safeName
        if ($safe) { Write-SetupLog -Level OK -Message "Safe verified: $safeName"; Register-Operation -Type Verified }
        else        { $errors.Add("MISSING SAFE: $safeName"); Register-Operation -Type Failed }
    }

    # Platform
    $platform = Test-CyberArkPlatform
    if ($platform) { Write-SetupLog -Level OK -Message "Platform verified: $($platform.Details.PolicyID) (Active: $($platform.Active))"; Register-Operation -Type Verified }
    else           { $errors.Add("MISSING PLATFORM: $Script:OKTA_PLATFORM"); Register-Operation -Type Failed }

    # Accounts by ID
    foreach ($entry in $RecordOfIds.GetEnumerator()) {
        if ($entry.Value -and $entry.Value -notlike 'WHATIF*') {
            try {
                $acct = Invoke-PVWARequest -Path "/api/Accounts/$([uri]::EscapeDataString($entry.Value))"
                Write-SetupLog -Level OK -Message "Account verified: $($acct.userName) (id: $($acct.id))"
                Register-Operation -Type Verified
            }
            catch { $errors.Add("MISSING ACCOUNT: $($entry.Key) (id: $($entry.Value))"); Register-Operation -Type Failed }
        }
    }

    if ($errors.Count -gt 0) {
        Write-Host ''
        Write-Host '--- Verification Errors ---' -ForegroundColor Red
        foreach ($e in $errors) { Write-Host "  [FAIL] $e" -ForegroundColor Red }
        Write-Host ''
    }
    else { Write-SetupLog -Level OK -Message 'All resources verified successfully' }

    return $errors.Count -eq 0
}

function Export-RecordOfIDs {
    param(
        [hashtable]$RecordOfIds,
        [hashtable]$Config
    )

    Write-Host ''
    Write-Host '================================================================' -ForegroundColor White
    Write-Host ' Record of IDs -- CyberArk HLA Setup' -ForegroundColor White
    Write-Host "  Tenant: $($Config.TenantId)  |  Okta: $($Config.OktaDomain)" -ForegroundColor White
    Write-Host "  Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor White
    Write-Host '================================================================' -ForegroundColor White

    foreach ($entry in ($RecordOfIds.GetEnumerator() | Sort-Object Key)) {
        Write-Host ("{0,-45} {1}" -f $entry.Key, $entry.Value)
    }

    Write-Host '================================================================' -ForegroundColor White
    Write-Host ''
}

#endregion

#region Manual Steps Guide

function Write-ManualStepsGuide {
    Write-Host ''
    Write-Host '================================================================' -ForegroundColor Cyan
    Write-Host ' MANUAL STEPS REMAINING' -ForegroundColor Cyan
    Write-Host '================================================================' -ForegroundColor Cyan
    Write-Host ''
    Write-Host '--- Step 1.1-1.2: CPM Plugin Deployment ---' -ForegroundColor Yellow
    Write-Host '  1. Download OktaCloud plugin from CyberArk Marketplace (authenticated browser).'
    Write-Host '  2. On CPM server: copy OktaCloud DLLs to %PROGRAMFILES%\CyberArk\Password Manager\bin'
    Write-Host '  3. Restart CyberArk Password Manager service on CPM server.'
    Write-Host ''
    Write-Host '--- Step 1.6: Verify CPM Plugin Loaded ---' -ForegroundColor Yellow
    Write-Host '  1. RDP to CPM server.'
    Write-Host '  2. Check PM.log: confirm "OktaCloud plugin loaded" with no errors.'
    Write-Host '  3. Trigger a manual CPM change on Tier 2 account from PVWA and confirm success.'
    Write-Host ''
    Write-Host '--- Step 10: PSM Connector (WebForm or AutoIt) ---' -ForegroundColor Yellow
    Write-Host '  WebForm connector: May have been deployed in Phase 1.5 above.'
    Write-Host '  Verify: PVWA > Platforms > OktaCloud > PSM Connection Components'
    Write-Host '  If NOT deployed, choose one:' -ForegroundColor DarkGray
    Write-Host '    WebForm (recommended): Import XML from psm/okta-oie-webform/ via PVWA admin'
    Write-Host '    AutoIt (legacy):' -ForegroundColor DarkGray
    Write-Host '      1. Copy PSMOktaCloud folder to %PROGRAMFILES%\CyberArk\PSM\Connectors'
    Write-Host '      2. Compile OktaConnect.au3 with AutoIt (run on PSM server).'
    Write-Host '      3. Copy compiled OktaConnect.exe to PSMOktaCloud folder.'
    Write-Host '      4. Update basic_psm.ini: add OktaCloud connection component entries.'
    Write-Host '      5. Restart PSM service.'
    Write-Host ''
    Write-Host '--- Step 12: Integration Testing ---' -ForegroundColor Yellow
    Write-Host '  12.3  PSM session test: launch PSM session via PVWA for Tier 2 account.'
    Write-Host '        Confirm auto-inject of TOTP MFA code (MfaCode parameter from ExtraPass2).'
    Write-Host '  12.4  TOTP fallback test: temporarily disable PSM auto-inject, verify manual TOTP works.'
    Write-Host '  12.5  Break-glass test (dual-control): request BG account access, confirm approval workflow.'
    Write-Host '        Use physical Envelope A (TOTP) + Envelope B (password) for tabletop simulation.'
    Write-Host ''
    Write-Host '================================================================' -ForegroundColor Cyan
    Write-Host ''
}

#endregion

#region Main Orchestration

function Main {
    Initialize-SIEMLogging -LogDir $SIEMLogPath
    $startTime = Get-Date
    Write-SetupLog -Level STEP -Message "Okta HLA Vault Setup v$Script:VERSION -- CorrelationId: $Script:CorrelationId"
    Write-SIEMLog  -Level 'INFO' -Action 'ScriptStart' -Message "OktaHLAVaultSetup v$Script:VERSION starting"

    # PS 5.1 variable hoisting: any unconditional OR conditional local assignment to a variable name
    # that matches a script parameter (case-insensitive) causes all reads of that name inside this
    # function to return '' instead of the script-scope value.  Capture the affected params via
    # $script: qualifier before any local assignment to the same name can shadow them.
    $OktaToken = $script:OktaToken      # shadowed by conditional: $OktaToken = Get-SecureInput...
    $PVWAUrl   = $script:PVWAUrl        # shadowed by: $pvwaUrl = Get-FirstNonNull @($PVWAUrl, ...)
    $TenantId  = $script:TenantId       # shadowed by: $tenantId = Resolve-TenantId ... $TenantId

    # ----------------------------------------------------------------
    # 0. Gather required inputs
    # ----------------------------------------------------------------
    Write-SetupLog -Level STEP -Message '=== Phase 0: Pre-flight ==='

    # Handle legacy JSON config path
    $legacyConfig = $null
    if ($PSCmdlet.ParameterSetName -eq 'Legacy' -and $ConfigPath) {
        Write-SetupLog -Level INFO -Message "Loading legacy config from $ConfigPath..."
        $legacyConfig = Get-Content $ConfigPath -Raw | ConvertFrom-Json
    }

    # ---------- Interactive Input Gathering ----------
    # Each input asks "do you have it?" before prompting.
    # If not, the script gracefully skips dependent phases.

    # Okta Token
    if ($SkipOktaDiscovery) {
        Write-SetupLog -Level INFO -Message 'SkipOktaDiscovery: Okta API calls will be skipped. CyberArk-side resources only.'
    }
    elseif (-not $OktaToken) {
        if ($legacyConfig) { $OktaToken = $null }  # Legacy config has no token
        if (-not $OktaToken) {
            if (Confirm-UserChoice -Prompt 'Do you have an Okta SSWS API token for this run?' -Default 'N') {
                $OktaToken = Get-SecureInput -Prompt '  Okta SSWS API token (SSWS ...)'
            }
        }
        if ([string]::IsNullOrWhiteSpace($OktaToken)) {
            $SkipOktaDiscovery = [switch]$true
            Write-SetupLog -Level INFO -Message 'No Okta token -- CyberArk-only mode. Okta-dependent phases will be skipped.'
        }
    }

    # PVWA URL
    $pvwaUrl = Get-FirstNonNull @($PVWAUrl, $(if ($legacyConfig) { $legacyConfig.PVWA.Url } else { $null }))
    if (-not $pvwaUrl) {
        if ($WhatIfPreference) { $pvwaUrl = 'https://cyberark.whatif.local' }
        else { $pvwaUrl = Read-Host 'PVWA base URL (e.g. https://tenant.privilegecloud.cyberark.cloud)' }
    }
    # Normalize: strip trailing /PasswordVault -- it is added automatically at request time
    $pvwaUrl = $pvwaUrl.TrimEnd('/')
    if ($pvwaUrl -match '/PasswordVault$') {
        $pvwaUrl = $pvwaUrl -replace '/PasswordVault$', ''
        Write-SetupLog -Level INFO -Message "Normalized PVWA URL (stripped /PasswordVault): $pvwaUrl"
    }

    # PVWA Authentication -- OAuth2 is the primary path.
    # Hierarchy: pre-obtained token > CA.Auth toolkit > OAuth2 Client Credentials > interactive prompt for token
    $pvwaCred = $PVWACredential
    if (-not $PVWAToken -and -not $Script:CAAuthAvailable -and -not $ClientId) {
        if ($pvwaCred) {
            # Credential was passed explicitly -- will try legacy auth methods as fallback
            Write-SetupLog -Level INFO -Message 'Using provided PVWA credential (legacy auth)'
        }
        elseif ($legacyConfig -and $legacyConfig.PVWA.Username) {
            $pvwaUser = $legacyConfig.PVWA.Username
            $pvwaPass = ConvertTo-SecureString $legacyConfig.PVWA.Password -AsPlainText -Force
            $pvwaCred = [System.Management.Automation.PSCredential]::new($pvwaUser, $pvwaPass)
        }
        else {
            # Detect environment and offer appropriate auth options
            $isCloud = Test-IsPrivilegeCloud -Url $pvwaUrl
            Write-Host ''
            Write-Host '--- PVWA Authentication ---' -ForegroundColor White
            if ($WhatIfPreference) {
                Write-Host '  (Providing credentials enables accurate WhatIf dry-run against real PVWA)' -ForegroundColor DarkGray
            }
            if ($isCloud) {
                Write-Host '  Privilege Cloud detected. Authentication options:' -ForegroundColor DarkGray
            }
            else {
                Write-Host '  Authentication options:' -ForegroundColor DarkGray
            }
            Write-Host ''
            Write-Host '    [1] Bearer token (from Identity portal, psPAS, or Identity CLI)' -ForegroundColor White
            Write-Host '    [2] OAuth2 Client Credentials (service account - client_id + secret)' -ForegroundColor White
            if (-not $isCloud) {
                Write-Host '    [3] Username/Password (CyberArk, LDAP, RADIUS, Windows)' -ForegroundColor White
            }
            Write-Host '    [S] Skip (no PVWA connection)' -ForegroundColor DarkGray
            Write-Host ''
            $authChoice = Read-Host "  Auth method [1]"
            if ([string]::IsNullOrWhiteSpace($authChoice)) { $authChoice = '1' }

            switch ($authChoice.Trim()) {
                '1' {
                    $PVWAToken = Get-SecureInput -Prompt '  Bearer token'
                    if (-not [string]::IsNullOrWhiteSpace($PVWAToken)) {
                        $PVWATokenType = 'Bearer'
                    }
                    else {
                        $PVWAToken = $null
                        Write-SetupLog -Level WARN -Message 'Empty token provided.'
                    }
                }
                '2' {
                    if (-not $TenantUrl) {
                        $TenantUrl = Read-Host '  Identity Tenant URL (e.g. https://abc1234.id.cyberark.cloud)'
                    }
                    $ClientId     = Read-Host '  Client ID'
                    $ClientSecret = Read-Host -Prompt '  Client Secret' -AsSecureString
                }
                '3' {
                    if (-not $isCloud) {
                        $pvwaCred = Get-Credential -Message 'PVWA credentials (Vault Admin or equivalent)'
                    }
                    else {
                        Write-SetupLog -Level WARN -Message 'Username/Password not supported for Privilege Cloud. Use Bearer token or OAuth2.'
                    }
                }
                { $_ -eq 'S' -or $_ -eq 's' } {
                    if ($WhatIfPreference) {
                        Write-SetupLog -Level INFO -Message 'No PVWA credentials -- dry-run will show simulated results for PVWA operations.'
                    }
                    else {
                        throw "No PVWA authentication method selected. Cannot continue without PVWA access."
                    }
                }
                default {
                    # Treat as Bearer token input directly (user may have pasted the token)
                    $PVWAToken = $authChoice.Trim()
                    $PVWATokenType = 'Bearer'
                    Write-SetupLog -Level INFO -Message 'Input treated as Bearer token.'
                }
            }
        }
    }

    # Okta Domain -- parameter > legacy config > prompt
    $resolvedOktaDomain = Get-FirstNonNull @(
        $OktaDomain,
        $(if ($legacyConfig) { $legacyConfig.Infrastructure.OktaDomain } else { $null })
    )
    if (-not $resolvedOktaDomain) {
        $resolvedOktaDomain = Read-Host 'Okta tenant domain (e.g. yourorg.okta.com)'
    }
    $effectiveOktaDomain = $resolvedOktaDomain

    # Connect to Okta (unless skipping)
    $orgName = $effectiveOktaDomain
    if (-not $SkipOktaDiscovery) {
        try {
            Initialize-OktaSession -Token $OktaToken -Domain $effectiveOktaDomain

            # Get org info for display name
            $orgInfo = $null
            try { $orgInfo = Get-OktaOrgInfo } catch { Write-SetupLog -Level WARN -Message "Could not read Okta org info: $_" }
            if ($orgInfo) { try { $orgName = $orgInfo.name } catch {} }

            # Resolve token level
            $null = Resolve-OktaTokenLevel
        }
        catch {
            Write-SetupLog -Level WARN -Message "Okta connection failed: $($_.Exception.Message)"
            Write-SetupLog -Level INFO -Message 'Continuing in CyberArk-only mode. Okta-dependent phases will be skipped.'
            $SkipOktaDiscovery = [switch]$true
            $Script:OktaTokenLevel = 'Skipped'
        }
    }
    else {
        $Script:OktaTokenLevel = 'Skipped'
        Write-SetupLog -Level INFO -Message 'Okta connection skipped -- token level set to Skipped'
    }

    # TenantId
    $tenantId = Resolve-TenantId -OktaDomain $effectiveOktaDomain -UserProvided $TenantId
    Write-SetupLog -Level INFO -Message "Derived TenantId: $tenantId"
    Write-SIEMLog  -Level 'INFO' -Action 'SessionContext' -Message "Session context established" `
        -Fields @{ OktaDomain = $effectiveOktaDomain; TenantId = $tenantId; WhatIf = if ($WhatIfPreference) { $true } else { $false }; Simulate = [bool]$Simulate }
    if (-not $AcceptDefaults) {
        $tenantOverride = Read-Host "TenantId will be '$tenantId'. Press Enter to accept or type override"
        if (-not [string]::IsNullOrWhiteSpace($tenantOverride)) { $tenantId = $tenantOverride.Trim().ToLower() }
    }

    # Platform source directory -- search order:
    #   1. Explicit -PlatformSourceDirectory parameter
    #   2. Legacy JSON config
    #   3. 'platform' subfolder next to this script (portable deployment)
    #   4. Relative to cpm-simulator repo layout
    $platformDir = Get-FirstNonNull @(
        $PlatformSourceDirectory,
        $(if ($legacyConfig) { $legacyConfig.Platform.SourceDirectory } else { $null }),
        $(if (Test-Path (Join-Path $PSScriptRoot 'platform')) { Join-Path $PSScriptRoot 'platform' } else { $null }),
        (Join-Path $PSScriptRoot '..\cpm-simulator\cpm-plugin\platform')
    )
    if (-not (Test-Path $platformDir)) {
        if (-not $SkipPlatformImport) {
            Write-SetupLog -Level WARN -Message "Platform source directory not found at '$platformDir'."
            if ($AcceptDefaults) {
                Write-SetupLog -Level INFO -Message 'AcceptDefaults: skipping platform import (directory not found).'
                $SkipPlatformImport = [switch]$true
            }
            else {
                $altDir = Read-Host '  Enter path to platform files directory (or press Enter to skip platform import)'
                if (-not [string]::IsNullOrWhiteSpace($altDir) -and (Test-Path $altDir)) {
                    $platformDir = $altDir.Trim()
                    Write-SetupLog -Level INFO -Message "Using platform directory: $platformDir"
                }
                else {
                    if (-not [string]::IsNullOrWhiteSpace($altDir)) {
                        Write-SetupLog -Level WARN -Message "Directory '$($altDir.Trim())' not found."
                    }
                    Write-SetupLog -Level INFO -Message 'Skipping platform import. Use -SkipPlatformImport or -PlatformSourceDirectory on next run.'
                    $SkipPlatformImport = [switch]$true
                }
            }
        }
    }

    # Build naming
    $naming = Resolve-NamingDefaults -TenantId $tenantId `
        -PasswordSafe $PasswordSafeName `
        -MFASafe $MFASafeName `
        -CPMSafe $CPMSafeName `
        -BGSafe $BGSafeName `
        -UsersGroup $UsersGroupName `
        -ApproversGroup $ApproversGroupName

    # CPM/PSM service account names
    $cpmUser = Get-FirstNonNull @(
        $(if ($legacyConfig) { $legacyConfig.Infrastructure.CPMServiceAccount } else { $null }),
        'PasswordManager'
    )
    $psmUser = Get-FirstNonNull @(
        $(if ($legacyConfig) { $legacyConfig.Infrastructure.PSMServiceAccount } else { $null }),
        'PSMApp'
    )
    if (-not $AcceptDefaults) {
        Write-Host ''
        Write-Host '--- Service Account Names ---' -ForegroundColor White
        Write-Host "  CPM User : $cpmUser"
        Write-Host "  PSM User : $psmUser"
        Write-Host '  (These are the CyberArk vault users assigned safe permissions)' -ForegroundColor DarkGray
        if (-not (Confirm-UserChoice -Prompt 'Accept these service account names?' -Default 'Y')) {
            $cpmOverride = Read-Host "  CPM User [$cpmUser]"
            if (-not [string]::IsNullOrWhiteSpace($cpmOverride)) { $cpmUser = $cpmOverride.Trim() }
            $psmOverride = Read-Host "  PSM User [$psmUser]"
            if (-not [string]::IsNullOrWhiteSpace($psmOverride)) { $psmUser = $psmOverride.Trim() }
        }
    }

    # Simulator path
    $simPath = $null
    if ($Simulate) {
        $simPath = Find-SimulatorPath
        if (-not $simPath) { throw "CPM simulator not found. Provide -SimulatorPath explicitly." }
        Write-SetupLog -Level INFO -Message "Simulator path: $simPath"
    }

    # Build config bundle
    $runConfig = @{
        PVWAUrl      = $pvwaUrl
        PVWACred     = $pvwaCred
        OktaDomain   = $effectiveOktaDomain
        OrgName      = $orgName
        TenantId     = $tenantId
        AccountFilter = $AccountFilter
        IncludeTiers = $IncludeTiers
        IncludeReadOnly = [bool]$IncludeReadOnly
        EnrollTOTP   = [bool]$EnrollTOTP
        Simulate     = [bool]$Simulate
        SimPath      = $simPath
        GenerateBGQR = [bool]$GenerateBGQR
        CPMUser      = $cpmUser
        PSMUser      = $psmUser
        PlatformDir  = $platformDir
        Naming       = $naming
    }

    # Pre-flight confirmation
    if (-not (Confirm-Proceed -Config $runConfig)) {
        Write-SetupLog -Level WARN -Message "Setup aborted by user."
        return
    }

    # Connect to PVWA.
    # In WhatIf mode: connect if credentials are available (GETs return real state for
    # accurate dry-run output; POST/PUT/DELETE are already suppressed in Invoke-PVWARequest).
    # If no credentials in WhatIf, session stays $null -- Invoke-PVWARequest returns $null
    # for all calls, and phases show "Would create..." messages.
    $hasAuth = $pvwaCred -or $PVWAToken -or $ClientId -or $Script:CAAuthAvailable
    if ($hasAuth) {
        $connectParams = @{
            Url        = $pvwaUrl
            AuthMethod = $AuthMethod
        }
        if ($pvwaCred)          { $connectParams['Credential'] = $pvwaCred }
        if ($PVWAToken)         { $connectParams['Token'] = $PVWAToken; $connectParams['TokenType'] = $PVWATokenType }
        if ($TenantUrl) { $connectParams['IdentityTenantUrl'] = $TenantUrl }
        if ($ClientId)    { $connectParams['ClientId'] = $ClientId }
        if ($ClientSecret){ $connectParams['ClientSecret'] = $ClientSecret }
        if ($WhatIfPreference) {
            Write-SetupLog -Level INFO -Message "[WhatIf] Connecting to PVWA for read-only state checks (write operations are suppressed)"
        }
        Connect-PVWA @connectParams
    }
    else {
        $Script:PVWABaseUrl = $pvwaUrl
        if ($WhatIfPreference) {
            Write-SetupLog -Level INFO -Message "[WhatIf] No PVWA credentials -- all PVWA calls will return simulated results"
        }
        else {
            Write-SetupLog -Level WARN -Message "No PVWA authentication available. PVWA operations will fail."
        }
    }
    try {
        if ($Script:PVWASession) {
            try {
                $null = Test-PVWAConnectivity
            }
            catch {
                Write-SetupLog -Level ERROR -Message "PVWA connectivity test failed: $($_.Exception.Message)"
                if (-not $WhatIfPreference) {
                    throw "Cannot continue -- PVWA is not reachable. Check your URL and credentials."
                }
                Write-SetupLog -Level INFO -Message '[WhatIf] Continuing with simulated results despite connectivity failure.'
            }
        }

        # Record of IDs (populated as we go)
        $recordOfIds = [ordered]@{}

        # ----------------------------------------------------------------
        # 1. Platform Import
        # ----------------------------------------------------------------
        if (-not $SkipPlatformImport -and -not $VerifyOnly) {
            Write-SetupLog -Level STEP -Message '=== Phase 1: Platform Import ==='
            try {
                $existing = Test-CyberArkPlatform
                if ($existing) {
                    Write-SetupLog -Level SKIP -Message "Platform '$Script:OKTA_PLATFORM' already exists (Active: $($existing.Active))"
                    Register-Operation -Type Skipped
                    if (-not $existing.Active) {
                        Write-SetupLog -Level INFO -Message "Platform exists but is inactive -- activating"
                        Enable-CyberArkPlatform
                    }
                }
                else {
                    if (Test-Path $platformDir) {
                        Import-CyberArkPlatform -SourceDirectory $platformDir
                        Enable-CyberArkPlatform
                        # Note: Import-CyberArkPlatform already calls Register-Operation internally
                    }
                    else {
                        Write-SetupLog -Level WARN -Message "Platform source not found at '$platformDir'. Use -SkipPlatformImport if already imported."
                    }
                }
            }
            catch {
                Write-SetupLog -Level ERROR -Message "Phase 1 (Platform Import) failed: $($_.Exception.Message)"
                Write-SetupLog -Level INFO -Message 'Continuing to next phase. Platform may already be imported or can be done manually.'
                Register-Operation -Type Failed
            }
        }

        if ($VerifyOnly) {
            # Jump directly to verification
            Write-SetupLog -Level STEP -Message '=== VerifyOnly: Skipping all creation steps ==='
            $null = Test-SetupVerification -Config $runConfig -RecordOfIds $recordOfIds
            Export-RecordOfIDs -RecordOfIds $recordOfIds -Config $runConfig
            Write-ManualStepsGuide
            $durationSec = [int]((Get-Date) - $startTime).TotalSeconds
            Write-DeploymentSummary -DurationSeconds $durationSec
            return
        }

        # ----------------------------------------------------------------
        # 1.5. PSM Connection Components (WebForm + AutoIt -- multi-connector)
        # ----------------------------------------------------------------
        # CyberArk supports multiple connection components per platform.
        # Users see a dropdown in PVWA when connecting:
        #   Connect via: > Okta OIE (WebForm Hardened)  [default]
        #                > Okta OIE (AutoIt)
        # This phase deploys whichever connectors you want, all at once.
        # ----------------------------------------------------------------
        Write-SetupLog -Level STEP -Message '=== Phase 1.5: PSM Connection Components ==='
        try {
            # Inventory: check which components already exist
            # DisplayNames in PVWA:
            #   "Okta HLA"            = AutoIt (default -- no method suffix)
            #   "Okta HLA (WebForm)"  = WebForm Hardened
            $knownComponents = [ordered]@{
                'PSM-OktaOIE'            = @{ Variant = 'AutoIt';     Type = 'AutoIt';  Exists = $false; Label = 'Okta HLA -- AutoIt (default connector)' }
                'PSM-OktaOIE-WebForm-H'  = @{ Variant = 'Hardened';   Type = 'WebForm'; Exists = $false; Label = 'Okta HLA (WebForm) -- adaptive 5-path OIE' }
                'PSM-OktaOIE-WebForm'    = @{ Variant = 'Native';     Type = 'WebForm'; Exists = $false; Label = 'Okta HLA (WebForm Native) -- password-first only' }
                'PSM-OktaOIE-WebForm-PC' = @{ Variant = 'PreConnect'; Type = 'WebForm'; Exists = $false; Label = 'Okta HLA (WebForm PreConnect) -- external DLL' }
            }

            Write-SetupLog -Level INFO -Message 'Checking existing connection components...'
            foreach ($ccId in @($knownComponents.Keys)) {
                $existing = Test-ConnectionComponent -ComponentId $ccId
                if ($existing) {
                    $knownComponents[$ccId].Exists = $true
                    Write-SetupLog -Level OK -Message "  Found: $ccId"
                }
            }

            $existingCount = @($knownComponents.Values | Where-Object { $_.Exists }).Count
            if ($existingCount -gt 0) {
                Write-SetupLog -Level INFO -Message "$existingCount connector(s) already deployed."
            }

            # Determine what to deploy
            $toDeploy = @()

            if ($AcceptDefaults -or $WhatIfPreference) {
                # AcceptDefaults: deploy both AutoIt (default name) + WebForm
                $toDeploy += 'AutoIt'
                if (-not $knownComponents['PSM-OktaOIE-WebForm-H'].Exists) {
                    $toDeploy += 'Hardened'
                }
            }
            else {
                Write-Host ''
                Write-Host '--- PSM Connection Components ---' -ForegroundColor White
                Write-Host '  CyberArk supports multiple connectors per platform.' -ForegroundColor DarkGray
                Write-Host '  Users see a dropdown when clicking Connect in PVWA:' -ForegroundColor DarkGray
                Write-Host ''
                Write-Host '    "Okta HLA"           = AutoIt connector (default)' -ForegroundColor White
                Write-Host '    "Okta HLA (WebForm)" = WebForm connector' -ForegroundColor White
                Write-Host ''
                Write-Host '  Notes:' -ForegroundColor DarkGray
                Write-Host '    - AutoIt shows up but won''t work until .au3/.exe is deployed to PSM server' -ForegroundColor DarkGray
                Write-Host '    - WebForm works immediately (managed entirely through PVWA)' -ForegroundColor DarkGray
                Write-Host '    - Deploy both to test side by side, swap default anytime in PVWA' -ForegroundColor DarkGray
                Write-Host ''
                Write-Host '  Available connectors:' -ForegroundColor White

                $menuItems = @(
                    @{ Key = '1'; Id = 'PSM-OktaOIE';            Desc = 'Okta HLA (AutoIt) -- needs .au3 on PSM server' }
                    @{ Key = '2'; Id = 'PSM-OktaOIE-WebForm-H';  Desc = 'Okta HLA (WebForm) -- adaptive, handles all OIE factor orderings, works immediately' }
                )
                foreach ($item in $menuItems) {
                    $status = if ($knownComponents[$item.Id].Exists) { ' [DEPLOYED]' } else { '' }
                    $color  = if ($knownComponents[$item.Id].Exists) { 'Green' } else { 'DarkGray' }
                    Write-Host "    $($item.Key). $($item.Desc)$status" -ForegroundColor $color
                }
                Write-Host ''
                Write-Host '  Enter numbers to deploy (comma-separated). Examples:' -ForegroundColor DarkGray
                Write-Host '    1,2    -- Both (recommended -- parallel testing / fallback)' -ForegroundColor DarkGray
                Write-Host '    2      -- WebForm only (works immediately, no PSM server work)' -ForegroundColor DarkGray
                Write-Host '    1      -- AutoIt only (deploy .au3 to PSM server separately)' -ForegroundColor DarkGray
                Write-Host '    <Enter> -- Skip' -ForegroundColor DarkGray
                Write-Host ''
                $ccInput = Read-Host '  Deploy connectors [1,2]'
                if ([string]::IsNullOrWhiteSpace($ccInput)) { $ccInput = '1,2' }

                foreach ($choice in ($ccInput -split '[,\s]+')) {
                    switch ($choice.Trim()) {
                        '1' { $toDeploy += 'AutoIt' }
                        '2' { if (-not $knownComponents['PSM-OktaOIE-WebForm-H'].Exists) { $toDeploy += 'Hardened' } else { Write-SetupLog -Level SKIP -Message 'Okta HLA (WebForm) already deployed' } }
                        default { Write-SetupLog -Level WARN -Message "Unknown connector choice: $choice" }
                    }
                }
            }

            # Deploy each selected connector
            foreach ($variant in $toDeploy) {
                if ($variant -eq 'AutoIt') {
                    Write-SetupLog -Level INFO -Message 'AutoIt connector requires PSM server file deployment.'
                    Write-Host ''
                    Write-Host '--- AutoIt PSM Connector Deployment (Manual Steps) ---' -ForegroundColor Yellow
                    Write-Host '  1. Copy psm/okta-oie/ folder to PSM server:' -ForegroundColor DarkGray
                    Write-Host '     %PROGRAMFILES%\CyberArk\PSM\Connectors\PSMOktaOIE\' -ForegroundColor White
                    Write-Host '  2. Compile PSM-OktaOIE-Connector.au3 with AutoIt3 on PSM server' -ForegroundColor DarkGray
                    Write-Host '  3. Add AppLocker rule for the compiled .exe' -ForegroundColor DarkGray
                    Write-Host '  4. In PVWA, add connection component "PSM-OktaOIE" (type: CyberArkPSM)' -ForegroundColor DarkGray
                    Write-Host '  5. Restart PSM service' -ForegroundColor DarkGray
                    Write-Host '  6. Then re-run this script -- it will detect the component and' -ForegroundColor DarkGray
                    Write-Host '     associate it with the OktaCloud platform automatically.' -ForegroundColor DarkGray
                    Write-Host ''
                    continue
                }

                # WebForm variants -- deploy via API
                $ccXmlPath = Get-WebFormXmlPath -Variant $variant
                if (-not $ccXmlPath) {
                    Write-SetupLog -Level WARN -Message "WebForm XML not found for variant '$variant'. Expected in psm/okta-oie-webform/"
                    continue
                }

                # Derive component ID from the XML
                $ccId = $null
                try {
                    [xml]$ccXml = Get-Content $ccXmlPath -Raw
                    $ccId = $ccXml.ConnectionComponent.Id
                }
                catch {}
                if (-not $ccId) { $ccId = "PSM-OktaOIE-WebForm-$($variant.Substring(0,1))" }

                $imported = Import-ConnectionComponentFromXml -XmlPath $ccXmlPath -ComponentId $ccId
                if ($imported) {
                    Add-PlatformConnectionComponent -ComponentId $ccId
                }
            }

            # Ensure ALL existing components are associated with the platform
            foreach ($ccId in @($knownComponents.Keys)) {
                if ($knownComponents[$ccId].Exists) {
                    Add-PlatformConnectionComponent -ComponentId $ccId
                }
            }

            # Collect all component IDs that are now deployed (existing + newly created)
            $deployedComponentIds = @()
            foreach ($ccId in @($knownComponents.Keys)) {
                if ($knownComponents[$ccId].Exists) { $deployedComponentIds += $ccId }
            }
            # Also include any we just deployed (may not be in knownComponents.Exists yet)
            foreach ($variant in $toDeploy) {
                if ($variant -ne 'AutoIt') {
                    $variantXml = Get-WebFormXmlPath -Variant $variant
                    if ($variantXml) {
                        try {
                            [xml]$x = Get-Content $variantXml -Raw
                            $id = $x.ConnectionComponent.Id
                            if ($id -and $id -notin $deployedComponentIds) { $deployedComponentIds += $id }
                        }
                        catch {}
                    }
                }
                else {
                    if ('PSM-OktaOIE' -notin $deployedComponentIds) { $deployedComponentIds += 'PSM-OktaOIE' }
                }
            }

            # PSM Server Targeting: deploy connection components to specific PSM servers
            if ($deployedComponentIds.Count -gt 0) {
                Write-SetupLog -Level STEP -Message '--- PSM Server Targeting ---'
                $targetServers = Select-PSMServers -Purpose 'Okta HLA connector deployment'
                if ($targetServers.Count -gt 0) {
                    foreach ($server in $targetServers) {
                        foreach ($compId in $deployedComponentIds) {
                            try {
                                $null = Add-ConnectionComponentToPSMServer -PSMServerId $server.Id -ComponentId $compId
                            }
                            catch {
                                Write-SetupLog -Level WARN -Message "Failed to add '$compId' to server '$($server.Name)': $($_.Exception.Message)"
                            }
                        }
                    }
                }
                else {
                    Write-SetupLog -Level INFO -Message 'PSM server targeting skipped (no servers discovered or selected).'
                    Write-SetupLog -Level INFO -Message 'Manual step: PVWA > Admin > PSM Servers > {server} > Connection Components > Add'
                }
            }

            if ($toDeploy.Count -eq 0 -and $existingCount -eq 0) {
                Write-SetupLog -Level SKIP -Message 'No connection components deployed. Deploy later via re-run or PVWA admin console.'
                Register-Operation -Type Skipped
            }
        }
        catch {
            Write-SetupLog -Level ERROR -Message "Phase 1.5 (Connection Components) failed: $($_.Exception.Message)"
            Write-SetupLog -Level INFO -Message 'Continuing to next phase. Connection components can be imported manually.'
            Register-Operation -Type Failed
        }

        # ----------------------------------------------------------------
        # 2. Safes
        # ----------------------------------------------------------------
        Write-SetupLog -Level STEP -Message '=== Phase 2: Safes ==='
        try {
            $safeDescriptions = @{
                $naming.PasswordSafe = 'Okta HLA privileged account passwords -- Tier 1/2/3 service accounts'
                $naming.MFASafe      = 'Okta HLA TOTP/MFA seed keys for PSM auto-inject'
                $naming.CPMSafe      = 'Okta CPM service account (SSWS token for rotation)'
                $naming.BGSafe       = 'Okta break-glass audit record -- dual-control approval required'
            }

            foreach ($safeName in @($naming.PasswordSafe, $naming.MFASafe, $naming.CPMSafe, $naming.BGSafe)) {
                $desc = $safeDescriptions[$safeName]
                try {
                    New-HLASafe -SafeName $safeName -Description $desc -CPMName $cpmUser | Out-Null
                }
                catch {
                    Write-SetupLog -Level ERROR -Message "Failed to create/verify safe '$safeName': $($_.Exception.Message)"
                    Register-Operation -Type Failed
                }
            }
        }
        catch {
            Write-SetupLog -Level ERROR -Message "Phase 2 (Safes) failed: $($_.Exception.Message)"
            Write-SetupLog -Level INFO -Message 'Continuing to next phase. Safes may need manual creation.'
            Register-Operation -Type Failed
        }

        # ----------------------------------------------------------------
        # 3. Safe Permissions
        # ----------------------------------------------------------------
        Write-SetupLog -Level STEP -Message '=== Phase 3: Safe Permissions ==='
        try {
            # --- Safe Admin Group (orphan protection) ---
            # Add the admin group as full owner of EVERY safe FIRST, before any other members.
            # This guarantees the safe is always manageable even if subsequent steps fail
            # or the creating service account is later removed.
            $safeAdminPerms = Get-SafePermissions -SafeRole Passwords -MemberRole SafeAdmin
            foreach ($safeName in @($naming.PasswordSafe, $naming.MFASafe, $naming.CPMSafe, $naming.BGSafe)) {
                Set-HLASafeMembers -SafeName $safeName -MemberName $SafeAdminGroup -MemberType 'Group' `
                    -Permissions $safeAdminPerms | Out-Null
            }
            Write-SetupLog -Level OK -Message "Admin group '$SafeAdminGroup' added as owner to all 4 safes"

            # Passwords safe
            Set-HLASafeMembers -SafeName $naming.PasswordSafe -MemberName $naming.UsersGroup -MemberType 'Group' `
                -Permissions (Get-SafePermissions -SafeRole Passwords -MemberRole UsersGroup) | Out-Null
            Set-HLASafeMembers -SafeName $naming.PasswordSafe -MemberName $cpmUser -MemberType 'User' `
                -Permissions (Get-SafePermissions -SafeRole Passwords -MemberRole CPMUser) | Out-Null
            Set-HLASafeMembers -SafeName $naming.PasswordSafe -MemberName $psmUser -MemberType 'User' `
                -Permissions (Get-SafePermissions -SafeRole Passwords -MemberRole PSMUser) | Out-Null

            # MFA safe
            Set-HLASafeMembers -SafeName $naming.MFASafe -MemberName $naming.UsersGroup -MemberType 'Group' `
                -Permissions (Get-SafePermissions -SafeRole MFAKeys -MemberRole UsersGroup) | Out-Null
            Set-HLASafeMembers -SafeName $naming.MFASafe -MemberName $psmUser -MemberType 'User' `
                -Permissions (Get-SafePermissions -SafeRole MFAKeys -MemberRole PSMUser) | Out-Null

            # CPM safe
            Set-HLASafeMembers -SafeName $naming.CPMSafe -MemberName $cpmUser -MemberType 'User' `
                -Permissions (Get-SafePermissions -SafeRole CPMServiceAccounts -MemberRole CPMUser) | Out-Null
            Set-HLASafeMembers -SafeName $naming.CPMSafe -MemberName $naming.ApproversGroup -MemberType 'Group' `
                -Permissions (Get-SafePermissions -SafeRole CPMServiceAccounts -MemberRole ApproversGroup) | Out-Null

            # BreakGlass safe
            Set-HLASafeMembers -SafeName $naming.BGSafe -MemberName $naming.ApproversGroup -MemberType 'Group' `
                -Permissions (Get-SafePermissions -SafeRole BreakGlass -MemberRole ApproversGroup) | Out-Null
        }
        catch {
            Write-SetupLog -Level ERROR -Message "Phase 3 (Safe Permissions) failed: $($_.Exception.Message)"
            Write-SetupLog -Level INFO -Message 'Continuing to next phase. Some permissions may need manual assignment.'
            Register-Operation -Type Failed
        }

        # ----------------------------------------------------------------
        # 4. Vault Groups
        # ----------------------------------------------------------------
        Write-SetupLog -Level STEP -Message '=== Phase 4: Vault Groups ==='
        try {
            New-HLAVaultGroup -GroupName $naming.UsersGroup `
                -Description 'Okta HLA service account users -- listAccounts + useAccounts only' | Out-Null
            New-HLAVaultGroup -GroupName $naming.ApproversGroup `
                -Description 'Okta HLA approvers -- dual-control authorization for Tier 1 and break-glass' | Out-Null
        }
        catch {
            Write-SetupLog -Level ERROR -Message "Phase 4 (Vault Groups) failed: $($_.Exception.Message)"
            Write-SetupLog -Level INFO -Message 'Continuing to next phase. Groups may need manual creation.'
            Register-Operation -Type Failed
        }

        # ----------------------------------------------------------------
        # 5. Discover Okta Accounts
        # ----------------------------------------------------------------
        $discoveredAccounts = @()
        $newAccounts = @()

        if ($SkipOktaDiscovery) {
            Write-SetupLog -Level STEP -Message '=== Phase 5: Okta Account Discovery [SKIPPED -- CyberArk-only mode] ==='
            Write-SetupLog -Level INFO -Message 'Re-run without -SkipOktaDiscovery to discover and onboard Okta accounts.'
        }
        else {
            Write-SetupLog -Level STEP -Message '=== Phase 5: Okta Account Discovery ==='
            try {
                $discoveredAccounts = Get-OktaHLAAccounts `
                    -Filter $runConfig.AccountFilter `
                    -IncludeTiers $runConfig.IncludeTiers `
                    -IncludeReadOnly:$runConfig.IncludeReadOnly

                if ($null -eq $discoveredAccounts -or @($discoveredAccounts).Count -eq 0) {
                    Write-SetupLog -Level WARN -Message "No accounts discovered matching filter '$($runConfig.AccountFilter)'. Check -AccountFilter and Okta token permissions."
                }

                # Compute delta (skip already-onboarded)
                if ($null -eq $discoveredAccounts -or @($discoveredAccounts).Count -eq 0) {
                    $newAccounts = @()
                }
                else {
                    $newAccounts = Get-SafeDelta -OktaAccounts $discoveredAccounts -SafeName $naming.PasswordSafe
                }
            }
            catch {
                Write-SetupLog -Level ERROR -Message "Phase 5 (Account Discovery) failed: $($_.Exception.Message)"
                Write-SetupLog -Level INFO -Message 'Continuing -- account onboarding phases will be skipped since no accounts were discovered.'
                Register-Operation -Type Failed
            }
        }

        # ----------------------------------------------------------------
        # 6. CPM SSWS Token (Path B self-mint)
        # ----------------------------------------------------------------
        $cpmToken = $null

        if ($SkipOktaDiscovery) {
            Write-SetupLog -Level STEP -Message '=== Phase 6: CPM SSWS Token [SKIPPED -- CyberArk-only mode] ==='
            Write-SetupLog -Level INFO -Message 'CPM token minting requires Okta API. Re-run without -SkipOktaDiscovery.'
        }
        elseif ($legacyConfig -and $legacyConfig.SSWSToken.TokenValue -ne 'FILL_ME_IN') {
            Write-SetupLog -Level STEP -Message '=== Phase 6: CPM SSWS Token ==='
            # Legacy config provides the token directly
            $cpmToken = $legacyConfig.SSWSToken.TokenValue
            Write-SetupLog -Level INFO -Message "CPM SSWS token provided via legacy config"
        }
        elseif ($Script:OktaTokenLevel -eq 'SuperAdmin') {
            Write-SetupLog -Level STEP -Message '=== Phase 6: CPM SSWS Token ==='

            # Check if the Okta token we're already using IS the CPM token.
            # Common in environments where CPM needs SuperAdmin to manage S0 accounts.
            $tokenOwnerLogin = if ($Script:OktaTokenOwner) { $Script:OktaTokenOwner.Login } else { $null }
            $tokenIsCpm = $false
            if ($tokenOwnerLogin) {
                Write-Host ''
                Write-Host "  The Okta SSWS token belongs to: $tokenOwnerLogin" -ForegroundColor White
                Write-Host '  If this is also the CPM service account, the existing token can be' -ForegroundColor DarkGray
                Write-Host '  reused directly (no need to mint a new one via Path B).' -ForegroundColor DarkGray
                Write-Host ''
                $tokenIsCpm = Confirm-UserChoice -Prompt "Is '$tokenOwnerLogin' the CPM service account for CyberArk?" -Default 'Y'
            }

            if ($tokenIsCpm) {
                # Reuse the current Okta token as the CPM SSWS token
                $cpmToken = $OktaToken
                Write-SetupLog -Level OK -Message "Using existing SSWS token as CPM token (owner: $tokenOwnerLogin)"
                Write-SetupLog -Level INFO -Message 'Path B minting skipped -- token already belongs to CPM service account.'
            }
            else {
                # Path B: find a different CPM user in Okta and mint a new token
                Write-SetupLog -Level INFO -Message "Searching for CPM service user in Okta..."
                Write-SetupLog -Level INFO -Message "Looking for user matching 'cpm' pattern in Okta..."
                $cpmOktaUsers = $null
                foreach ($searchTerm in @('cpm', 'PasswordManager', 'okta-cpm')) {
                    try {
                        $found = Invoke-OktaRequest -Path "/api/v1/users?search=profile.login+sw+%22svc%22&q=$([uri]::EscapeDataString($searchTerm))&limit=10"
                        if ($found -and $found.Count -gt 0) { $cpmOktaUsers = $found; break }
                    }
                    catch { continue }
                }

                if ($cpmOktaUsers) {
                    Write-Host ''
                    Write-Host 'Found potential CPM service user(s) in Okta:' -ForegroundColor Yellow
                    for ($i = 0; $i -lt $cpmOktaUsers.Count; $i++) {
                        Write-Host "  [$i] $($cpmOktaUsers[$i].profile.login) (id: $($cpmOktaUsers[$i].id))"
                    }
                    $sel = Read-Host 'Enter index of CPM service user, or S to skip Path B'
                    if ($sel.Trim().ToUpper() -ne 'S' -and $sel -match '^\d+$') {
                        $cpmOktaUser = $cpmOktaUsers[[int]$sel]
                        $cpmToken = New-OktaAPIToken -CPMUserId $cpmOktaUser.id `
                            -CPMUserLogin $cpmOktaUser.profile.login `
                            -TokenName "cyberark-cpm-$(Get-Date -Format yyyyMMdd)"
                    }
                }
                else {
                    Write-SetupLog -Level WARN -Message "Could not auto-locate CPM Okta user."
                    Write-Host ''
                    Write-Host '  Options:' -ForegroundColor DarkGray
                    Write-Host '    1. Enter the CPM Okta user login manually' -ForegroundColor DarkGray
                    Write-Host '    2. Provide an existing SSWS token for the CPM account' -ForegroundColor DarkGray
                    Write-Host '    3. Press Enter to skip (linked accounts 1 and 3 will not be configured)' -ForegroundColor DarkGray
                    Write-Host ''
                    $cpmChoice = Read-Host '  Choice [1/2/3]'
                    if ($cpmChoice -eq '1') {
                        $cpmLoginManual = Read-Host '  CPM Okta user login'
                        if (-not [string]::IsNullOrWhiteSpace($cpmLoginManual)) {
                            $cpmUserObj = Invoke-OktaRequest -Path "/api/v1/users?search=profile.login+eq+%22$([uri]::EscapeDataString($cpmLoginManual))%22"
                            if ($cpmUserObj -and @($cpmUserObj).Count -gt 0) {
                                $cpmToken = New-OktaAPIToken -CPMUserId $cpmUserObj[0].id `
                                    -CPMUserLogin $cpmLoginManual `
                                    -TokenName "cyberark-cpm-$(Get-Date -Format yyyyMMdd)"
                            }
                            else {
                                Write-SetupLog -Level WARN -Message "User '$cpmLoginManual' not found in Okta."
                            }
                        }
                    }
                    elseif ($cpmChoice -eq '2') {
                        $cpmTokenManual = Get-SecureInput -Prompt '  CPM SSWS token'
                        if ($cpmTokenManual) { $cpmToken = $cpmTokenManual }
                    }
                }
            }
        }
        else {
            Write-SetupLog -Level STEP -Message '=== Phase 6: CPM SSWS Token ==='
            Write-SetupLog -Level WARN -Message "Token level is $Script:OktaTokenLevel -- Path B (CPM token self-mint) requires Super Admin."
            Write-SetupLog -Level WARN -Message "SSWS token for CPM must be provided manually or via legacy config."
            $cpmTokenManual = Get-SecureInput -Prompt 'Enter CPM SSWS token (or press Enter to skip)'
            if ($cpmTokenManual) { $cpmToken = $cpmTokenManual }
        }

        if ($cpmToken) {
            try {
                $sswsAccount = Add-SSWSAccount -SafeName $naming.CPMSafe `
                    -Address $effectiveOktaDomain `
                    -TokenValue $cpmToken
                $recordOfIds["CPM SSWS Token ($Script:CPM_ACCOUNT_NAME)"] = $sswsAccount.id
            }
            catch {
                Write-SetupLog -Level ERROR -Message "Failed to onboard CPM SSWS token: $($_.Exception.Message)"
                Write-SetupLog -Level INFO -Message 'Continuing -- linked account indexes 1 and 3 will be skipped.'
                $cpmToken = $null
                Register-Operation -Type Failed
            }
        }
        else {
            Write-SetupLog -Level WARN -Message "No CPM SSWS token available -- SSWS account not onboarded. Linked account indexes 1 and 3 will be skipped."
        }

        # ----------------------------------------------------------------
        # 7. HLA Password Accounts
        # ----------------------------------------------------------------
        $hlaAccountIds = @{}   # login -> CyberArk account id

        if ($SkipOktaDiscovery) {
            Write-SetupLog -Level STEP -Message '=== Phase 7: HLA Password Accounts [SKIPPED -- CyberArk-only mode] ==='
        }
        else {
        Write-SetupLog -Level STEP -Message '=== Phase 7: HLA Password Accounts ==='
        try {
            foreach ($acct in $newAccounts) {
                # Get initial password -- prompt per account or from legacy config
                $password = $null
                if ($legacyConfig) {
                    $legacyMatch = $legacyConfig.HLAAccounts | Where-Object { $_.Username -eq $acct.Login }
                    if ($legacyMatch -and $legacyMatch.Password -ne 'FILL_ME_IN') {
                        $password = $legacyMatch.Password
                    }
                }
                if (-not $password) {
                    if ($WhatIfPreference) {
                        $password = "WhatIf-Placeholder-$([guid]::NewGuid().ToString('N').Substring(0,8))"
                    }
                    else {
                        Write-SetupLog -Level INFO -Message "Initial password needed for $($acct.Login)"
                        $password = Get-SecureInput -Prompt "Initial password for $($acct.Login) (or press Enter to use placeholder)"
                        if ([string]::IsNullOrWhiteSpace($password)) {
                            $password = "PlaceholderPass-$(Get-Date -Format yyyyMMddHHmmss)-$([guid]::NewGuid().ToString('N').Substring(0,8))"
                            Write-SetupLog -Level WARN -Message "Using placeholder password for $($acct.Login) -- change immediately after setup"
                        }
                    }
                }

                try {
                    $hlaAcct = Add-HLAAccount `
                        -Username $acct.Login `
                        -Address  $acct.Address `
                        -SafeName $naming.PasswordSafe `
                        -Password $password `
                        -OktaUserId $acct.OktaId `
                        -Tier $acct.Tier

                    if ($hlaAcct) {
                        $hlaAccountIds[$acct.Login] = $hlaAcct.id
                        $recordOfIds["HLA Password ($($acct.Login))"] = $hlaAcct.id
                    }
                }
                catch {
                    Write-SetupLog -Level ERROR -Message "Failed to onboard $($acct.Login): $($_.Exception.Message)"
                    Register-Operation -Type Failed
                }
                finally {
                    Clear-SensitiveString -StringRef ([ref]$password)
                }
            }

            # Also include already-existing accounts for linking
            try {
                $existingHLASearch = Invoke-PVWARequest -Path "/api/Accounts?safeName=$([uri]::EscapeDataString($naming.PasswordSafe))&limit=1000"
                foreach ($a in $(if ($null -ne $existingHLASearch) { $existingHLASearch.value } else { @() })) {
                    if (-not $hlaAccountIds.ContainsKey($a.userName)) {
                        $hlaAccountIds[$a.userName] = $a.id
                    }
                }
            }
            catch { Write-SetupLog -Level WARN -Message "Could not enumerate existing HLA accounts for linking: $_" }
        }
        catch {
            Write-SetupLog -Level ERROR -Message "Phase 7 (HLA Accounts) failed: $($_.Exception.Message)"
            Write-SetupLog -Level INFO -Message 'Continuing to next phase.'
            Register-Operation -Type Failed
        }

        } # end SkipOktaDiscovery guard for Phase 7

        # ----------------------------------------------------------------
        # 8. TOTP Seed Accounts
        # ----------------------------------------------------------------
        $totpAccountIds = @{}   # login -> CyberArk TOTP account id (initialized here so Phase 9 never hits undefined)
        if ($SkipOktaDiscovery) {
            Write-SetupLog -Level STEP -Message '=== Phase 8: TOTP Seed Accounts [SKIPPED -- CyberArk-only mode] ==='
        }
        else {
        Write-SetupLog -Level STEP -Message '=== Phase 8: TOTP Seed Accounts ==='

        foreach ($acct in $discoveredAccounts) {
            $totpSeed = $null

            if ($EnrollTOTP) {
                if ($Script:OktaTokenLevel -ne 'SuperAdmin') {
                    Write-SetupLog -Level WARN -Message "TOTP enrollment requires Super Admin token. Skipping for $($acct.Login)."
                }
                else {
                    $enrollment = Invoke-OktaTOTPEnrollment `
                        -UserId   $acct.OktaId `
                        -UserLogin $acct.Login `
                        -OrgName  $orgName
                    if ($enrollment) {
                        $totpSeed = $enrollment.SharedSecret
                        if ($Simulate -and $simPath) {
                            Write-SeedToSimulator -SimPath $simPath -Username $acct.Login -Seed $totpSeed
                        }
                    }
                }
            }
            else {
                # Try legacy config
                if ($legacyConfig) {
                    $legacyMatch = $legacyConfig.HLAAccounts | Where-Object { $_.Username -eq $acct.Login }
                    if ($legacyMatch -and $legacyMatch.TOTPSeed -ne 'FILL_ME_IN') {
                        $totpSeed = $legacyMatch.TOTPSeed
                    }
                }
                if (-not $totpSeed) {
                    if ($WhatIfPreference) {
                        Write-SetupLog -Level INFO -Message "[WhatIf] Would prompt for TOTP seed for $($acct.Login)"
                    }
                    else {
                        Write-SetupLog -Level INFO -Message "TOTP seed needed for $($acct.Login) (use -EnrollTOTP to auto-enroll)"
                        $totpSeed = Get-SecureInput -Prompt "TOTP seed for $($acct.Login) (Base32, or Enter to skip)"
                    }
                }
            }

            if ($totpSeed) {
                $totpAcct = Add-TOTPAccount `
                    -Username $acct.Login `
                    -Address  $acct.Address `
                    -SafeName $naming.MFASafe `
                    -TOTPSeed $totpSeed
                if ($totpAcct) {
                    $totpAccountIds[$acct.Login] = $totpAcct.id
                    $recordOfIds["TOTP Seed ($($acct.Login))"] = $totpAcct.id
                }
            }
            else {
                Write-SetupLog -Level SKIP -Message "No TOTP seed for $($acct.Login) -- TOTP account not created"
            }
        }

        } # end SkipOktaDiscovery guard for Phase 8

        # ----------------------------------------------------------------
        # 9. Link Accounts (ExtraPass 1/2/3)
        # ----------------------------------------------------------------
        if ($SkipOktaDiscovery) {
            Write-SetupLog -Level STEP -Message '=== Phase 9: Linked Accounts [SKIPPED -- CyberArk-only mode] ==='
        }
        else {
        Write-SetupLog -Level STEP -Message '=== Phase 9: Linked Accounts ==='

        foreach ($login in $hlaAccountIds.Keys) {
            $hlaId = $hlaAccountIds[$login]
            if ($hlaId -like 'WHATIF*') { continue }

            # ExtraPass 1 + 3 = SSWS token (logon + reconcile)
            if ($cpmToken -and $recordOfIds.ContainsKey("CPM SSWS Token ($Script:CPM_ACCOUNT_NAME)")) {
                Set-LinkedAccount -HLAAccountId $hlaId `
                    -ExtraPasswordIndex $Script:EXTRA_PASS_LOGON `
                    -LinkedSafeName $naming.CPMSafe `
                    -LinkedAccountName $Script:CPM_ACCOUNT_NAME

                Set-LinkedAccount -HLAAccountId $hlaId `
                    -ExtraPasswordIndex $Script:EXTRA_PASS_RECONCILE `
                    -LinkedSafeName $naming.CPMSafe `
                    -LinkedAccountName $Script:CPM_ACCOUNT_NAME
            }

            # ExtraPass 2 = TOTP seed
            if ($totpAccountIds.ContainsKey($login)) {
                $totpUsername = "$login$Script:TOTP_SUFFIX"
                Set-LinkedAccount -HLAAccountId $hlaId `
                    -ExtraPasswordIndex $Script:EXTRA_PASS_TOTP `
                    -LinkedSafeName $naming.MFASafe `
                    -LinkedAccountName $totpUsername
            }
        }

        } # end SkipOktaDiscovery guard for Phase 9

        # ----------------------------------------------------------------
        # 10. Break-Glass
        # ----------------------------------------------------------------
        if ($SkipOktaDiscovery) {
            Write-SetupLog -Level STEP -Message '=== Phase 10: Break-Glass [SKIPPED -- CyberArk-only mode] ==='
            Write-SetupLog -Level INFO -Message 'Break-glass setup requires Okta API for TOTP enrollment. Re-run without -SkipOktaDiscovery.'
        }
        else {
        Write-SetupLog -Level STEP -Message '=== Phase 10: Break-Glass ==='

        $bgUsername  = $null
        $bgPlaceholder = 'PLACEHOLDER-SEE-BREAK-GLASS-SOP'

        if ($legacyConfig -and $legacyConfig.BreakGlass) {
            $bgUsername = $legacyConfig.BreakGlass.Username
        }
        else {
            # Build expected BG username from org domain + suffix
            $defaultBG = "svc-okta-bg01@$effectiveOktaDomain"
            if ($WhatIfPreference -or $AcceptDefaults) {
                $bgUsername = $defaultBG
            }
            else {
                $bgInput   = Read-Host "Break-glass Okta username [$defaultBG]"
                $bgUsername = if ([string]::IsNullOrWhiteSpace($bgInput)) { $defaultBG } else { $bgInput.Trim() }
            }
        }

        $bgAccount = Add-BreakGlassRecord `
            -SafeName           $naming.BGSafe `
            -Address            $effectiveOktaDomain `
            -Username           $bgUsername `
            -PlaceholderPassword $bgPlaceholder
        if ($bgAccount) { $recordOfIds["BreakGlass Audit Record ($bgUsername)"] = $bgAccount.id }

        # Generate BG QR URI if requested
        if ($GenerateBGQR) {
            Write-SetupLog -Level INFO -Message "Enrolling TOTP for break-glass account and generating QR URI..."
            if ($Script:OktaTokenLevel -eq 'SuperAdmin') {
                $bgOktaUsers = Invoke-OktaRequest -Path "/api/v1/users?search=profile.login+eq+%22$([uri]::EscapeDataString($bgUsername))%22"
                if ($bgOktaUsers -and $bgOktaUsers.Count -gt 0) {
                    $bgEnrollment = Invoke-OktaTOTPEnrollment `
                        -UserId   $bgOktaUsers[0].id `
                        -UserLogin $bgUsername `
                        -OrgName  $orgName
                    if ($bgEnrollment) {
                        $null = Export-BreakGlassQRUri -Username $bgUsername -OrgName $orgName -Seed $bgEnrollment.SharedSecret
                    }
                }
                else { Write-SetupLog -Level WARN -Message "BG user '$bgUsername' not found in Okta -- skipping QR generation" }
            }
            else { Write-SetupLog -Level WARN -Message "-GenerateBGQR requires Super Admin token -- skipping" }
        }

        } # end SkipOktaDiscovery guard for Phase 10

        # ----------------------------------------------------------------
        # ReplaceTOTP parameter set
        # ----------------------------------------------------------------
        if ($PSCmdlet.ParameterSetName -eq 'Replace') {
            Write-SetupLog -Level STEP -Message '=== ReplaceTOTP: Recovery Re-enrollment ==='
            foreach ($replaceLogin in $ReplaceTOTP) {
                Write-SetupLog -Level INFO -Message "Re-enrolling TOTP for $replaceLogin"
                $oktaUser = Invoke-OktaRequest -Path "/api/v1/users?search=profile.login+eq+%22$([uri]::EscapeDataString($replaceLogin))%22"
                if (-not $oktaUser -or $oktaUser.Count -eq 0) {
                    Write-SetupLog -Level ERROR -Message "Okta user not found: $replaceLogin"
                    continue
                }
                Invoke-OktaTOTPReset -UserId $oktaUser[0].id -UserLogin $replaceLogin
                $enrollment = Invoke-OktaTOTPEnrollment -UserId $oktaUser[0].id -UserLogin $replaceLogin -OrgName $orgName
                if ($enrollment) {
                    Write-SetupLog -Level OK -Message "New TOTP seed for $replaceLogin -- update CyberArk TOTP account manually or re-run with -EnrollTOTP"
                    if (Confirm-UserChoice -Prompt "Display new TOTP seed for $replaceLogin on screen? (sensitive)" -Default 'N') {
                        Write-Host "  New seed: $($enrollment.SharedSecret)" -ForegroundColor Yellow
                        Write-Host "  URI: $($enrollment.TOTPUri)" -ForegroundColor Cyan
                    }
                    else {
                        Write-SetupLog -Level INFO -Message "TOTP seed for $replaceLogin suppressed. Use -EnrollTOTP to onboard automatically."
                    }
                }
            }
        }

        # ----------------------------------------------------------------
        # 11. Verification
        # ----------------------------------------------------------------
        Write-SetupLog -Level STEP -Message '=== Phase 11: Verification ==='
        $null = Test-SetupVerification -Config $runConfig -RecordOfIds $recordOfIds
        Export-RecordOfIDs -RecordOfIds $recordOfIds -Config $runConfig

        if ($SkipOktaDiscovery) {
            Write-Host ''
            Write-Host '--- Phases Skipped (CyberArk-Only Mode) ---' -ForegroundColor Yellow
            Write-Host '  Phases 5-10 were skipped because -SkipOktaDiscovery was set.' -ForegroundColor Yellow
            Write-Host '  Re-run WITHOUT -SkipOktaDiscovery to:' -ForegroundColor Yellow
            Write-Host '    - Discover Okta HLA accounts' -ForegroundColor Yellow
            Write-Host '    - Mint CPM SSWS token (Path B)' -ForegroundColor Yellow
            Write-Host '    - Onboard HLA password accounts' -ForegroundColor Yellow
            Write-Host '    - Enroll and onboard TOTP seeds' -ForegroundColor Yellow
            Write-Host '    - Configure linked accounts (ExtraPass 1/2/3)' -ForegroundColor Yellow
            Write-Host '    - Set up break-glass audit record' -ForegroundColor Yellow
            Write-Host ''
        }

        Write-ManualStepsGuide

        $durationSec = [int]((Get-Date) - $startTime).TotalSeconds
        Write-DeploymentSummary -DurationSeconds $durationSec
        Write-SIEMLog -Level 'INFO' -Action 'ScriptComplete' -Message "OktaHLAVaultSetup v$Script:VERSION completed" `
            -Fields @{ DurationSeconds = $durationSec; SkipOktaDiscovery = [bool]$SkipOktaDiscovery }
    }
    catch {
        $durationSec = [int]((Get-Date) - $startTime).TotalSeconds
        Write-SIEMLog -Level 'ERROR' -Action 'ScriptFailed' -Message "Setup failed: $($_.Exception.Message)" `
            -Fields @{ ErrorMessage = $_.Exception.Message; DurationSeconds = $durationSec }
        Write-DeploymentSummary -DurationSeconds $durationSec
        throw
    }
    finally {
        Disconnect-PVWA
        # Clear Okta session state (token in headers)
        if ($null -ne $Script:OktaHeaders) {
            $Script:OktaHeaders = $null
        }
        # Release token references
        Clear-SensitiveString -StringRef ([ref]$OktaToken)
        Clear-SensitiveString -StringRef ([ref]$cpmToken)
    }
}

#endregion

#region Teardown

function Invoke-VaultTeardown {
    <#
    .SYNOPSIS
        Discovers and removes CyberArk-side resources created by this script.
        Operates in dependency-safe reverse order. Does NOT revoke Okta TOTP seeds.
    #>
    param(
        [Parameter(Mandatory)][string]$TenantId
    )

    $startTime = Get-Date
    Write-SetupLog -Level STEP -Message "=== TEARDOWN: CyberArk Okta HLA Resources (TenantId: $TenantId) ==="
    Write-SIEMLog -Level 'INFO' -Action 'TeardownStart' -Message "Teardown initiated for tenant $TenantId"

    Write-Host ''
    Write-Host '  SCOPE: This teardown removes CyberArk resources only.' -ForegroundColor Yellow
    Write-Host '  - Accounts in safes (HLA passwords, TOTP seeds, SSWS token, break-glass record)'
    Write-Host '  - 4 safes (Passwords, MFAKeys, CPM-ServiceAccounts, BreakGlass)'
    Write-Host '  - OktaCloud platform (deactivate + delete)'
    Write-Host '  - PSM connection components (PSM-OktaOIE variants)'
    Write-Host '  - Vault groups (Okta-HLA-Users, Okta-HLA-Approvers)'
    Write-Host ''
    Write-Host '  NOT IN SCOPE:' -ForegroundColor DarkGray
    Write-Host '  - Okta TOTP seeds are NOT revoked (handle via Okta team or re-deploy)' -ForegroundColor DarkGray
    Write-Host '  - Okta users, groups, policies, roles (use Deploy-OktaHLABootstrap -Action Teardown)' -ForegroundColor DarkGray
    Write-Host ''

    # --- Resolve safe names ---
    $safeNames = @{
        Passwords   = "Okta-$TenantId-HLA-Passwords"
        MFAKeys     = "Okta-$TenantId-HLA-MFAKeys"
        CPMService  = "Okta-$TenantId-CPM-ServiceAccounts"
        BreakGlass  = "Okta-$TenantId-BreakGlass"
    }
    $groupNames   = @('Okta-HLA-Users', 'Okta-HLA-Approvers')
    $platformId   = $Script:OKTA_PLATFORM  # 'OktaCloud'

    # --- Phase 1: Discovery ---
    Write-SetupLog -Level STEP -Message '--- Phase 1: Discovering deployed resources ---'

    $discoveredAccounts = @{}
    $discoveredSafes    = @()
    $discoveredGroups   = @()
    $discoveredPlatform = $null
    $discoveredPSM      = @()

    # Discover safes and their accounts
    foreach ($safeKey in @('Passwords', 'MFAKeys', 'CPMService', 'BreakGlass')) {
        $safeName = $safeNames[$safeKey]
        try {
            $safe = Invoke-PVWARequest -Path "/api/Safes?search=$safeName" -Method GET
            $matches = @()
            if ($safe.value) { $matches = @($safe.value | Where-Object { $_.safeName -eq $safeName }) }
            elseif ($safe.Safes) { $matches = @($safe.Safes | Where-Object { $_.SafeName -eq $safeName }) }
            if ($matches.Count -gt 0) {
                $discoveredSafes += $safeName
                Write-SetupLog -Level INFO -Message "  Found safe: $safeName"

                # Enumerate accounts in this safe
                try {
                    $accts = Invoke-PVWARequest -Path "/api/Accounts?filter=safeName eq $safeName&limit=100" -Method GET
                    $acctList = @()
                    if ($accts.value) { $acctList = @($accts.value) }
                    elseif ($accts.Accounts) { $acctList = @($accts.Accounts) }
                    $discoveredAccounts[$safeName] = $acctList
                    Write-SetupLog -Level INFO -Message "    Accounts in $safeName`: $($acctList.Count)"
                }
                catch {
                    Write-SetupLog -Level WARN -Message "    Could not enumerate accounts in $safeName`: $_"
                    $discoveredAccounts[$safeName] = @()
                }
            }
            else {
                Write-SetupLog -Level INFO -Message "  Safe not found (already removed?): $safeName"
            }
        }
        catch {
            Write-SetupLog -Level INFO -Message "  Safe not accessible: $safeName -- $($_.Exception.Message)"
        }
    }

    # Discover vault groups
    foreach ($groupName in $groupNames) {
        try {
            $grp = Invoke-PVWARequest -Path "/api/UserGroups?search=$groupName" -Method GET
            $grpList = @()
            if ($grp.value) { $grpList = @($grp.value | Where-Object { $_.groupName -eq $groupName }) }
            elseif ($grp) { $grpList = @($grp | Where-Object { $_.groupName -eq $groupName }) }
            if ($grpList.Count -gt 0) {
                $discoveredGroups += @{ Name = $groupName; Id = $grpList[0].id }
                Write-SetupLog -Level INFO -Message "  Found vault group: $groupName (id: $($grpList[0].id))"
            }
            else {
                Write-SetupLog -Level INFO -Message "  Vault group not found: $groupName"
            }
        }
        catch {
            Write-SetupLog -Level INFO -Message "  Vault group not accessible: $groupName"
        }
    }

    # Discover platform
    try {
        $plat = Invoke-PVWARequest -Path "/api/Platforms/Targets" -Method GET
        $platList = @()
        if ($plat.Platforms) { $platList = @($plat.Platforms | Where-Object { $_.general.id -eq $platformId -or $_.PlatformID -eq $platformId }) }
        if ($platList.Count -gt 0) {
            $discoveredPlatform = $platList[0]
            $platActive = try { $platList[0].general.active } catch { $platList[0].Active }
            Write-SetupLog -Level INFO -Message "  Found platform: $platformId (active: $platActive)"
        }
        else {
            Write-SetupLog -Level INFO -Message "  Platform not found: $platformId"
        }
    }
    catch {
        Write-SetupLog -Level INFO -Message "  Platform query failed: $($_.Exception.Message)"
    }

    # Discover PSM connection components (best-effort)
    foreach ($ccId in @('PSM-OktaOIE', 'PSM-OktaOIE-WebForm-H', 'PSM-OktaOIE-WebForm-N', 'PSM-OktaOIE-WebForm-P')) {
        try {
            $cc = Invoke-PVWARequest -Path "/api/ConnectionComponents/$ccId" -Method GET
            if ($cc) {
                $discoveredPSM += $ccId
                Write-SetupLog -Level INFO -Message "  Found PSM connection component: $ccId"
            }
        }
        catch {
            # 404 = not found, which is fine
        }
    }

    # --- Summary ---
    $totalAccounts = ($discoveredAccounts.Values | ForEach-Object { $_.Count } | Measure-Object -Sum).Sum
    Write-Host ''
    Write-Host '  --- Discovery Summary ---' -ForegroundColor White
    Write-Host "  Safes:                $($discoveredSafes.Count) / 4"
    Write-Host "  Accounts in safes:    $totalAccounts"
    Write-Host "  Vault groups:         $($discoveredGroups.Count) / 2"
    Write-Host "  Platform:             $(if ($discoveredPlatform) { 'Found' } else { 'Not found' })"
    Write-Host "  PSM components:       $($discoveredPSM.Count)"
    Write-Host ''

    if ($discoveredSafes.Count -eq 0 -and $discoveredGroups.Count -eq 0 -and $null -eq $discoveredPlatform -and $discoveredPSM.Count -eq 0) {
        Write-SetupLog -Level OK -Message 'Nothing to tear down -- no deployed resources found.'
        return
    }

    # --- Confirm ---
    if (-not $AcceptDefaults) {
        Write-Host '  TEARDOWN ORDER (CR backout plan):' -ForegroundColor Yellow
        Write-Host '    1. Delete all accounts from all 4 safes'
        Write-Host '    2. Delete the 4 safes'
        Write-Host '    3. Deactivate and delete OktaCloud platform'
        Write-Host '    4. Delete PSM connection components'
        Write-Host '    5. Delete vault groups'
        Write-Host ''

        if (-not (Confirm-UserChoice -Prompt 'Proceed with teardown?' -Default 'N')) {
            Write-SetupLog -Level INFO -Message 'Teardown cancelled by user.'
            return
        }
    }

    $teardownErrors = 0

    # --- Phase 2: Delete accounts from all safes ---
    Write-SetupLog -Level STEP -Message '--- Phase 2: Removing accounts from safes ---'
    foreach ($safeName in $discoveredSafes) {
        $accounts = $discoveredAccounts[$safeName]
        foreach ($acct in $accounts) {
            $acctId   = $acct.id
            $acctName = try { $acct.name } catch { try { $acct.userName } catch { $acctId } }
            try {
                if ($PSCmdlet.ShouldProcess("Account $acctName (id: $acctId) in $safeName", 'Delete')) {
                    Invoke-PVWARequest -Path "/api/Accounts/$acctId" -Method DELETE | Out-Null
                    Write-SetupLog -Level OK -Message "  Deleted account: $acctName from $safeName"
                    Write-SIEMLog -Level 'INFO' -Action 'TeardownDeleteAccount' -Message "Deleted account $acctName" `
                        -Fields @{ AccountId = $acctId; AccountName = $acctName; SafeName = $safeName }
                }
            }
            catch {
                $teardownErrors++
                Write-SetupLog -Level WARN -Message "  Failed to delete account $acctName from $safeName`: $_"
            }
        }
    }

    # --- Phase 3: Delete safes ---
    Write-SetupLog -Level STEP -Message '--- Phase 3: Deleting safes ---'
    foreach ($safeName in $discoveredSafes) {
        try {
            if ($PSCmdlet.ShouldProcess("Safe $safeName", 'Delete')) {
                Invoke-PVWARequest -Path "/api/Safes/$safeName" -Method DELETE | Out-Null
                Write-SetupLog -Level OK -Message "  Deleted safe: $safeName"
                Write-SIEMLog -Level 'INFO' -Action 'TeardownDeleteSafe' -Message "Deleted safe $safeName" `
                    -Fields @{ SafeName = $safeName }
            }
        }
        catch {
            $teardownErrors++
            Write-SetupLog -Level WARN -Message "  Failed to delete safe $safeName`: $_"
            Write-Host "    Hint: Safe may still contain accounts or have active members. Remove members first." -ForegroundColor DarkGray
        }
    }

    # --- Phase 4: Deactivate and delete platform ---
    if ($discoveredPlatform) {
        Write-SetupLog -Level STEP -Message '--- Phase 4: Removing OktaCloud platform ---'
        try {
            if ($PSCmdlet.ShouldProcess("Platform $platformId", 'Deactivate and Delete')) {
                # Deactivate first
                try {
                    Invoke-PVWARequest -Path "/api/Platforms/Targets/$platformId/Deactivate" -Method POST | Out-Null
                    Write-SetupLog -Level INFO -Message "  Deactivated platform: $platformId"
                }
                catch {
                    Write-SetupLog -Level INFO -Message "  Platform deactivation skipped (may already be inactive): $_"
                }
                # Delete
                Invoke-PVWARequest -Path "/api/Platforms/Targets/$platformId" -Method DELETE | Out-Null
                Write-SetupLog -Level OK -Message "  Deleted platform: $platformId"
                Write-SIEMLog -Level 'INFO' -Action 'TeardownDeletePlatform' -Message "Deleted platform $platformId"
            }
        }
        catch {
            $teardownErrors++
            Write-SetupLog -Level WARN -Message "  Failed to delete platform $platformId`: $_"
            Write-Host "    Hint: Platform may still be referenced by existing accounts." -ForegroundColor DarkGray
        }
    }

    # --- Phase 5: Remove PSM connection components ---
    if ($discoveredPSM.Count -gt 0) {
        Write-SetupLog -Level STEP -Message '--- Phase 5: Removing PSM connection components ---'
        foreach ($ccId in $discoveredPSM) {
            try {
                if ($PSCmdlet.ShouldProcess("PSM Component $ccId", 'Delete')) {
                    Invoke-PVWARequest -Path "/api/ConnectionComponents/$ccId" -Method DELETE | Out-Null
                    Write-SetupLog -Level OK -Message "  Deleted connection component: $ccId"
                    Write-SIEMLog -Level 'INFO' -Action 'TeardownDeletePSM' -Message "Deleted PSM component $ccId"
                }
            }
            catch {
                $teardownErrors++
                Write-SetupLog -Level WARN -Message "  Failed to delete PSM component $ccId`: $_"
            }
        }
    }

    # --- Phase 6: Delete vault groups ---
    Write-SetupLog -Level STEP -Message '--- Phase 6: Deleting vault groups ---'
    foreach ($grp in $discoveredGroups) {
        try {
            if ($PSCmdlet.ShouldProcess("Vault group $($grp.Name) (id: $($grp.Id))", 'Delete')) {
                Invoke-PVWARequest -Path "/api/UserGroups/$($grp.Id)" -Method DELETE | Out-Null
                Write-SetupLog -Level OK -Message "  Deleted vault group: $($grp.Name)"
                Write-SIEMLog -Level 'INFO' -Action 'TeardownDeleteGroup' -Message "Deleted vault group $($grp.Name)" `
                    -Fields @{ GroupId = $grp.Id; GroupName = $grp.Name }
            }
        }
        catch {
            $teardownErrors++
            Write-SetupLog -Level WARN -Message "  Failed to delete vault group $($grp.Name)`: $_"
        }
    }

    # --- Summary ---
    $durationSec = [int]((Get-Date) - $startTime).TotalSeconds
    Write-Host ''
    Write-SetupLog -Level STEP -Message "=== TEARDOWN COMPLETE (${durationSec}s, $teardownErrors error(s)) ==="
    Write-SIEMLog -Level 'INFO' -Action 'TeardownComplete' -Message "Teardown completed" `
        -Fields @{ DurationSeconds = $durationSec; Errors = $teardownErrors; TenantId = $TenantId }

    if ($teardownErrors -gt 0) {
        Write-Host ''
        Write-Host "  $teardownErrors error(s) occurred. Review output above for details." -ForegroundColor Yellow
        Write-Host '  Common causes: accounts still in safe, safe members still assigned, platform still referenced.' -ForegroundColor DarkGray
        Write-Host '  Re-run teardown to retry failed items (idempotent).' -ForegroundColor DarkGray
    }

    Write-Host ''
    Write-Host '  REMAINING MANUAL STEPS:' -ForegroundColor Yellow
    Write-Host '    - Remove REST API CPM Plugin DLLs from CPM server (if no longer needed)'
    Write-Host '    - Remove PSM-OktaOIE-Connector.exe + lib/ from PSM server Components/'
    Write-Host '    - Okta-side teardown: Deploy-OktaHLABootstrap.ps1 -Action Teardown'
    Write-Host ''
}

#endregion

#region Teardown Entry

function Invoke-TeardownEntry {
    <#
    .SYNOPSIS
        Entry point for the -Teardown parameter set. Handles auth, tenant resolution,
        and calls Invoke-VaultTeardown.
    #>
    $startTime = Get-Date

    # Initialize SIEM logging
    Initialize-SIEMLogging

    Write-Host ''
    Write-Host "  Invoke-OktaHLAVaultSetup.ps1 v$Script:VERSION -- TEARDOWN MODE" -ForegroundColor Red
    Write-Host '  Removes CyberArk-side Okta HLA resources in dependency-safe reverse order.' -ForegroundColor White
    Write-Host ''

    # PVWA URL
    $resolvedPVWAUrl = $PVWAUrl
    if (-not $resolvedPVWAUrl) {
        $resolvedPVWAUrl = Read-Host 'PVWA URL (e.g. https://cyberark.corp.com)'
    }
    if (-not $resolvedPVWAUrl) { throw 'PVWA URL is required for teardown.' }
    $Script:PVWABaseUrl = $resolvedPVWAUrl.TrimEnd('/')

    # Authenticate to PVWA (reuse existing auth infrastructure)
    Connect-PVWA

    # Tenant ID (needed to resolve safe names)
    $tenantId = $TeardownTenantId
    if (-not $tenantId) {
        $oktaDomain = $OktaDomain
        if (-not $oktaDomain) {
            $oktaDomain = Read-Host 'Okta tenant domain (needed to derive TenantId, e.g. yourorg.okta.com)'
        }
        if ($oktaDomain) {
            $tenantId = Resolve-TenantId -OktaDomain $oktaDomain -UserProvided $null
        }
    }
    if (-not $tenantId) {
        $tenantId = Read-Host 'TenantId (short identifier used in safe names, e.g. "acme")'
    }
    if (-not $tenantId) { throw 'TenantId is required to resolve safe names for teardown.' }

    Write-SetupLog -Level INFO -Message "Teardown TenantId: $tenantId"

    try {
        Invoke-VaultTeardown -TenantId $tenantId
    }
    finally {
        Disconnect-PVWA
    }
}

#endregion

# Entry point
if ($Help) {
    Write-Host ''
    Write-Host "  Invoke-OktaHLAVaultSetup.ps1  v$Script:VERSION" -ForegroundColor Cyan
    Write-Host '  Automates CyberArk PAM configuration for Okta HLA 3-Tier privileged account management.' -ForegroundColor White
    Write-Host ''
    Write-Host '  CR Reference: CHG00YYYYY' -ForegroundColor DarkGray
    Write-Host '  Requires:     PowerShell 5.1+, CyberArk PAS v12.2+' -ForegroundColor DarkGray
    Write-Host ''
    Write-Host '  USAGE' -ForegroundColor Yellow
    Write-Host '  -----'
    Write-Host '  # Interactive (prompts for all inputs):' -ForegroundColor DarkGray
    Write-Host '  .\Invoke-OktaHLAVaultSetup.ps1'
    Write-Host ''
    Write-Host '  # Dry-run (validates config, prints what would be created):' -ForegroundColor DarkGray
    Write-Host '  .\Invoke-OktaHLAVaultSetup.ps1 -WhatIf'
    Write-Host ''
    Write-Host '  # Non-interactive with Okta token:' -ForegroundColor DarkGray
    Write-Host '  .\Invoke-OktaHLAVaultSetup.ps1 -OktaToken $env:OKTA_API_TOKEN -PVWAUrl https://cyberark.corp.com -AcceptDefaults'
    Write-Host ''
    Write-Host '  # CyberArk-only mode (no Okta API calls -- pre-stage safes, groups, platform):' -ForegroundColor DarkGray
    Write-Host '  .\Invoke-OktaHLAVaultSetup.ps1 -SkipOktaDiscovery -PVWAUrl https://cyberark.corp.com'
    Write-Host ''
    Write-Host '  # Lab/simulator mode:' -ForegroundColor DarkGray
    Write-Host '  .\Invoke-OktaHLAVaultSetup.ps1 -Simulate -SimulatorPath ..\cpm-simulator'
    Write-Host ''
    Write-Host '  # Verify existing setup (read-only):' -ForegroundColor DarkGray
    Write-Host '  .\Invoke-OktaHLAVaultSetup.ps1 -VerifyOnly'
    Write-Host ''
    Write-Host '  # TOTP re-enrollment (recovery):' -ForegroundColor DarkGray
    Write-Host '  .\Invoke-OktaHLAVaultSetup.ps1 -ReplaceTOTP "svc-okta-h01@corp.okta.com" -CCPUrl https://ccp.corp.com -CCPAppId OktaSetup'
    Write-Host ''
    Write-Host '  AUTHENTICATION' -ForegroundColor Yellow
    Write-Host '  --------------'
    Write-Host '  PVWA (CyberArk):  -PVWAToken (Bearer/Session), -ClientId + -ClientSecret + -TenantUrl,'
    Write-Host '                     -PVWACredential (legacy), or interactive prompt.'
    Write-Host '  Okta:             -OktaToken (SSWS). Org Admin minimum, Super Admin for Path B token minting.'
    Write-Host ''
    Write-Host '  KEY PARAMETERS' -ForegroundColor Yellow
    Write-Host '  --------------'
    Write-Host '  -OktaToken <string>              Okta SSWS API token'
    Write-Host '  -OktaDomain <string>             Okta tenant (e.g. yourorg.okta.com)'
    Write-Host '  -PVWAUrl <string>                CyberArk PVWA base URL (without /PasswordVault)'
    Write-Host '  -AuthMethod <string>             Auto|CyberArk|LDAP|RADIUS|Windows|OAuth2_PKCE|OAuth2_ClientCredentials|Token'
    Write-Host '  -IncludeTiers <int[]>            Which HLA tiers to onboard (default: 1,2,3)'
    Write-Host '  -EnrollTOTP                      Enroll TOTP factors via Okta API'
    Write-Host '  -TOTPProvider <OKTA|GOOGLE>      TOTP authenticator provider (default: OKTA)'
    Write-Host '  -GenerateBGQR                    Output break-glass otpauth:// QR URI'
    Write-Host '  -SkipOktaDiscovery               CyberArk-side resources only (no Okta API)'
    Write-Host '  -SkipPlatformImport              Skip platform ZIP creation/import'
    Write-Host '  -PlatformSourceDirectory <path>  Directory with OktaCloud platform files'
    Write-Host '  -Simulate                        Route writes to CPM simulator'
    Write-Host '  -AcceptDefaults                  Suppress all interactive prompts'
    Write-Host '  -VerifyOnly                      Read-only verification pass'
    Write-Host '  -Teardown                        Remove all CyberArk-side Okta HLA resources'
    Write-Host '  -TeardownTenantId <string>       TenantId for teardown safe name resolution'
    Write-Host '  -WhatIf                          Dry-run (no changes made)'
    Write-Host '  -Help                            Show this help message'
    Write-Host ''
    Write-Host '  TEARDOWN' -ForegroundColor Yellow
    Write-Host '  --------'
    Write-Host '  # Interactive teardown (discovers and removes CyberArk resources):' -ForegroundColor DarkGray
    Write-Host '  .\Invoke-OktaHLAVaultSetup.ps1 -Teardown -PVWAUrl https://cyberark.corp.com'
    Write-Host ''
    Write-Host '  # Teardown dry-run:' -ForegroundColor DarkGray
    Write-Host '  .\Invoke-OktaHLAVaultSetup.ps1 -Teardown -WhatIf'
    Write-Host ''
    Write-Host '  Teardown removes: accounts -> safes -> platform -> PSM components -> vault groups'
    Write-Host '  Does NOT revoke Okta TOTP seeds (use Deploy-OktaHLABootstrap -Action Teardown for Okta).'
    Write-Host ''
    Write-Host '  PHASES' -ForegroundColor Yellow
    Write-Host '  ------'
    Write-Host '  0.   Pre-flight (input gathering, connectivity checks)'
    Write-Host '  1.   Platform import (OktaCloud ZIP creation + activation)'
    Write-Host '  1.5  PSM connection components (WebForm + AutoIt connectors)'
    Write-Host '  2.   Safe creation (4 safes per tenant)'
    Write-Host '  3.   Safe permissions (per CR CHG00YYYYY)'
    Write-Host '  4.   Vault groups (Okta-HLA-Users, Okta-HLA-Approvers)'
    Write-Host '  5.   Okta account discovery'
    Write-Host '  6.   CPM SSWS token (Path B self-mint)'
    Write-Host '  7.   HLA password account onboarding'
    Write-Host '  8.   TOTP seed enrollment + onboarding'
    Write-Host '  9.   Linked account configuration (ExtraPass 1/2/3)'
    Write-Host '  10.  Break-glass (optional, -GenerateBGQR)'
    Write-Host '  V.   Verification pass + Record of IDs'
    Write-Host ''
    Write-Host '  For full parameter documentation: Get-Help .\Invoke-OktaHLAVaultSetup.ps1 -Full' -ForegroundColor DarkGray
    Write-Host '  SIEM log output: scripts/Logs/OktaHLASetup_*.json (NDJSON)' -ForegroundColor DarkGray
    Write-Host ''
    return
}

# Route to the correct mode
if ($Teardown) {
    Invoke-TeardownEntry
}
else {
    Main
}
