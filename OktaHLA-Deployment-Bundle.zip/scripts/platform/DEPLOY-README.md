# CyberArk Platform & Connector Deployment Guide

Comprehensive guide covering platform import, connector deployment, and
CPM plugin testing for both Privilege Cloud (SaaS) and self-hosted PAS.

## Key Discovery: How CyberArk Platform Import Works

CyberArk's Platform Import (`Administration > Platform Management > Import Platform`)
is a **general-purpose deployment mechanism**, not limited to platforms. It inspects
the ZIP contents and routes files accordingly:

| ZIP Contains | Deployed To | Purpose |
|---|---|---|
| INI + Policy XML | Vault (PVConfiguration.xml) | Platform configuration |
| Configuration XML | CPM `bin\` folder | API call definitions |
| DLLs (`.dll`) | CPM `bin\` folder | Plugin framework binaries |
| `.exe` + `package.json` | PSM `Components\` folder | Connection component binaries |
| All of the above | Both CPM + PSM servers | Combined platform + connector |

**All deployments are vault-mediated.** Files uploaded through the portal are stored
in CyberArk safes (`PVWAConfig`, `PSMUniversalConnectors`) and auto-synced to
on-prem connector servers on the next refresh cycle (default: 10 minutes).

**No manual file copies needed** in most cases -- import the ZIP and wait for sync.

## Two REST API Plugin Frameworks

CyberArk has two different REST API plugin systems. They are NOT interchangeable.

| | Generic REST API (Recommended) | WSChains (Legacy) |
|---|---|---|
| **DLL** | `CyberArk.Extensions.Generic.Plugin.RestAPI.dll` | `CyberArk.Extensions.Plugin.WSChains.dll` |
| **INI keys** | `DllName` + `ExeName` + `XMLFile=Yes` | `DllName` + `ExeName` + `XMLFile=Yes` |
| **Config reference** | `ConfigurationFilePath=` in `[ExtraInfo]` | `ChainsFilePath=bin\` in `[ExtraInfo]` |
| **Config deployment** | Bundled in ZIP, auto-deployed | Manual copy to CPM `bin\` |
| **CyberArk support** | Documented, supported, actively maintained | Undocumented, works but unsupported |
| **INI format** | Flat (no section headers except `[ExtraInfo]`) | Flat (no section headers except `[ExtraInfo]`) |
| **Config XML root** | `<RestPlugin>` | Different schema |
| **Reference impl** | Tim Schindler Shopizer, CyberArk Marketplace | SailPoint IQ |
| **Framework ZIP** | `Plugin.RestAPIFramework-vXX.X.X.X-Master.zip` | N/A (ships with CPM) |

## INI File Format (Critical -- Import Fails if Wrong)

The platform INI is **flat** -- NOT sectioned with `[Main]`, `[AutomaticPasswordManagement]`, etc.
The only section headers are `[ADExtraInfo]`, `[ChangeTask]`, and `[ExtraInfo]` at the bottom.

CyberArk's own documentation describes the PVWA UI sections, which is misleading.
The actual INI file format (proven by CyberArk's own framework ZIP and Tim Schindler's
working Shopizer implementation) is:

```ini
PolicyID=OktaCloud
PolicyName=Okta Cloud User Accounts
PolicyType=Regular
ImmediateInterval=5
Interval=1440
MaxConcurrentConnections=3
AllowedSafes=.*
...all other keys flat, no section headers...
DllName=CyberArk.Extensions.Generic.Plugin.RestAPI.dll
ExeName=CANetPluginInvoker.exe
XMLFile=Yes
...password, verification, reconciliation, notification keys...
PasswordLength=20
MinUpperCase=2
...
[ExtraInfo]
Port=443
Debug=No
ConfigurationFilePath=OktaCloudConfiguration.xml
AddressValidationPattern=.*
ManagementType=Password
FrameworkName=Rest API Framework
FrameworkId=RestAPIFramework
FrameworkVersion=21.0.0
```

**The `[ExtraInfo]` section must include:**
- `ConfigurationFilePath` -- filename of the API chains XML
- `ManagementType` -- `Password` (CPM generates) or `AccessKeys` (target generates)
- `FrameworkName`, `FrameworkId`, `FrameworkVersion` -- framework metadata

## Automated deployment via PowerShell

Four PowerShell helpers live in `scripts/`:

| Script | Use for | Notes |
|---|---|---|
| `Import-CyberArkPlatformZip.ps1` | **V6 / V7 (and any Marketplace zip)** | Single-zip import. Auto-extracts PolicyID, idempotent (skip-or-Force), supports OAuth2 and on-prem auth, optional `-Activate`. |
| `Build-PSMConnectorPackage.ps1` | **PSM connectors** (compiled `.exe` thick-app or `.xml` WebFormFields) | Builds the importable zip with auto-generated `package.json` (AppLocker rules + `ConnectionComponentId`). Auto-detects type from extension. Optional `-Deploy` switch to also import via PVWA `/api/Platforms/Import`. |
| `Deploy-OktaCloudPlatform.ps1` | **V5 (REST API plugin framework)** | Full V5 flow: framework import + sample duplication + property scripting + config XML deploy. |
| `Test-CyberArkSafe.ps1` | **Confidence-builder** for PVWA Safes API | Lean CRUD on safes + members. `-Action Roundtrip` runs the full create→add→update→remove→delete sequence with PASS/FAIL per step. **Anti-orphan**: auto-adds an admin group as Owner immediately after Create (default: `Privilege Cloud Administrators` for cloud, `Vault Admins` for on-prem). |

### `Import-CyberArkPlatformZip.ps1` — examples

```powershell
# Privilege Cloud (OAuth2 client credentials, auto-derived tenant URL)
.\Import-CyberArkPlatformZip.ps1 `
    -PVWAUrl 'https://tenant.privilegecloud.cyberark.cloud' `
    -Variant V6 -ClientId 'svc-app' -ClientSecret $env:CYBERARK_CLIENT_SECRET -Activate

# On-prem PAS with CyberArk auth, importing V7 failsafe
.\Import-CyberArkPlatformZip.ps1 -PVWAUrl 'https://pvwa.corp.com' `
    -Variant V7 -PVWACredential (Get-Credential) -AuthMethod CyberArk

# Pre-obtained Bearer token (from another script), force-recreate
.\Import-CyberArkPlatformZip.ps1 -PVWAUrl 'https://tenant.privilegecloud.cyberark.cloud' `
    -PVWAToken 'eyJ...' -Variant V6 -Activate -Force

# Explicit zip path (e.g. a Marketplace download)
.\Import-CyberArkPlatformZip.ps1 -PVWAUrl 'https://...' `
    -PlatformZipPath '.\CyberArk-Marketplace\OktaClientCredentialsPlugin.zip' `
    -PVWAToken $token

# WhatIf -- prints what would be sent without calling PVWA modify endpoints
.\Import-CyberArkPlatformZip.ps1 -PVWAUrl 'https://...' -Variant V6 -PVWAToken $t -WhatIf
```

The script auto-derives the Identity tenant URL when `PVWAUrl` matches
`*.privilegecloud.cyberark.cloud`, so `-TenantUrl` is usually optional. It
extracts the platform's `PolicyID` from the zip's `Policy-*.ini` to detect
already-imported instances and skip cleanly (or delete-and-reimport with
`-Force`).

REST API contract (per CyberArk docs / `cyberark/epv-api-scripts`):
- `POST /PasswordVault/api/Platforms/Import` with body `{"ImportFile":"<base64>"}`
- `POST /PasswordVault/api/Platforms/Targets/{id}/Activate` to activate
- `DELETE /PasswordVault/api/Platforms/Targets/{id}` to remove (after Deactivate)

### `Test-CyberArkSafe.ps1` -- examples

Use this as a confidence-builder before running the larger HLA orchestration
scripts. It exercises the same Safes API endpoints those scripts use, in
isolation, so you can prove auth + basic CRUD work end-to-end against your
PVWA tenant without any of the Okta/HLA complexity.

```powershell
# Full happy-path roundtrip (recommended first run): create -> add member ->
# update permissions -> remove member -> delete safe, with PASS/FAIL per step
.\Test-CyberArkSafe.ps1 -PVWAUrl 'https://tenant.privilegecloud.cyberark.cloud' `
    -PVWAToken $token -Action Roundtrip -MemberName 'svc-cpm-test'

# One-off operations
.\Test-CyberArkSafe.ps1 -PVWAUrl '...' -PVWAToken $t -Action Create `
    -SafeName 'My-Test-Safe' -Description 'scratch' -ManagingCPM 'PasswordManager'
.\Test-CyberArkSafe.ps1 -PVWAUrl '...' -PVWAToken $t -Action ListMembers -SafeName 'My-Test-Safe'
.\Test-CyberArkSafe.ps1 -PVWAUrl '...' -PVWAToken $t -Action AddMember `
    -SafeName 'My-Test-Safe' -MemberName 'CPMService' -PermissionSet ReadWrite
.\Test-CyberArkSafe.ps1 -PVWAUrl '...' -PVWAToken $t -Action Delete -SafeName 'My-Test-Safe'

# Custom permissions
.\Test-CyberArkSafe.ps1 -PVWAUrl '...' -PVWAToken $t -Action AddMember `
    -SafeName 'My-Safe' -MemberName 'CPMService' -PermissionSet Custom `
    -CustomPermissions @{
        useAccounts = $true; retrieveAccounts = $true
        initiateCPMAccountManagementOperations = $true
    }
```

Built-in permission presets (use with `-PermissionSet`):
- **ReadOnly**  -- listAccounts, retrieveAccounts, useAccounts, viewSafeMembers
- **ReadWrite** -- ReadOnly + addAccounts, updateAccountContent/Properties, accessWithoutConfirmation
- **Manager**   -- ReadWrite + manageSafe, manageSafeMembers, viewAuditLog, initiateCPMAccountManagementOperations, backupSafe
- **Owner**     -- all 22 canonical permissions = $true
- **Custom**    -- pass `-CustomPermissions @{...}`

Roundtrip mode auto-cleans on failure (deletes the safe even if mid-flow
fails), unless `-KeepOnFailure` is specified for debugging. The roundtrip
returns exit code 1 if any step fails -- safe to use in CI gates.

### Anti-orphan: safe ownership

Both `Create` and `Roundtrip` actions automatically add an admin group as
**Owner** (manageSafe + manageSafeMembers + viewSafeMembers + all 22
permissions) immediately after the safe is created. This prevents the safe
from becoming orphaned/unmanageable if the OAuth2 service account or
creator user is later deleted -- a known CyberArk failure mode that can
require CyberArk Support intervention to recover.

Defaults via `-SafeAdminGroup auto`:
- Privilege Cloud → `Privilege Cloud Administrators`
- On-prem → `Vault Admins`

To use a specific group/user instead:
```powershell
.\Test-CyberArkSafe.ps1 -PVWAUrl '...' -PVWAToken $t -Action Create `
    -SafeName 'Test' -SafeAdminGroup 'My-Custom-Admin-Group' -SafeAdminGroupType Group
```

To disable (NOT recommended outside of throwaway test environments):
```powershell
.\Test-CyberArkSafe.ps1 ... -SafeAdminGroup ''
```

If the admin group lookup or add fails (group doesn't exist, name typo, etc.),
the script emits a WARN but the safe is still created -- you'll see clear
log output telling you to add an owner manually. The roundtrip continues
in this case because the rest of the test sequence doesn't depend on
the owner add.

### `Build-PSMConnectorPackage.ps1` -- examples

Builds a CyberArk PSM connection-component package zip from a single
connector source file. Auto-detects type:
- `.exe` → Application (compiled AutoIt thick-app)
- `.xml` → WebApplication (WebFormFields)

```powershell
# WebForm XML (no compilation needed)
.\Build-PSMConnectorPackage.ps1 `
    -ConnectorFile '.\psm\okta-oie-webform\PSM-OktaOIE-WebForm-Hardened.xml' `
    -ComponentId 'PSM-OktaOIE-WebForm-Hardened'

# Compiled AutoIt thick-app (compile .au3 -> .exe externally first)
.\Build-PSMConnectorPackage.ps1 `
    -ConnectorFile '.\psm\okta-oie\bin\PSM-OktaOIE-Connector.exe' `
    -ComponentId 'PSM-OktaOIE-AutoIt' `
    -ExtraAppLockerExe @('TOTPToken.exe')

# Build + deploy to PVWA in one shot (uses /api/Platforms/Import)
.\Build-PSMConnectorPackage.ps1 `
    -ConnectorFile '.\psm\okta-oie-webform\PSM-OktaOIE-WebForm-Native.xml' `
    -ComponentId 'PSM-OktaOIE-WebForm-Native' `
    -Deploy -PVWAUrl 'https://tenant.privilegecloud.cyberark.cloud' -PVWAToken $token
```

Output zip layout:
```
PSM-<ComponentId>-Package.zip
├── <connector>.{exe|xml}
└── package.json    # ConnectionComponentId + Applications[] (AppLocker rules)
```

For pure connection-component XML imports via the dedicated
`/api/ConnectionComponents` endpoint (no zip wrapping, no AppLocker), use
the existing `Deploy-PSMConnector.ps1`'s `New-ConnectionComponent` function.

## Pre-built PSM connector zips (Okta OIE WebForm)

Both AutoIt thick-app and WebFormFields variants are pre-built and committed,
ready to drop into PVWA via Import Platform (or `Import-CyberArkPlatformZip.ps1`):

```
psm/okta-oie/packages/                     <- AutoIt thick-app (compiled .exe)
+-- PSM-OktaOIE-Connector-ProductionV2.zip    <- recommended (adaptive auth, ~3x faster)
+-- PSM-OktaOIE-Connector-Production.zip      <- v1 sequential, kept as archival/fallback
+-- README.md                                  <- variant comparison + runtime deps

psm/okta-oie-webform/packages/             <- WebFormFields (declarative XML)
+-- PSM-OktaOIE-WebForm-Hardened.zip          <- recommended for production (PAS 14.8+)
+-- PSM-OktaOIE-WebForm-Native.zip            <- native TOTP via TOTPToken.exe
+-- PSM-OktaOIE-WebForm-PreConnect.zip        <- community PreConnect DLL approach
+-- README.md                                  <- per-variant context + import instructions
```

The two flavors are alternatives -- pick one based on your PSM environment.
See `psm/okta-oie-webform/COMPARISON-AutoIt-vs-WebForm.md` for tradeoffs.
Rebuild any zip from its source via `Build-PSMConnectorPackage.ps1` (and
`Aut2exe.exe` first for the AutoIt variants -- compilation is out of scope
for our PowerShell scripts).

Each AutoIt zip ships with a `package.json` AppLocker rule for the connector
`.exe` (Hash method, since the binaries are unsigned). Each WebForm zip
ships with an AppLocker rule for `CyberArk.PSM.WebAppDispatcher.exe`
(Publisher method, since CyberArk's dispatcher is signed).

## On the cyberark/epv-api-scripts CyberArk-Common module

CyberArk publishes [`CyberArk-Common.psm1`](https://github.com/cyberark/epv-api-scripts/tree/main/CyberArk-Common)
(distribution package: `EPV-API-Common-0.1.6.2-Alpha`) -- a PowerShell module
with `New-Session`, `Write-LogMessage`, account/safe/user helpers, AD
integration, etc. We deliberately do NOT depend on it because:

1. **PowerShell 7.4+ requirement** -- our scripts target Windows PowerShell 5.1
   so they run unmodified on Windows-bundled PSM/CPM servers (Windows Server
   2016/2019/2022). Adopting the module would force PS7+ deployment on every
   CPM/PSM host.
2. **Alpha status** (`0.1.6.2-Alpha`) -- API surface still in flux.
3. **Self-contained over dependency** -- our `Connect-PVWA` /
   `Invoke-PVWARequest` patterns are duplicated across scripts but each script
   stays single-file and copy-paste-deployable to the CPM/PSM box without
   `Install-Module`.

If your environment standardizes on PS7+ later, the module is worth revisiting
-- specifically for `Write-LogMessage` (uniform logging with sensitive-data
masking) and the AD helpers in `Get-LogonHeader` / member-search code.

## Local validation -- the cyberark/epv-api-scripts Mock Server

CyberArk publishes a [Mockoon-based mock server](https://github.com/cyberark/epv-api-scripts/tree/main/Mock%20Server)
that stubs PAS REST API endpoints for local development. **Scope is narrower
than the name suggests** -- it only stubs `/api/Accounts` and `/api/AccountGroups`
(Account Management family). It does NOT stub:

- `/api/Auth/*` (logon/logoff)
- `/api/Safes` and `/api/Safes/{name}/Members`
- `/api/Platforms/Targets`, `/api/Platforms/Import`
- `/api/ConnectionComponents`
- `/api/Users`

So the mock server **does not validate** any of the scripts in this repo
end-to-end. It's mentioned here for completeness so future contributors
don't go looking for it as a validation answer.

If we ever want full local validation, options are:
1. Extend the JSON config to add the missing endpoints (Mockoon supports
   templated/scripted responses)
2. Build a small Express/Flask stub for our specific endpoints
3. Set up a personal CyberArk Privilege Cloud trial / lab tenant

The default Mockoon port (per their JSON) is **3002**.

## Deployment Steps (Privilege Cloud)

### Step 1: Import the REST API Framework (one-time)

Download `Plugin.RestAPIFramework-vXX.X.X.X-Master.zip` from CyberArk Marketplace.

1. Administration > Platform Management > Import Platform
2. Select the framework ZIP
3. Verify `SampleRestAPIPlatform` (labeled "Sample REST API Platform") appears in the platform list
4. Set `SampleRestAPIPlatform` to **Active = No** (right-click > Deactivate)
5. The framework ZIP also installs the 3 DLLs on all CPM connector servers (auto-sync)

**Do NOT delete `SampleRestAPIPlatform` after import.** The OktaCloud platform
inherits from it via `PlatformBaseID="SampleRestAPIPlatform"` in `Policy-OktaCloud.xml`.
Deleting the parent breaks the inheritance chain: the OktaCloud import will fail
with "base platform not found", and any already-imported `OktaCloud` will lose
its inherited defaults. Setting it `Active=No` is the supported way to hide it
from end-user platform lists while preserving the platform definition record.

**Accounts never link to `SampleRestAPIPlatform`.** Inheritance is at the
platform-definition layer (the `PlatformBaseID` reference); account-to-platform
binding is at the runtime layer (an account's `PlatformID` field). Your Okta
admin accounts get created on `OktaCloud`. `SampleRestAPIPlatform` should sit
in the vault dormant: `Active=No`, no safe permissions, zero accounts. Same
pattern as an abstract base class -- required for the type system, never
instantiated directly.

The `Invoke-OktaHLAVaultSetup.ps1` script's pre-import validator
(`Test-CyberArkBasePlatform`) checks for this parent before attempting the
OktaCloud import and fails with actionable guidance if it's missing.

### Step 1.5: Configure OAuth2 Auth in Okta (v3.4+, replaces SSWS token)

The CyberArk REST API plugin framework's `Authorization` header allowlist is
hard-coded to `Basic` and `Bearer` only — `SSWS` is rejected with error 8021.
Starting at platform XML v3.4, the OktaCloud plugin uses OAuth2 Client
Credentials grant instead of SSWS API tokens.

**One-time Okta setup:**

1. Okta Admin Console → **Applications** → **Create App Integration**
2. Pick **API Services** → Next
3. App name: `CyberArk-CPM-OktaPlatform` (or similar)
4. **Client Authentication: Client secret** (NOT private_key_jwt — the framework
   cannot generate signed JWTs natively)
5. After creation, on the **General** tab:
   - Copy **Client ID** (you'll store it as the linked logon account's `Username` field in CyberArk)
   - Copy **Client secret** (you'll store it as the linked logon account's `Password` field in CyberArk)
6. **Okta API Scopes** tab → grant **both**:
   - `okta.users.manage`
   - `okta.users.read`
7. Save

**Vault account model change:**

In PVWA, the linked vault account that the OktaCloud platform's `LogonAccount`
points to should now hold:
- `Username` = the OAuth2 `client_id`
- `Password` = the OAuth2 `client_secret`

(Previously this held an SSWS API token in the password field. The token can be
revoked in Okta admin once OAuth2 is verified working.)

**At runtime, what happens per chain:**

`changepass` chain:
1. `GetAccessToken` POSTs to `/oauth2/v1/token` with Basic auth
   (auto-base64'd `client_id:client_secret`) → returns a short-lived access token
2. `ChangePassword` uses `Authorization: Bearer <access_token>` against
   `/api/v1/users/{OktaUserId}` to admin-set the password
3. `VerifyCredentials` uses target's password against public `/api/v1/authn`
   (no Bearer needed)

The access token lives only for the duration of the chain; no token caching,
no refresh logic. Each chain run gets a fresh token.

### Step 2: Import the OktaCloud Platform

1. Administration > Platform Management > Import Platform
2. Select `OktaCloud-OfficialFormat.zip` (3 files: INI + Policy XML + Config XML)
3. Verify "OktaCloud" appears in Platform Management
4. Verify settings:
   - CPM Plugin > DllName = `CyberArk.Extensions.Generic.Plugin.RestAPI.dll`
   - CPM Plugin > ExeName = `CANetPluginInvoker.exe`
   - Additional Policy Settings > ConfigurationFilePath = `OktaCloudConfiguration.xml`

### Step 3: Verify CPM Server Sync

Wait 10-15 minutes for auto-sync, then check on the CPM connector server:

```powershell
# Verify DLLs deployed
Test-Path "C:\Program Files (x86)\CyberArk\PasswordManager\bin\CyberArk.Extensions.Generic.Plugin.RestAPI.dll"

# Verify Configuration XML deployed
Test-Path "C:\Program Files (x86)\CyberArk\PasswordManager\bin\OktaCloudConfiguration.xml"
```

### Step 4: Test with CANetPluginInvoker (Optional but Recommended)

Before onboarding accounts, test the plugin directly on the CPM server:

```powershell
# Edit oktacloud-test.ini with real credentials, then:
cd "C:\Program Files (x86)\CyberArk\PasswordManager"

# Test verify (does the stored password work?)
.\bin\CANetPluginInvoker.exe oktacloud-test.ini verifypass CyberArk.Extensions.Generic.Plugin.RestAPI.dll True

# Test change (can CPM rotate the password?)
.\bin\CANetPluginInvoker.exe oktacloud-test.ini changepass CyberArk.Extensions.Generic.Plugin.RestAPI.dll True

# Test reconcile (can CPM force-reset?)
.\bin\CANetPluginInvoker.exe oktacloud-test.ini reconcilepass CyberArk.Extensions.Generic.Plugin.RestAPI.dll True
```

Expected output: `The plugin ended successfully (RC = 0)`

## Deploying PSM Connectors (AutoIt or WebFormFields)

### AutoIt Thick-App Connectors (e.g., BeyondTrust)

PSM connectors use the **same Platform Import mechanism**. Compile the `.au3` to `.exe`,
package with `package.json`, and import:

```
PSM-BeyondTrustRS.zip
  BeyondTrust-RemoteSupport-PSM.exe     (compiled AutoIt connector)
  package.json                           (AppLocker rules)
```

**package.json format:**
```json
{
  "ConnectionComponentId": "PSM-BeyondTrustRS",
  "Applications": [
    {
      "Name": "BeyondTrustConnector",
      "Type": "Exe",
      "SessionType": "*",
      "Path": "BeyondTrust-RemoteSupport-PSM.exe",
      "Method": "Hash"
    }
  ]
}
```

Import via: Administration > Platform Management > Import Platform

The `.exe` auto-deploys to `PSM\Components\` on all PSM servers.
AppLocker rules from `package.json` are auto-applied.

**Note:** The target application (e.g., `bomgar-rep.exe`) must be installed
separately on each PSM server and its AppLocker rule added manually.

### Combined Platform + Connector Package

For maximum convenience, combine everything in one ZIP:

```
OktaCloud-Complete.zip
  Policy-OktaCloud.ini                   --> platform config
  Policy-OktaCloud.xml                   --> PVWA UI fields
  OktaCloudConfiguration.xml             --> API chains (CPM bin\)
  PSM-OktaOIE-WebForm-Hardened.exe       --> PSM connector (Components\)
  package.json                           --> AppLocker rules
```

One import deploys everything to both CPM and PSM servers.

## V7 WSChains Platform (failsafe for SSWS-only environments)

`OktaCloud-V7-WSChains.zip` is the **fourth-generation** Okta platform, built
on CyberArk's WSChains framework (`Cyberark.Extensions.Plugin.WSChains.dll`).
Sibling to V6, intended as a failsafe for environments where:

- OAuth API Services apps aren't permitted in the Okta tenant
- PowerShell ExecutionPolicy / TPC dependencies are blocked
- A purely declarative XML approach is preferred for audit/compliance
- As a backup if V6 hits PVWA-import or runtime issues

### Pattern reference

V7 mirrors the structure of CyberArk Marketplace's
**OktaClientCredentialsPlugin** (which rotates Okta OAuth app `client_secret`
values). Same WSChains framework, same SSWS auth, just adapted from
`/oauth2/v1/clients/{id}/lifecycle/newSecret` to `/api/v1/users/{id}` admin-set
+ `/api/v1/authn` verify.

### V7 file layout

```
OktaCloud-V7-WSChains.zip
├── Policy-OktaCloudWSChains.ini          # platform definition (DLLName=Cyberark.Extensions.Plugin.WSChains.dll, ExeName=CANetPluginInvoker.exe)
├── Policy-OktaCloudWSChains.xml          # account property defs (Username, Address, OktaUserId)
└── OktaCloudWSChainsChains.xml           # WSChains state machine (Requests + Fails + Chains)
```

### V7 auth model

| Account | Field | Value |
|---|---|---|
| Target | password | the Okta admin user's actual password (rotated by CPM) |
| LogonAccount (PropertyIndex 1) | password | SSWS API token with `okta.users.manage` permission |
| ReconcileAccount (PropertyIndex 3) | password | same SSWS token (typical) |

The chains XML uses `<Authorization>SSWS {{pmextrapass1}}</Authorization>` for
admin operations. WSChains is a legacy framework but actively maintained
(OktaClientCredentialsPlugin updated in 2026), and crucially **does** accept
the `SSWS` Authorization scheme that the newer REST API Plugin Framework
rejects.

### V7 chain semantics

| Chain | Steps | RC table |
|---|---|---|
| `verifypass` | `POST /api/v1/authn` with target's stored password | 200=END, 401=8102, 400=8101, 403=8103, 404=8104, 429=8107, 500=8108, *=8109 |
| `changepass` | `POST /api/v1/users/{OktaUserId}` admin-set with SSWS token, then `POST /api/v1/authn` to verify new pass | success path returns END; 8110 if verify fails |
| `reconcilepass` | `GET /api/v1/users/{OktaUserId}` preflight, then admin-set, then verify | same RC pattern |

### V7 local testing

V7 uses `CANetPluginInvoker.exe` (NOT TPC.exe) since it's a `.NET DLL`-based
plugin. Local test pattern is identical to V5:

```powershell
cd "C:\Program Files (x86)\CyberArk\PasswordManager"
.\bin\CANetPluginInvoker.exe oktacloud-v7-test.ini verifypass `
    Cyberark.Extensions.Plugin.WSChains.dll True
```

### V6 vs V7 -- when to ship which

Both can coexist as separate platforms in the same vault (different `PolicyID`s).
Recommendation:

- Ship **V6** as primary -- supports both OAuth+JWT and SSWS, modern direction
- Ship **V7** as labeled fallback -- mark `Active=No` in PVWA until needed
- Migrate accounts between them by changing `PolicyID` -- no data loss

## V6 TPC Platform (recommended for OAuth/JWT auth flows)

`OktaCloud-V6-TPC.zip` is the **third-generation** Okta platform, built on
CyberArk's Terminal Plugin Controller (`CyberArk.TPC.exe`) instead of the
REST API plugin framework. Use this when:

- Okta admin operations require OAuth2 with `private_key_jwt` (the
  REST API plugin framework cannot sign JWTs natively)
- You want a single platform that supports **both** SSWS and OAuth/JWT
  auth, switchable via the `OktaAuthMode` property per-account

### Why TPC instead of the REST API plugin

CyberArk's REST API plugin framework only allows `Basic` and `Bearer`
Authorization headers (error 8021 on `SSWS`) and cannot sign JWTs in XML
chains. Okta admin scopes (`okta.users.manage`, etc.) require either an
SSWS token (rejected by REST API plugin) or OAuth2 with `private_key_jwt`
(needs JWT signing). TPC sidesteps both limits by shelling out to a
PowerShell script that does the auth flow and HTTP calls itself.

### V6 file layout

```
OktaCloud-V6-TPC.zip
├── Policy-OktaCloudTPC.ini          # platform definition (DllName blank, ExeName=CyberArk.TPC.exe)
├── Policy-OktaCloudTPC.xml          # account property defs (Username, Address, OktaUserId, OktaAuthMode)
├── OktaCloudTPC.ps1                 # rotation script (verify/change/reconcile)
├── OktaCloudTPCProcess.ini          # TPC state machine + transitions
└── OktaCloudTPCPrompts.ini          # minimal -- conditions live in Process.ini
```

After PVWA import, the three `bin\CustomPlugins\PrivilegeCloud\*` files
auto-deploy to every CPM server's bin folder. `CyberArk.TPC.exe` is
already pre-installed in CPM's bin folder.

### Auth modes

The `OktaAuthMode` account property (Optional, default `oauthjwt` from
the platform `[ExtraInfo]`) selects between two paths:

| Mode | Linked LogonAccount holds | Auth header |
|---|---|---|
| `ssws` | SSWS API token in password field | `SSWS <token>` |
| `oauthjwt` | client_id in username, RSA private key on disk | `Bearer <accessToken>` (script signs JWT, exchanges via `/oauth2/v1/token`) |

For `oauthjwt`, the RSA private key lives at
`bin\CustomPlugins\PrivilegeCloud\okta-cpm-private.json` on the CPM
server (path configurable via the `OktaPrivateKeyPath` ExtraInfo key).
Generate the key + provision the Okta API Services app via:

```powershell
.\scripts\Create-OktaApiServicesApp.ps1 -OktaDomain integrator-XXXX.okta.com
.\scripts\Test-OktaOAuth2Jwt.ps1 -OktaDomain integrator-XXXX.okta.com -ClientId <fromAbove>
```

The `Test-OktaOAuth2Jwt.ps1` script writes the key as JSON; copy it to
the CPM server's `bin\CustomPlugins\PrivilegeCloud\okta-cpm-private.json`.

### V6 chain semantics

| Chain | Steps | Notes |
|---|---|---|
| `verifypass` | `/api/v1/authn` with target's stored password | Public endpoint, no Bearer needed |
| `changepass` | Get auth header → `POST /api/v1/users/{id}` admin-set → verify | Bearer/SSWS auth required |
| `reconcilepass` | Get auth header → `GET /api/v1/users/{id}` (preflight) → admin-set → verify | Same auth path as change |

Return codes:
- `0` (SUCCESS) -- success
- `9000` -- auth failure (couldn't authenticate to Okta)
- `9001` -- update creds failure (admin-set rejected)
- `9002` -- unsupported action

### Local testing (no PVWA round-trip)

Same `CANetPluginInvoker.exe` workflow as V5, but with TPC the test
harness is `CyberArk.TPC.exe -t <test.ini>` (TPC's own self-test mode).
Refer to coworker's IdentityRotationOauth platform for the working
pattern -- TPC is identical regardless of which script it spawns.

## Platform ZIP Inventory

| File | Format | Status | Notes |
|---|---|---|---|
| `OktaCloud-V6-TPC.zip` | 5-file TPC bundle | **Recommended (primary)** | TPC + PowerShell. Supports both SSWS and OAuth+private_key_jwt via `OktaAuthMode` switch. |
| `OktaCloud-V7-WSChains.zip` | 3-file WSChains plugin | **Recommended (failsafe)** | Pure XML, SSWS-only. Mirrors official Marketplace `OktaClientCredentialsPlugin` pattern. Use when V6 isn't viable (no OAuth, PowerShell blocked, audit prefers declarative XML). |
| `OktaCloud-V5-CyberArkNaming.zip` | 3-file REST API plugin | Archived | REST API plugin framework path; blocked by 8021 if SSWS used; superseded by V6 (modern auth) and V7 (SSWS failsafe). |
| `OktaCloud-OfficialFormat.zip` | 3-file, flat INI, [ExtraInfo] only | Legacy | Matches CyberArk v21.0.6 sample exactly |
| `OktaCloud-ShopizerFormat.zip` | 3-file, flat INI, extra sections | Backup | Adds [ADExtraInfo], [ChangeTask] from Shopizer |
| `OktaCloud-PrivilegeCloud.zip` | 2-file, WSChains format | Legacy | For WSChains environments (SailPoint-style) |
| `Plugin.RestAPIFramework-v21.0.6.39.zip` | Official CyberArk framework | Import first | Installs DLLs + creates SampleRestAPIPlatform base |

## INI File Inventory

| File | Format | Use |
|---|---|---|
| `OktaCloud-OfficialFormat.ini` | Flat, [ExtraInfo] only | **Production import** |
| `OktaCloud-Shopizer-Format.ini` | Flat, [ADExtraInfo]+[ChangeTask]+[ExtraInfo] | Backup |
| `OktaCloud.ini` | Flat, WSChains format | WSChains environments |
| `Policy-OktaCloud.ini` | Sectioned ([Main], etc.) | Reference / self-hosted PAS |
| `oktacloud-test.ini` | CANetPluginInvoker test format | CPM server testing |

## Troubleshooting

### Platform Import Fails: "XML structure is invalid"

| Cause | Fix |
|---|---|
| Sectioned INI (`[Main]`, `[AutomaticPasswordManagement]`) | Use flat INI format |
| Missing `DllName`/`ExeName`/`XMLFile` keys | Add all three (see sample above) |
| Files in subfolder inside ZIP | Ensure files are at ZIP root |
| `PlatformBaseID` references non-existent base | Import the framework ZIP first; do NOT delete `SampleRestAPIPlatform` (inheritance parent). Pre-checked by `Test-CyberArkBasePlatform` in `Invoke-OktaHLAVaultSetup.ps1`. |
| UTF-8 BOM on XML files | CyberArk's own samples have BOM -- usually OK |
| Missing `[ExtraInfo]` section | Required -- contains ConfigurationFilePath |
| Missing `FrameworkName`/`FrameworkId`/`FrameworkVersion` | Add to [ExtraInfo] |

### CANetPluginInvoker Returns Non-Zero RC

| RC | Meaning | Check |
|---|---|---|
| 2001 | Invalid credentials (verify) | Password in test INI matches Okta |
| 2002 | User not found | OktaUserId is correct |
| 2010 | Password policy violation (change) | Password length/complexity matches Okta policy |
| 2011 | Insufficient permissions | OAuth2 access token has okta.users.manage scope |
| 2012 | User not found (change) | OktaUserId is correct |
| 8xxx | Framework errors | Check DLLs in bin\, Configuration XML syntax |

### OAuth2 Authentication (Privilege Cloud)

- Token endpoint: `https://<tenant>.id.cyberark.cloud/oauth2/platformtoken`
- NOT `/oauth2/token` (Identity-scoped) or `/oauth2/token/oag-token` (invalid)
- Requires a dedicated OAuth2 Confidential Client app in CyberArk Identity
- The built-in `__idaptive_cybr_user_oidc` app does NOT support Client Credentials
- Service account needs explicit safe membership to enumerate safes via API
- `Privilege Cloud Administrators` role grants platform/vault management but NOT safe enumeration

### Safe Ownership (Preventing Orphans)

- Always add `Privilege Cloud Administrators` (or `Vault Admins` for self-hosted) as a
  safe member with full ownership (ManageSafe + ManageSafeMembers) immediately after creation
- The `-SafeAdminGroup` parameter in `Invoke-OktaHLAVaultSetup.ps1` handles this automatically
- If the creating OAuth2 service account is later deleted without an admin group on the safe,
  the safe becomes orphaned and requires CyberArk support to recover

## References

- [CyberArk REST API Plugin Framework docs](https://docs.cyberark.com/pam-self-hosted/latest/en/content/plugins/cpm-plugins-rest-api.htm)
- [Tim Schindler: Creating a CPM Plugin via REST API](https://timschindler.blog/creating-a-cyberark-central-policy-manager-plugin-for-an-api-using-the-new-rest-api-framework)
- [Shopizer reference implementation (GitHub)](https://github.com/aaearon/cyberark-shopizer-admin-extensions)
- [CyberArk REST API Placeholders](https://docs.cyberark.com/pam-self-hosted/latest/en/content/plugins/cpm-plugins-rest-api-placeholders.htm)
- Local reference docs: `docs/cyberark-reference/` (22 pages fetched from docs.cyberark.com)
- Tim Schindler blog PDF: `scripts/CyberArk CPM Plugin via REST API Framework.pdf`
