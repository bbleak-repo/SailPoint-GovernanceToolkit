<#
.SYNOPSIS
    Phase 1 validation: prove the OAuth2 + private_key_jwt flow works end-to-end
    against an Okta API Services app, then exercise an admin scope.

.DESCRIPTION
    Steps performed:
      1. Generate a 2048-bit RSA key pair (saved to cpm-simulator/keys/)
      2. Convert the public key to a JWK and PATCH the Okta app to use
         token_endpoint_auth_method=private_key_jwt with the JWK registered
      3. Construct + sign a JWT (RS256) suitable for client_assertion
      4. Exchange the JWT for an access token at /oauth2/v1/token
      5. Use the access token to call /api/v1/users/me (admin scope test)

    If step 5 returns 200, the OAuth2 path is proven working in your tenant.
    This is the gate before investing in a custom .NET plugin.

.PARAMETER OktaDomain
.PARAMETER OktaToken
    SSWS token for the one-time app config update. Same as Create-Okta...ps1.
.PARAMETER ClientId
    Okta API Services app client_id (also the AppId since they match).
.PARAMETER KeyDir
    Where to write the RSA key pair. Default: cpm-simulator/keys/

.NOTES
    The keys/ directory is gitignored. Keep the private key local. The public
    key gets PATCHed onto the Okta app.
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$OktaDomain,
    [string]$OktaToken = $env:OKTA_API_TOKEN,
    [Parameter(Mandatory)][string]$ClientId,
    [string]$KeyDir = (Join-Path $PSScriptRoot '..\cpm-simulator\keys')
)

$ErrorActionPreference = 'Stop'
if (-not $OktaToken) { throw "OKTA_API_TOKEN not provided." }

$baseUrl = "https://$OktaDomain"
$ssws    = @{ 'Accept'='application/json'; 'Content-Type'='application/json'; 'Authorization'="SSWS $OktaToken" }

function ConvertTo-Base64Url([byte[]]$bytes) {
    [Convert]::ToBase64String($bytes).TrimEnd('=').Replace('+','-').Replace('/','_')
}
function Read-ErrBody($e) {
    if ($e.Exception.Response) {
        $rs = $e.Exception.Response.GetResponseStream()
        return (New-Object System.IO.StreamReader($rs)).ReadToEnd()
    }
    return $e.ToString()
}

# ---- Step 1: Key generation ----
# Note: PowerShell 5.1 / .NET 4.x doesn't have RSA.ExportPkcs8PrivateKey or
# .ExportSubjectPublicKeyInfo (those landed in .NET Core 3.0). For this Phase 1
# validation we use ExportParameters and serialize as JSON. For Phase 2 / a
# real custom plugin, key management should use openssl-generated PEM files
# loaded by the .NET plugin via RSA.ImportFromPem (.NET 5+) or BouncyCastle.
Write-Host "[1/5] Generating RSA key pair..." -ForegroundColor Cyan
if (-not (Test-Path $KeyDir)) { New-Item -ItemType Directory -Path $KeyDir -Force | Out-Null }
$keyId    = "okta-cpm-$(Get-Date -Format yyyyMMddHHmmss)"
$privPath = Join-Path $KeyDir 'okta-cpm-private.json'
$pubPath  = Join-Path $KeyDir 'okta-cpm-public.json'
$rsa = [System.Security.Cryptography.RSA]::Create(2048)
$privParams = $rsa.ExportParameters($true)
$pubParams  = $rsa.ExportParameters($false)
function To-B64([byte[]]$b) { if ($null -eq $b) { return $null } else { return [Convert]::ToBase64String($b) } }
$privDump = [PSCustomObject]@{
    kid      = $keyId
    Modulus  = (To-B64 $privParams.Modulus)
    Exponent = (To-B64 $privParams.Exponent)
    D        = (To-B64 $privParams.D)
    P        = (To-B64 $privParams.P)
    Q        = (To-B64 $privParams.Q)
    DP       = (To-B64 $privParams.DP)
    DQ       = (To-B64 $privParams.DQ)
    InverseQ = (To-B64 $privParams.InverseQ)
}
$privDump | ConvertTo-Json | Out-File -Encoding utf8 -FilePath $privPath -Force
[PSCustomObject]@{ kid = $keyId; Modulus = (To-B64 $pubParams.Modulus); Exponent = (To-B64 $pubParams.Exponent) } |
    ConvertTo-Json | Out-File -Encoding utf8 -FilePath $pubPath -Force
$jwk = [PSCustomObject]@{
    kty = 'RSA'
    e   = (ConvertTo-Base64Url $pubParams.Exponent)
    n   = (ConvertTo-Base64Url $pubParams.Modulus)
    kid = $keyId
    use = 'sig'
    alg = 'RS256'
}
Write-Host "      Wrote: $privPath (private key params, gitignored)" -ForegroundColor Green
Write-Host "      Wrote: $pubPath  (public key params)"               -ForegroundColor Green
Write-Host "      kid:   $keyId"                                      -ForegroundColor Green

# ---- Step 2: Update Okta app to private_key_jwt + register JWK ----
Write-Host "[2/5] Reconfiguring Okta app $ClientId for private_key_jwt..." -ForegroundColor Cyan
try {
    $existing = Invoke-RestMethod -Uri "$baseUrl/api/v1/apps/$ClientId" -Headers $ssws
}
catch {
    throw "Could not GET app $ClientId : $(Read-ErrBody $_)"
}
# Deep-clone the existing app object via JSON round-trip, then mutate just the
# two fields we care about. Keeps every other field byte-for-byte identical so
# Okta sees an effective no-op everywhere except token_endpoint_auth_method
# and settings.oauthClient.jwks.
$updateBody = $existing | ConvertTo-Json -Depth 20 | ConvertFrom-Json
$updateBody.credentials.oauthClient.token_endpoint_auth_method = 'private_key_jwt'
if ($null -eq $updateBody.settings.oauthClient.jwks) {
    $updateBody.settings.oauthClient |
        Add-Member -MemberType NoteProperty -Name jwks -Value ([PSCustomObject]@{ keys = @($jwk) })
} else {
    $updateBody.settings.oauthClient.jwks = [PSCustomObject]@{ keys = @($jwk) }
}
# Strip read-only computed fields that Okta returns but doesn't accept on PUT
foreach ($prop in @('id', 'created', 'lastUpdated', 'status', '_links', '_embedded')) {
    if ($updateBody.PSObject.Properties.Name -contains $prop) {
        $updateBody.PSObject.Properties.Remove($prop)
    }
}
try {
    $updateJson = $updateBody | ConvertTo-Json -Depth 10 -Compress
    $updated = Invoke-RestMethod -Uri "$baseUrl/api/v1/apps/$ClientId" -Method PUT -Headers $ssws -Body $updateJson
    Write-Host "      App updated. token_endpoint_auth_method = $($updated.credentials.oauthClient.token_endpoint_auth_method)" -ForegroundColor Green
    Write-Host "      JWKs registered: $($updated.settings.oauthClient.jwks.keys.Count)" -ForegroundColor Green
}
catch {
    throw "Failed to update app: $(Read-ErrBody $_)"
}

# ---- Step 3: Construct + sign JWT ----
Write-Host "[3/5] Signing client_assertion JWT (RS256)..." -ForegroundColor Cyan
$now = [int][DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
$header = @{ alg='RS256'; typ='JWT'; kid=$keyId } | ConvertTo-Json -Compress
$payload = @{
    iss = $ClientId
    sub = $ClientId
    aud = "$baseUrl/oauth2/v1/token"
    iat = $now
    exp = $now + 300
    jti = [guid]::NewGuid().ToString('N')
} | ConvertTo-Json -Compress
$headerB64  = ConvertTo-Base64Url ([Text.Encoding]::UTF8.GetBytes($header))
$payloadB64 = ConvertTo-Base64Url ([Text.Encoding]::UTF8.GetBytes($payload))
$signInput  = "$headerB64.$payloadB64"
$sigBytes   = $rsa.SignData([Text.Encoding]::UTF8.GetBytes($signInput), [System.Security.Cryptography.HashAlgorithmName]::SHA256, [System.Security.Cryptography.RSASignaturePadding]::Pkcs1)
$sigB64     = ConvertTo-Base64Url $sigBytes
$jwt        = "$signInput.$sigB64"
Write-Host "      JWT length: $($jwt.Length) chars" -ForegroundColor Green

# ---- Step 4: Exchange JWT for access token ----
Write-Host "[4/5] Exchanging JWT for OAuth2 access token..." -ForegroundColor Cyan
$tokenBody = @(
    "grant_type=client_credentials",
    "scope=okta.users.manage okta.users.read",
    "client_assertion_type=urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
    "client_assertion=$jwt"
) -join '&'
try {
    $tokenResp = Invoke-RestMethod -Uri "$baseUrl/oauth2/v1/token" -Method POST `
        -Headers @{ 'Content-Type' = 'application/x-www-form-urlencoded'; 'Accept' = 'application/json' } `
        -Body $tokenBody
    $accessToken = $tokenResp.access_token
    Write-Host "      token_type   : $($tokenResp.token_type)" -ForegroundColor Green
    Write-Host "      expires_in   : $($tokenResp.expires_in) s" -ForegroundColor Green
    Write-Host "      scope        : $($tokenResp.scope)" -ForegroundColor Green
    Write-Host "      access_token : $($accessToken.Substring(0,40))... (len=$($accessToken.Length))" -ForegroundColor Green
}
catch {
    throw "Token exchange failed: $(Read-ErrBody $_)"
}

# ---- Step 5: Call admin API with the access token ----
Write-Host "[5/5] Calling admin endpoint with Bearer access token..." -ForegroundColor Cyan
try {
    $bearerHeaders = @{ 'Accept'='application/json'; 'Authorization' = "Bearer $accessToken" }
    $userList = Invoke-RestMethod -Uri "$baseUrl/api/v1/users?limit=1" -Headers $bearerHeaders
    Write-Host "      GET /api/v1/users -> 200 OK ($($userList.Count) result)" -ForegroundColor Green
    if ($userList.Count -gt 0) {
        Write-Host "      Sample user: $($userList[0].profile.login) (id=$($userList[0].id))" -ForegroundColor Gray
    }
}
catch {
    Write-Host "      Admin call FAILED: $(Read-ErrBody $_)" -ForegroundColor Red
    throw "Admin scope call failed - OAuth flow not validated end-to-end."
}

Write-Host ""
Write-Host "===== PHASE 1 PASS =====" -ForegroundColor Green
Write-Host ""
Write-Host "OAuth2 + private_key_jwt validated end-to-end:"
Write-Host "  - RSA keys at $KeyDir"
Write-Host "  - App $ClientId reconfigured for private_key_jwt"
Write-Host "  - Access token obtained and admin call succeeded"
Write-Host ""
Write-Host "Implication: a custom .NET CPM plugin can replicate this flow in C#"
Write-Host "(System.Security.Cryptography for RSA, JwtSecurityTokenHandler or similar"
Write-Host "for JWT signing, HttpClient for the token + admin calls)."
Write-Host ""
