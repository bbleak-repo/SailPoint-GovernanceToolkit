<#
.SYNOPSIS
    Provisions an Okta API Services (OAuth2) application for use with the
    CyberArk CPM Okta platform plugin v3.4+ (REST API Plugin Framework).

.DESCRIPTION
    Creates a Service-type OAuth client in Okta configured for the Client
    Credentials grant, then grants the scopes required for CPM password
    rotation (okta.users.manage and okta.users.read).

    The CyberArk REST API Plugin Framework's Authorization-scheme allowlist
    is hard-coded to Basic and Bearer only. Okta's SSWS scheme is rejected
    with error 8021. This script provisions the OAuth2 app whose access
    tokens are used as Bearer credentials by the OktaCloudConfiguration.xml
    GetAccessToken APICall.

    Idempotent: if an app with the given label already exists, returns its
    metadata without creating a duplicate. The client_secret is only
    available at initial creation -- if you've lost it, delete the existing
    app in Okta admin and re-run.

.PARAMETER OktaDomain
    Okta tenant domain, no protocol. e.g. integrator-5941494.okta.com.

.PARAMETER OktaToken
    SSWS API token with Super Admin or Org Admin privileges. Used ONLY for
    one-time provisioning of the OAuth app -- after this, CPM uses the
    OAuth2 Bearer credentials, not SSWS. Defaults to $env:OKTA_API_TOKEN.

.PARAMETER AppLabel
    Display label for the new app. Default: CyberArk-CPM-OktaPlatform.

.PARAMETER Scopes
    OAuth scopes to grant. Default covers password rotation and user lookup.

.PARAMETER WhatIf
    Plan-only mode. Verifies the token, checks for existing app, prints what
    would be created, but makes no changes.

.EXAMPLE
    .\Create-OktaApiServicesApp.ps1 -OktaDomain integrator-5941494.okta.com

    Uses $env:OKTA_API_TOKEN. Creates app, grants default scopes, prints
    client_id and client_secret.

.EXAMPLE
    .\Create-OktaApiServicesApp.ps1 -OktaDomain example.okta.com `
        -OktaToken (Get-Content cpm-simulator/.env |
            Select-String '^OKTA_API_TOKEN=(.+)$' |
            ForEach-Object { $_.Matches[0].Groups[1].Value })

    Loads token from a .env file.

.OUTPUTS
    PSCustomObject with AppId, AppLabel, ClientId, ClientSecret, Scopes,
    OktaDomain. ClientSecret is $null when the app already existed.

.NOTES
    The client_secret is shown ONCE on creation -- store immediately in the
    CyberArk vault as the linked LogonAccount's password field. Use the
    client_id as the linked LogonAccount's username field.
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory)]
    [string]$OktaDomain,

    [string]$OktaToken = $env:OKTA_API_TOKEN,

    [string]$AppLabel = 'CyberArk-CPM-OktaPlatform',

    [string[]]$Scopes = @('okta.users.manage', 'okta.users.read')
)

$ErrorActionPreference = 'Stop'

if (-not $OktaToken) {
    throw "OktaToken not provided and `$env:OKTA_API_TOKEN is empty. Set the env var or pass -OktaToken explicitly."
}

if ($OktaDomain -match '^https?://') {
    throw "OktaDomain must NOT include protocol. Use e.g. 'integrator-5941494.okta.com'."
}

$baseUrl = "https://$OktaDomain"
$headers = @{
    'Accept'        = 'application/json'
    'Content-Type'  = 'application/json'
    'Authorization' = "SSWS $OktaToken"
}

function Invoke-OktaApi {
    param(
        [Parameter(Mandatory)][string]$Path,
        [string]$Method = 'GET',
        $Body = $null
    )
    $params = @{
        Uri         = "$baseUrl$Path"
        Method      = $Method
        Headers     = $headers
        ErrorAction = 'Stop'
    }
    if ($Body) {
        $params.Body = ($Body | ConvertTo-Json -Depth 10 -Compress)
    }
    return Invoke-RestMethod @params
}

# Step 1: Sanity-check the SSWS token
Write-Host "[1/4] Verifying SSWS token against $baseUrl..." -ForegroundColor Cyan
try {
    $whoami = Invoke-OktaApi -Path '/api/v1/users/me'
    Write-Host "      Authenticated as: $($whoami.profile.login)" -ForegroundColor Green
}
catch {
    throw "SSWS token authentication failed: $($_.Exception.Message)"
}

# Step 2: Check for an existing app with this label (idempotency)
Write-Host "[2/4] Checking for existing app labeled '$AppLabel'..." -ForegroundColor Cyan
$searchResults = Invoke-OktaApi -Path "/api/v1/apps?q=$([uri]::EscapeDataString($AppLabel))&limit=20"
$existing = $searchResults | Where-Object { $_.label -eq $AppLabel } | Select-Object -First 1
if ($existing) {
    Write-Host "      App already exists. id=$($existing.id) status=$($existing.status)" -ForegroundColor Yellow
    Write-Host "      client_id: $($existing.credentials.oauthClient.client_id)" -ForegroundColor Yellow
    Write-Host "      (client_secret cannot be retrieved after creation; delete and re-run if rotation is needed)" -ForegroundColor Yellow
    return [PSCustomObject]@{
        AppId        = $existing.id
        AppLabel     = $AppLabel
        ClientId     = $existing.credentials.oauthClient.client_id
        ClientSecret = $null
        Scopes       = $Scopes
        OktaDomain   = $OktaDomain
        AlreadyExisted = $true
    }
}

if (-not $PSCmdlet.ShouldProcess($baseUrl, "Create OAuth API Services app '$AppLabel'")) {
    Write-Host "      [WhatIf] Would create app and grant scopes: $($Scopes -join ', ')" -ForegroundColor Yellow
    return
}

# Step 3: Create the OAuth Service app
Write-Host "[3/4] Creating Service-type OAuth app..." -ForegroundColor Cyan
$appBody = @{
    name        = 'oidc_client'
    label       = $AppLabel
    signOnMode  = 'OPENID_CONNECT'
    credentials = @{
        oauthClient = @{
            token_endpoint_auth_method = 'client_secret_basic'
        }
    }
    settings    = @{
        oauthClient = @{
            application_type = 'service'
            grant_types      = @('client_credentials')
            redirect_uris    = @()
            response_types   = @()
        }
    }
}
$app = Invoke-OktaApi -Path '/api/v1/apps' -Method POST -Body $appBody
$clientId     = $app.credentials.oauthClient.client_id
$clientSecret = $app.credentials.oauthClient.client_secret
Write-Host "      Created. id=$($app.id) client_id=$clientId" -ForegroundColor Green

# Step 4: Grant scopes
Write-Host "[4/4] Granting scopes..." -ForegroundColor Cyan
foreach ($scope in $Scopes) {
    Write-Host "      Granting: $scope" -ForegroundColor Cyan
    $grantBody = @{
        scopeId = $scope
        issuer  = $baseUrl
    }
    try {
        $grant = Invoke-OktaApi -Path "/api/v1/apps/$($app.id)/grants" -Method POST -Body $grantBody
        Write-Host "        OK (grant id $($grant.id))" -ForegroundColor Green
    }
    catch {
        Write-Host "        FAILED: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host "        App was created but scopes incomplete. Either grant manually in Okta admin," -ForegroundColor Yellow
        Write-Host "        or delete app id $($app.id) and re-run." -ForegroundColor Yellow
        throw
    }
}

# Summary -- print credentials clearly so they can be captured
Write-Host ""
Write-Host "===== SUCCESS =====" -ForegroundColor Green
Write-Host ""
Write-Host "OAuth2 API Services app provisioned. Capture these NOW; the secret will" -ForegroundColor White
Write-Host "not be retrievable from Okta admin or this API after this run." -ForegroundColor White
Write-Host ""
Write-Host "  AppId         : $($app.id)"
Write-Host "  AppLabel      : $AppLabel"
Write-Host "  ClientId      : $clientId"
Write-Host "  ClientSecret  : $clientSecret"
Write-Host "  GrantedScopes : $($Scopes -join ', ')"
Write-Host ""
Write-Host "CyberArk vault wiring (linked LogonAccount, PropertyIndex 1):" -ForegroundColor White
Write-Host "  Username field: $clientId"
Write-Host "  Password field: $clientSecret"
Write-Host ""
Write-Host "Same vault account is also referenced at PropertyIndex 3 (ReconcileAccount)." -ForegroundColor Gray
Write-Host "Once OAuth2 path is verified, the legacy SSWS token can be revoked in" -ForegroundColor Gray
Write-Host "Okta admin > Security > API > Tokens." -ForegroundColor Gray
Write-Host ""

return [PSCustomObject]@{
    AppId          = $app.id
    AppLabel       = $AppLabel
    ClientId       = $clientId
    ClientSecret   = $clientSecret
    Scopes         = $Scopes
    OktaDomain     = $OktaDomain
    AlreadyExisted = $false
}
