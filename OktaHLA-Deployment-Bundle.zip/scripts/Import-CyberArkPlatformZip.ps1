#Requires -Version 5.1
<#
.SYNOPSIS
    Imports a pre-built CyberArk platform OR PSM connection component ZIP
    into PVWA via REST API.

.DESCRIPTION
    Single-purpose deployer for V6 (TPC), V7 (WSChains), any other
    self-contained CyberArk platform package, OR a PSM connection
    component package (PSM-OktaOIE-WebForm-*.zip,
    PSM-OktaOIE-Connector-*.zip).

    Auto-routes based on zip contents:
      - ZIP contains Policy-*.ini  -> POST /api/Platforms/Import
      - ZIP contains package.json (no Policy-*.ini) -> POST /api/ConnectionComponents/Import

    Matches CyberArk's documented patterns (cyberark/epv-api-scripts).

    Companion to (not replacement for) Deploy-OktaCloudPlatform.ps1, which
    handles the V5-specific framework-duplicate-and-customize flow. V6/V7
    don't need that -- they're self-contained zips that import directly.

    Idempotent for platforms: detects already-imported via /api/Platforms/Targets
    and skips by default (use -Force to delete + reimport).
    Connection components: relies on PVWA returning a duplicate-id error;
    -Force tries DELETE /api/ConnectionComponents/{id} first.

    Auto-discovery: if -PlatformZipPath is omitted, looks in scripts/platform/
    for OktaCloud-V6-TPC.zip and/or OktaCloud-V7-WSChains.zip and uses
    -Variant to pick.

.PARAMETER PVWAUrl
    Base URL of the PVWA (e.g., https://tenant.privilegecloud.cyberark.cloud).
    The /PasswordVault suffix is added at request time -- omit it.

.PARAMETER PlatformZipPath
    Path to the platform ZIP. If omitted, auto-discovered via -Variant.

.PARAMETER Variant
    When -PlatformZipPath is omitted, picks which auto-discovered zip to
    import. Default V6.

.PARAMETER TenantUrl
    CyberArk Identity tenant URL (Privilege Cloud OAuth2 only). Optional --
    auto-derived from PVWAUrl pattern when possible.

.PARAMETER AuthMethod
    Authentication method. Default Auto (detects Privilege Cloud vs on-prem).

.PARAMETER ClientId
    OAuth2 Client ID for Privilege Cloud Client Credentials flow.

.PARAMETER ClientSecret
    OAuth2 Client Secret. Accepts both plain string and SecureString.

.PARAMETER PVWAToken
    Pre-obtained Bearer or session token (skips authentication entirely).

.PARAMETER PVWACredential
    PSCredential for CyberArk/LDAP/RADIUS/Windows auth (on-prem).

.PARAMETER Activate
    Activate the platform after import. Default: skip (CyberArk best practice
    is to leave new platforms inactive until configuration is verified).

.PARAMETER Force
    If platform with same PolicyID already exists, deactivate + delete it
    before reimporting. Without -Force, existing platforms cause an early
    skip with a friendly log message.

.EXAMPLE
    .\Import-CyberArkPlatformZip.ps1 `
        -PVWAUrl 'https://tenant.privilegecloud.cyberark.cloud' `
        -PlatformZipPath '.\scripts\platform\OktaCloud-V6-TPC.zip' `
        -ClientId 'svc-app' -ClientSecret $env:CYBERARK_CLIENT_SECRET -Activate

.EXAMPLE
    .\Import-CyberArkPlatformZip.ps1 -PVWAUrl 'https://pvwa.corp.com' `
        -Variant V7 -PVWACredential (Get-Credential) -AuthMethod CyberArk

.EXAMPLE
    # Pre-obtained token from another script
    .\Import-CyberArkPlatformZip.ps1 -PVWAUrl 'https://tenant.privilegecloud.cyberark.cloud' `
        -PVWAToken 'eyJ...' -Variant V6 -Activate -Force

.NOTES
    REST API contract (per CyberArk docs):
      POST /PasswordVault/api/Platforms/Import
      Body:    { "ImportFile": "<base64 of zip>" }
      Returns: { "PlatformID": "<id>" }

      POST /PasswordVault/api/Platforms/Targets/{id}/Activate
      Body:    none
      Returns: 200 OK

      POST /PasswordVault/api/ConnectionComponents/Import
      Body:    { "ImportFile": "<base64 of zip>" }
      Returns: { } or { "ConnectionComponentID": "<id>" }

      DELETE /PasswordVault/api/ConnectionComponents/{id}    (-Force only)
      Returns: 200 OK or 404 (tolerated)

    On error 400 with "ITAPS016E", the platform already exists (handled).
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory)][string]$PVWAUrl,

    [string]$PlatformZipPath,

    [ValidateSet('V5','V6','V7')]
    [string]$Variant = 'V6',

    [string]$TenantUrl,

    [ValidateSet('Auto','OAuth2_ClientCredentials','CyberArk','LDAP','RADIUS','Windows')]
    [string]$AuthMethod = 'Auto',

    [string]$ClientId,
    [object]$ClientSecret,
    [string]$PVWAToken,
    [PSCredential]$PVWACredential,

    [switch]$Activate,
    [switch]$Force
)

$ErrorActionPreference = 'Stop'

#region Logging

function Write-Step {
    param([string]$Message, [string]$Level = 'INFO')
    $colors = @{ INFO='White'; WARN='Yellow'; ERROR='Red'; OK='Green'; SKIP='DarkGray'; STEP='Cyan' }
    $color = if ($colors.ContainsKey($Level)) { $colors[$Level] } else { 'White' }
    $ts = Get-Date -Format 'HH:mm:ss'
    Write-Host "[$ts][$Level] $Message" -ForegroundColor $color
}

#endregion

#region Auto-discovery

function Resolve-PlatformZipPath {
    if ($PlatformZipPath) {
        if (-not (Test-Path -LiteralPath $PlatformZipPath)) {
            throw "PlatformZipPath does not exist: $PlatformZipPath"
        }
        return (Resolve-Path -LiteralPath $PlatformZipPath).Path
    }

    # Auto-discover from scripts/platform/ relative to this script
    $platformDir = Join-Path $PSScriptRoot 'platform'
    $candidates = switch ($Variant) {
        'V5' { @('OktaCloud-V5-CyberArkNaming.zip', 'OktaCloud-OfficialFormat.zip') }
        'V6' { @('OktaCloud-V6-TPC.zip') }
        'V7' { @('OktaCloud-V7-WSChains.zip') }
    }

    foreach ($candidate in $candidates) {
        $path = Join-Path $platformDir $candidate
        if (Test-Path -LiteralPath $path) {
            Write-Step "Auto-discovered $Variant zip: $path" -Level INFO
            return (Resolve-Path -LiteralPath $path).Path
        }
    }

    throw "No $Variant platform zip found. Looked in: $platformDir for: $($candidates -join ', '). Pass -PlatformZipPath explicitly."
}

#endregion

#region PVWA HTTP

function Invoke-PVWARequest {
    param(
        [Parameter(Mandatory)][string]$Path,
        [ValidateSet('GET','POST','PUT','PATCH','DELETE')][string]$Method = 'GET',
        [object]$Body = $null,
        [int]$MaxRetries = 3
    )
    if (-not $Script:PVWASession) { throw "Not connected to PVWA." }
    $url = "$($Script:PVWASession.BaseUrl)/PasswordVault$Path"
    $headers = @{
        'Authorization' = $Script:PVWASession.Token
        'Content-Type'  = 'application/json'
    }
    $attempt = 0
    do {
        $attempt++
        try {
            $params = @{ Uri = $url; Method = $Method; Headers = $headers; UseBasicParsing = $true }
            if ($null -ne $Body) {
                $params['Body'] = ($Body | ConvertTo-Json -Depth 10)
            }
            $resp = Invoke-WebRequest @params
            if ($resp.Content) { return ($resp.Content | ConvertFrom-Json) }
            return $null
        }
        catch {
            $status = $null
            if ($_.Exception.Response) { $status = [int]$_.Exception.Response.StatusCode }
            if ($status -in @(429, 503) -and $attempt -lt $MaxRetries) {
                $wait = [Math]::Min(60, 2 * $attempt)
                Write-Step "$Method $Path => $status. Retry $attempt/$MaxRetries in ${wait}s..." -Level WARN
                Start-Sleep -Seconds $wait
            }
            else {
                $errBody = ''
                try {
                    $stream = $_.Exception.Response.GetResponseStream()
                    $reader = [System.IO.StreamReader]::new($stream)
                    $errBody = $reader.ReadToEnd()
                } catch {}
                throw "PVWA $Method $Path failed (HTTP $status): $errBody`n$($_.Exception.Message)"
            }
        }
    } while ($attempt -lt $MaxRetries)
}

function Connect-PVWA {
    $normalizedUrl = $PVWAUrl.TrimEnd('/')
    if ($normalizedUrl -match '/PasswordVault$') {
        $normalizedUrl = $normalizedUrl -replace '/PasswordVault$', ''
    }
    $Script:PVWABaseUrl = $normalizedUrl
    $isCloud = $Script:PVWABaseUrl -match 'privilegecloud\.cyberark\.cloud'

    if ($PVWAToken) {
        Write-Step "Using pre-obtained PVWA token" -Level INFO
        $tokenType = if ($PVWAToken -match '^ey') { 'Bearer' } else { 'Session' }
        $Script:PVWASession = @{
            BaseUrl = $Script:PVWABaseUrl
            Token   = if ($tokenType -eq 'Bearer') { "Bearer $PVWAToken" } else { $PVWAToken }
        }
        return
    }

    $effectiveAuth = $AuthMethod
    if ($effectiveAuth -eq 'Auto') {
        $effectiveAuth = if (($ClientId -and $ClientSecret) -or $isCloud) { 'OAuth2_ClientCredentials' } else { 'CyberArk' }
    }

    if ($effectiveAuth -eq 'OAuth2_ClientCredentials') {
        if (-not $TenantUrl) {
            # Auto-derive: tenant.privilegecloud.cyberark.cloud -> tenant.id.cyberark.cloud
            if ($Script:PVWABaseUrl -match 'https?://([^.]+)\.privilegecloud\.cyberark\.cloud') {
                $TenantUrl = "https://$($Matches[1]).id.cyberark.cloud"
                Write-Step "Auto-derived Identity tenant URL: $TenantUrl" -Level INFO
            }
            else {
                $TenantUrl = Read-Host 'Identity Tenant URL (e.g., https://abc.id.cyberark.cloud)'
            }
        }
        if (-not $ClientId) { $ClientId = Read-Host 'OAuth2 Client ID' }
        if (-not $ClientSecret) {
            $ss = Read-Host 'OAuth2 Client Secret' -AsSecureString
            $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($ss)
            try { $ClientSecret = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr) }
            finally { [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
        }
        $secretPlain = if ($ClientSecret -is [SecureString]) {
            $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($ClientSecret)
            try { [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr) }
            finally { [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
        } else { $ClientSecret }

        $tokenUrl = "$($TenantUrl.TrimEnd('/'))/oauth2/platformtoken"
        $encodedId = [System.Net.WebUtility]::UrlEncode($ClientId)
        $encodedSecret = [System.Net.WebUtility]::UrlEncode($secretPlain)
        $tokenBody = "grant_type=client_credentials&client_id=$encodedId&client_secret=$encodedSecret"

        Write-Step "Authenticating via OAuth2 Client Credentials at $tokenUrl..." -Level STEP
        $tokenResp = Invoke-RestMethod -Uri $tokenUrl -Method POST `
            -Body $tokenBody -ContentType 'application/x-www-form-urlencoded' -UseBasicParsing
        $Script:PVWASession = @{
            BaseUrl = $Script:PVWABaseUrl
            Token   = "Bearer $($tokenResp.access_token)"
        }
        Write-Step "PVWA authenticated (OAuth2 Client Credentials)" -Level OK
        return
    }

    if (-not $PVWACredential) {
        $PVWACredential = Get-Credential -Message "PVWA credentials ($effectiveAuth)"
    }
    $authPath = switch ($effectiveAuth) {
        'CyberArk' { '/api/Auth/CyberArk/Logon' }
        'LDAP'     { '/api/Auth/LDAP/Logon' }
        'RADIUS'   { '/api/Auth/RADIUS/Logon' }
        'Windows'  { '/api/Auth/Windows/Logon' }
    }
    $body = @{ username = $PVWACredential.UserName; password = $PVWACredential.GetNetworkCredential().Password } | ConvertTo-Json
    Write-Step "Authenticating via $effectiveAuth..." -Level STEP
    $response = Invoke-RestMethod -Uri "$Script:PVWABaseUrl/PasswordVault$authPath" `
        -Method POST -Body $body -ContentType 'application/json' -UseBasicParsing
    $Script:PVWASession = @{ BaseUrl = $Script:PVWABaseUrl; Token = $response }
    Write-Step "PVWA authenticated ($effectiveAuth)" -Level OK
}

function Disconnect-PVWA {
    if (-not $Script:PVWASession) { return }
    try { Invoke-PVWARequest -Path '/api/Auth/Logoff' -Method POST | Out-Null } catch {}
    $Script:PVWASession = $null
}

#endregion

#region Platform operations

function Get-ZipKind {
    <#
        Inspects the zip and returns one of:
          'Platform'             -- has a Policy-*.ini  (CPM platform package)
          'ConnectionComponent'  -- has package.json, NO Policy-*.ini  (PSM connector package)
        Throws if neither is found.
    #>
    param([Parameter(Mandatory)][string]$ZipPath)
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)
    try {
        $hasPolicyIni = ($zip.Entries | Where-Object { $_.Name -match '^Policy-.*\.ini$' } | Select-Object -First 1) -ne $null
        $hasPackageJson = ($zip.Entries | Where-Object { $_.Name -eq 'package.json' } | Select-Object -First 1) -ne $null
        if ($hasPolicyIni)         { return 'Platform' }
        elseif ($hasPackageJson)   { return 'ConnectionComponent' }
        else {
            $names = ($zip.Entries | ForEach-Object { $_.FullName }) -join ', '
            throw "ZIP does not look like a CyberArk platform or connection component package. Expected Policy-*.ini or package.json. Contents: $names"
        }
    } finally { $zip.Dispose() }
}

function Get-PlatformIdFromZip {
    param([Parameter(Mandatory)][string]$ZipPath)
    # Read the Policy-*.ini inside the zip and extract PolicyID=
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)
    try {
        $policyIni = $zip.Entries | Where-Object { $_.Name -match '^Policy-.*\.ini$' } | Select-Object -First 1
        if (-not $policyIni) { return $null }
        $sr = New-Object System.IO.StreamReader($policyIni.Open())
        try {
            while (-not $sr.EndOfStream) {
                $line = $sr.ReadLine()
                if ($line -match '^\s*PolicyID\s*=\s*(\S+)') { return $Matches[1] }
            }
        } finally { $sr.Dispose() }
        return $null
    } finally { $zip.Dispose() }
}

function Get-ConnectionComponentIdFromZip {
    param([Parameter(Mandatory)][string]$ZipPath)
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)
    try {
        $pkg = $zip.Entries | Where-Object { $_.Name -eq 'package.json' } | Select-Object -First 1
        if (-not $pkg) { return $null }
        $sr = New-Object System.IO.StreamReader($pkg.Open())
        try {
            $json = $sr.ReadToEnd() | ConvertFrom-Json
            return $json.ConnectionComponentId
        } finally { $sr.Dispose() }
    } finally { $zip.Dispose() }
}

function Test-CyberArkPlatform {
    param([Parameter(Mandatory)][string]$PlatformId)
    try {
        return Invoke-PVWARequest -Path "/api/Platforms/Targets/$([uri]::EscapeDataString($PlatformId))"
    } catch {
        if ($_ -match 'HTTP 404') { return $null }
        throw
    }
}

function Remove-CyberArkPlatform {
    param([Parameter(Mandatory)][string]$PlatformId)
    Write-Step "Deactivating + deleting existing platform '$PlatformId' (Force)..." -Level WARN
    try { Invoke-PVWARequest -Path "/api/Platforms/Targets/$([uri]::EscapeDataString($PlatformId))/Deactivate" -Method POST | Out-Null } catch {}
    Invoke-PVWARequest -Path "/api/Platforms/Targets/$([uri]::EscapeDataString($PlatformId))" -Method DELETE | Out-Null
    Write-Step "Platform '$PlatformId' removed" -Level OK
}

function Import-PlatformZip {
    param([Parameter(Mandatory)][string]$ZipPath)
    $zipBytes = [System.IO.File]::ReadAllBytes($ZipPath)
    $b64 = [Convert]::ToBase64String($zipBytes)
    Write-Step "Posting $([Math]::Round($zipBytes.Length / 1KB, 1)) KB ZIP to /api/Platforms/Import..." -Level STEP
    if ($PSCmdlet.ShouldProcess($Script:PVWASession.BaseUrl, "POST /api/Platforms/Import")) {
        $resp = Invoke-PVWARequest -Path '/api/Platforms/Import' -Method POST -Body @{ ImportFile = $b64 }
        Write-Step "Platform imported. PlatformID=$($resp.PlatformID)" -Level OK
        return $resp
    }
    return $null
}

function Remove-CyberArkConnectionComponent {
    param([Parameter(Mandatory)][string]$ConnectionComponentId)
    Write-Step "Attempting to remove existing connection component '$ConnectionComponentId' (Force)..." -Level WARN
    try {
        Invoke-PVWARequest -Path "/api/ConnectionComponents/$([uri]::EscapeDataString($ConnectionComponentId))" -Method DELETE | Out-Null
        Write-Step "Connection component '$ConnectionComponentId' removed" -Level OK
    } catch {
        Write-Step "DELETE on connection component returned an error (often 404 / not implemented). Continuing -- import will surface a duplicate-id error if needed. Detail: $($_.Exception.Message)" -Level WARN
    }
}

function Import-ConnectionComponentZip {
    param([Parameter(Mandatory)][string]$ZipPath)
    $zipBytes = [System.IO.File]::ReadAllBytes($ZipPath)
    $b64 = [Convert]::ToBase64String($zipBytes)
    Write-Step "Posting $([Math]::Round($zipBytes.Length / 1KB, 1)) KB ZIP to /api/ConnectionComponents/Import..." -Level STEP
    if ($PSCmdlet.ShouldProcess($Script:PVWASession.BaseUrl, "POST /api/ConnectionComponents/Import")) {
        $resp = Invoke-PVWARequest -Path '/api/ConnectionComponents/Import' -Method POST -Body @{ ImportFile = $b64 }
        $id = $null
        if ($resp) {
            if ($resp.ConnectionComponentID) { $id = $resp.ConnectionComponentID }
            elseif ($resp.ConnectionComponentId) { $id = $resp.ConnectionComponentId }
        }
        if ($id) {
            Write-Step "Connection component imported. ConnectionComponentId=$id" -Level OK
        } else {
            Write-Step "Connection component import returned 200 (no ConnectionComponentId in response body)." -Level OK
        }
        return $resp
    }
    return $null
}

function Enable-CyberArkPlatform {
    param([Parameter(Mandatory)][string]$PlatformId)
    Write-Step "Activating platform '$PlatformId'..." -Level STEP
    if ($PSCmdlet.ShouldProcess($PlatformId, "POST /api/Platforms/Targets/{id}/Activate")) {
        Invoke-PVWARequest -Path "/api/Platforms/Targets/$([uri]::EscapeDataString($PlatformId))/Activate" -Method POST | Out-Null
        $state = Test-CyberArkPlatform -PlatformId $PlatformId
        if ($null -eq $state) { throw "Platform '$PlatformId' not found after Activate. Import may have failed silently." }
        $active = ($state.Active -eq $true) -or ($null -ne $state.Details -and $state.Details.Active -eq $true)
        if (-not $active) { throw "Platform '$PlatformId' exists but is not Active after Activate. State: $($state | ConvertTo-Json -Depth 3 -Compress)" }
        Write-Step "Platform '$PlatformId' activated and verified" -Level OK
    }
}

#endregion

#region Main

function Main {
    Write-Step "===== Import-CyberArkPlatformZip =====" -Level STEP

    $zipPath = Resolve-PlatformZipPath
    Write-Step "Source ZIP: $zipPath" -Level INFO

    $kind = Get-ZipKind -ZipPath $zipPath
    Write-Step "ZIP kind: $kind" -Level INFO

    Connect-PVWA
    try {
        if ($kind -eq 'Platform') {
            $platformId = Get-PlatformIdFromZip -ZipPath $zipPath
            if (-not $platformId) {
                Write-Step "Could not extract PolicyID from ZIP's Policy-*.ini -- existence-check disabled. Will attempt import unconditionally." -Level WARN
            }
            else {
                Write-Step "ZIP declares PolicyID=$platformId" -Level INFO
            }

            # Idempotency check
            if ($platformId) {
                $existing = Test-CyberArkPlatform -PlatformId $platformId
                if ($existing) {
                    if ($Force) {
                        Remove-CyberArkPlatform -PlatformId $platformId
                    }
                    else {
                        Write-Step "Platform '$platformId' already exists (Active=$($existing.Active -or $existing.Details.Active)). Pass -Force to delete + reimport." -Level SKIP
                        return
                    }
                }
            }

            $imported = Import-PlatformZip -ZipPath $zipPath
            if (-not $imported -and -not $WhatIfPreference) {
                throw "Import returned no PlatformID. Check PVWA logs."
            }

            $importedId = if ($imported) { $imported.PlatformID } else { $platformId }

            if ($Activate -and $importedId) {
                Enable-CyberArkPlatform -PlatformId $importedId
            }
            elseif (-not $Activate -and $importedId) {
                Write-Step "Platform '$importedId' imported as INACTIVE. Activate via PVWA UI or rerun with -Activate." -Level INFO
            }
        }
        elseif ($kind -eq 'ConnectionComponent') {
            $ccId = Get-ConnectionComponentIdFromZip -ZipPath $zipPath
            if ($ccId) { Write-Step "ZIP declares ConnectionComponentId=$ccId" -Level INFO }
            else      { Write-Step "Could not extract ConnectionComponentId from package.json." -Level WARN }

            if ($Force -and $ccId) {
                Remove-CyberArkConnectionComponent -ConnectionComponentId $ccId
            }

            try {
                Import-ConnectionComponentZip -ZipPath $zipPath | Out-Null
            }
            catch {
                $msg = $_.Exception.Message
                if ($msg -match 'already exist' -or $msg -match 'duplicate' -or $msg -match 'ITAPS') {
                    Write-Step "Connection component '$ccId' already exists. Pass -Force to delete + reimport." -Level SKIP
                    return
                }
                throw
            }

            if ($Activate) {
                Write-Step "Note: -Activate is not applicable to connection components (PVWA does not gate them by Active flag)." -Level INFO
            }
        }
        else {
            throw "Unrecognized ZIP kind: $kind"
        }

        Write-Step "===== Done =====" -Level OK
    }
    finally {
        Disconnect-PVWA
    }
}

#endregion

Main
